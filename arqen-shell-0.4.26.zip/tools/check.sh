#!/usr/bin/env bash
# Prints what Arqen / Hyprland currently look like, to find out why a gesture or a click fails.
# Run inside your Hyprland session:  ./check.sh
H="$HOME/.config/hypr"
echo "== Hyprland version";            hyprctl version 2>&1 | head -4
echo; echo "== Hyprland config errors (should be empty)"; hyprctl configerrors 2>&1
if [ -f "$H/hyprland.lua" ]; then
echo; echo "== config: hyprland.lua (Lua)"; hyprctl eval 'local _ = 1' 2>&1 | head -2
echo; echo "== is arqen.lua loaded?";                   grep -nE 'require[ (,]*"arqen"' "$H/hyprland.lua" || echo "NO: hyprland.lua does not load arqen.lua (run ./update.sh)"
echo; echo "== gestures / persistent desktops in arqen.lua"; grep -n "gesture\|workspace_rule" "$H/arqen.lua" 2>&1
echo; echo "== any other gesture settings (can clash)";   grep -rn "gesture" "$H"/*.lua 2>/dev/null | grep -v "arqen.lua" || echo "none"
else
echo; echo "== config: hyprland.conf"
echo; echo "== is the overrides file sourced?";           grep -n "arqen-overrides" "$H/hyprland.conf" || echo "NO: hyprland.conf has no 'source' line for arqen-overrides.conf"
echo; echo "== gestures / persistent desktops in the overrides file"; grep -n "gesture\|^workspace" "$H/arqen-overrides.conf" 2>&1
echo; echo "== any other gesture settings (can clash)";   grep -rn "gesture\|workspace_swipe" "$H"/*.conf 2>/dev/null | grep -v "arqen-overrides.conf" || echo "none"
fi
echo; echo "== touchpads";                 hyprctl devices 2>&1 | grep -i -B1 -A3 "touchpad" | head -12 || true
echo; echo "== desktops Hyprland knows";   hyprctl workspaces 2>&1 | grep "workspace ID"
echo; echo "== Arqen IPC (should list target arqen)"; qs -c arqen ipc show 2>&1 | head -12
echo; echo "== try a desktop switch (should jump to desktop 2, then back to 1)"
if [ -f "$H/hyprland.lua" ]; then hyprctl dispatch 'hl.dsp.focus({ workspace = 2 })'; sleep 1; hyprctl dispatch 'hl.dsp.focus({ workspace = 1 })'
else hyprctl dispatch workspace 2; sleep 1; hyprctl dispatch workspace 1; fi
