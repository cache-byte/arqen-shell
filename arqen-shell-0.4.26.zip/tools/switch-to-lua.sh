#!/usr/bin/env bash
# Move Hyprland from hyprland.conf to hyprland.lua (Hyprland 0.55+, e.g. the lionheartp COPR build),
# and take Quickshell from the same lionheartp COPR instead of errornointernet/quickshell.
#
#   1. checks Hyprland is new enough
#   2. backs up ~/.config/hypr
#   3. converts hyprland.conf (and every file it sources) to hyprland.lua with hyprlang2lua,
#      fixing what the converter does not handle (gesture commands, hyprbars, the Arqen overrides)
#   4. renames hyprland.conf to hyprland.conf.disabled  (Hyprland uses hyprland.lua when it exists)
#   5. swaps Quickshell to the lionheartp build and disables the errornointernet/quickshell COPR
#
# Undo with tools/switch-to-conf.sh. Everything is logged to ~/.cache/arqen-switch-to-lua.log.
set -uo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
H="$HOME/.config/hypr"
STAMP="$(date +%Y%m%d-%H%M%S)"
mkdir -p "$HOME/.cache"
LOG="$HOME/.cache/arqen-switch-to-lua.log"
exec > >(tee "$LOG") 2>&1
fromrepo() { dnf repoquery --installed --quiet --qf '%{from_repo}\n' "$1" 2>/dev/null | head -n1; }
die() { echo; echo "!! $*"; echo "   Nothing in ~/.config/hypr was changed. Log: $LOG"; exit 1; }

echo "== 1. Hyprland"
ver="$(rpm -q --qf '%{version}\n' hyprland 2>/dev/null | head -n1)"
[ -z "$ver" ] || [[ "$ver" == *"not installed"* ]] && ver="$(hyprctl version -j 2>/dev/null | python3 -c 'import json,sys; print(json.load(sys.stdin).get("version",""))' 2>/dev/null)"
echo "installed: ${ver:-unknown}  (from $(fromrepo hyprland))"
major="$(echo "$ver" | cut -d. -f1)"; minor="$(echo "$ver" | cut -d. -f2)"
if [ -z "$ver" ] || { [ "${major:-0}" -eq 0 ] && [ "${minor:-0}" -lt 55 ]; }; then
  die "hyprland.lua needs Hyprland 0.55 or newer (found ${ver:-none}). Update Hyprland from the lionheartp COPR first:
     sudo dnf copr enable lionheartp/Hyprland && sudo dnf upgrade --refresh hyprland"
fi

if [ -f "$H/hyprland.lua" ] && [ ! -f "$H/hyprland.conf" ]; then
  echo "Already on hyprland.lua - skipping the conversion."
else
  [ -f "$H/hyprland.conf" ] || die "There is no ~/.config/hypr/hyprland.conf to convert."
  [ "$(uname -m)" = "x86_64" ] || die "The bundled converter (tools/hyprlang2lua) is for x86_64 only; this is $(uname -m)."
  command -v python3 >/dev/null || die "python3 is needed (sudo dnf install python3)."

  echo; echo "== 2. Backup"
  cp -a "$H" "$H.bak-before-lua-$STAMP" || die "could not back up ~/.config/hypr"
  echo "~/.config/hypr  ->  ~/.config/hypr.bak-before-lua-$STAMP"
  # an old hyprland.lua (e.g. from a package) would be replaced
  [ -f "$H/hyprland.lua" ] && mv "$H/hyprland.lua" "$H/hyprland.lua.old-$STAMP"

  echo; echo "== 3. Convert"
  out="$(python3 -I "$HERE/convert-hypr.py" "$H" "$HERE/hyprlang2lua")" || die "conversion failed (above)"
  echo "${out%%@@TODO@@*}"
  todo="$(echo "${out#*@@TODO@@}" | sed '/^$/d')"
  [ -s "$H/hyprland.lua" ] || die "the converter wrote an empty hyprland.lua"

  # syntax check when a Lua compiler is around (Fedora: sudo dnf install lua)
  if command -v luac >/dev/null 2>&1; then
    bad=0
    while IFS= read -r f; do luac -p "$f" || bad=1; done < <(find "$H" -name '*.lua' -newer "$H.bak-before-lua-$STAMP" -not -path '*.bak*')
    if [ "$bad" = 1 ]; then
      rm -f "$H/hyprland.lua"
      die "the converted Lua has syntax errors (above); hyprland.lua was removed again."
    fi
    echo "Lua syntax: OK"
  fi

  echo; echo "== 4. Switch"
  mv "$H/hyprland.conf" "$H/hyprland.conf.disabled"
  echo "hyprland.conf -> hyprland.conf.disabled  (Hyprland now reads hyprland.lua)"
  if [ -n "$todo" ]; then
    echo
    echo "The converter left these for a human look (they are comments, Hyprland still starts):"
    echo "$todo" | sed 's/^/   /'
  fi
fi

echo; echo "== 5. Quickshell from lionheartp"
copr_repo() { dnf repolist --all 2>/dev/null | awk 'tolower($1) ~ /lionheartp/ {print $1; exit}'; }
LH="$(copr_repo)"
if [ -z "$LH" ]; then
  sudo dnf copr enable -y lionheartp/Hyprland || echo "   (could not enable the lionheartp/Hyprland COPR)"
  LH="$(copr_repo)"
fi
if [ -z "$LH" ]; then
  echo "!! lionheartp COPR not found - Quickshell left as it is."
else
  sudo dnf makecache -q --repo="$LH" >/dev/null 2>&1 || true
  names="$(dnf repoquery --quiet --available --repo="$LH" --qf '%{name}\n' 'quickshell*' 2>/dev/null | grep -vE 'debug|devel' | sort -u)"
  pick=""
  for n in quickshell quickshell-git; do echo "$names" | grep -qx "$n" && { pick="$n"; break; }; done
  [ -z "$pick" ] && pick="$(echo "$names" | head -n1)"
  if [ -z "$pick" ]; then
    echo "!! $LH has no Quickshell package - keeping the current one (errornointernet/quickshell stays enabled so it keeps updating)."
  else
    have="$(rpm -qa --qf '%{name}\n' 'quickshell*' | grep -vE 'debug|devel' | head -n1)"
    echo "lionheartp provides: $pick    installed now: ${have:-nothing} $( [ -n "$have" ] && echo "($(rpm -q --qf '%{version}' "$have"), from $(fromrepo "$have"))")"
    sudo dnf copr disable errornointernet/quickshell >/dev/null 2>&1 && echo "Disabled COPR errornointernet/quickshell" || true
    # only lionheartp + Fedora's own repos for this transaction, so the package really comes from lionheartp
    repos=(--repo="$LH" --repo=fedora --repo=updates)
    if [ -z "$have" ]; then sudo dnf install -y "${repos[@]}" "$pick"
    elif [ "$have" != "$pick" ]; then sudo dnf swap -y "${repos[@]}" "$have" "$pick"
    else sudo dnf distro-sync -y "${repos[@]}" "$pick" && sudo dnf reinstall -y "${repos[@]}" "$pick" >/dev/null 2>&1; fi
    from="$(fromrepo "$pick")"
    echo "Quickshell: $(rpm -q --qf '%{version}' "$pick" 2>/dev/null) from ${from:-?}"
    case "$from" in *lionheartp*) ;; *) echo "!! Quickshell is not from lionheartp yet - send $LOG to Claude." ;; esac
  fi
fi

# put the shell's Lua-aware pieces in place (launcher keys, session line, title bars)
echo; echo "== 6. Arqen"
bash "$HERE/update.sh" || echo "!! update.sh failed (above)"

cat <<MSG

Done. Log out and back in (Hyprland only picks hyprland.conf or hyprland.lua when it starts).
After logging in, check for config errors with:   hyprctl configerrors
Arqen Settings now writes ~/.config/hypr/arqen.lua instead of arqen-overrides.conf.
To go back:  tools/switch-to-conf.sh
MSG
