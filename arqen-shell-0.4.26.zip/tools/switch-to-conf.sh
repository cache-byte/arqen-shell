#!/usr/bin/env bash
# Undo tools/switch-to-lua.sh: Hyprland reads hyprland.conf again. hyprland.lua is kept as
# hyprland.lua.disabled, so switching back later is a rename. Quickshell is left as it is.
set -uo pipefail
H="$HOME/.config/hypr"
STAMP="$(date +%Y%m%d-%H%M%S)"
if [ ! -f "$H/hyprland.conf.disabled" ] && [ ! -f "$H/hyprland.conf" ]; then
  echo "!! No hyprland.conf or hyprland.conf.disabled to go back to."
  echo "   Backups made by switch-to-lua.sh:  ls -d ~/.config/hypr.bak-before-lua-*"
  exit 1
fi
if [ -f "$H/hyprland.lua" ]; then
  [ -f "$H/hyprland.lua.disabled" ] && mv "$H/hyprland.lua.disabled" "$H/hyprland.lua.disabled-$STAMP"
  mv "$H/hyprland.lua" "$H/hyprland.lua.disabled"
  echo "hyprland.lua -> hyprland.lua.disabled"
fi
if [ -f "$H/hyprland.conf.disabled" ] && [ ! -f "$H/hyprland.conf" ]; then
  mv "$H/hyprland.conf.disabled" "$H/hyprland.conf"
  echo "hyprland.conf.disabled -> hyprland.conf"
fi
echo
echo "Done. Log out and back in. Arqen notices and writes arqen-overrides.conf again."
echo "(To use Lua again, run tools/switch-to-lua.sh - it converts hyprland.conf afresh.)"
echo "Quickshell was not changed. To take it from errornointernet again:"
echo "   sudo dnf copr enable errornointernet/quickshell && sudo dnf distro-sync --refresh quickshell"
