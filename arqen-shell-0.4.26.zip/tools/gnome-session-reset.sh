#!/bin/sh
# If GNOME sends you back to the login screen after you have used Arqen, run this from a text console
# (Ctrl+Alt+F3, log in there), then log out of the console and try GNOME again.
# It only removes what Arqen leaves behind that a GNOME session can trip over, and shows what to look at next.
CFG="${XDG_CONFIG_HOME:-$HOME/.config}"
echo "== disk space in your home (a full disk makes logins fail) =="
df -h "$HOME" | tail -n 1
echo
echo "== Arqen's general portal file (it also applied to GNOME) =="
f="$CFG/xdg-desktop-portal/portals.conf"
if [ -f "$f" ] && grep -q 'default=hyprland;gtk' "$f"; then mv -f "$f" "$f.arqen-removed" && echo "moved to $f.arqen-removed"; else echo "none"; fi
echo
echo "== leftovers of the Hyprland session in your user services =="
systemctl --user stop arqen-session.target 2>/dev/null && echo "stopped arqen-session.target"
systemctl --user unset-environment WAYLAND_DISPLAY DISPLAY HYPRLAND_INSTANCE_SIGNATURE HYPRLAND_CMD XDG_CURRENT_DESKTOP XDG_SESSION_DESKTOP XDG_SESSION_TYPE 2>/dev/null && echo "cleared the session variables"
echo
echo "== what the last failed login said (send this to Claude if it still fails) =="
journalctl -b --no-pager 2>/dev/null | grep -i -E 'gnome-shell|gnome-session|gdm|mutter|xdg-desktop-portal' | tail -n 40
echo
echo "Next: 'loginctl terminate-user $USER' ends every session of yours (this console too) and the user services start clean;"
echo "then log in to GNOME at the login screen."
