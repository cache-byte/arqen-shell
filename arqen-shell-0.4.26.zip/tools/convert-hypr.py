#!/usr/bin/env python3
"""Convert ~/.config/hypr/hyprland.conf (and the files it sources) to hyprland.lua for Hyprland 0.55+.

Usage: convert-hypr.py HYPR_DIR CONVERTER
       convert-hypr.py --describe FILE.lua...   (only label Arqen's binds, see describe_bind)
Writes hyprland.lua (+ one .lua per sourced file) into HYPR_DIR and an initial arqen.lua.
Does not touch hyprland.conf; the calling script renames it afterwards.
Prints the lines that need a human look (TODO markers) at the end.
"""
import glob
import os
import re
import subprocess
import sys

HOME = os.path.expanduser("~")

GESTURE_EXEC = re.compile(r"^\s*gesture\s*=\s*(\d+)\s*,\s*([A-Za-z]+)\s*,\s*(?:dispatcher\s*,\s*)?exec\s*,\s*(.+?)\s*$")
SOURCE = re.compile(r"^\s*source\s*=\s*(.+?)\s*$")


def lua_str(s):
    return '"' + s.replace("\\", "\\\\").replace('"', '\\"') + '"'


def expand(p, base):
    p = p.strip().strip('"').strip("'")
    p = p.replace("$HOME", HOME)
    p = os.path.expanduser(p)
    if not os.path.isabs(p):
        p = os.path.join(base, p)
    return os.path.normpath(p)


def strip_plugin_blocks(lines, names):
    """Drop `plugin { <name> { ... } }` blocks for plugins Arqen configures itself."""
    out, depth, skipping, skip_depth = [], 0, False, 0
    stack = []
    for line in lines:
        code = line.split("#", 1)[0]
        opens, closes = code.count("{"), code.count("}")
        m = re.match(r"^\s*([A-Za-z0-9_\-:.]+)\s*\{", code)
        if not skipping and m and m.group(1) in names and stack and stack[-1] == "plugin":
            skipping, skip_depth = True, len(stack)
        if m:
            stack.append(m.group(1))
        for _ in range(closes):
            if stack:
                stack.pop()
        if skipping:
            if len(stack) <= skip_depth:
                skipping = False
            continue
        out.append(line)
    # drop a `plugin { }` left empty
    text = re.sub(r"(?m)^\s*plugin\s*\{\s*\}\s*$\n?", "", "\n".join(out) + "\n")
    return text.splitlines()


def preprocess(text, is_overrides=False):
    """Fix what the converter gets wrong / does not know, before converting.
    Returns (hyprlang text, extra Lua lines to append)."""
    lines = text.splitlines()
    lines = strip_plugin_blocks(lines, {"hyprbars"})
    keep, extra = [], []
    for line in lines:
        # gesture = 3, up, dispatcher, exec, cmd  ->  an hl.gesture with a Lua function action
        m = GESTURE_EXEC.match(line)
        if m:
            fingers, direction, cmd = m.groups()
            extra.append("hl.gesture({ fingers = %s, direction = %s, action = function() hl.exec_cmd(%s) end })"
                         % (fingers, lua_str(direction), lua_str(cmd)))
            continue
        # the shell's own hyprlang overrides are replaced by arqen.lua
        sm = SOURCE.match(line)
        if sm and "arqen-overrides" in sm.group(1):
            continue
        # hyprbars rules: arqen.lua adds them once the plugin is loaded
        if "hyprbars" in line and re.match(r"^\s*(windowrule|plugin:hyprbars)", line):
            continue
        keep.append(line)
    return "\n".join(keep) + "\n", extra


def convert_text(text):
    r = subprocess.run([CONV, "-r"], input=text, capture_output=True, text=True)
    if r.returncode not in (0,):
        sys.stderr.write(r.stderr)
    return r.stdout, r.stderr


BIND_EXEC = re.compile(r'^(\s*hl\.bind\(.*hl\.dsp\.exec_cmd\(("(?:[^"\\]|\\.)*")\))(\)|, \{ (.*) \}\))\s*$')


def describe_bind(line):
    """In Lua every bind shows up as dispatcher "__lua" in `hyprctl binds`, so the shell cannot see
    which command a key runs. Give Arqen's own binds their command as description."""
    m = BIND_EXEC.match(line)
    if not m or "ipc call arqen" not in m.group(2) or "description" in line:
        return line
    head, cmd, _, opts = m.groups()
    if opts:
        return "%s, { %s, description = %s })" % (head, opts, cmd)
    return "%s, { description = %s })" % (head, cmd)


todo = []
done = set()


def convert_file(src, dst, extra_tail=""):
    if src in done:
        return
    done.add(src)
    with open(src, encoding="utf-8", errors="replace") as f:
        text, extra = preprocess(f.read())
    out, report = convert_text(text)
    # the converter writes a comment + require("name") for every `source =`; convert those files too
    base = os.path.dirname(src)
    lines = out.splitlines()
    for i, line in enumerate(lines):
        m = re.match(r"^-- Source: (.+?)(?: — | \(glob)", line)
        if not m:
            continue
        raw = m.group(1)
        if "*" in raw or "?" in raw or "[" in raw:
            # hl_source_glob() loads <pattern>.lua at runtime: convert every match next to itself
            for g in glob.glob(expand(raw, base)):
                convert_file(g, re.sub(r"\.conf$", "", g) + ".lua")
            continue
        nxt = lines[i + 1] if i + 1 < len(lines) else ""
        rm = re.match(r'^require\("([^"]+)"\)', nxt)
        path = expand(raw, base)
        if rm and os.path.isfile(path):
            target = os.path.join(HYPR, rm.group(1).replace(".", "/") + ".lua")
            os.makedirs(os.path.dirname(target), exist_ok=True)
            convert_file(path, target)
            # a missing or broken sourced file should not take the whole config down
            lines[i + 1] = 'pcall(require, "%s")' % rm.group(1)
        elif rm:
            lines[i + 1] = '-- (file not found when converting) ' + nxt
    lines = [describe_bind(l) for l in lines]
    body = "\n".join(lines).rstrip() + "\n"
    if extra:
        body += "\n-- gestures that run commands (converted by Arqen)\n" + "\n".join(extra) + "\n"
    body += extra_tail
    with open(dst, "w", encoding="utf-8") as f:
        f.write(body)
    for n, line in enumerate(body.splitlines(), 1):
        if "TODO" in line and not line.startswith("-- Generated by hyprlang2lua"):
            todo.append("%s:%d: %s" % (os.path.relpath(dst, HYPR), n, line.strip()))
    print("  converted %s -> %s" % (os.path.relpath(src, HYPR) if src.startswith(HYPR) else src,
                                   os.path.relpath(dst, HYPR)))


ARQEN_TAIL = '''
-- Arqen shell settings (gaps, blur, gestures, desktops, title bars ...), written by Arqen Settings.
-- Loaded last so they win, like the old arqen-overrides.conf.
do
    local ok, err = pcall(require, "arqen")
    if not ok and not tostring(err):find("module 'arqen' not found", 1, true) then
        error(err)
    end
end
'''

if sys.argv[1] == "--describe":
    # update.sh: add descriptions to Arqen's binds in an existing hyprland.lua
    for path in sys.argv[2:]:
        with open(path, encoding="utf-8") as f:
            old = f.read()
        new = "\n".join(describe_bind(l) for l in old.split("\n"))
        if new != old:
            with open(path, "w", encoding="utf-8") as f:
                f.write(new)
    sys.exit(0)

HYPR = os.path.abspath(sys.argv[1])
CONV = sys.argv[2]
main_conf = os.path.join(HYPR, "hyprland.conf")
main_lua = os.path.join(HYPR, "hyprland.lua")
convert_file(main_conf, main_lua, ARQEN_TAIL)

# a first arqen.lua from the current overrides (the shell rewrites it within a second of starting)
ov = os.path.join(HYPR, "arqen-overrides.conf")
il = os.path.join(HYPR, "arqen.lua")
if os.path.isfile(ov) and not os.path.isfile(il):
    with open(ov, encoding="utf-8", errors="replace") as f:
        text, extra = preprocess(f.read())
    out, _ = convert_text(text)
    out = out.replace("-- Generated by hyprlang2lua. Review TODOs before reloading Hyprland.",
                      "-- Generated by Arqen Settings - edit via the Settings app.")
    with open(il, "w", encoding="utf-8") as f:
        f.write(out.rstrip() + "\n" + ("\n".join(extra) + "\n" if extra else ""))
    print("  converted arqen-overrides.conf -> arqen.lua")

print("@@TODO@@")
for t in todo:
    print(t)
