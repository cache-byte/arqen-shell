#!/usr/bin/env bash
# Arqen shell uninstaller (the program is quickshell/arqen/scripts/uninstall.sh; the same one Settings > System > Uninstall makes).
exec bash "$(cd "$(dirname "$0")" && pwd)/quickshell/arqen/scripts/uninstall.sh" "$@"
