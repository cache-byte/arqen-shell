#!/bin/sh
# Show a command in a terminal and wait for the person to confirm it (Enter runs it, Ctrl+C cancels).
#   run-in-terminal.sh "TITLE" "COMMAND"
# Used for uninstalling apps: nothing is removed until it is confirmed in the terminal.
title="$1"; cmd="$2"
[ -n "$cmd" ] || exit 1
inner="printf '%s\n\n  %s\n\n' \"$title\" \"\$ $cmd\"; printf 'Press Enter to run this, Ctrl+C to cancel. '; read _ && { $cmd; printf '\n[done, press Enter to close] '; read _; }"
exec sh "$(dirname "$0")/term-run.sh" "$inner"
