#!/bin/sh
# Open a folder in a graphical file manager. `xdg-open` alone opens whatever program is set for folders, and on
# some systems that is a terminal file manager (yazi, ranger, lf, nnn, vifm...): a terminal window popped up
# instead of Files. So: the default is used only when it is a normal (non-terminal) app; otherwise the first
# graphical file manager found; xdg-open is the last resort.
# usage: open-folder.sh DIR
dir="${1:?folder}"
mkdir -p "$dir" 2>/dev/null
def="$(xdg-mime query default inode/directory 2>/dev/null)"
term=0
if [ -n "$def" ]; then
  for d in "$HOME/.local/share/applications" /usr/local/share/applications /usr/share/applications \
           "$HOME/.local/share/flatpak/exports/share/applications" /var/lib/flatpak/exports/share/applications; do
    if [ -f "$d/$def" ]; then
      grep -qi '^Terminal=true' "$d/$def" && term=1
      grep -qiE '^Exec=.*(yazi|ranger|nnn|vifm|lf |mc |xplr|joshuto|broot|kitty|alacritty|foot|wezterm|konsole|gnome-terminal|xterm)' "$d/$def" && term=1
      break
    fi
  done
fi
if [ -n "$def" ] && [ "$term" = 0 ]; then exec xdg-open "$dir"; fi
for fm in nautilus dolphin thunar nemo pcmanfm-qt pcmanfm caja; do
  command -v "$fm" >/dev/null 2>&1 && exec "$fm" "$dir"
done
exec xdg-open "$dir"
