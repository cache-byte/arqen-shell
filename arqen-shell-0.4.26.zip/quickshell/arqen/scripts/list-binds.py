#!/usr/bin/env python3
"""Every keyboard shortcut Hyprland has right now, readable, for Settings > Keyboard shortcuts.

Output: JSON list of {keys: "SUPER + SHIFT + Q", action: "Run: kitty", mouse: bool}.
With hyprland.conf the action comes from Hyprland itself. With hyprland.lua every shortcut is a
Lua function, so the action is read from the hl.bind(...) lines in ~/.config/hypr/*.lua instead.
"""
import glob
import json
import os
import re
import subprocess

MODS = [(64, "SUPER"), (4, "CTRL"), (8, "ALT"), (1, "SHIFT")]
ALIAS = {"MOD4": "SUPER", "WIN": "SUPER", "LOGO": "SUPER", "META": "SUPER", "CONTROL": "CTRL", "MOD1": "ALT"}


def norm(keys):
    parts = [p.strip() for p in re.split(r"\s*\+\s*|\s+", keys.strip()) if p.strip()]
    if not parts:
        return ""
    mods = sorted({ALIAS.get(p.upper(), p.upper()) for p in parts[:-1]})
    return "+".join(mods + [parts[-1].lower()])


def pretty(mask, key):
    names = [n for bit, n in MODS if mask & bit]
    return " + ".join(names + [key])


# ---- what the Lua config says each shortcut does ----
def lua_actions():
    hypr = os.path.expanduser("~/.config/hypr")
    out = {}
    files = sorted(glob.glob(os.path.join(hypr, "*.lua")) + glob.glob(os.path.join(hypr, "*", "*.lua")))
    for f in files:
        try:
            text = open(f, encoding="utf-8", errors="replace").read()
        except OSError:
            continue
        vars_ = dict(re.findall(r'^\s*local\s+(\w+)\s*=\s*"((?:[^"\\]|\\.)*)"', text, re.M))
        for m in re.finditer(r"hl\.bind\(", text):
            args, depth, i, cur, s = [], 0, m.end(), "", None
            while i < len(text):
                c = text[i]
                if s:
                    cur += c
                    if c == "\\":
                        cur += text[i + 1]; i += 1
                    elif c == s:
                        s = None
                elif c in "\"'":
                    s = c; cur += c
                elif c in "({[":
                    depth += 1; cur += c
                elif c in ")}]":
                    if depth == 0:
                        args.append(cur.strip()); break
                    depth -= 1; cur += c
                elif c == "," and depth == 0:
                    args.append(cur.strip()); cur = ""
                else:
                    cur += c
                i += 1
            if len(args) < 2:
                continue
            # the key: "SUPER + Q", or mainMod .. " + Q"
            key = ""
            for tok in [t.strip() for t in args[0].split("..")]:
                if tok.startswith('"') and tok.endswith('"'):
                    key += tok[1:-1]
                else:
                    key += vars_.get(tok, tok)
            desc = re.search(r'description\s*=\s*"((?:[^"\\]|\\.)*)"', args[2]) if len(args) > 2 else None
            out[norm(key)] = readable_lua(args[1], vars_, desc.group(1) if desc else "")
    return out


def lua_value(expr, vars_):
    """A Lua string expression: "a" .. var .. "b" -> its text."""
    out = ""
    for tok in [t.strip() for t in re.split(r"\.\.", expr)]:
        if len(tok) >= 2 and tok[0] in "\"'" and tok[-1] == tok[0]:
            out += tok[1:-1]
        else:
            out += vars_.get(tok, tok)
    return out


def friendly_run(cmd):
    """Arqen's own commands read as what they do."""
    m = re.match(r"qs -c \S+ ipc call \S+ (.*)$", cmd.strip())
    if m:
        words = m.group(1).split()
        if words[:1] == ["key"] and len(words) > 1:
            if words[1] == "capture":
                return "Arqen: Screenshot / record"
            return "Arqen: " + words[1].replace("-", " ") + " key"
        if words[:1] in (["toggle"], ["open"]) and len(words) > 1:
            names = {"launcher": "App launcher", "search": "Search", "quick": "Control centre", "notifs": "Notifications",
                     "clipboard": "Clipboard", "overview": "Desktop view", "capture": "Screenshot / record"}
            return "Arqen: " + names.get(words[1], words[1])
        if words[:1] == ["launch"] and len(words) > 1:
            return "Open " + words[1]
        if words[:1] in (["settings"], ["settingsApp"]):
            return "Arqen: Settings"
        return "Arqen: " + " ".join(words)
    return "Run: " + cmd


def readable_lua(act, vars_, desc):
    m = re.match(r'hl\.dsp\.exec_cmd\((.*)\)$', act, re.S)
    if m:
        return friendly_run(lua_value(m.group(1).strip(), vars_))
    if desc:
        return desc
    a = re.sub(r"^hl\.dsp\.", "", act)
    name = re.sub(r"\(.*$", "", a, flags=re.S)
    inner = re.sub(r"^[^(]*\(|\)$", "", a, flags=re.S).strip()
    friendly = {"window.close": "Close window", "exit": "Leave Hyprland", "window.drag": "Move window (drag)",
                "window.resize": "Resize window", "window.float": "Float or tile window", "window.pseudo": "Pseudo-tile window",
                "window.fullscreen": "Fullscreen / maximise", "window.move": "Move window", "focus": "Focus",
                "workspace.toggle_special": "Show / hide scratchpad", "layout": "Layout"}
    label = friendly.get(name, name.replace(".", " ").replace("_", " ").capitalize())
    detail = re.sub(r'[{}"]', "", inner).replace(" = ", " ").strip()
    return label + ("  ·  " + detail if detail and name not in ("window.drag", "window.resize", "window.close", "exit") else "")


def readable_legacy(d, arg):
    if d == "exec":
        return friendly_run(arg)
    return (d + " " + arg).strip()


try:
    raw = subprocess.run(["hyprctl", "binds", "-j"], capture_output=True, text=True, timeout=5).stdout
    binds = json.loads(raw)
except Exception:
    binds = []
lua = lua_actions()
rows, seen = [], set()
for b in binds:
    key = b.get("key") or ("code:%s" % b.get("keycode"))
    keys = pretty(b.get("modmask", 0), key)
    if b.get("submap"):
        keys = "[" + b["submap"] + "] " + keys
    d, arg = b.get("dispatcher", ""), b.get("arg", "")
    if d == "__lua":
        desc = b.get("description") or ""
        action = lua.get(norm(keys)) or (friendly_run(desc) if desc.startswith("qs ") else desc) or "Set in hyprland.lua"
    else:
        action = readable_legacy(d, arg) if d == "exec" else (b.get("description") or readable_legacy(d, arg))
    k = (keys, action)
    if k in seen:
        continue
    seen.add(k)
    rows.append({"keys": keys, "action": action, "mouse": bool(b.get("mouse")) or key.startswith("mouse")})
rows.sort(key=lambda r: (r["mouse"], r["keys"]))
print(json.dumps(rows))
