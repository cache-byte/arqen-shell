#!/bin/sh
# Files on the clipboard, the way file managers share them (Files, Nemo, Thunar, Dolphin...):
#   file-clip.sh set copy|cut PATH...   put these files on the clipboard
#   file-clip.sh get                    print "copy" or "cut", then one file:// link per line
#   file-clip.sh clear                  empty it (after a cut has been pasted)
urlencode() { python3 -I -c 'import sys, urllib.parse; print("file://" + urllib.parse.quote(sys.argv[1]))' "$1"; }
case "$1" in
  set)
    mode="$2"; shift 2
    { printf '%s' "$mode"; for f; do printf '\n%s' "$(urlencode "$f")"; done; } \
      | wl-copy --type x-special/gnome-copied-files ;;
  get)
    types="$(wl-paste --list-types 2>/dev/null)"
    if printf '%s\n' "$types" | grep -qx 'x-special/gnome-copied-files'; then
      wl-paste -n -t x-special/gnome-copied-files
    elif printf '%s\n' "$types" | grep -qx 'text/uri-list'; then
      # KDE marks a cut with application/x-kde-cutselection = 1
      if printf '%s\n' "$types" | grep -qx 'application/x-kde-cutselection' && [ "$(wl-paste -n -t application/x-kde-cutselection 2>/dev/null)" = 1 ]; then echo cut; else echo copy; fi
      wl-paste -n -t text/uri-list | tr -d '\r'
    fi ;;
  clear) wl-copy --clear ;;
esac
