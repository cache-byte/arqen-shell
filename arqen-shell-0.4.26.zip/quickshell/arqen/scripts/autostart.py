#!/usr/bin/env python3
"""Apps that start at login (Settings > Apps > Start at login): the XDG autostart folder, as GNOME and KDE use it.

  autostart.py list                 -> JSON [{file, name, exec, icon, enabled, mine}]
  autostart.py add DESKTOP_ID       -> start that app at login
  autostart.py command NAME CMD     -> start a command at login
  autostart.py set FILE on|off      -> switch one on or off (the file is kept, with Hidden=true when off)
  autostart.py remove FILE          -> stop starting it (only files in your own folder)
"""
import glob
import json
import os
import re
import sys

HOME = os.path.expanduser("~")
CFG = os.environ.get("XDG_CONFIG_HOME") or os.path.join(HOME, ".config")
MINE = os.path.join(CFG, "autostart")
SYS = ["/etc/xdg/autostart"]
APPS = [os.path.join(HOME, ".local/share/applications"), "/usr/share/applications", "/usr/local/share/applications",
        "/var/lib/flatpak/exports/share/applications", os.path.join(HOME, ".local/share/flatpak/exports/share/applications")]


def read(path):
    d = {}
    try:
        with open(path, encoding="utf-8", errors="replace") as f:
            on = False
            for line in f:
                line = line.rstrip("\n")
                if line.startswith("["):
                    on = line == "[Desktop Entry]"
                elif on and "=" in line and not line.startswith("#"):
                    k, v = line.split("=", 1)
                    d.setdefault(k, v)
    except OSError:
        pass
    return d


def listing():
    files = {}
    for d in SYS:
        for p in glob.glob(os.path.join(d, "*.desktop")):
            files[os.path.basename(p)] = (p, False)
    for p in glob.glob(os.path.join(MINE, "*.desktop")):
        files[os.path.basename(p)] = (p, True)
    out = []
    for name, (p, mine) in files.items():
        d = read(p)
        if d.get("Type", "Application") != "Application" or d.get("NoDisplay") == "true" and not mine:
            continue
        hidden = d.get("Hidden", "false") == "true" or d.get("X-GNOME-Autostart-enabled", "true") == "false"
        # a system entry the user switched off has a copy in their folder with Hidden=true
        if not mine and os.path.exists(os.path.join(MINE, name)):
            continue
        out.append({"file": name, "name": d.get("Name", name[:-8]), "exec": d.get("Exec", ""), "icon": d.get("Icon", ""),
                    "enabled": not hidden, "mine": mine})
    return sorted(out, key=lambda a: a["name"].lower())


def write(name, d):
    os.makedirs(MINE, exist_ok=True)
    with open(os.path.join(MINE, name), "w", encoding="utf-8") as f:
        f.write("[Desktop Entry]\n")
        for k, v in d.items():
            f.write("%s=%s\n" % (k, v))


def find_app(did):
    did = re.sub(r"\.desktop$", "", did)
    for d in APPS:
        p = os.path.join(d, did + ".desktop")
        if os.path.isfile(p):
            return p
        for q in glob.glob(os.path.join(d, "**", "*.desktop"), recursive=True):
            if os.path.relpath(q, d).replace("/", "-")[:-8] == did:
                return q
    return ""


def main(a):
    if not a or a[0] == "list":
        print(json.dumps(listing()))
    elif a[0] == "add" and len(a) > 1:
        p = find_app(a[1])
        if not p:
            return 1
        d = read(p)
        exe = re.sub(r"\s%[a-zA-Z]", "", d.get("Exec", ""))
        write(os.path.basename(p), {"Type": "Application", "Name": d.get("Name", a[1]), "Exec": exe, "Icon": d.get("Icon", ""),
                                    "X-GNOME-Autostart-enabled": "true"})
    elif a[0] == "command" and len(a) > 2:
        safe = re.sub(r"[^A-Za-z0-9_-]+", "-", a[1]).strip("-").lower() or "command"
        write("arqen-%s.desktop" % safe, {"Type": "Application", "Name": a[1], "Exec": a[2], "X-GNOME-Autostart-enabled": "true"})
    elif a[0] == "set" and len(a) > 2:
        name, on = os.path.basename(a[1]), a[2] == "on"
        mine = os.path.join(MINE, name)
        src = mine if os.path.exists(mine) else os.path.join(SYS[0], name)
        d = read(src)
        d.pop("Hidden", None)
        d["X-GNOME-Autostart-enabled"] = "true" if on else "false"
        if not on:
            d["Hidden"] = "true"
        d.setdefault("Type", "Application")
        write(name, d)
    elif a[0] == "remove" and len(a) > 1:
        p = os.path.join(MINE, os.path.basename(a[1]))
        if os.path.exists(p):
            os.remove(p)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
