#!/usr/bin/env bash
# live-look.sh KIND GAPS_IN GAPS_OUT BORDER ROUNDING   KIND: lua|legacy
# Sets the window gaps, border and corner radius on the running Hyprland, one setting at a time (one
# refused setting cannot stop the others). Prints "ok" or what Hyprland said.
kind="$1"; gi="$2"; go="$3"; bs="$4"; rd="$5"
err=""
one() {   # section key value
  local o
  if [ "$kind" = lua ]; then
    o="$(hyprctl eval "hl.config({ $1 = { $2 = $3 } })" 2>&1)"
  else
    o="$(hyprctl keyword "$1:$2" "$3" 2>&1)"
  fi
  case "$o" in ""|ok*|*"ok"*) ;; *) err="$err $2: $o;" ;; esac
}
one general gaps_in "$gi"
one general gaps_out "$go"
one general border_size "$bs"
one decoration rounding "$rd"
[ -z "$err" ] && echo ok || echo "$err"
