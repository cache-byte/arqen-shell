#!/usr/bin/env python3
"""Ask for a folder with the system's own folder picker; print the chosen path (nothing if cancelled).

  pick-folder.py TITLE START_FOLDER

Tries the desktop portal (the same dialog apps use, follows the system theme), then zenity, then kdialog.
"""
import os
import shutil
import subprocess
import sys
from urllib.parse import unquote, urlparse

title = sys.argv[1] if len(sys.argv) > 1 else "Choose a folder"
start = sys.argv[2] if len(sys.argv) > 2 else os.path.expanduser("~")
while start and not os.path.isdir(start):
    start = os.path.dirname(start)


def portal():
    try:
        from gi.repository import Gio, GLib
    except Exception:
        return None
    bus = Gio.bus_get_sync(Gio.BusType.SESSION, None)
    token = "arqen%d" % os.getpid()
    sender = bus.get_unique_name()[1:].replace(".", "_")
    handle = "/org/freedesktop/portal/desktop/request/%s/%s" % (sender, token)
    loop = GLib.MainLoop()
    result = {"path": None, "done": False}

    def on_response(_c, _s, _p, _i, _sig, params):
        code, res = params.unpack()
        if code == 0 and res.get("uris"):
            u = urlparse(res["uris"][0])
            result["path"] = unquote(u.path)
        result["done"] = True
        loop.quit()

    bus.signal_subscribe("org.freedesktop.portal.Desktop", "org.freedesktop.portal.Request", "Response",
                         handle, None, Gio.DBusSignalFlags.NO_MATCH_RULE, on_response)
    opts = {"handle_token": GLib.Variant("s", token), "directory": GLib.Variant("b", True),
            "modal": GLib.Variant("b", True)}
    if start:
        opts["current_folder"] = GLib.Variant("ay", (start + "\0").encode())
    try:
        bus.call_sync("org.freedesktop.portal.Desktop", "/org/freedesktop/portal/desktop",
                      "org.freedesktop.portal.FileChooser", "OpenFile",
                      GLib.Variant("(ssa{sv})", ("", title, opts)), None, Gio.DBusCallFlags.NONE, 5000, None)
    except Exception:
        return None
    GLib.timeout_add_seconds(3600, loop.quit)
    loop.run()
    return (result["path"] or "") if result["done"] else None


path = portal()
if path is None and shutil.which("zenity"):
    r = subprocess.run(["zenity", "--file-selection", "--directory", "--title", title, "--filename", start.rstrip("/") + "/"],
                       capture_output=True, text=True)
    path = r.stdout.strip() if r.returncode == 0 else ""
if path is None and shutil.which("kdialog"):
    r = subprocess.run(["kdialog", "--title", title, "--getexistingdirectory", start], capture_output=True, text=True)
    path = r.stdout.strip() if r.returncode == 0 else ""
print(path or "")
