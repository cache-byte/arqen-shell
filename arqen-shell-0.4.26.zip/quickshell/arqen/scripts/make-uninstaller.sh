#!/usr/bin/env bash
# Makes the uninstaller in the Downloads folder (Settings > System > Uninstall) and prints where it is.
here="$(cd "$(dirname "$0")" && pwd)"
dl="$(xdg-user-dir DOWNLOAD 2>/dev/null)"; [ -n "$dl" ] && [ -d "$dl" ] || dl="$HOME/Downloads"
out="$dl/arqen-uninstall"
mkdir -p "$out" || { echo "ERR could not make $out"; exit 1; }
cp "$here/uninstall.sh" "$out/uninstall.sh" && cp "$here/deps.txt" "$out/deps.txt" || { echo "ERR could not copy the files into $out"; exit 1; }
chmod +x "$out/uninstall.sh"
cat > "$out/README.txt" <<'TXT'
Uninstalling Arqen shell
------------------------
1. Log out of Hyprland and log in to another desktop (GNOME, KDE ...), or switch to a text console with Ctrl+Alt+F3.
2. Run uninstall.sh from this folder, one of these ways:
   - double-click it and choose "Run" / "Run in terminal" (if your file manager offers it), or
   - open a terminal, type  bash  and a space, drag uninstall.sh into the terminal window, press Enter.
3. Answer its questions (what settings and packages to keep or delete).
You can delete this folder afterwards.
TXT
echo "OK $out"
