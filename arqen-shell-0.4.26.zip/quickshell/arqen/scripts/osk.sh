#!/bin/sh
# The on-screen keyboard's hands: types into the window you were using (wtype, a Wayland virtual
# keyboard), and fetches GIFs.
#   osk.sh text "héllo 👋"          type text
#   osk.sh key BackSpace [MODS]     press a key (MODS: ctrl,alt,shift,logo, comma-separated)
#   osk.sh char c [MODS]            a character with modifiers held (Ctrl+C ...)
#   osk.sh gif-insert URL           copy the GIF and paste it into the window
#   osk.sh gif-copy URL             copy the GIF (paste it yourself)
#   osk.sh gif-download URL NAME    save it in ~/Pictures/GIFs
#   osk.sh link URL                 copy the link
cache="${XDG_CACHE_HOME:-$HOME/.cache}/arqen/gifs"
mods_args() {   # "ctrl,alt" -> -M ctrl -M alt  (and the matching -m at the end)
  pre=""; post=""
  for m in $(echo "$1" | tr ',' ' '); do pre="$pre -M $m"; post="$post -m $m"; done
}
notify() {
  if command -v notify-send >/dev/null 2>&1; then notify-send -a Arqen -i "${3:-input-keyboard}" -t 3000 "$1" "$2"; fi
}
need_wtype() {
  command -v wtype >/dev/null 2>&1 && return 0
  notify "On-screen keyboard" "wtype is not installed: run ./update.sh (or sudo dnf install wtype)"
  exit 1
}
fetch() {   # URL -> path of the downloaded GIF
  mkdir -p "$cache"
  f="$cache/$(printf '%s' "$1" | md5sum | cut -c1-16).gif"
  [ -s "$f" ] || curl -fsSL "$1" -o "$f" || { rm -f "$f"; return 1; }
  echo "$f"
}

case "$1" in
  text) need_wtype; wtype -- "$2" ;;
  paste)   # put text in by pasting it (emoji), then give the clipboard back what it had
    need_wtype
    # what is on the clipboard now: a picture is kept as a file, text as text
    keep="${XDG_RUNTIME_DIR:-/tmp}/arqen-osk-clip"; ktype=""
    for ty in $(wl-paste --list-types 2>/dev/null); do
      case "$ty" in image/png|image/jpeg|image/gif|image/webp) ktype="$ty"; break ;; esac
    done
    if [ -n "$ktype" ]; then wl-paste --type "$ktype" > "$keep" 2>/dev/null; had=2
    else old=$(wl-paste --no-newline --type text 2>/dev/null); had=$?; fi
    printf '%s' "$2" | wl-copy
    sleep 0.08
    # terminals paste with Ctrl+Shift+V
    cls=$(hyprctl -j activewindow 2>/dev/null | sed -n 's/.*"class": *"\([^"]*\)".*/\1/p' | head -n 1)
    case "$(printf '%s' "$cls" | tr 'A-Z' 'a-z')" in
      *kitty*|*alacritty*|*foot*|*wezterm*|*ghostty*|*konsole*|*terminal*|*xterm*|*ptyxis*) wtype -M ctrl -M shift v -m shift -m ctrl ;;
      *) wtype -M ctrl v -m ctrl ;;
    esac
    sleep 0.35
    # keep the clipboard history free of every emoji typed
    if command -v cliphist >/dev/null 2>&1; then
      cliphist list 2>/dev/null | head -n 1 | grep -qF "$2" && cliphist list | head -n 1 | cliphist delete 2>/dev/null
    fi
    if [ $had -eq 2 ]; then wl-copy --type "$ktype" < "$keep"; rm -f "$keep"
    elif [ $had -eq 0 ]; then printf '%s' "$old" | wl-copy
    else wl-copy --clear; fi ;;
  key)  need_wtype; mods_args "$3"; wtype $pre -k "$2" $post ;;
  char) need_wtype; mods_args "$3"; wtype $pre -- "$2" $post ;;
  gif-copy|gif-insert)
    f=$(fetch "$2") || { notify "GIF" "Could not download it"; exit 1; }
    wl-copy --type image/gif < "$f"
    if [ "$1" = gif-insert ]; then
      need_wtype; sleep 0.15; wtype -M ctrl v -m ctrl
    else
      notify "GIF copied" "Paste it where you want it" image-x-generic
    fi ;;
  gif-download)
    f=$(fetch "$2") || { notify "GIF" "Could not download it"; exit 1; }
    mkdir -p ~/Pictures/GIFs
    name=$(printf '%s' "${3:-gif}" | tr -c 'A-Za-z0-9 _-' '_' | cut -c1-60)
    out=~/Pictures/GIFs/"${name:-gif}"_$(date +%H%M%S).gif
    cp "$f" "$out"
    # waits (this runs in the background) for a click on the notification
    act=$(timeout 3600 notify-send -a Arqen -i "$out" -t 6000 -A "default=Show in folder" --wait "GIF saved" "$(basename "$out") in Pictures/GIFs. Click to show it" 2>/dev/null)
    [ "$act" = default ] && { gdbus call --session --dest org.freedesktop.FileManager1 --object-path /org/freedesktop/FileManager1 \
        --method org.freedesktop.FileManager1.ShowItems "['file://$out']" "" >/dev/null 2>&1 || sh "$(dirname "$0")/open-folder.sh" ~/Pictures/GIFs; } ;;
  link) printf '%s' "$2" | wl-copy; notify "Link copied" "$2" ;;
esac
