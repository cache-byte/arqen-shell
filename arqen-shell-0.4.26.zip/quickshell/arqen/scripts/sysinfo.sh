#!/bin/sh
# What this computer is, for Settings > System (like fastfetch or GNOME's About page).
# One "key<TAB>value" per line. Nothing private here: serial numbers, addresses and IDs come from
# sysinfo-private.sh, only after your password.
# "sysinfo.sh live": only what changes (uptime, battery health),
# for the 5-second refresh while the page is open.
d=/sys/class/dmi/id
rd() { [ -r "$1" ] && tr -d '\n' < "$1" 2>/dev/null; }
# placeholders some makers leave in the firmware
clean() { case "$1" in ""|"To Be Filled"*|"To be filled"*|"Default string"|"System Product Name"|"System Version"|"Not Applicable"|"None"|"O.E.M."|"OEM"*|"0"|"1.0"|"Type1"*) ;; *) echo "$1" ;; esac; }
out() { [ -n "$2" ] && printf '%s\t%s\n' "$1" "$2"; }

if [ "${1:-}" != live ]; then
vendor="$(clean "$(rd $d/sys_vendor)")"
product="$(clean "$(rd $d/product_name)")"
version="$(clean "$(rd $d/product_version)")"
family="$(clean "$(rd $d/product_family)")"
# Lenovo keeps the readable model name in product_version (e.g. "ThinkPad T14 Gen 3")
case "$vendor" in LENOVO|Lenovo) [ -n "$version" ] && { model="$version"; version=""; } ;; esac
[ -z "${model:-}" ] && model="$product"
[ -z "$model" ] && model="$family"
out vendor "$vendor"
out model "$model"
out chassis "$(rd $d/chassis_type)"
[ -r /sys/firmware/devicetree/base/model ] && out model "$(tr -d '\0' < /sys/firmware/devicetree/base/model)"

out hostname "$(hostnamectl hostname 2>/dev/null || hostname)"
out pretty "$(hostnamectl --pretty 2>/dev/null)"
. /etc/os-release 2>/dev/null && out os "${PRETTY_NAME:-$NAME}"
out kernel "$(uname -r)"
out arch "$(uname -m)"
out hyprland "$(hyprctl version -j 2>/dev/null | sed -n 's/.*"version": *"\([^"]*\)".*/\1/p' | head -n1)"
out quickshell "$(qs --version 2>/dev/null | head -n1 | grep -oE '[0-9]+\.[0-9]+(\.[0-9]+)?' | head -n1)"

cpu="$(sed -n 's/^model name[[:space:]]*: //p' /proc/cpuinfo | head -n1)"
[ -z "$cpu" ] && cpu="$(lscpu 2>/dev/null | sed -n 's/^Model name: *//p' | head -n1)"
cpu="$(echo "$cpu" | sed -E 's/\((R|TM|tm|r)\)//g; s/ CPU//; s/ with Radeon.*//; s/ +@.*//; s/  +/ /g')"
out cpu "$cpu ($(nproc) threads)"

# graphics: the names lspci knows, without the bus details
if command -v lspci >/dev/null 2>&1; then
  lspci -mm 2>/dev/null | grep -E '"(VGA compatible controller|3D controller|Display controller)"' | while IFS= read -r l; do
    v="$(echo "$l" | awk -F'"' '{print $4}' | sed 's/ Corporation//; s/Advanced Micro Devices, Inc. \[AMD\/ATI\]/AMD/; s/NVIDIA/NVIDIA/')"
    n="$(echo "$l" | awk -F'"' '{print $6}' | sed -E 's/.*\[([^]]+)\].*/\1/')"
    out gpu "$v $n"
  done
fi
# installed memory: what the system sees, rounded up to the size it was sold as (15.4 -> 16 GB)
mt="$(awk '/MemTotal/{print $2}' /proc/meminfo)"
[ -n "$mt" ] && out memory "$(awk -v k="$mt" 'BEGIN{g=k/1048576; split("2 3 4 6 8 12 16 24 32 48 64 96 128 192 256 384 512 768 1024",c," "); for(i=1;i<=19;i++) if (c[i]+0 >= g) { print c[i] " GB"; exit } printf "%.0f GB\n", g}')"
# storage: the whole size of every built-in drive (not one partition), the way drives are sold
out storage "$(lsblk -dbnP -o NAME,SIZE,TYPE,RM,TRAN 2>/dev/null | awk '
  { for (i = 1; i <= NF; i++) { split($i, kv, "="); gsub(/"/, "", kv[2]); f[kv[1]] = kv[2] }
    if (f["TYPE"] == "disk" && f["RM"] == "0" && f["TRAN"] != "usb" && f["NAME"] !~ /^(zram|loop|ram)/ && f["SIZE"] > 0) { s += f["SIZE"]; n++ } }
  END { if (s > 0) { if (s >= 1e12) v = sprintf("%.1f TB", s / 1e12); else v = sprintf("%.0f GB", s / 1e9); sub(/\.0 TB/, " TB", v); print v (n > 1 ? " (" n " drives)" : "") } }')"
out displays "$(hyprctl monitors -j 2>/dev/null | tr -d '\n ' | grep -o '"width":[0-9]*,"height":[0-9]*,"refreshRate":[0-9.]*' | sed -E 's/"width":([0-9]+),"height":([0-9]+),"refreshRate":([0-9]+).*/\1 × \2 at \3 Hz/' | paste -sd ', ')"
fi
out uptime "$(uptime -p 2>/dev/null | sed 's/^up //')"
bat="$(ls -d /sys/class/power_supply/BAT* 2>/dev/null | head -n1)"
if [ -n "$bat" ]; then
  full="$(rd $bat/energy_full)"; design="$(rd $bat/energy_full_design)"
  [ -z "$full" ] && { full="$(rd $bat/charge_full)"; design="$(rd $bat/charge_full_design)"; }
  [ -n "$full" ] && [ -n "$design" ] && [ "$design" -gt 0 ] 2>/dev/null && out battery "$(( full * 100 / design ))% of its original capacity"
fi
exit 0
