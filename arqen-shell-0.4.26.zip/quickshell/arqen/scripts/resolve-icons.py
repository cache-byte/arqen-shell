#!/usr/bin/env python3
"""Find the image file for each app icon name, without Qt's icon theme machinery.

Some Quickshell / Qt builds find no icons at all (no icon theme picked up, or no SVG support),
which leaves the dock, launcher and desktop blank. This looks the names up in the icon folders
directly. Usage: resolve-icons.py THEME -- NAME...   ->  JSON {name: "/path/file"}
PNG files are preferred (they work everywhere); SVG is used when there is no PNG.
"""
import json
import os
import re
import sys

home = os.path.expanduser("~")
xdg = os.environ.get("XDG_DATA_DIRS", "/usr/local/share:/usr/share").split(":")
bases = [os.path.join(home, ".local/share/icons"), os.path.join(home, ".icons")]
bases += [os.path.join(d, "icons") for d in xdg if d]
bases += ["/var/lib/flatpak/exports/share/icons", os.path.join(home, ".local/share/flatpak/exports/share/icons")]
pixmaps = ["/usr/share/pixmaps", "/usr/local/share/pixmaps"]

args = sys.argv[1:]
# --all: any kind of icon (status, devices, actions...), not just app icons (control centre icons)
anykind = "--all" in args
args = [a for a in args if a != "--all"]
cut = args.index("--") if "--" in args else len(args)
chosen = [t for t in args[:cut] if t]
if not chosen:
    # the system's icon theme when none was picked in Settings
    try:
        import subprocess
        t = subprocess.run(["gsettings", "get", "org.gnome.desktop.interface", "icon-theme"], capture_output=True, text=True, timeout=3).stdout.strip().strip("'")
        if t:
            chosen = [t]
    except Exception:
        pass
themes = []
def add_theme(t, depth=0):
    """the theme, then the themes it builds on (Inherits= in its index.theme)"""
    if not t or t in themes or depth > 4:
        return
    themes.append(t)
    for b in [os.path.join(home, ".local/share/icons"), os.path.join(home, ".icons")] + [os.path.join(d, "icons") for d in xdg if d]:
        f = os.path.join(b, t, "index.theme")
        if os.path.isfile(f):
            for line in open(f, errors="replace"):
                if line.startswith("Inherits="):
                    for p in line.split("=", 1)[1].strip().split(","):
                        add_theme(p.strip(), depth + 1)
            break
for t in chosen:
    add_theme(t)
for t in ["Adwaita", "hicolor"]:
    add_theme(t)
names = [n.strip() for n in args[cut + 1:] if n.strip()]
want = set(n for n in names if not n.startswith("/"))
out = {}

# absolute paths in .desktop files
for n in names:
    if n.startswith("/") and os.path.isfile(n):
        out[n] = n


def size_rank(path):
    """Higher is better: a large PNG, then scalable SVG, then smaller PNGs."""
    parts = path.split(os.sep)
    ext = os.path.splitext(path)[1].lower()
    size = 0
    for p in parts:
        if "x" in p and p.split("x")[0].isdigit():
            size = int(p.split("x")[0])
            break
        if p in ("scalable", "symbolic"):
            size = -1
    if ext == ".png":
        if size >= 128:
            return 300 - abs(size - 256) / 10
        return 100 + size
    if ext == ".svg":
        return 250 if "symbolic" not in path else 10
    return 50


best = {}   # name -> (theme_rank, size_rank, path)
for b in bases:
    if not os.path.isdir(b):
        continue
    for theme in os.listdir(b):
        tdir = os.path.join(b, theme)
        if not os.path.isdir(tdir):
            continue
        trank = themes.index(theme) if theme in themes else len(themes) + 1
        for root, _dirs, files in os.walk(tdir):
            # app icons only (and "scalable/apps" etc.)
            if not anykind and "/apps" not in root and not root.endswith("apps"):
                continue
            for f in files:
                stem, ext = os.path.splitext(f)
                if ext.lower() not in (".png", ".svg") or stem not in want:
                    continue
                p = os.path.join(root, f)
                cand = (-trank, size_rank(p), p)
                if stem not in best or cand > best[stem]:
                    best[stem] = cand
for d in pixmaps:
    if os.path.isdir(d):
        for f in os.listdir(d):
            stem, ext = os.path.splitext(f)
            if stem in want and stem not in best and ext.lower() in (".png", ".svg", ".xpm"):
                best[stem] = (-99, 0, os.path.join(d, f))

# Steam games: windows are called steam_app_<id> and Steam's shortcuts use steam_icon_<id>; when no
# icon theme has one, use the picture Steam itself downloaded for the game
steam_roots = [os.path.join(home, p) for p in (
    ".local/share/Steam", ".steam/steam", ".steam/root",
    ".var/app/com.valvesoftware.Steam/.local/share/Steam", ".var/app/com.valvesoftware.Steam/data/Steam")]


def steam_icon(appid):
    for root in steam_roots:
        cache = os.path.join(root, "appcache", "librarycache")
        if not os.path.isdir(cache):
            continue
        d = os.path.join(cache, appid)
        if os.path.isdir(d):
            # newer Steam: a folder per game; the icon is the file named by a 40-letter hash
            for f in sorted(os.listdir(d)):
                stem, ext = os.path.splitext(f)
                if ext.lower() in (".jpg", ".png") and len(stem) == 40 and all(c in "0123456789abcdef" for c in stem.lower()):
                    return os.path.join(d, f)
        for f in (appid + "_icon.jpg", appid + "_icon.png"):
            if os.path.isfile(os.path.join(cache, f)):
                return os.path.join(cache, f)
        # no icon: the game's cover
        for f in (os.path.join(d, "library_600x900.jpg"), os.path.join(cache, appid + "_library_600x900.jpg"),
                  os.path.join(d, "header.jpg"), os.path.join(cache, appid + "_header.jpg")):
            if os.path.isfile(f):
                return f
    return None


for n in want:
    if n in best:
        continue
    m = re.match(r"^steam_(?:app|icon)_(\d+)$", n)
    if m:
        f = steam_icon(m.group(1))
        if f:
            best[n] = (0, 0, f)

for n, (_t, _s, p) in best.items():
    out[n] = p
json.dump(out, sys.stdout)
