#!/bin/sh
# Paste a clipboard-history entry straight into the window you were using (without copying it again by hand).
#   paste.sh ID      ID from cliphist
# The entry is put on the clipboard and Ctrl+V is sent (Ctrl+Shift+V to a terminal).
id="$1"
case "$id" in ''|*[!0-9]*) exit 1 ;; esac
command -v cliphist >/dev/null 2>&1 && command -v wl-copy >/dev/null 2>&1 || exit 1
cliphist decode "$id" | wl-copy || exit 1
if ! command -v wtype >/dev/null 2>&1; then
  command -v notify-send >/dev/null 2>&1 && notify-send -a Arqen -t 3000 "Clipboard" "Copied. wtype is not installed, so paste it yourself (sudo dnf install wtype)"
  exit 0
fi
sleep 0.2      # focus is back on the window by now
cls="$(hyprctl activewindow -j 2>/dev/null | python3 -I -c 'import json,sys
try: print(json.load(sys.stdin).get("class",""))
except Exception: print("")' 2>/dev/null)"
case "$(printf '%s' "$cls" | tr 'A-Z' 'a-z')" in
  kitty|alacritty|foot|footclient|wezterm|org.wezfurlong.wezterm|ghostty|com.mitchellh.ghostty|xterm|org.gnome.terminal|org.gnome.ptyxis|org.gnome.console|konsole|org.kde.konsole|xfce4-terminal|tilix|terminator)
    wtype -M ctrl -M shift v -m shift -m ctrl ;;
  *) wtype -M ctrl v -m ctrl ;;
esac
