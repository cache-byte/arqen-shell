#!/usr/bin/env bash
# Drag any window by its very top: Arqen puts an invisible strip just above every window with
# Hyprland's official "hyprbars" plugin (no title, no buttons, fully transparent). Grab it and the
# window moves; double-click it to maximise.
# This installs the plugin: a ready-made package first, else built with hyprpm for your exact
# Hyprland version. Log: ~/.cache/arqen-window-drag.log.  --quiet: no "press Enter" at the end.
mkdir -p "$HOME/.cache"
LOG="$HOME/.cache/arqen-window-drag.log"
QUIET=0; [ "${1:-}" = "--quiet" ] && QUIET=1
exec > >(tee "$LOG") 2>&1
set -uo pipefail
# hyprland.lua (0.55+) wins over hyprland.conf when both exist
if [ -f "$HOME/.config/hypr/hyprland.lua" ]; then H="$HOME/.config/hypr/hyprland.lua"; LUA=1
else H="$HOME/.config/hypr/hyprland.conf"; LUA=0; fi
# run a command once at login, in the config's own language
add_start() {
  if [ "$LUA" = 1 ]; then printf '\n-- %s\nhl.on("hyprland.start", function()\n    hl.exec_cmd("%s")\nend)\n' "$1" "$2" >> "$H"
  else printf '\n# %s\nexec-once = %s\n' "$1" "$2" >> "$H"; fi
}
loaded() { hyprctl plugin list 2>/dev/null | grep -qi hyprbars; }
finish() {
  echo
  if loaded; then echo "OK: windows can be dragged by their top edge now."
  else echo "!! The hyprbars plugin is not loaded. Send ~/.cache/arqen-window-drag.log to Claude."; fi
  [ "$QUIET" = 1 ] || { echo; read -r -p "Press Enter to close " _ || true; }
  exit 0
}
echo "== $(hyprctl version 2>/dev/null | head -n1)"
loaded && { echo "Already loaded."; finish; }

echo "== 1. Ready-made package (needs sudo)"
for p in hyprland-plugins hyprland-plugin-hyprbars hyprbars; do
  if dnf list --available "$p" >/dev/null 2>&1 || rpm -q "$p" >/dev/null 2>&1; then
    sudo dnf install -y "$p" && break
  fi
done
so="$(find /usr/lib64 /usr/lib /usr/local/lib -iname '*hyprbars*.so' 2>/dev/null | head -n1)"
if [ -n "$so" ]; then
  echo "Found $so"
  hyprctl plugin load "$so"
  if loaded; then
    grep -qF "hyprctl plugin load $so" "$H" 2>/dev/null || add_start "drag windows by their top edge (hyprbars)" "hyprctl plugin load $so"
    finish
  fi
  echo "That package does not match this Hyprland; building instead."
fi

echo "== 2. Build with hyprpm (needs sudo for the build tools)"
sudo dnf install -y hyprland-devel cmake meson ninja-build cpio gcc-c++ git pkgconf-pkg-config
hyprpm update -v || echo "!! hyprpm update failed (above)"
hyprpm list 2>/dev/null | grep -q "hyprland-plugins" || hyprpm add https://github.com/hyprwm/hyprland-plugins || echo "!! hyprpm add failed (above)"
hyprpm enable hyprbars || echo "!! hyprpm enable failed (above)"
hyprpm reload -n
if loaded && [ -f "$H" ] && ! grep -q "hyprpm reload" "$H"; then
  add_start "Hyprland plugins (drag windows by their top edge)" "hyprpm reload -n"
fi
finish
