#!/usr/bin/env bash
# Arqen shell uninstaller: stops the shell and removes its files, then asks which of the packages the shell
# installed (dependencies) to keep or delete.
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
# run from inside the shell's own folder (which is about to be deleted)? continue from a temporary copy
case "$HERE" in
  "${XDG_CONFIG_HOME:-$HOME/.config}"/quickshell/arqen*)
    tmpd="$(mktemp -d)"; cp "$0" "$tmpd/uninstall.sh"; [ -f "$HERE/deps.txt" ] && cp "$HERE/deps.txt" "$tmpd/"
    exec bash "$tmpd/uninstall.sh" "$@" ;;
esac
CONFIG_HOME="${XDG_CONFIG_HOME:-$HOME/.config}"
DATA="${XDG_DATA_HOME:-$HOME/.local/share}"
yn() { local r; read -r -p "$1 [y/N] " r || r=n; [[ "${r:-n}" =~ ^[yY] ]]; }

echo "Arqen shell uninstaller"

# ---- are you in Hyprland right now? ----
# Removing the shell (and Hyprland / Quickshell) from inside the session that uses them leaves you with no desktop.
# The clean way: log out, log in to another desktop (GNOME, KDE ... or a text console, Ctrl+Alt+F3), and run this there.
IN_HYPR=0
if [ -n "${HYPRLAND_INSTANCE_SIGNATURE:-}" ] || echo "${XDG_CURRENT_DESKTOP:-}:${XDG_SESSION_DESKTOP:-}" | grep -qi hyprland || pgrep -x Hyprland >/dev/null 2>&1 || pgrep -x hyprland >/dev/null 2>&1; then
  IN_HYPR=1
  others="$(for d in /usr/share/wayland-sessions /usr/share/xsessions; do ls "$d" 2>/dev/null; done | sed 's/\.desktop$//' | grep -vi hyprland | sort -u | tr '\n' ' ' || true)"
  echo
  echo "!! You are logged in to Hyprland right now."
  echo "   Please log out, log in to another desktop, and run ./uninstall.sh again from there:"
  echo "     1. save your work and log out"
  echo "     2. at the login screen choose another desktop${others:+ (found: $others)} (the gear / session menu)"
  echo "        or switch to a text console with Ctrl+Alt+F3 and log in there"
  echo "     3. run ./uninstall.sh again"
  echo
  if ! yn "Continue anyway? (the shell's files are removed and Hyprland / Quickshell packages are kept while you are in it)"; then
    echo "Nothing was changed."; exit 0
  fi
fi
pkill -f "qs.* -c arqen" 2>/dev/null || true
rm -rf "$CONFIG_HOME/quickshell/arqen" && echo "removed the shell ($CONFIG_HOME/quickshell/arqen)"
rm -f "$DATA/applications/org.arqen.Settings.desktop" "$DATA/icons/hicolor/scalable/apps/org.arqen.Settings.svg"
rm -f "$CONFIG_HOME/hypr/arqen-overrides.conf" "$CONFIG_HOME/hypr/arqen.lua" && echo "removed the Hyprland settings Arqen wrote"
echo "Your hyprland.conf / hyprland.lua still starts the shell: delete the lines that mention arqen,"
echo "or restore the backup next to it (hyprland.*.bak-<date>)."
if yn "Also delete your Arqen settings (~/.config/arqen)?"; then rm -rf "$CONFIG_HOME/arqen"; echo "removed"; fi
# ---- packages (dependencies) ----
# install.sh / update.sh write down the packages they had to install (the ones that were not on the system before).
# Those are offered here, group by group, so nothing you already had or use for other things is removed by mistake.
LOG="$CONFIG_HOME/arqen/packages-installed"
if command -v dnf >/dev/null 2>&1 && command -v rpm >/dev/null 2>&1; then
  mkdir -p /tmp 2>/dev/null
  # groups: "id|what it is for|packages" (the list install.sh uses)
  groups=""
  for f in "$HERE/deps.txt" "$HERE/quickshell/arqen/scripts/deps.txt" "$HERE/deps.txt"; do [ -f "$f" ] && { groups="$(cat "$f")"; break; }; done
  guess=0
  if [ -s "$LOG" ]; then cand="$(sort -u "$LOG")"
  else
    guess=1
    echo
    echo "There is no record of which packages the shell installed (this install is older than that record)."
    echo "Below are the packages the shell uses that are on this system now; some may have been there before the shell,"
    echo "so the default for each group is to keep it."
    cand="$(printf '%s\n' "$groups" | awk -F'|' '{print $3}' | tr ' ' '\n' | grep . | sort -u)"
  fi
  # only what is installed now
  have_now=""; for p in $cand; do
    # while you are in Hyprland its own packages are never offered
    [ "$IN_HYPR" = 1 ] && case "$p" in hyprland|quickshell) continue ;; esac
    rpm -q "$p" >/dev/null 2>&1 && have_now="$have_now $p"
  done
  [ "$IN_HYPR" = 1 ] && echo "(hyprland and quickshell are not offered while you are in Hyprland: log in to another desktop and run this again to remove them)"
  if [ -z "$have_now" ]; then
    echo; echo "No packages installed by the shell are left to remove."
  else
    echo; echo "Packages the shell installed (dependencies):"
    # sort them into groups
    declare -A gpk gwhy; order=""
    left="$have_now "
    while IFS='|' read -r id why pk; do
      [ -n "$id" ] || continue
      mine=""; for p in $pk; do case " $left " in *" $p "*) mine="$mine $p"; left="${left/ $p / }" ;; esac; done
      mine="$(echo $mine)"
      [ -n "$mine" ] && { gpk[$id]="$mine"; gwhy[$id]="$why"; order="$order $id"; }
    done <<EOF
$groups
EOF
    left="$(echo $left)"
    [ -n "$left" ] && { gpk[other]="$left"; gwhy[other]="Other packages the installer added"; order="$order other"; }
    for id in $order; do printf '  %-12s %s\n               %s\n' "$id" "${gwhy[$id]}" "${gpk[$id]}"; done
    echo
    echo "  a) delete all of these"
    echo "  c) choose group by group"
    echo "  k) keep all of them (default)"
    read -r -p "Choose a, c or k [k]: " pc || pc=k
    rm_list=""
    case "$pc" in
      a|A) for id in $order; do rm_list="$rm_list ${gpk[$id]}"; done ;;
      c|C) for id in $order; do
             warn=""; [ "$id" = core ] && warn="  (this is Hyprland and Quickshell: your desktop session)"
             yn "  Delete $id (${gwhy[$id]}): ${gpk[$id]}?$warn" && rm_list="$rm_list ${gpk[$id]}"
           done ;;
    esac
    rm_list="$(echo $rm_list)"
    if [ -n "$rm_list" ]; then
      echo
      echo "dnf will now show everything it would remove (nothing is removed yet):"
      sudo dnf remove --assumeno $rm_list 2>&1 | tail -n 40 || true
      echo
      if yn "Remove these packages now?"; then
        sudo dnf remove -y $rm_list && {
          for p in $rm_list; do rpm -q "$p" >/dev/null 2>&1 || sed -i "/^$p\$/d" "$LOG" 2>/dev/null; done
          echo "removed"
        } || echo "dnf could not remove everything (see above)"
      else
        echo "kept"
      fi
    else
      echo "Keeping all packages."
    fi
  fi
fi
# downloaded by install.sh (not packages): the icon font and the cursor
if [ -f "$DATA/fonts/MaterialSymbolsRounded.ttf" ] && yn "Delete the Material Symbols icon font the installer downloaded (needed only by the shell)?"; then
  rm -f "$DATA/fonts/MaterialSymbolsRounded.ttf"; fc-cache -f 2>/dev/null || true; echo "removed"
fi
if [ -d "$DATA/icons/Bibata-Modern-Classic" ] && yn "Delete the Bibata-Modern-Classic cursor the installer downloaded (other apps may use it)?"; then
  rm -rf "$DATA/icons/Bibata-Modern-Classic"; echo "removed"
fi
# the COPR repositories the installer switched on
if command -v dnf >/dev/null 2>&1; then
  for c in lionheartp/Hyprland errornointernet/quickshell nett00n/hyprland ashbuk/Hyprland-Fedora; do
    if dnf copr list --enabled 2>/dev/null | grep -qi "${c#*/}" && dnf copr list --enabled 2>/dev/null | grep -qi "${c%/*}"; then
      yn "Switch off the COPR repository $c that the installer enabled?" && sudo dnf copr disable -y "$c" >/dev/null 2>&1 && echo "switched off $c"
    fi
  done
fi
# an old Arqen login screen (greetd) from an earlier build: hand the login back to the previous manager
if [ -d /var/lib/arqen-greeter ]; then
  prev="$(cat /var/lib/arqen-greeter/previous-dm 2>/dev/null || echo gdm.service)"; case "$prev" in *.service) ;; *) prev="$prev.service" ;; esac
  if yn "Found an old Arqen login screen. Switch the login manager back to $prev?"; then
    sudo systemctl disable greetd.service 2>/dev/null || true; sudo systemctl enable --force "$prev" >/dev/null
    [ -f /etc/greetd/config.toml.arqen-backup ] && sudo mv -f /etc/greetd/config.toml.arqen-backup /etc/greetd/config.toml || true
    sudo rm -rf /usr/share/arqen-greeter /var/lib/arqen-greeter; echo "login manager restored (takes effect next boot)"
  fi
fi
echo "Done."
