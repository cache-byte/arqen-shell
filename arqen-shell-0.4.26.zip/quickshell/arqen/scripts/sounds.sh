#!/bin/sh
# System sounds (freedesktop sound themes).
#   sounds.sh list                 -> one "id<TAB>name<TAB>description" line per installed sound theme
#   sounds.sh files                -> every sound of every theme: "theme<TAB>sound name<TAB>file"
#   sounds.sh file PATH            -> plays that one file
#   sounds.sh play THEME EVENT...  -> plays the first EVENT the theme (or what it builds on) has
#   sounds.sh apply THEME          -> tells GTK / GNOME apps (event sounds on, that theme; "" = off)
#   sounds.sh doctor THEME         -> what is there and what is missing, one line each (for the Settings page)
dirs() { echo "$HOME/.local/share/sounds"; echo "${XDG_DATA_HOME:-$HOME/.local/share}/sounds"; IFS=:; for d in ${XDG_DATA_DIRS:-/usr/local/share:/usr/share}; do echo "$d/sounds"; done; }

case "$1" in
  list)
    dirs | sort -u | while read -r d; do
      [ -d "$d" ] || continue
      for t in "$d"/*/index.theme; do
        [ -f "$t" ] || continue
        id=$(basename "$(dirname "$t")")
        name=$(sed -n 's/^Name=//p' "$t" | head -n 1)
        desc=$(sed -n 's/^Comment=//p' "$t" | head -n 1)
        hidden=$(sed -n 's/^Hidden=//p' "$t" | head -n 1)
        [ "$hidden" = "true" ] && continue
        printf '%s\t%s\t%s\n' "$id" "${name:-$id}" "$desc"
      done
    done | sort -u -t "$(printf '\t')" -k1,1
    ;;
  files)
    dirs | sort -u | while read -r d; do
      [ -d "$d" ] || continue
      for t in "$d"/*/index.theme; do
        [ -f "$t" ] || continue
        th=$(basename "$(dirname "$t")")
        find "$(dirname "$t")" -type f \( -name '*.oga' -o -name '*.ogg' -o -name '*.wav' \) 2>/dev/null | while read -r f; do
          n=$(basename "$f"); n=${n%.*}
          printf '%s\t%s\t%s\n' "$th" "$n" "$f"
        done
      done
    done | sort -u -t "$(printf '\t')" -k1,2
    ;;
  file)
    [ -f "$2" ] || exit 0
    if command -v pw-play >/dev/null 2>&1; then exec pw-play --media-role=Notification "$2"
    elif command -v paplay >/dev/null 2>&1; then exec paplay "$2"
    elif command -v canberra-gtk-play >/dev/null 2>&1; then exec canberra-gtk-play -f "$2"
    fi
    ;;
  play)
    theme="$2"; shift 2
    [ -z "$theme" ] && exit 0
    find_in() {   # theme event -> file
      for d in $(dirs); do
        for sub in stereo 5.1 ""; do
          for ext in oga ogg wav; do
            f="$d/$1/${sub:+$sub/}$2.$ext"
            [ -f "$f" ] && { echo "$f"; return 0; }
          done
        done
      done
      return 1
    }
    parents() {   # a theme and the ones it builds on, then freedesktop
      echo "$1"
      for d in $(dirs); do
        [ -f "$d/$1/index.theme" ] && sed -n 's/^Inherits=//p' "$d/$1/index.theme" | tr ',' '\n' && break
      done
      echo freedesktop
    }
    for ev in "$@"; do
      for th in $(parents "$theme"); do
        f=$(find_in "$th" "$ev") || continue
        if command -v pw-play >/dev/null 2>&1; then exec pw-play --media-role=Notification "$f"
        elif command -v paplay >/dev/null 2>&1; then exec paplay "$f"
        elif command -v canberra-gtk-play >/dev/null 2>&1; then exec canberra-gtk-play -f "$f"
        fi
        exit 0
      done
    done
    ;;
  doctor)
    th="$2"
    for p in pw-play paplay canberra-gtk-play; do command -v "$p" >/dev/null 2>&1 && { player="$p"; break; }; done
    if [ -n "$player" ]; then echo "ok	Sound player: $player"; else echo "bad	No sound player found. Install pipewire-utils (./update.sh does)"; fi
    n=$(sh "$0" list | wc -l)
    if [ "$n" -gt 0 ]; then echo "ok	$n sound theme(s) installed"; else echo "bad	No sound theme installed. Install sound-theme-freedesktop (./update.sh does)"; fi
    if [ -n "$th" ] && ! sh "$0" list | cut -f1 | grep -qx "$th"; then echo "bad	The chosen theme \"$th\" is not installed: pick another one"; fi
    if command -v pw-cli >/dev/null 2>&1 && ! pw-cli info 0 >/dev/null 2>&1; then echo "bad	PipeWire is not answering: no sound can play"; fi
    if command -v wpctl >/dev/null 2>&1 && wpctl get-volume @DEFAULT_AUDIO_SINK@ 2>/dev/null | grep -q MUTED; then echo "warn	The output is muted"; fi
    ;;
  apply)
    if [ -n "$2" ]; then
      gsettings set org.gnome.desktop.sound theme-name "$2" 2>/dev/null
      gsettings set org.gnome.desktop.sound event-sounds true 2>/dev/null
    else
      gsettings set org.gnome.desktop.sound event-sounds false 2>/dev/null
    fi
    ;;
esac
