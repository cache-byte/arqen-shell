#!/bin/sh
# The exact battery of paired phones, from KDE Connect (Bluetooth only gets a rough 20 % step from most phones).
# Prints one line per reachable phone: NAME<TAB>CHARGE<TAB>CHARGING(0|1). Prints nothing when KDE Connect is not there.
command -v gdbus >/dev/null 2>&1 || exit 0
D=org.kde.kdeconnect
ids="$(gdbus call --session --dest $D --object-path /modules/kdeconnect --method $D.daemon.devices true true 2>/dev/null | grep -o "'[^']*'" | tr -d "'")"
[ -n "$ids" ] || exit 0
prop() { gdbus call --session --dest $D --object-path "$1" --method org.freedesktop.DBus.Properties.Get "$2" "$3" 2>/dev/null; }
for id in $ids; do
  base="/modules/kdeconnect/devices/$id"
  name="$(prop "$base" $D.device name | sed "s/.*<'\(.*\)'>.*/\1/")"
  charge="$(prop "$base/battery" $D.device.battery charge | sed 's/[^0-9-]//g')"
  chg="$(prop "$base/battery" $D.device.battery isCharging | grep -q true && echo 1 || echo 0)"
  [ -n "$name" ] && [ -n "$charge" ] && [ "$charge" -ge 0 ] 2>/dev/null && printf '%s\t%s\t%s\n' "$name" "$charge" "$chg"
done
