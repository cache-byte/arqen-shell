#!/bin/sh
# Your picture: set-face.sh set FILE | clear | sync | apply
#   set    copy FILE to ~/.face and ~/.face.icon (the shell, KDE, SDDM) and give it to the login screen
#   clear  remove the picture everywhere
#   sync   at shell start: give an existing ~/.face to the login screen when it has none yet
#   apply  give the current ~/.face to the login screen again
# The last line printed says how the login screen went:  login: ok  |  login: failed - why
uid=$(id -u)
OBJ="/org/freedesktop/Accounts/User$uid"
last=""
icon_now() { busctl --system get-property org.freedesktop.Accounts "$OBJ" org.freedesktop.Accounts.User IconFile 2>/dev/null | sed -n 's/^s "\(.*\)"$/\1/p'; }
call() {
  last=$(busctl --system call org.freedesktop.Accounts "$OBJ" org.freedesktop.Accounts.User SetIconFile s "$1" 2>&1) && return 0
  last=$(gdbus call --system --dest org.freedesktop.Accounts --object-path "$OBJ" --method org.freedesktop.Accounts.User.SetIconFile "$1" 2>&1) && return 0
  return 1
}
# the service runs as root and cannot always read a home folder: hand it a readable copy first, then the home file
login() {
  src="$1"; [ -s "$src" ] || { echo "login: failed - no picture"; return; }
  small="$src"
  if [ "$(stat -c %s "$src" 2>/dev/null || echo 0)" -gt 900000 ]; then   # the service refuses pictures over 1 MB
    t="${XDG_RUNTIME_DIR:-/tmp}/arqen-face-small.png"
    if command -v magick >/dev/null 2>&1; then magick "$src[0]" -resize 512x512^ -gravity center -extent 512x512 "$t" 2>/dev/null && small="$t"
    elif command -v convert >/dev/null 2>&1; then convert "$src[0]" -resize 512x512^ -gravity center -extent 512x512 "$t" 2>/dev/null && small="$t"; fi
  fi
  pub="/var/tmp/arqen-face-$uid"
  if cp -f -- "$small" "$pub" 2>/dev/null && chmod 644 "$pub" 2>/dev/null && call "$pub"; then rm -f "$pub"; echo "login: ok"; return; fi
  rm -f "$pub"
  if call "$small"; then echo "login: ok"; return; fi
  if ! command -v busctl >/dev/null 2>&1 && ! command -v gdbus >/dev/null 2>&1; then echo "login: failed - busctl / gdbus missing"; return; fi
  echo "login: failed - $(printf '%s' "$last" | head -n1 | cut -c1-120)"
}
sddm_access() {
  # SDDM reads ~/.face.icon as its own user: let it pass through the home folder
  if id -u sddm >/dev/null 2>&1 && command -v setfacl >/dev/null 2>&1; then setfacl -m u:sddm:x "$HOME" 2>/dev/null; fi
}
case "$1" in
  set)
    cp -f -- "$2" "$HOME/.face" || { echo "login: failed - could not copy the picture"; exit 0; }
    cp -f -- "$HOME/.face" "$HOME/.face.icon"
    sddm_access
    login "$HOME/.face"
    ;;
  apply)
    sddm_access
    login "$HOME/.face"
    ;;
  sync)
    [ -s "$HOME/.face" ] || exit 0
    cur=$(icon_now)
    [ -n "$cur" ] && [ -s "$cur" ] && exit 0
    sddm_access
    login "$HOME/.face"
    ;;
  clear)
    rm -f "$HOME/.face" "$HOME/.face.icon"
    call "" && echo "login: ok" || echo "login: failed - $(printf '%s' "$last" | head -n1 | cut -c1-120)"
    ;;
esac
exit 0
