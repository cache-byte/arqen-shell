#!/usr/bin/env python3
"""Default apps for Settings > Default apps.

  default-apps.py list           -> JSON [{id, label, icon, current, options: [desktop ids]}]
  default-apps.py set CAT ID     -> make ID (a .desktop file id) the default for that kind of file
The defaults live in ~/.config/mimeapps.list (written with xdg-mime / xdg-settings), the terminal in
~/.config/xdg-terminals.list, so other apps and desktops see the same choices.
"""
import configparser
import glob
import json
import os
import subprocess
import sys

CATS = [
    ("browser", "Web browser", "public", ["x-scheme-handler/https", "x-scheme-handler/http", "text/html", "application/xhtml+xml"]),
    ("mail", "Email", "mail", ["x-scheme-handler/mailto"]),
    ("files", "Files", "folder", ["inode/directory"]),
    ("terminal", "Terminal", "terminal", []),
    ("text", "Text editor", "edit_note", ["text/plain", "text/markdown", "application/x-shellscript"]),
    ("image", "Pictures", "image", ["image/png", "image/jpeg", "image/webp", "image/gif", "image/bmp", "image/tiff", "image/svg+xml", "image/avif", "image/heif"]),
    ("video", "Videos", "movie", ["video/mp4", "video/x-matroska", "video/webm", "video/quicktime", "video/x-msvideo", "video/mpeg"]),
    ("music", "Music", "music_note", ["audio/mpeg", "audio/flac", "audio/ogg", "audio/x-wav", "audio/mp4", "audio/x-vorbis+ogg", "audio/opus"]),
    ("pdf", "Documents (PDF)", "picture_as_pdf", ["application/pdf"]),
    ("archive", "Archives", "folder_zip", ["application/zip", "application/x-tar", "application/x-7z-compressed", "application/x-rar", "application/gzip"]),
]

home = os.path.expanduser("~")
dirs = [os.path.join(home, ".local/share/applications")]
dirs += [os.path.join(d, "applications") for d in os.environ.get("XDG_DATA_DIRS", "/usr/local/share:/usr/share").split(":") if d]
dirs += ["/var/lib/flatpak/exports/share/applications", os.path.join(home, ".local/share/flatpak/exports/share/applications")]


def entries():
    seen = {}
    for d in dirs:
        for f in glob.glob(os.path.join(d, "**", "*.desktop"), recursive=True):
            did = os.path.relpath(f, d).replace("/", "-")
            if did in seen:
                continue      # the first one found wins (user copies before system ones)
            cp = configparser.RawConfigParser(strict=False, interpolation=None)
            try:
                cp.read(f, encoding="utf-8")
                e = cp["Desktop Entry"]
            except Exception:
                continue
            if e.get("Type", "Application") != "Application" or e.get("Hidden", "false").lower() == "true":
                continue
            seen[did] = {
                "mimes": [m for m in e.get("MimeType", "").split(";") if m],
                "cats": [c for c in e.get("Categories", "").split(";") if c],
                "nodisplay": e.get("NoDisplay", "false").lower() == "true",
            }
    return seen


def query(mime):
    try:
        return subprocess.run(["xdg-mime", "query", "default", mime], capture_output=True, text=True, timeout=5).stdout.strip()
    except Exception:
        return ""


def terminal_now():
    p = os.path.join(home, ".config/xdg-terminals.list")
    try:
        for line in open(p):
            line = line.strip()
            if line and not line.startswith("#"):
                return line.lstrip("+")
    except OSError:
        pass
    return ""


def do_list():
    es = entries()
    out = []
    for cid, label, icon, mimes in CATS:
        if cid == "terminal":
            opts = [i for i, e in es.items() if "TerminalEmulator" in e["cats"] and not e["nodisplay"]]
            cur = terminal_now()
        else:
            opts = [i for i, e in es.items() if any(m in e["mimes"] for m in mimes) and (not e["nodisplay"] or cid == "files")]
            cur = query(mimes[0])
        # a default that is not installed, or an entry that opens nothing (a settings panel left in mimeapps.list
        # as the "email app"), is not shown as the default
        if cur and cid != "terminal":
            if cur not in es or (cur not in opts and not es[cur]["mimes"]):
                cur = ""
            elif cur not in opts:
                opts.insert(0, cur)
        elif cur and cur not in opts and cur in es:
            opts.insert(0, cur)
        out.append({"id": cid, "label": label, "icon": icon, "current": cur, "options": sorted(set(opts))})
    print(json.dumps(out))


def do_set(cid, did):
    for c, _l, _i, mimes in CATS:
        if c != cid:
            continue
        if cid == "terminal":
            p = os.path.join(home, ".config/xdg-terminals.list")
            os.makedirs(os.path.dirname(p), exist_ok=True)
            rest = []
            try:
                rest = [l.rstrip("\n") for l in open(p) if l.strip() and l.strip().lstrip("+") != did]
            except OSError:
                pass
            with open(p, "w") as f:
                f.write("\n".join([did] + rest) + "\n")
            return
        if cid == "browser":
            subprocess.run(["xdg-settings", "set", "default-web-browser", did], capture_output=True)
        subprocess.run(["xdg-mime", "default", did] + mimes, capture_output=True)
        return


if len(sys.argv) >= 2 and sys.argv[1] == "list":
    do_list()
elif len(sys.argv) >= 4 and sys.argv[1] == "set":
    do_set(sys.argv[2], sys.argv[3])
    print("ok")
