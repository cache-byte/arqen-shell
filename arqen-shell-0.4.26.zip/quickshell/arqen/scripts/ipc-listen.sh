#!/bin/sh
# Run by the shell: prints every line written to the pipe (see scripts/ipc).
F="${XDG_RUNTIME_DIR:-/tmp}/arqen-ipc"
rm -f "$F"
mkfifo -m 600 "$F" || exit 1
echo $$ > "$F.pid"
# on the way out, tidy up only if no newer listener has taken over (a shell reload starts the new
# one before the old one is stopped)
bye() { read -r P < "$F.pid" 2>/dev/null; [ "$P" = "$$" ] && rm -f "$F" "$F.pid"; exit 0; }
trap bye TERM INT HUP
while :; do
  # another shell took over (or the pipe is gone): stop instead of spinning
  [ -p "$F" ] || exit 0
  read -r P < "$F.pid" 2>/dev/null; [ "$P" = "$$" ] || exit 0
  while IFS= read -r line; do printf '%s\n' "$line" || exit 0; done < "$F" 2>/dev/null
done
