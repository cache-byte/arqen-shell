#!/bin/sh
# video-thumb.sh FILE   Prints the path of a small picture taken from the video (made once, kept in ~/.cache/arqen/thumbs),
# or nothing when it can't be made (no ffmpeg / ffmpegthumbnailer).
src="$1"; [ -f "$src" ] || exit 0
dir="${XDG_CACHE_HOME:-$HOME/.cache}/arqen/thumbs"; mkdir -p "$dir" || exit 0
key=$(printf '%s' "$src $(stat -c '%Y %s' "$src" 2>/dev/null)" | md5sum | cut -c1-16)
out="$dir/$key.jpg"
if [ -s "$out" ]; then echo "$out"; exit 0; fi
if command -v ffmpeg >/dev/null 2>&1; then
  ffmpeg -v error -y -ss 1 -i "$src" -frames:v 1 -vf scale=640:-2 "$out" 2>/dev/null
  [ -s "$out" ] || ffmpeg -v error -y -i "$src" -frames:v 1 -vf scale=640:-2 "$out" 2>/dev/null
elif command -v ffmpegthumbnailer >/dev/null 2>&1; then
  ffmpegthumbnailer -i "$src" -o "$out" -s 640 -q 8 2>/dev/null
fi
[ -s "$out" ] && echo "$out"
exit 0
