#!/bin/sh
# Watches the Caps Lock and Num Lock lights, for the on-screen display.
# Prints "have caps num" (the lights there are) once, then "caps 1", "num 0"... on every change.
# Exits (3) when there are no such lights; Arqen then relies on the key shortcuts alone.
# (The old loop started `cat` twice and `sleep` every 0.15 seconds, for as long as the shell ran: about 20
# programs a second. This reads the two files itself, four times a second, and starts nothing.)
caps=$(ls -d /sys/class/leds/*::capslock 2>/dev/null | head -n 1)
num=$(ls -d /sys/class/leds/*::numlock 2>/dev/null | head -n 1)
[ -z "$caps$num" ] && exit 3
echo "have ${caps:+caps} ${num:+num}"
exec python3 -u -c '
import sys, time
leds = [("caps", sys.argv[1]), ("num", sys.argv[2])]
leds = [(n, p + "/brightness") for n, p in leds if p]
last = {}
def read(p):
    try:
        with open(p) as f: return f.read().strip()
    except OSError: return last.get(p)
while True:
    for n, p in leds:
        v = read(p)
        if p in last and v != last[p] and v is not None:
            print(n, v, flush=True)
        if v is not None: last[p] = v
    try: time.sleep(0.25)
    except KeyboardInterrupt: break
' "$caps" "$num"
