#!/bin/sh
# Puts "//@ pragma IconTheme NAME" at the top of shell.qml (Quickshell reads it when it starts),
# or removes it for "". Prints "changed" when the file was changed, so the shell restarts once.
f="$1"; theme="$2"
[ -f "$f" ] || exit 0
cur="$(grep -m1 '^//@ pragma IconTheme ' "$f" | sed 's#^//@ pragma IconTheme ##')"
[ "$cur" = "$theme" ] && { echo same; exit 0; }
sed -i '\#^//@ pragma IconTheme #d' "$f"
[ -n "$theme" ] && sed -i "1i //@ pragma IconTheme $theme" "$f"
echo changed
