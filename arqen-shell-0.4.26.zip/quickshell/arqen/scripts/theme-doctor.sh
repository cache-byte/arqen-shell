#!/bin/sh
# Why do apps stay dark (or light) when the shell's mode changes? Looks at every place an app can learn it from,
# fixes what it can, and prints what it found. Run from Settings > Appearance > Other apps > Check and repair.
cfg="${XDG_CONFIG_HOME:-$HOME/.config}/arqen/config.json"
want_dark="$(python3 -I - "$cfg" <<'PY' 2>/dev/null
import json, sys
try: print("1" if json.load(open(sys.argv[1])).get("darkMode", True) else "0")
except Exception: print("?")
PY
)"
want=$([ "$want_dark" = 1 ] && echo prefer-dark || echo prefer-light)
echo "The shell is in $([ "$want_dark" = 1 ] && echo DARK || echo LIGHT) mode (apps should be told: $want)."
echo
have() { command -v "$1" >/dev/null 2>&1; }
echo "1. What GNOME / libadwaita apps read (gsettings):   $(gsettings get org.gnome.desktop.interface color-scheme 2>&1)"
echo "   The same, straight from the dconf database:       $(have dconf && dconf read /org/gnome/desktop/interface/color-scheme || echo 'dconf is not installed')"
echo "   Settings backend in use:                          ${GSETTINGS_BACKEND:-default}"
echo "2. What the desktop portal tells Flatpak / browsers:  $(gdbus call --session --timeout 3 --dest org.freedesktop.portal.Desktop --object-path /org/freedesktop/portal/desktop --method org.freedesktop.portal.Settings.ReadOne org.freedesktop.appearance color-scheme 2>&1 | head -1)"
echo "   (uint32 1 = dark, 2 = light, 0 = no preference)"
echo "3. Environment this terminal has:  GTK_THEME='${GTK_THEME:-}'  ADW_DISABLE_PORTAL='${ADW_DISABLE_PORTAL:-}'  QT_QPA_PLATFORMTHEME='${QT_QPA_PLATFORMTHEME:-}'"
[ -n "${GTK_THEME:-}" ] && echo "   !! GTK_THEME is set: it overrides dark / light for every GTK app. It comes from a line in your Hyprland config or environment; remove it."
echo "4. Packages: $(rpm -q dconf gsettings-desktop-schemas xdg-desktop-portal xdg-desktop-portal-gtk adw-gtk3-theme 2>&1 | tr '\n' ' ')"
echo "5. Colour overrides in your GTK files (anything outside Arqen's own block pins colours):"
for f in "$HOME/.config/gtk-3.0/gtk.css" "$HOME/.config/gtk-4.0/gtk.css"; do
  [ -f "$f" ] || continue
  n="$(sed -E '/\/\* (arqen|insomny)-start/,/\/\* (arqen|insomny)-end \*\//d' "$f" | grep -c 'define-color\|window_bg_color\|--window-bg')"
  echo "   $f: $n colour line(s) of yours"
  [ "$n" -gt 0 ] && echo "   !! these can keep apps dark. Back it up and remove those lines: $f"
done
for f in "$HOME/.config/gtk-3.0/settings.ini" "$HOME/.config/gtk-4.0/settings.ini"; do [ -f "$f" ] && echo "   $f: $(grep -h 'prefer-dark\|theme-name' "$f" | tr '\n' ' ')"; done
echo
echo "Repairing:"
if [ "$want_dark" != "?" ]; then
  if have dconf; then dconf write /org/gnome/desktop/interface/color-scheme "'$want'" && echo " - wrote $want with dconf"; fi
  gsettings set org.gnome.desktop.interface color-scheme "$want" 2>/dev/null && echo " - wrote $want with gsettings"
fi
if ! have dconf; then echo " - dconf is missing: sudo dnf install dconf gsettings-desktop-schemas   (without it GNOME apps cannot read the setting)"; fi
systemctl --user restart xdg-desktop-portal xdg-desktop-portal-gtk 2>/dev/null && echo " - restarted the desktop portal"
sleep 1
echo
echo "Now: $(gsettings get org.gnome.desktop.interface color-scheme 2>&1)   portal: $(gdbus call --session --timeout 3 --dest org.freedesktop.portal.Desktop --object-path /org/freedesktop/portal/desktop --method org.freedesktop.portal.Settings.ReadOne org.freedesktop.appearance color-scheme 2>&1 | head -1)"
echo "Close and open one app (Files) to see whether it follows. If not, copy this whole output to Claude."
