#!/bin/sh
# Makes other apps follow Arqen's look: dark / light, accent colour, GTK theme, icons, cursor, font.
# Run by the shell (services/Appearance.qml) whenever one of those changes.
#   GNOME / libadwaita / GTK4, and Flatpak apps through the desktop portal  -> gsettings
#   exact accent colour on GTK3 + GTK4 apps                                 -> ~/.config/gtk-*/gtk.css
#   GTK3 apps that read settings.ini                                         -> ~/.config/gtk-3.0/settings.ini
#   Qt / KDE apps                                                            -> qt6ct / qt5ct colour scheme
#   Flatpak apps                                                             -> read access to themes, icons, gtk.css
# usage: apply-theme.sh DARK(1|0) ACCENT(#rrggbb) ACCENT_NAME GTK_THEME ICON_THEME CURSOR CURSOR_SIZE FONT FONT_SIZE
dark="$1"; acc="$2"; accname="$3"; gtk="$4"; icons="$5"; cursor="$6"; csize="${7:-24}"; font="$8"; fsize="${9:-11}"
C="$HOME/.config"
have() { command -v "$1" >/dev/null 2>&1; }
themedir() { for d in "$HOME/.local/share/themes" "$HOME/.themes" /usr/share/themes; do [ -d "$d/$1" ] && { echo "$d/$1"; return; }; done; }

# ---- GTK theme: "auto" = adw-gtk3 (looks like libadwaita), in the dark or light version ----
if [ "$gtk" = "auto" ] || [ -z "$gtk" ]; then
  if [ "$dark" = 1 ]; then gtk=adw-gtk3-dark; else gtk=adw-gtk3; fi
  [ -n "$(themedir "$gtk")" ] || { if [ "$dark" = 1 ]; then gtk=Adwaita-dark; else gtk=Adwaita; fi; }
fi

# a theme picked by hand that exists in a dark and a light version: use the one that matches the mode, or the
# apps would stay dark after switching to light (adw-gtk3-dark <-> adw-gtk3, Foo-dark <-> Foo, Foo-Dark <-> Foo)
case "$gtk" in
  *-dark|*-Dark)
    if [ "$dark" != 1 ]; then l="${gtk%-[dD]ark}"; [ -n "$(themedir "$l")" ] && gtk="$l"; fi ;;
  *)
    if [ "$dark" = 1 ]; then for d in "$gtk-dark" "$gtk-Dark"; do [ -n "$(themedir "$d")" ] && { gtk="$d"; break; }; done; fi ;;
esac

# ---- gsettings (GNOME apps, and Flatpak apps via the portal) ----
if have gsettings; then
  # only change what differs: every write makes GTK / libadwaita apps restyle (a visible flash)
  gs() {
    cur="$(gsettings get org.gnome.desktop.interface "$1" 2>/dev/null)"
    { [ "$cur" = "'$2'" ] || [ "$cur" = "$2" ]; } && return 0
    gsettings set org.gnome.desktop.interface "$1" "$2" 2>/dev/null || true
  }
  # "prefer-light" exists from GNOME 47; older versions only know "default"
  if [ "$dark" = 1 ]; then gs color-scheme prefer-dark
  else
    cur="$(gsettings get org.gnome.desktop.interface color-scheme 2>/dev/null)"
    if [ "$cur" != "'prefer-light'" ] && [ "$cur" != "'default'" ]; then
      gsettings set org.gnome.desktop.interface color-scheme prefer-light 2>/dev/null || gs color-scheme default
    fi
  fi
  gs gtk-theme "$gtk"
  [ -n "$accname" ] && gs accent-color "$accname"
  [ -n "$icons" ] && gs icon-theme "$icons"
  [ -n "$cursor" ] && { gs cursor-theme "$cursor"; gs cursor-size "$csize"; }
  [ -n "$font" ] && gs font-name "$font $fsize"
fi

# ---- make sure it really took (some setups ignore gsettings: no dconf service, a stale profile) ----
# The value apps read is org.gnome.desktop.interface color-scheme: if it is not what was asked, write it with dconf too.
if have gsettings; then
  want=$([ "$dark" = 1 ] && echo prefer-dark || echo prefer-light)
  now="$(gsettings get org.gnome.desktop.interface color-scheme 2>/dev/null)"
  case "$now" in
    "'$want'") ;;
    "'default'") [ "$dark" = 1 ] && have dconf && dconf write /org/gnome/desktop/interface/color-scheme "'prefer-dark'" ;;
    *) have dconf && dconf write /org/gnome/desktop/interface/color-scheme "'$want'" ;;
  esac
fi
# GTK 4 apps that do not use libadwaita read this file
mkdir -p "$C/gtk-4.0"
{
  echo "[Settings]"
  echo "gtk-application-prefer-dark-theme=$dark"
  [ -n "$icons" ] && echo "gtk-icon-theme-name=$icons"
  [ -n "$cursor" ] && { echo "gtk-cursor-theme-name=$cursor"; echo "gtk-cursor-theme-size=$csize"; }
  [ -n "$font" ] && echo "gtk-font-name=$font $fsize"
} > "$C/gtk-4.0/settings.ini"

# ---- live cursor ----
# (only when it changed: setting it makes the pointer blink)
if [ -n "$cursor" ] && have hyprctl; then
  stamp="$HOME/.cache/arqen-cursor"
  if [ "$(cat "$stamp" 2>/dev/null)" != "$cursor $csize" ]; then
    hyprctl setcursor "$cursor" "$csize" >/dev/null 2>&1 && { mkdir -p "$HOME/.cache"; echo "$cursor $csize" > "$stamp"; }
  fi
fi

# ---- exact accent for GTK apps (a marked block in gtk.css; the rest of the file is kept) ----
block() {   # $1 = file, $2 = text
  mkdir -p "$(dirname "$1")"; [ -f "$1" ] || : > "$1"
  tmp="$1.arqen-tmp"
  # (also the block written under the shell's previous name)
  sed -E '/\/\* (arqen|insomny)-start/,/\/\* (arqen|insomny)-end \*\//d' "$1" > "$tmp"
  printf '%s\n' "$2" >> "$tmp"
  # leave the file alone when nothing changed (apps that watch it would restyle)
  if cmp -s "$tmp" "$1"; then rm -f "$tmp"; else mv "$tmp" "$1"; fi
}
block "$C/gtk-3.0/gtk.css" "/* arqen-start: accent from Arqen Settings, this block is rewritten */
@define-color accent_color $acc;
@define-color accent_bg_color $acc;
@define-color accent_fg_color #ffffff;
@define-color theme_selected_bg_color $acc;
@define-color theme_selected_fg_color #ffffff;
/* arqen-end */"
block "$C/gtk-4.0/gtk.css" "/* arqen-start: accent from Arqen Settings, this block is rewritten */
@define-color accent_color $acc;
@define-color accent_bg_color $acc;
@define-color accent_fg_color #ffffff;
:root { --accent-color: $acc; --accent-bg-color: $acc; --accent-fg-color: #ffffff; }
/* arqen-end */"

# ---- settings.ini for GTK3 apps that do not use gsettings ----
mkdir -p "$C/gtk-3.0"
{
  echo "[Settings]"
  echo "gtk-application-prefer-dark-theme=$dark"
  echo "gtk-theme-name=$gtk"
  [ -n "$icons" ] && echo "gtk-icon-theme-name=$icons"
  [ -n "$cursor" ] && { echo "gtk-cursor-theme-name=$cursor"; echo "gtk-cursor-theme-size=$csize"; }
  [ -n "$font" ] && echo "gtk-font-name=$font $fsize"
} > "$C/gtk-3.0/settings.ini"

# ---- Chrome, Chromium, Brave, Vivaldi, Edge, Opera: dark / light ----
# They follow the desktop portal's colour scheme (set above) when their own Mode is "Device", but not all
# builds / setups do. So their flags files (made by scripts/keyring.sh, read when the browser starts) also say it:
# --force-dark-mode while dark, nothing while light (then the browser follows the system again).
for n in chrome chromium brave vivaldi microsoft-edge microsoft-edge-stable opera thorium; do
  for f in "$C/$n-flags.conf" "$HOME"/.var/app/*/config/"$n"-flags.conf; do
    [ -f "$f" ] || continue
    if [ "$dark" = 1 ]; then grep -qxF -- "--force-dark-mode" "$f" || echo "--force-dark-mode" >> "$f"
    else grep -qxF -- "--force-dark-mode" "$f" && sed -i '/^--force-dark-mode$/d' "$f"; fi
  done
done

# ---- Qt apps: qt6ct / qt5ct with a matching palette ----
if [ "$dark" = 1 ]; then
  P="#e8e8ee, #2a2a30, #3a3a42, #323238, #151518, #26262b, #e8e8ee, #ffffff, #e8e8ee, #1c1c21, #222227, #000000, $acc, #ffffff, $acc, $acc, #26262b, #000000, #2a2a30, #e8e8ee, #8a8a93"
  D="#6c6c74, #2a2a30, #3a3a42, #323238, #151518, #26262b, #6c6c74, #ffffff, #6c6c74, #1c1c21, #222227, #000000, #3a3a42, #8a8a93, $acc, $acc, #26262b, #000000, #2a2a30, #e8e8ee, #6c6c74"
else
  P="#1c1c21, #f2f2f6, #ffffff, #f7f7fa, #c8c8d0, #dcdce2, #1c1c21, #000000, #1c1c21, #ffffff, #f2f2f6, #9a9aa2, $acc, #ffffff, $acc, $acc, #f6f6f9, #000000, #ffffff, #1c1c21, #8a8a93"
  D="#9a9aa2, #f2f2f6, #ffffff, #f7f7fa, #c8c8d0, #dcdce2, #9a9aa2, #000000, #9a9aa2, #ffffff, #f2f2f6, #9a9aa2, #dcdce2, #6c6c74, $acc, $acc, #f6f6f9, #000000, #ffffff, #1c1c21, #9a9aa2"
fi
f6="${font:-Inter}"
for q in qt6ct qt5ct; do
  mkdir -p "$C/$q/colors"
  printf '[ColorScheme]\nactive_colors=%s\ndisabled_colors=%s\ninactive_colors=%s\n' "$P" "$D" "$P" > "$C/$q/colors/arqen.conf"
  if [ "$q" = qt6ct ]; then fstr="$f6,$fsize,-1,5,400,0,0,0,0,0,0,0,0,0,0,1"; else fstr="$f6,$fsize,-1,5,50,0,0,0,0,0"; fi
  {
    echo "[Appearance]"
    echo "color_scheme_path=$C/$q/colors/arqen.conf"
    echo "custom_palette=true"
    [ -n "$icons" ] && echo "icon_theme=$icons"
    echo "standard_dialogs=default"
    echo "style=Fusion"
    echo
    echo "[Fonts]"
    echo "general=\"$fstr\""
  } > "$C/$q/$q.conf"
done

# ---- Flatpak: let apps read the themes, icons, cursors and gtk.css ----
if have flatpak; then
  # system themes are not visible inside Flatpak: put a copy of the GTK theme in the user's themes
  for t in "$gtk" adw-gtk3 adw-gtk3-dark; do
    src="$(themedir "$t")"
    case "$src" in /usr/share/themes/*) [ -d "$HOME/.local/share/themes/$t" ] || { mkdir -p "$HOME/.local/share/themes"; cp -r "$src" "$HOME/.local/share/themes/"; } ;; esac
  done
  flatpak override --user \
    --filesystem=xdg-config/gtk-3.0:ro --filesystem=xdg-config/gtk-4.0:ro \
    --filesystem=xdg-data/themes:ro --filesystem=~/.themes:ro \
    --filesystem=xdg-data/icons:ro --filesystem=~/.icons:ro \
    --filesystem=xdg-config/qt5ct:ro --filesystem=xdg-config/qt6ct:ro >/dev/null 2>&1 || true
  # ADW_DISABLE_PORTAL (set for installed apps, see Config.qml) is passed into Flatpak apps too, where
  # it cut libadwaita apps off from the portal, the only place they can learn dark / light from
  flatpak override --user --unset-env=ADW_DISABLE_PORTAL >/dev/null 2>&1 || true
  # GTK3 apps inside Flatpak read the theme name through the portal (gsettings above); they can only
  # use it when the theme is installed as a Flatpak extension: ./update.sh does that
fi
exit 0
