#!/usr/bin/env python3
"""Screens for Settings > Display and windows.

monitors.py        -> JSON list: every screen Hyprland knows (also turned-off ones) with its modes
monitors.py check  -> the same, plus for each screen the modes its EDID (what the screen itself
                      says it can do) lists that Hyprland does not offer, and its top refresh rate
"""
import glob
import json
import os
import re
import subprocess
import sys


def hypr_monitors():
    try:
        out = subprocess.run(["hyprctl", "-j", "monitors", "all"], capture_output=True, text=True, timeout=5).stdout
        return json.loads(out or "[]")
    except Exception:
        return []


def parse_mode(s):
    m = re.match(r"(\d+)x(\d+)@([\d.]+)", s)
    return (int(m.group(1)), int(m.group(2)), round(float(m.group(3)), 2)) if m else None


def dtd(b):
    """an 18-byte detailed timing -> (w, h, hz) or None"""
    clock = (b[0] | b[1] << 8) * 10_000
    if clock == 0:
        return None
    ha = b[2] | (b[4] & 0xF0) << 4
    hb = b[3] | (b[4] & 0x0F) << 8
    va = b[5] | (b[7] & 0xF0) << 4
    vb = b[6] | (b[7] & 0x0F) << 8
    if b[17] & 0x80 or ha == 0 or va == 0:      # interlaced
        return None
    hz = clock / ((ha + hb) * (va + vb))
    return (ha, va, round(hz, 2))


def edid_modes(e):
    modes, vmax = set(), 0
    if len(e) < 128 or e[:8] != b"\x00\xff\xff\xff\xff\xff\xff\x00":
        return modes, vmax
    # standard timings
    for i in range(38, 54, 2):
        b0, b1 = e[i], e[i + 1]
        if (b0, b1) in ((1, 1), (0, 0), (0x20, 0x20)):
            continue
        w = (b0 + 31) * 8
        h = {0: w * 10 // 16, 1: w * 3 // 4, 2: w * 4 // 5, 3: w * 9 // 16}[b1 >> 6]
        modes.add((w, h, float((b1 & 0x3F) + 60)))
    # detailed timings and the range limits (top refresh rate)
    for off in (54, 72, 90, 108):
        blk = e[off:off + 18]
        m = dtd(blk)
        if m:
            modes.add(m)
        elif blk[3] == 0xFD:
            vmax = max(vmax, blk[6] + (255 if blk[4] & 0x02 else 0))
    # extension blocks (CTA-861): more detailed timings
    for n in range(1, e[126] + 1):
        ext = e[128 * n:128 * (n + 1)]
        if len(ext) < 128 or ext[0] != 0x02:
            continue
        d = ext[2]
        off = d
        while d and off + 18 <= 127:
            m = dtd(ext[off:off + 18])
            if m:
                modes.add(m)
            off += 18
    return modes, vmax


def edid_for(name):
    for p in glob.glob("/sys/class/drm/card*-" + name + "/edid"):
        try:
            with open(p, "rb") as f:
                data = f.read()
            if data:
                return data
        except OSError:
            pass
    return b""


def connected(name):
    """False only when the kernel says nothing is plugged into that connector"""
    for p in glob.glob("/sys/class/drm/card*-" + name + "/status"):
        try:
            with open(p) as f:
                return f.read().strip() != "disconnected"
        except OSError:
            pass
    return True


def main():
    check = len(sys.argv) > 1 and sys.argv[1] == "check"
    out = []
    for m in hypr_monitors():
        if not connected(m.get("name", "")):
            continue
        modes = []
        for s in m.get("availableModes", []):
            pm = parse_mode(s)
            if pm and pm not in modes:
                modes.append(pm)
        modes.sort(key=lambda x: (-x[0] * x[1], -x[2]))
        mon = {
            "name": m.get("name", ""),
            "description": (m.get("description") or "").strip(),
            "make": m.get("make", ""), "model": m.get("model", ""),
            "width": m.get("width", 0), "height": m.get("height", 0),
            "refresh": round(float(m.get("refreshRate", 0) or 0), 2),
            "scale": m.get("scale", 1), "x": m.get("x", 0), "y": m.get("y", 0),
            "transform": m.get("transform", 0), "disabled": bool(m.get("disabled", False)),
            "vrr": bool(m.get("vrr", False)),
            "modes": [{"w": a, "h": b, "r": c} for a, b, c in modes],
        }
        if check:
            em, vmax = edid_modes(edid_for(mon["name"]))
            have = {(a, b, round(c)) for a, b, c in modes}
            extra = sorted([x for x in em if (x[0], x[1], round(x[2])) not in have],
                           key=lambda x: (-x[0] * x[1], -x[2]))
            mon["extra"] = [{"w": a, "h": b, "r": c} for a, b, c in extra]
            mon["edidMaxHz"] = vmax
            top = max((c for a, b, c in modes), default=0)
            mon["bestHz"] = top
            # the screen says it can go faster than any mode offered: suggest its native size at that rate
            if vmax and modes and vmax > top + 1:
                w, h = modes[0][0], modes[0][1]
                if not any(x["w"] == w and x["h"] == h and abs(x["r"] - vmax) < 1 for x in mon["extra"]):
                    mon["extra"].insert(0, {"w": w, "h": h, "r": float(vmax), "guess": True})
            mon["hasEdid"] = bool(edid_for(mon["name"]))
        out.append(mon)
    json.dump(out, sys.stdout)


main()
