#!/usr/bin/env bash
# Saved passwords unlock when you log in, whatever login screen you use (GDM, SDDM, LightDM, ly,
# greetd, or a text console), and every Chromium-based browser keeps them in the keyring.
#
#   1. installs gnome-keyring and its PAM module
#   2. adds pam_gnome_keyring to each login screen's PAM file that lacks it (backup next to it):
#      your login password unlocks the "login" keyring
#   3. makes "login" the default keyring when it exists
#   4. Chromium-family browsers (Chrome, Chromium, Brave, Vivaldi, Edge, Opera, Thorium...; normal and
#      Flatpak): outside GNOME / KDE they store passwords without the keyring, or ask to unlock it.
#      They get --password-store=gnome-libsecret through their *-flags.conf and a copy of their
#      launcher in ~/.local/share/applications
# Firefox and Thunderbird keep their own password store and need nothing.
# Log: ~/.cache/arqen-keyring.log.   --quiet: no "press Enter" at the end.
mkdir -p "$HOME/.cache"
LOG="$HOME/.cache/arqen-keyring.log"
QUIET=0; [ "${1:-}" = "--quiet" ] && QUIET=1
exec > >(tee "$LOG") 2>&1
set -uo pipefail
STAMP="$(date +%Y%m%d-%H%M%S)"
FLAG="--password-store=gnome-libsecret"
finish() { [ "$QUIET" = 1 ] || { echo; read -r -p "Press Enter to close " _ || true; }; exit 0; }

echo "== 1. Packages"
need=""
for p in gnome-keyring gnome-keyring-pam libsecret; do rpm -q "$p" >/dev/null 2>&1 || need="$need $p"; done
if [ -n "$need" ]; then sudo dnf install -y $need || echo "!! could not install:$need"; else echo "gnome-keyring, its PAM module and libsecret are installed"; fi

echo; echo "== 2. Login screens (PAM)"
pam_mod="$(ls /usr/lib64/security/pam_gnome_keyring.so /usr/lib/security/pam_gnome_keyring.so 2>/dev/null | head -n1)"
if [ -z "$pam_mod" ]; then
  echo "!! pam_gnome_keyring.so not found - step 1 failed"
else
  # gdm-password: GDM;  sddm, lightdm, lxdm, ly, greetd: other login screens;  login: text console
  for f in gdm-password sddm lightdm lxdm ly greetd login; do
    pf="/etc/pam.d/$f"
    [ -f "$pf" ] || continue
    if grep -q "pam_gnome_keyring" "$pf"; then echo "$f: already unlocks the keyring"; continue; fi
    sudo cp "$pf" "$pf.bak-arqen-$STAMP"
    # auth: remember the password typed at login;  session: unlock (start the daemon if needed);
    # password: changing your login password changes the keyring's too
    tmp="$(mktemp)"
    awk '
      { lines[NR] = $0 }
      /^[[:space:]]*-?auth[[:space:]]/     { la = NR }
      /^[[:space:]]*-?session[[:space:]]/  { ls = NR }
      /^[[:space:]]*-?password[[:space:]]/ { lp = NR }
      END {
        for (i = 1; i <= NR; i++) {
          print lines[i]
          if (i == la) print "-auth       optional    pam_gnome_keyring.so"
          if (i == lp) print "-password   optional    pam_gnome_keyring.so use_authtok"
          if (i == ls) print "-session    optional    pam_gnome_keyring.so auto_start"
        }
        if (!la) print "-auth       optional    pam_gnome_keyring.so"
        if (!ls) print "-session    optional    pam_gnome_keyring.so auto_start"
      }' "$pf" > "$tmp"
    sudo cp "$tmp" "$pf" && rm -f "$tmp"
    sudo restorecon "$pf" 2>/dev/null || true
    echo "$f: added (backup: $pf.bak-arqen-$STAMP)"
  done
fi

echo; echo "== 3. Keyrings"
K="$HOME/.local/share/keyrings"
mkdir -p "$K"
ls -1 "$K" 2>/dev/null | sed 's/^/   /'
if [ -f "$K/login.keyring" ]; then
  if [ "$(cat "$K/default" 2>/dev/null)" != "login" ]; then
    echo "login" > "$K/default"; echo "Default keyring is now \"login\""
  else echo "\"login\" is the default keyring"; fi
else
  others="$(ls "$K"/*.keyring 2>/dev/null | grep -v '/login.keyring$' || true)"
  if [ -n "$others" ]; then
    echo "!! There is no \"login\" keyring, only:"
    echo "$others" | sed 's#.*/#      #'
    echo "   Those were made with a separate password, so logging in cannot unlock them. Either:"
    echo "   - open Passwords and Keys (seahorse), right-click the keyring > Change Password, and set it"
    echo "     to your login password, then run this again; or"
    echo "   - log out and in once: a \"login\" keyring is made with your login password, then run this again"
  else
    echo "No keyring yet: the next login makes a \"login\" keyring with your login password."
  fi
fi
echo "(Automatic login has no password to unlock it with: the keyring then asks once per session.)"

echo; echo "== 4. Browsers"
# their own flags files (read by the launch scripts of Chrome, Chromium, Brave, Vivaldi, Edge...)
add_flag() {   # $1 = flags file
  mkdir -p "$(dirname "$1")"
  grep -qsF -- "--password-store" "$1" && return 0
  echo "$FLAG" >> "$1"; echo "   $FLAG -> ${1/#$HOME/~}"
}
for n in chrome chromium brave vivaldi microsoft-edge microsoft-edge-stable opera thorium; do add_flag "$HOME/.config/$n-flags.conf"; done
# Flatpak builds read the same files inside their own folder
for app in com.google.Chrome:chrome org.chromium.Chromium:chromium com.brave.Browser:brave com.vivaldi.Vivaldi:vivaldi \
           com.microsoft.Edge:microsoft-edge com.opera.Opera:opera io.github.ungoogled_software.ungoogled_chromium:chromium; do
  id="${app%%:*}"; n="${app##*:}"
  [ -d "$HOME/.var/app/$id" ] && add_flag "$HOME/.var/app/$id/config/$n-flags.conf"
done
# and their launchers, so the flag is there however they are started
A="$HOME/.local/share/applications"; mkdir -p "$A"
re='(google-chrome|chromium|chromium-browser|brave|brave-browser|vivaldi|vivaldi-stable|microsoft-edge|opera|thorium|com\.google\.Chrome|org\.chromium\.Chromium|com\.brave\.Browser|com\.vivaldi\.Vivaldi|com\.microsoft\.Edge|com\.opera\.Opera|ungoogled)'
for d in /usr/share/applications /usr/local/share/applications /var/lib/flatpak/exports/share/applications "$HOME/.local/share/flatpak/exports/share/applications"; do
  [ -d "$d" ] || continue
  for f in "$d"/*.desktop; do
    [ -f "$f" ] || continue
    grep -qE "^Exec=[^ ]*$re" "$f" || grep -qE "^Exec=.*flatpak run .*$re" "$f" || continue
    grep -q "^NoDisplay=true" "$f" && continue
    dst="$A/$(basename "$f")"
    [ -f "$dst" ] || cp "$f" "$dst"
    grep -qF -- "--password-store" "$dst" && continue
    # the flag goes before the file / URL placeholders (%U, @@u ...), or at the end
    sed -i -E "/^Exec=/{ /--password-store/! { /@@u/ s/ @@u/ $FLAG @@u/; t; /%[uUfF]/ s/ (%[uUfF])/ $FLAG \1/; t; s/\$/ $FLAG/ } }" "$dst"
    echo "   launcher: $(basename "$f")"
  done
done
update-desktop-database -q "$A" 2>/dev/null || true

echo; echo "== 5. Right now"
if command -v gdbus >/dev/null 2>&1; then
  locked="$(gdbus call --session --dest org.freedesktop.secrets --object-path /org/freedesktop/secrets/collection/login \
            --method org.freedesktop.DBus.Properties.Get org.freedesktop.Secret.Collection Locked 2>/dev/null || true)"
  case "$locked" in
    *false*) echo "The login keyring is unlocked." ;;
    *true*)  echo "The login keyring is locked now; it unlocks at your next login." ;;
    *)       echo "No login keyring is open yet; log out and in." ;;
  esac
fi
echo
echo "Done. Log out and back in, then restart your browsers."
finish
