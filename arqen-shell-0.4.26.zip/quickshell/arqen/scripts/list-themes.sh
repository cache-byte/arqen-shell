#!/bin/sh
# Lists what can be picked in Settings > Fonts, themes and cursor. One section per header line.
dirs_themes="$HOME/.local/share/themes $HOME/.themes /usr/share/themes"
dirs_icons="$HOME/.local/share/icons $HOME/.icons /usr/share/icons"
echo "@@GTK"
{
  echo Adwaita; echo Adwaita-dark          # built into GTK, no folder of their own
  for d in $dirs_themes; do
    [ -d "$d" ] || continue
    for t in "$d"/*/; do [ -f "${t}gtk-3.0/gtk.css" ] || [ -f "${t}gtk-4.0/gtk.css" ] && basename "$t"; done
  done
} | sort -u
echo "@@ICONS"
for d in $dirs_icons; do
  [ -d "$d" ] || continue
  for t in "$d"/*/; do
    [ -f "${t}index.theme" ] || continue
    n="$(basename "$t")"
    case "$n" in hicolor|default|locolor) continue ;; esac
    # an icon theme has folders other than "cursors"
    ls -d "$t"*/ 2>/dev/null | grep -qv '/cursors/$' && echo "$n"
  done
done | sort -u
echo "@@CURSORS"
for d in $dirs_icons; do
  [ -d "$d" ] || continue
  for t in "$d"/*/; do [ -d "${t}cursors" ] && basename "$t"; done
done | sort -u
echo "@@FONTS"
fc-list : family 2>/dev/null | cut -d, -f1 | sed 's/\\//g' | grep -v '^\s*$' | sort -u
