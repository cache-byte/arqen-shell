#!/bin/sh
# What the music is doing, for the music widget and the panel: bars (0-100) of what the speakers play, ~30 times a second.
#   beat.sh [BARS] [FRAMERATE]      prints one line per frame: "12;40;33;..."   (needs cava; without it, exits at once with "missing")
bars="${1:-16}"
command -v cava >/dev/null 2>&1 || { echo "missing"; exit 0; }
cfg="${XDG_RUNTIME_DIR:-/tmp}/arqen-cava.conf"
cat > "$cfg" <<CFG
[general]
bars = $bars
framerate = ${2:-30}
[input]
method = pipewire
source = auto
[output]
method = raw
raw_target = /dev/stdout
data_format = ascii
ascii_max_range = 100
bar_delimiter = 59
frame_delimiter = 10
[smoothing]
noise_reduction = 55
CFG
cava -p "$cfg" 2>/dev/null && exit 0
# PipeWire input refused: try the PulseAudio one (works through pipewire-pulse too)
sed -i 's/^method = pipewire/method = pulse/' "$cfg"
exec cava -p "$cfg" 2>/dev/null
