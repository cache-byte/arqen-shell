#!/usr/bin/env python3
"""Mice, keyboards, controllers and headsets however they are connected, with their battery when the kernel knows it.

  peripherals.py        one JSON line: { "devices": [ { name, kind, bus, dongle, battery, charging, vendor, product } ] }

Bluetooth is not the only way: a 2.4 GHz receiver (Logitech Unifying / Bolt / Lightspeed, Razer, 8BitDo, Xbox
wireless adapter, a vendor's own dongle) shows the paired device to the system, and a cable is another. They are
found from /proc/bus/input/devices and the USB device above them; the battery comes from the power supply the
driver (hid-logitech-hidpp, hid-playstation, xpad / xone, hid-nintendo...) makes for it.
Only the standard library.
"""
import glob, json, os, re

DONGLE = re.compile(r"receiver|dongle|unifying|bolt|lightspeed|nano|2\.4\s?g|wireless (adapter|usb)|usb wireless|"
                    r"xbox (wireless )?adapter|powerplay|logi|razer .*(hyperspeed|dongle)", re.I)
SKIP_NAME = re.compile(r"power button|sleep button|lid switch|video bus|speaker|hdmi|headphone jack|pc speaker|"
                       r"intel hid|dell|thinkpad extra|touchpad|trackpoint|synaptics|elan|virtual|uinput|"
                       r"receiver (keyboard|mouse|consumer control|system control)|\(arqen\)|ydotool|wtype|keyd|consumer control|system control|avrcp", re.I)


def rd(p):
    try:
        return open(p).read().strip()
    except Exception:
        return ""


def blocks():
    cur = {}
    for line in open(os.environ.get("ARQEN_INPUT_DEVICES", "/proc/bus/input/devices"), errors="replace"):
        line = line.rstrip("\n")
        if not line.strip():
            if cur:
                yield cur
            cur = {}
            continue
        k, _, v = line.partition(": ")
        if k == "I":
            m = dict(re.findall(r"(\w+)=(\w+)", v))
            cur["bus"], cur["vendor"], cur["product"] = m.get("Bus", ""), m.get("Vendor", ""), m.get("Product", "")
        elif k == "N":
            cur["name"] = v.split("=", 1)[-1].strip().strip('"')
        elif k == "S":
            cur["sysfs"] = "/sys" + v.split("=", 1)[-1].strip()
        elif k == "H":
            cur["handlers"] = v.split("=", 1)[-1].split()
        elif k == "B" and v.startswith("EV="):
            cur["ev"] = int(v[3:], 16)
        elif k == "B" and v.startswith("KEY="):
            cur["key"] = v[4:]
    if cur:
        yield cur


def kind_of(b):
    h = b.get("handlers", [])
    n = b.get("name", "")
    if any(x.startswith("js") for x in h) or re.search(r"controller|gamepad|dualsense|dualshock|xbox|joy-?con|pro controller|8bitdo", n, re.I):
        return "controller"
    if re.search(r"headset|headphone|earbuds|arctis|cloud|hyperx|buds", n, re.I):
        return "headset"
    mouse = any(x.startswith("mouse") for x in h)
    if "kbd" in h and not mouse and (b.get("ev", 0) & 0x100000):      # keys that repeat: a keyboard
        return "keyboard"
    if mouse:
        return "mouse"
    return ""


def up(path, n=9):
    """The device and the ones above it, up to the USB / PCI device."""
    p = os.path.realpath(path)
    for _ in range(n):
        yield p
        if os.path.basename(p).startswith(("usb", "pci")) or p in ("/sys", "/sys/devices", "/"):
            return
        p = os.path.dirname(p)


def supply(path):
    for p in up(path):
        for ps in glob.glob(p + "/power_supply/*"):
            # not the computer's own battery or its charger
            if rd(ps + "/scope").lower() == "system" or rd(ps + "/type").lower() in ("mains", "usb"):
                continue
            cap = rd(ps + "/capacity")
            lvl = {"full": 100, "high": 75, "normal": 50, "low": 20, "critical": 5}.get(rd(ps + "/capacity_level").lower(), -1)
            return (int(cap) if cap.isdigit() else lvl), rd(ps + "/status").lower() == "charging", rd(ps + "/model_name")
    return -1, False, ""


def usb_parent(path):
    """The USB device (not the interface) this input device hangs on: its product name and ids."""
    for p in up(path):
        if os.path.exists(p + "/idVendor"):
            return {"product": rd(p + "/product"), "manufacturer": rd(p + "/manufacturer"),
                    "vendor": rd(p + "/idVendor"), "id": rd(p + "/idProduct")}
    return None


def main():
    out, seen = [], set()
    try:
        bl = list(blocks())
    except Exception:
        bl = []
    for b in bl:
        name = b.get("name", "")
        bus = {"0003": "usb", "0005": "bluetooth", "0011": "built-in", "0019": "built-in", "0006": "virtual"}.get(b.get("bus", ""), "other")
        if bus in ("built-in", "virtual", "other") or not name or SKIP_NAME.search(name):
            continue
        k = kind_of(b)
        if not k:
            continue
        sysfs = b.get("sysfs", "")
        cap, chg, model = supply(sysfs) if sysfs else (-1, False, "")
        usb = usb_parent(sysfs) if sysfs and bus == "usb" else None
        # behind a receiver: the USB device is the receiver, the input device is what is paired to it
        dongle = ""
        if usb and (DONGLE.search(usb["product"] or "") or (usb["product"] and usb["product"].lower() not in name.lower()
                                                            and re.search(r"receiver|dongle|adapter|wireless", usb["product"], re.I))):
            dongle = usb["product"]
        label = model or name
        key = (label, k)
        if key in seen:
            continue                            # one device shows up as several input nodes (keyboard + mouse parts)
        seen.add(key)
        out.append({"name": label, "kind": k, "bus": bus, "dongle": dongle, "battery": cap, "charging": chg,
                    "vendor": b.get("vendor", ""), "product": b.get("product", ""),
                    "via": (usb or {}).get("product", "")})
    # power supplies of devices that have no input node (headsets, earbuds, wireless mice seen only through UPower)
    for ps in glob.glob("/sys/class/power_supply/*"):
        if rd(ps + "/scope").lower() == "system" or rd(ps + "/type").lower() in ("mains", "usb", "ups"):
            continue
        model = rd(ps + "/model_name") or os.path.basename(ps)
        if any(d["name"] == model for d in out) or any(model.lower() in d["name"].lower() for d in out):
            continue
        cap = rd(ps + "/capacity")
        if not cap.isdigit():
            continue
        real = os.path.realpath(ps)
        bus = "bluetooth" if "bluetooth" in real or "/hci" in real else "usb" if "/usb" in real else "other"
        out.append({"name": model, "kind": "other", "bus": bus, "dongle": "", "battery": int(cap),
                    "charging": rd(ps + "/status").lower() == "charging", "vendor": "", "product": "", "via": ""})
    print(json.dumps({"devices": out}), flush=True)


if __name__ == "__main__":
    main()
