#!/usr/bin/env python3
"""Prints where the pointer is ("X Y"), only when it moves, a few times a second (the window handle).
Asks Hyprland's socket directly: no program is started each time, and nothing is logged."""
import os, socket, sys, time

sig = os.environ.get("HYPRLAND_INSTANCE_SIGNATURE", "")
run = os.environ.get("XDG_RUNTIME_DIR", "/tmp")
path = os.path.join(run, "hypr", sig, ".socket.sock")
if not os.path.exists(path):
    path = os.path.join("/tmp/hypr", sig, ".socket.sock")
interval = float(sys.argv[1]) if len(sys.argv) > 1 else 0.11
last = None
while True:
    try:
        s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        s.settimeout(1)
        s.connect(path)
        s.sendall(b"cursorpos")
        data = b""
        while True:
            chunk = s.recv(256)
            if not chunk:
                break
            data += chunk
        s.close()
        txt = data.decode(errors="replace").replace(",", " ").split()
        if len(txt) >= 2:
            pos = (txt[0], txt[1])
            if pos != last:
                last = pos
                print(pos[0], pos[1], flush=True)
    except BrokenPipeError:          # the shell is gone
        sys.exit(0)
    except (OSError, ValueError):
        time.sleep(1)
    time.sleep(interval)
