#!/bin/sh
# Run a shell command in a terminal and wait until it is closed.
#   term-run.sh "COMMAND"
# The terminal is the one chosen in Settings > Apps > Default apps (else the first one installed).
cmd_="$1"
[ -n "$cmd_" ] || exit 1
# the terminal chosen in Settings > Apps > Default apps comes first (it is the first line of xdg-terminals.list)
pref=""
list="${XDG_CONFIG_HOME:-$HOME/.config}/xdg-terminals.list"
[ -f "$list" ] && pref="$(grep -v '^[[:space:]]*#' "$list" | sed 's/^[[:space:]]*+*//' | grep . | head -n1)"
prefbin=""
if [ -n "$pref" ]; then
  for d in "$HOME/.local/share/applications" /usr/local/share/applications /usr/share/applications /var/lib/flatpak/exports/share/applications "$HOME/.local/share/flatpak/exports/share/applications"; do
    if [ -f "$d/$pref" ]; then
      ex="$(grep -m1 '^Exec=' "$d/$pref" | cut -d= -f2- | sed 's/^env  *[A-Za-z_]*=[^ ]* *//')"
      prefbin="$(printf '%s' "$ex" | awk '{print $1}')"
      break
    fi
  done
fi
for t in $prefbin xdg-terminal-exec kitty foot alacritty wezterm ghostty gnome-terminal konsole xfce4-terminal kgx ptyxis tilix xterm; do
  command -v "$t" >/dev/null 2>&1 || continue
  case "$(basename "$t")" in
    wezterm)         exec "$t" start -- sh -c "$cmd_" ;;
    gnome-terminal) exec "$t" --wait -- sh -c "$cmd_" ;;
    ptyxis|kgx|tilix|gnome-console) exec "$t" -- sh -c "$cmd_" ;;
    *)               exec "$t" -e sh -c "$cmd_" ;;     # kitty, foot, alacritty, ghostty, konsole, xfce4-terminal, xterm, xdg-terminal-exec ...
  esac
done
echo "no terminal found" >&2; exit 1
