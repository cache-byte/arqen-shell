#!/bin/sh
# A short sound in one ear: lr-test.sh left|right|both [AA_BB_CC_DD_EE_FF]
# Played on that Bluetooth device when it is an audio output, else on the current output.
side="${1:-both}"; mac="$2"
dir="${XDG_CACHE_HOME:-$HOME/.cache}/arqen"; mkdir -p "$dir"
f="$dir/lr-$side.wav"
if [ ! -s "$f" ]; then
  python3 - "$f" "$side" <<'PY'
import math, struct, sys, wave
path, side = sys.argv[1], sys.argv[2]
rate = 48000
w = wave.open(path, "wb"); w.setnchannels(2); w.setsampwidth(2); w.setframerate(rate)
frames = bytearray()
# three soft rising notes
for n, hz in enumerate((660, 880, 1100)):
    for i in range(int(rate * 0.16)):
        t = i / rate
        env = min(1, t / 0.01) * max(0, 1 - t / 0.16) ** 1.5
        v = int(0.32 * 32767 * env * math.sin(2 * math.pi * hz * t))
        l = v if side in ("left", "both") else 0
        r = v if side in ("right", "both") else 0
        frames += struct.pack("<hh", l, r)
    frames += bytes(4 * int(rate * 0.04))
w.writeframes(bytes(frames)); w.close()
PY
fi
target=""
if [ -n "$mac" ] && command -v pactl >/dev/null 2>&1; then
  target="$(pactl list short sinks 2>/dev/null | awk -v m="$mac" '$2 ~ m {print $2; exit}')"
fi
if command -v pw-play >/dev/null 2>&1; then
  exec pw-play ${target:+--target "$target"} "$f"
elif command -v paplay >/dev/null 2>&1; then
  exec paplay ${target:+--device="$target"} "$f"
fi
