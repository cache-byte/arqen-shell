#!/usr/bin/env python3
"""Where an installed app came from, and how to remove it.

  app-info.py info DESKTOP_ID   -> JSON {id, name, source, package, version, uninstall, file}
  app-info.py list              -> JSON [{id, name, source, package}] of every app (for Settings > Apps > About)

source: flatpak | rpm | deb | pacman | snap | appimage | user | unknown
`uninstall` is a command the shell shows in a terminal for you to confirm: it is never run by itself.
"""
import glob
import json
import os
import re
import shutil
import subprocess
import sys

HOME = os.path.expanduser("~")
DIRS = [os.path.join(HOME, ".local/share/applications")]
DIRS += [os.path.join(d, "applications") for d in os.environ.get("XDG_DATA_DIRS", "/usr/local/share:/usr/share").split(":") if d]
DIRS += ["/var/lib/flatpak/exports/share/applications", os.path.join(HOME, ".local/share/flatpak/exports/share/applications"),
         "/var/lib/snapd/desktop/applications"]


def run(*cmd):
    try:
        return subprocess.run(cmd, capture_output=True, text=True, timeout=15).stdout.strip()
    except (OSError, subprocess.SubprocessError):
        return ""


def find(did):
    did = re.sub(r"\.desktop$", "", did)
    for d in DIRS:
        for name in (did, did.lower()):
            p = os.path.join(d, name + ".desktop")
            if os.path.isfile(p):
                return p
        for p in glob.glob(os.path.join(d, "**", "*.desktop"), recursive=True):
            if os.path.relpath(p, d).replace("/", "-")[:-8].lower() == did.lower():
                return p
    return ""


def field(path, key):
    try:
        with open(path, encoding="utf-8", errors="replace") as f:
            in_entry = False
            for line in f:
                line = line.strip()
                if line.startswith("["):
                    in_entry = line == "[Desktop Entry]"
                elif in_entry and line.startswith(key + "="):
                    return line.split("=", 1)[1]
    except OSError:
        pass
    return ""


def info(did):
    path = find(did)
    out = {"id": did, "name": "", "source": "unknown", "package": "", "version": "", "uninstall": "", "file": path}
    if not path:
        return out
    out["name"] = field(path, "Name")
    exec_line = field(path, "Exec")
    if "/flatpak/exports/" in path or field(path, "X-Flatpak"):
        app = field(path, "X-Flatpak") or os.path.basename(path)[:-8]
        out.update(source="flatpak", package=app)
        v = run("flatpak", "info", app)
        m = re.search(r"Version:\s*(.+)", v)
        if m:
            out["version"] = m.group(1).strip()
        out["uninstall"] = "flatpak uninstall %s" % app
    elif path.startswith("/var/lib/snapd/") or "/snap/" in exec_line:
        name = os.path.basename(path)[:-8].split("_")[0]
        out.update(source="snap", package=name, uninstall="sudo snap remove %s" % name)
    elif path.startswith(HOME) or path.startswith("/opt"):
        if ".AppImage" in exec_line or "appimage" in exec_line.lower():
            out.update(source="appimage", package="", uninstall="")
            m = re.search(r'(/[^\s"]+\.AppImage)', exec_line)
            if m:
                out["uninstall"] = "rm -i %s %s" % (m.group(1), path)
        else:
            out.update(source="user", uninstall="rm -i %s" % path)
    else:
        if shutil.which("rpm"):
            pkg = run("rpm", "-qf", "--qf", "%{NAME}", path)
            if pkg and "not owned" not in pkg:
                out.update(source="rpm", package=pkg, version=run("rpm", "-q", "--qf", "%{VERSION}", pkg),
                           uninstall="sudo dnf remove %s" % pkg)
        elif shutil.which("pacman"):
            r = run("pacman", "-Qo", path)
            m = re.search(r"is owned by (\S+) (\S+)", r)
            if m:
                out.update(source="pacman", package=m.group(1), version=m.group(2), uninstall="sudo pacman -Rns %s" % m.group(1))
        elif shutil.which("dpkg"):
            r = run("dpkg", "-S", path)
            if ":" in r:
                pkg = r.split(":")[0].split(",")[0]
                out.update(source="deb", package=pkg, version=run("dpkg-query", "-W", "-f=${Version}", pkg), uninstall="sudo apt remove %s" % pkg)
    return out


def listing():
    seen, res = set(), []
    for d in DIRS:
        for p in sorted(glob.glob(os.path.join(d, "**", "*.desktop"), recursive=True)):
            did = os.path.relpath(p, d).replace("/", "-")[:-8]
            if did in seen or field(p, "NoDisplay") == "true" or field(p, "Type") not in ("Application", ""):
                continue
            seen.add(did)
            src = "flatpak" if "/flatpak/" in p else "snap" if "snapd" in p else "user" if p.startswith(HOME) else "system"
            res.append({"id": did, "name": field(p, "Name") or did, "source": src})
    return sorted(res, key=lambda a: a["name"].lower())


if __name__ == "__main__":
    if len(sys.argv) >= 3 and sys.argv[1] == "info":
        print(json.dumps(info(sys.argv[2])))
    elif len(sys.argv) >= 2 and sys.argv[1] == "list":
        print(json.dumps(listing()))
    else:
        print(__doc__)
