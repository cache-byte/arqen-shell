#!/usr/bin/env bash
# win-nudge.sh move|resize left|right|up|down [lua|legacy]
# The keyboard way to move / resize the focused window (Settings > Keyboard shortcuts): arrow keys with the
# modifiers picked there. A floating window moves / grows by 40 px; a tiled one swaps places with its
# neighbour (move) or has its split pushed (resize).
act="${1:-move}"; dir="${2:-left}"; kind="${3:-legacy}"; step=40
dx=0; dy=0; d=l
case "$dir" in left) dx=-$step; d=l ;; right) dx=$step; d=r ;; up) dy=-$step; d=u ;; down) dy=$step; d=d ;; *) exit 1 ;; esac
info="$(hyprctl activewindow -j 2>/dev/null)" || exit 0
read -r addr fl x y w h fs <<<"$(printf '%s' "$info" | python3 -I -c '
import json, sys
try: c = json.load(sys.stdin)
except Exception: sys.exit(0)
if not c.get("address"): sys.exit(0)
print(c["address"], 1 if c.get("floating") else 0, c["at"][0], c["at"][1], c["size"][0], c["size"][1], c.get("fullscreen", 0))
')"
[ -n "${addr:-}" ] || exit 0
[ "${fs:-0}" = 0 ] || exit 0
disp() { hyprctl dispatch "$@" >/dev/null 2>&1; }
if [ "$fl" = 1 ]; then
  if [ "$act" = move ]; then nx=$((x + dx)); ny=$((y + dy))
    if [ "$kind" = lua ]; then disp "hl.dsp.window.move({ x = $nx, y = $ny, window = \"address:$addr\" })"
    else disp movewindowpixel "exact $nx $ny,address:$addr"; fi
  else nw=$((w + dx)); nh=$((h + dy)); [ $nw -lt 200 ] && nw=200; [ $nh -lt 150 ] && nh=150
    if [ "$kind" = lua ]; then disp "hl.dsp.window.resize({ x = $nw, y = $nh, window = \"address:$addr\" })"
    else disp resizewindowpixel "exact $nw $nh,address:$addr"; fi
  fi
else
  if [ "$act" = move ]; then
    if [ "$kind" = lua ]; then
      case "$d" in l) n=left ;; r) n=right ;; u) n=up ;; *) n=down ;; esac
      disp "hl.dsp.window.move({ direction = \"$n\" })"
    else disp movewindow "$d"; fi
  else
    if [ "$kind" = lua ]; then disp "hl.dsp.window.resize({ x = $dx, y = $dy, relative = true })"
    else disp resizeactive "$dx $dy"; fi
  fi
fi
exit 0
