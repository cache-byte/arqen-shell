#!/bin/sh
# Search the web for part of the screen: draw a box around it, and Google image search (Lens)
# opens with it in your default browser.
# The picture goes straight from your browser to Google (a small local page hands it over), so
# the results open in your own browser session; nothing is uploaded anywhere else.
# with an argument from the capture screen there is nothing to draw:
#   frozen:FILE WxH+X+Y   a part of the picture the capture screen froze (what you saw is what is searched)
#   geo:X,Y WxH           a part of the live screen          output:NAME   a whole screen
case "${1:-}" in
  frozen:*) ;;                                  # no waiting: the picture exists already
  "")       sleep 0.2 ;;
  *)        sleep 0.6 ;;                        # let the capture screen fade out before looking at the screen
esac
case "${1:-}" in
  frozen:*) src="${1#frozen:}"; crop="${2:-}"; mode=frozen ;;
  geo:*)    geo="${1#geo:}"; mode=geo ;;
  output:*) out="${1#output:}"; mode=out ;;
  *)        geo="$(slurp)" || exit 0; mode=geo ;;
esac
dir="${XDG_CACHE_HOME:-$HOME/.cache}/arqen"
mkdir -p "$dir"
img="$dir/lens-$$.png"
page="$dir/lens-$$.html"
if [ "$mode" = frozen ]; then
  if command -v magick >/dev/null 2>&1; then magick "$src" -crop "$crop" +repage "$img" || exit 1
  elif command -v convert >/dev/null 2>&1; then convert "$src" -crop "$crop" +repage "$img" || exit 1
  else cp "$src" "$img"; fi
elif [ "$mode" = out ]; then grim -o "$out" "$img" || exit 1
else grim -g "$geo" "$img" || exit 1; fi
b64="$(base64 -w0 "$img")"
rm -f "$img"
cat > "$page" <<HTML
<!doctype html>
<html><head><meta charset="utf-8"><title>Searching…</title>
<style>body{background:#111;color:#ccc;font:15px sans-serif;display:grid;place-items:center;height:100vh;margin:0}</style></head>
<body><p>Searching for your picture…</p>
<form id="f" method="POST" enctype="multipart/form-data" action="https://lens.google.com/v3/upload?ep=ccm&amp;re=dcsp&amp;s=4&amp;st=$(date +%s%3N)">
<input type="file" name="encoded_image" id="i" style="display:none">
</form>
<script>
const b = atob("$b64"); const u = new Uint8Array(b.length);
for (let k = 0; k < b.length; k++) u[k] = b.charCodeAt(k);
const dt = new DataTransfer();
dt.items.add(new File([u], "screen.png", { type: "image/png" }));
document.getElementById("i").files = dt.files;
document.getElementById("f").submit();
</script></body></html>
HTML
xdg-open "file://$page" >/dev/null 2>&1 || gio open "$page"
# the page is only needed until the browser has read it
( sleep 60; rm -f "$page" ) &
