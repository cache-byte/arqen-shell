#!/bin/sh
# The private part of Settings > System > This computer. Runs as root through pkexec, which asks
# for your password first; the result is only shown, never saved.
d=/sys/class/dmi/id
rd() { [ -r "$1" ] && tr -d '\n' < "$1" 2>/dev/null; }
out() { [ -n "$2" ] && printf '%s\t%s\n' "$1" "$2"; }
case "$(rd $d/product_serial)" in ""|"To Be Filled"*|"Default string"|"System Serial Number"|"0") ;; *) out "Serial number" "$(rd $d/product_serial)" ;; esac
case "$(rd $d/board_serial)" in ""|"To Be Filled"*|"Default string"|"0") ;; *) out "Board serial number" "$(rd $d/board_serial)" ;; esac
out "Hardware ID" "$(rd $d/product_uuid)"
out "Machine ID" "$(tr -d '\n' < /etc/machine-id 2>/dev/null)"
for i in $(ls /sys/class/net 2>/dev/null); do
  [ "$i" = lo ] && continue
  a="$(rd /sys/class/net/$i/address)"
  ip4="$(ip -o -4 addr show dev "$i" 2>/dev/null | awk '{print $4}' | paste -sd ' ')"
  [ -n "$ip4" ] && out "IP address ($i)" "$ip4"
  [ -n "$a" ] && [ "$a" != "00:00:00:00:00:00" ] && out "MAC address ($i)" "$a"
done
for dsk in /sys/block/nvme*n1 /sys/block/sd?; do
  [ -e "$dsk" ] || continue
  s="$(rd $dsk/device/serial)"; [ -z "$s" ] && s="$(rd $dsk/serial)"
  [ -n "$s" ] && out "Disk serial ($(basename "$dsk"))" "$(echo "$s" | tr -d ' ')"
done
exit 0
