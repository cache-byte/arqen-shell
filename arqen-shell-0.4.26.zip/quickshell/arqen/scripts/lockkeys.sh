#!/bin/sh
# Caps Lock / Num Lock the way Settings says they should be at login.
#   lockkeys.sh CAPS NUM     each: on | off | keep
# Runs once per login (a shell restart does not touch them again).
marker="${XDG_RUNTIME_DIR:-/tmp}/arqen-lockkeys-done"
[ -e "$marker" ] && exit 0
: > "$marker"
sleep 2
set_key() {   # led name, key name, wanted
  [ "$3" = keep ] && return
  led="$(ls -d /sys/class/leds/*::"$1" 2>/dev/null | head -n 1)"
  [ -n "$led" ] || return
  cur="$(cat "$led/brightness" 2>/dev/null || echo 0)"
  [ "$cur" -gt 0 ] && now=on || now=off
  [ "$now" = "$3" ] || wtype -k "$2" 2>/dev/null
}
set_key capslock Caps_Lock "${1:-keep}"
set_key numlock Num_Lock "${2:-keep}"
