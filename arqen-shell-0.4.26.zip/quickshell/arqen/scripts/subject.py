#!/usr/bin/env python3
"""subject.py IMAGE  ->  a mask of where the main subject of a wallpaper is, or "none".

Prints "W H" and then H lines of W digits (1 = subject), for the picture cut into W x H cells.
The guess: what does not look like the picture's own background. The background is taken from the
picture's edges (colours that are there are "background"), the subject is the connected part that
differs from it most and has the most detail. Needs Python 3 and either Pillow or ImageMagick.
"""
import subprocess, sys, shutil, math

def load(path, W, H):
    try:
        from PIL import Image
        im = Image.open(path).convert("RGB")
        w0, h0 = im.size
        b = im.resize((W, H), Image.BILINEAR).tobytes()
        return [(b[i], b[i + 1], b[i + 2]) for i in range(0, len(b), 3)], w0, h0
    except ImportError:
        pass
    exe = shutil.which("magick") or shutil.which("convert")
    if not exe:
        return None
    ident = [exe, "identify"] if exe.endswith("magick") else ["identify"]
    r = subprocess.run(ident + ["-format", "%w %h", path + "[0]"], capture_output=True, text=True)
    try:
        w0, h0 = [int(v) for v in r.stdout.split()[:2]]
    except Exception:
        return None
    out = subprocess.run([exe, path + "[0]", "-resize", "%dx%d!" % (W, H), "-depth", "8", "ppm:-"], capture_output=True).stdout
    parts = out.split(b"\n", 3)
    data = parts[3] if len(parts) > 3 else b""
    if len(data) < W * H * 3:
        return None
    return [(data[i], data[i + 1], data[i + 2]) for i in range(0, W * H * 3, 3)], w0, h0

def blur(a, W, H, passes=1):
    for _ in range(passes):
        n = [0.0] * (W * H)
        for y in range(H):
            for x in range(W):
                s = c = 0
                for dy in (-1, 0, 1):
                    yy = y + dy
                    if yy < 0 or yy >= H: continue
                    for dx in (-1, 0, 1):
                        xx = x + dx
                        if 0 <= xx < W:
                            s += a[yy * W + xx]; c += 1
                n[y * W + x] = s / c
        a = n
    return a

def components(mask, W, H):
    seen = [False] * (W * H); comps = []
    for s0 in range(W * H):
        if not mask[s0] or seen[s0]: continue
        st = [s0]; seen[s0] = True; cells = []
        while st:
            i = st.pop(); cells.append(i)
            x, y = i % W, i // W
            for xx, yy in ((x + 1, y), (x - 1, y), (x, y + 1), (x, y - 1)):
                if 0 <= xx < W and 0 <= yy < H:
                    j = yy * W + xx
                    if mask[j] and not seen[j]:
                        seen[j] = True; st.append(j)
        comps.append(cells)
    return comps

def main():
    W = 80
    got = load(sys.argv[1], W, 45)
    if not got:
        print("none"); return
    px, w0, h0 = got
    H = max(10, min(80, round(W * h0 / max(1, w0))))
    if H != 45:
        got = load(sys.argv[1], W, H)
        if not got: print("none"); return
        px = got[0]
    n = W * H
    # --- the background: colours found along the picture's edges (the bottom counts less: subjects stand on it)
    edge = []
    m = max(2, int(0.07 * min(W, H)))
    for y in range(H):
        for x in range(W):
            top = y < m; left = x < m; right = x >= W - m
            if top or left or right:
                if (x + y) % 2 == 0: edge.append(px[y * W + x])
    if len(edge) < 8:
        print("none"); return
    # about 150 samples spread along the edges: any colour that is there is background
    step = max(1, len(edge) // 150)
    bg = edge[::step]
    gray = [(0.299 * r + 0.587 * g + 0.114 * b) for r, g, b in px]
    diff = [0.0] * n
    det = [0.0] * n
    for y in range(H):
        for x in range(W):
            i = y * W + x
            r, g, b = px[i]
            diff[i] = min(math.sqrt((r - c[0]) ** 2 + (g - c[1]) ** 2 + (b - c[2]) ** 2) for c in bg)
            gx = abs(gray[i] - gray[y * W + min(W - 1, x + 1)]) + abs(gray[i] - gray[y * W + max(0, x - 1)])
            gy = abs(gray[i] - gray[min(H - 1, y + 1) * W + x]) + abs(gray[i] - gray[max(0, y - 1) * W + x])
            det[i] = gx + gy
    diff = blur(diff, W, H, 2)
    det = blur(det, W, H, 3)
    md, mt = max(diff) or 1.0, max(det) or 1.0
    score = []
    for y in range(H):
        for x in range(W):
            i = y * W + x
            cx = (x / W - 0.5) * 2; cy = (y / H - 0.5) * 2
            centre = 0.75 + 0.25 * math.exp(-(cx * cx + cy * cy) * 0.9)
            score.append((0.7 * diff[i] / md + 0.3 * det[i] / mt) * centre)
    # --- a threshold between "background" and "subject" (Otsu), then the connected blobs
    top = max(score) or 1.0
    hist = [0] * 64
    for v in score: hist[min(63, int(v / top * 63))] += 1
    tot = n; sum_all = sum(i * h for i, h in enumerate(hist))
    wb = sb = 0; best = -1; thr = 20
    for t in range(64):
        wb += hist[t]
        if wb == 0: continue
        wf = tot - wb
        if wf == 0: break
        sb += t * hist[t]
        mb = sb / wb; mf = (sum_all - sb) / wf
        v = wb * wf * (mb - mf) ** 2
        if v > best: best = v; thr = t
    cut = max(thr, 14) / 63 * top
    # the background that is joined to the picture's top / left / right edges by smooth ground (no outline in the
    # way) is not the subject, however different its colour is from the edge colours (a wall that gets lighter)
    flooded = [False] * n
    st = []
    for y in range(H):
        for x in range(W):
            if (x < 2 or x >= W - 2 or y < 2) and not flooded[y * W + x]:
                flooded[y * W + x] = True; st.append(y * W + x)
    TAU = 16.0
    while st:
        i = st.pop(); x, y = i % W, i // W
        r, g, b = px[i]
        for xx, yy in ((x + 1, y), (x - 1, y), (x, y + 1), (x, y - 1)):
            if 0 <= xx < W and 0 <= yy < H:
                j = yy * W + xx
                if not flooded[j]:
                    r2, g2, b2 = px[j]
                    if math.sqrt((r - r2) ** 2 + (g - g2) ** 2 + (b - b2) ** 2) < TAU:
                        flooded[j] = True; st.append(j)
    mask = [(v > cut) and not flooded[i] for i, v in enumerate(score)]
    comps = components(mask, W, H)
    if not comps:
        print("none"); return
    comps.sort(key=lambda c: -sum(score[i] for i in c))
    keep = [False] * n
    first = comps[0]
    for c in comps:
        if len(c) >= max(6, 0.25 * len(first)) or c is first:
            for i in c: keep[i] = True
    # fill small holes: a cell with subject on both sides (row and column) is subject too
    for y in range(H):
        xs = [x for x in range(W) if keep[y * W + x]]
        if xs and xs[-1] - xs[0] < 0.7 * W:
            for x in range(xs[0], xs[-1] + 1): keep[y * W + x] = True
    # shave one cell off the edge of the shape (it is a rough guess: better a little too small than blocking empty wall)
    shaved = keep[:]
    for y in range(H):
        for x in range(W):
            if keep[y * W + x]:
                for xx, yy in ((x + 1, y), (x - 1, y), (x, y + 1), (x, y - 1)):
                    if 0 <= xx < W and 0 <= yy < H and not keep[yy * W + xx]:
                        shaved[y * W + x] = False; break
    keep = shaved
    area = sum(keep) / n
    if area > 0.6 or area < 0.02:
        print("none"); return
    print(W, H)
    for y in range(H):
        print("".join("1" if keep[y * W + x] else "0" for x in range(W)))

try:
    main()
except Exception:
    print("none")
