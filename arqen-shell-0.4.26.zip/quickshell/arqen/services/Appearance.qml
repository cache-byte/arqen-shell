pragma Singleton
import Quickshell
import Quickshell.Io
import QtQuick
import qs.config

// Makes other apps (GTK / GNOME / libadwaita, Flatpak, Qt / KDE) follow Arqen's dark or light
// mode, accent colour, app theme, icons, cursor and font, by running scripts/apply-theme.sh
// whenever one of them changes. Also lists the installed themes, cursors and fonts for the
// pickers in Settings > Fonts, themes and cursor (scripts/list-themes.sh).
Singleton {
    id: root
    readonly property string scripts: Qt.resolvedUrl("../scripts/").toString().replace("file://", "")

    property var gtkThemes: []
    property var iconThemes: []
    property var cursorThemes: []
    property var fonts: []
    property bool listed: false

    function init() { startup.start() }
    Timer { id: startup; interval: 2500; onTriggered: { root.refreshLists(); root.apply(); root.syncIconTheme() } }

    // ---- the shell's own icons (launcher, search, dock, desktop) follow the icon theme ----
    // Quickshell picks its icon theme when it starts ("//@ pragma IconTheme" in shell.qml), so a
    // change is written there and the shell restarts itself once.
    readonly property string shellFile: Qt.resolvedUrl("../shell.qml").toString().replace("file://", "")
    function syncIconTheme() {
        if (iconProc.running) return
        iconProc.command = ["sh", root.scripts + "set-icon-theme.sh", root.shellFile, Config.c.iconTheme || ""]
        iconProc.running = true
    }
    Process {
        id: iconProc
        stdout: StdioCollector { onStreamFinished: if (text.trim() === "changed") root.restartShell() }
    }
    function restartShell() {
        Quickshell.execDetached(["sh", "-c", "sleep 1; setsid qs -c arqen -d >/dev/null 2>&1 &"])
        Qt.quit()
    }

    // ---- what apps are told (dark / light), through the desktop portal ----
    property string portalScheme: ""        // "dark" | "light" | "default" | "none" (portal not answering)
    function checkPortal() { if (!portalProc.running) portalProc.running = true }
    Process {
        id: portalProc
        command: ["sh", "-c", "gdbus call --session --timeout 3 --dest org.freedesktop.portal.Desktop --object-path /org/freedesktop/portal/desktop --method org.freedesktop.portal.Settings.ReadOne org.freedesktop.appearance color-scheme 2>&1"]
        stdout: StdioCollector {
            onStreamFinished: {
                const m = /uint32 (\d)/.exec(text)
                root.portalScheme = !m ? "none" : (m[1] === "1" ? "dark" : (m[1] === "2" ? "light" : "default"))
            }
        }
    }

    // ---- lists for the pickers ----
    function refreshLists() { if (!lister.running) lister.running = true }
    Process {
        id: lister
        command: ["sh", root.scripts + "list-themes.sh"]
        stdout: StdioCollector { onStreamFinished: root.parse(text) }
    }
    function parse(t) {
        const out = { GTK: [], ICONS: [], CURSORS: [], FONTS: [] }
        let cur = ""
        for (const line of t.split("\n")) {
            const l = line.trim()
            if (l.startsWith("@@")) { cur = l.slice(2); continue }
            if (l !== "" && out[cur]) out[cur].push(l)
        }
        gtkThemes = out.GTK
        iconThemes = out.ICONS
        cursorThemes = out.CURSORS
        fonts = out.FONTS
        listed = true
    }

    // GNOME's named accents (GNOME 47+), nearest to our colour, for apps that only know those
    function accentName(hex) {
        const c = Qt.color(hex)
        if (c.hslSaturation < 0.2) return "slate"
        const h = c.hslHue * 360
        if (h < 15 || h >= 345) return "red"
        if (h < 40) return "orange"
        if (h < 65) return "yellow"
        if (h < 160) return "green"
        if (h < 195) return "teal"
        if (h < 255) return "blue"
        if (h < 290) return "purple"
        return "pink"
    }

    // ---- apply ----
    property bool again: false
    function apply() {
        if (!Config.c.themeApps) return
        const a = Config.c
        applier.command = ["sh", root.scripts + "apply-theme.sh",
            a.darkMode ? "1" : "0", a.accent, accentName(a.accent),
            a.gtkTheme || "auto", a.iconTheme || "", a.cursorTheme || "", String(a.cursorSize || 24),
            a.appFont || a.fontFamily || "", String(a.appFontSize || 11)]
        if (applier.running) again = true
        else applier.running = true
    }
    Process {
        id: applier
        onExited: { if (root.again) { root.again = false; root.apply() } else portalTimer.restart() }
    }
    Timer { id: soon; interval: 600; onTriggered: root.apply() }
    Timer { id: portalTimer; interval: 800; onTriggered: root.checkPortal() }

    Timer { id: iconTimer; interval: 1500; onTriggered: root.syncIconTheme() }
    Connections {
        target: Config.c
        function onDarkModeChanged() { soon.restart() }
        function onAccentChanged() { soon.restart() }
        function onGtkThemeChanged() { soon.restart() }
        function onIconThemeChanged() { soon.restart(); iconTimer.restart() }
        function onCursorThemeChanged() { soon.restart() }
        function onCursorSizeChanged() { soon.restart() }
        function onAppFontChanged() { soon.restart() }
        function onAppFontSizeChanged() { soon.restart() }
        function onFontFamilyChanged() { soon.restart() }
        function onThemeAppsChanged() { soon.restart() }
    }
}
