pragma Singleton
import Quickshell
import Quickshell.Io
import Quickshell.Bluetooth
import QtQuick
import qs.config

// The things plugged into / connected to this computer that the shell draws:
//  - Bluetooth devices: what kind each is (earbuds, headphones, a controller, a mouse...) from what
//    the device says it is and its name, and its battery when it reports one.
//  - Everything else plugged in or paired (cable, a 2.4 GHz receiver), with its battery: scripts/peripherals.py.
Singleton {
    id: root
    function init() {}

    // ---------- Bluetooth ----------
    readonly property var connected: (Bluetooth.devices?.values ?? []).filter(d => d.connected)

    // the kind of device: from BlueZ's icon name first, then the name (many earbuds say only "audio-card")
    function kind(d) {
        if (!d) return "other"
        const ic = (d.icon || "").toLowerCase()
        const n = ((d.name || "") + " " + (d.deviceName || "")).toLowerCase()
        if (/airpods max/.test(n)) return "headphones"
        if (/airpods|buds|earbud|earphone|freebuds|earfun|wf-\d|tws|elite \d|soundcore (liberty|life p|space a)|nothing ear|pixel buds|jabra elite|beats (fit|studio buds|flex)|powerbeats|in-ear/.test(n)) return "earbuds"
        if (/controller|gamepad|xbox|dualsense|dualshock|wireless controller|pro controller|joy-con|8bitdo|stadia|gamesir|joystick|switch pro/.test(n) || ic === "input-gaming") return "controller"
        if (/airpods max|headphone|wh-\d|qc\s?\d|quietcomfort|bose 700|momentum|studio pro|xm\d|maxwell|arctis|cloud|headset|hyperx/.test(n)) return /headset|arctis|cloud|hyperx/.test(n) || ic === "audio-headset" ? "headset" : "headphones"
        if (ic === "audio-headset") return "headset"
        if (ic === "audio-headphones") return "headphones"
        if (/speaker|soundlink|flip|charge \d|boom|soundcore (motion|flare)|sonos|homepod|echo|soundbar/.test(n) || ic === "audio-speakers") return "speaker"
        if (ic === "audio-card") return "speaker"
        if (/keyboard|keys|mx keys/.test(n) || ic === "input-keyboard") return "keyboard"
        if (/mouse|mx master|mx anywhere|trackball|trackpad|magic trackpad/.test(n) || ic === "input-mouse") return "mouse"
        if (/\bpen\b|stylus|pencil/.test(n) || ic === "input-tablet") return "pen"
        if (/watch|band|fitbit|garmin|amazfit/.test(n)) return "watch"
        if (ic === "phone" || /phone|galaxy s|pixel \d|iphone/.test(n)) return "phone"
        if (/ipad|\btab\b|galaxy tab/.test(n)) return "tablet"
        if (ic === "computer" || /macbook|laptop|\bpc\b/.test(n)) return "computer"
        if (/\btv\b|bravia/.test(n) || ic === "video-display") return "tv"
        if (ic === "camera-video" || ic === "camera-photo") return "camera"
        if (ic === "printer") return "printer"
        if (ic.indexOf("audio") === 0) return "headphones"
        return "other"
    }
    readonly property var icons: ({
        earbuds: "earbuds", headphones: "headphones", headset: "headset_mic", speaker: "speaker",
        controller: "sports_esports", keyboard: "keyboard", mouse: "mouse", pen: "stylus",
        watch: "watch", phone: "smartphone", tablet: "tablet", computer: "computer", tv: "tv",
        camera: "photo_camera", printer: "print", other: "bluetooth"
    })
    readonly property var names: ({
        earbuds: "Earbuds", headphones: "Headphones", headset: "Headset", speaker: "Speaker",
        controller: "Game controller", keyboard: "Keyboard", mouse: "Mouse", pen: "Pen",
        watch: "Watch", phone: "Phone", tablet: "Tablet", computer: "Computer", tv: "TV",
        camera: "Camera", printer: "Printer", other: "Device"
    })
    function icon(d) { return icons[kind(d)] ?? "bluetooth" }
    function isAudio(d) { return ["earbuds", "headphones", "headset", "speaker"].indexOf(kind(d)) >= 0 }
    // Normalized charge fraction (0..1), or -1 when unavailable. BlueZ wrappers
    // may expose Battery1.Percentage as 0..100 while some Quickshell versions
    // expose a normalized fraction; normalize both so every UI consumer agrees.
    // The exact battery of paired phones from KDE Connect (name -> { charge, charging }); BlueZ only gets a rough step
    // from most phones (20 % at a time, from the hands-free profile)
    property var phoneBat: ({})
    function norm(n) { return String(n || "").toLowerCase().replace(/[^a-z0-9]/g, "") }
    Process {
        id: phoneProc
        command: ["sh", Quickshell.shellDir + "/scripts/phone-battery.sh"]
        stdout: StdioCollector {
            onStreamFinished: {
                const m = {}
                for (const l of text.split("\n")) {
                    const p = l.split("\t")
                    if (p.length >= 2 && p[0] !== "") m[root.norm(p[0])] = { charge: parseInt(p[1]), charging: p[2] === "1" }
                }
                root.phoneBat = m
            }
        }
    }
    Timer { interval: 60000; repeat: true; running: root.connected.length > 0; triggeredOnStart: true; onTriggered: if (!phoneProc.running) phoneProc.running = true }
    onConnectedChanged: if (connected.length > 0 && !phoneProc.running) phoneProc.running = true
    function phoneEntry(d) { return d ? (phoneBat[norm(d.name || d.deviceName)] ?? null) : null }
    // true when the figure is only the phone's rough step (a phone, no exact figure, a multiple of 20)
    function approx(d) {
        if (!d || kind(d) !== "phone" || phoneEntry(d)) return false
        const raw = Number(d.battery); const pct = Math.round((raw > 1 ? raw : raw * 100))
        return d.batteryAvailable && pct % 20 === 0
    }
    // Normalized charge fraction (0..1), or -1 when unavailable. KDE Connect's exact figure for a phone when there is
    // one; else BlueZ's (some versions give 0..100, others a fraction: both are handled).
    function battery(d) {
        const e = phoneEntry(d)
        if (e && e.charge >= 0) return Math.max(0, Math.min(1, e.charge / 100))
        if (!d || !d.batteryAvailable) return -1
        const raw = Number(d.battery)
        if (!Number.isFinite(raw) || raw < 0) return -1
        return Math.max(0, Math.min(1, raw > 1 ? raw / 100 : raw))
    }
    // "85 %", or "about 40 %" for a phone's rough step
    function batteryText(d) {
        const b = battery(d)
        return b < 0 ? "" : (approx(d) ? "about " : "") + Math.round(b * 100) + " %"
    }

    // Left / right sound check on this device (or the current output when it cannot be found)
    function soundTest(d, side) {
        const mac = d ? String(d.address).replace(/:/g, "_") : ""
        Quickshell.execDetached(["sh", Quickshell.shellDir + "/scripts/lr-test.sh", side, mac])
    }

    // looked at again when input devices come and go (and every minute, for batteries)
    function refresh() { refreshPeripherals() }
    Process {
        running: true
        command: ["sh", "-c", "command -v udevadm >/dev/null && exec udevadm monitor --udev --subsystem-match=input"]
        stdout: SplitParser { onRead: line => { if (/(add|remove)\s/.test(line)) soon.restart() } }
    }
    Timer { id: soon; interval: 600; onTriggered: root.refreshPeripherals() }
    Timer { interval: 60000; repeat: true; running: true; onTriggered: root.refreshPeripherals() }
    Component.onCompleted: refreshPeripherals()

    // ---------- everything plugged in or paired, any way: Bluetooth, cable, 2.4 GHz receiver ----------
    // { name, kind, bus ("usb" | "bluetooth" | "other"), dongle (the receiver's name, or ""), battery (0..100 or -1),
    //   charging, via }: from scripts/peripherals.py (what the system knows, from the kernel's own device lists)
    property var peripherals: []
    // the ones the Bluetooth list above does not already show
    readonly property var otherPeripherals: peripherals.filter(d => d.bus !== "bluetooth"
        && !connected.some(c => (c.name || "").toLowerCase() === d.name.toLowerCase()))
    Process {
        id: periLister
        command: ["python3", Quickshell.shellDir + "/scripts/peripherals.py"]
        stdout: StdioCollector {
            onStreamFinished: { try { root.peripherals = JSON.parse(text).devices || [] } catch (e) {} }
        }
    }
    function refreshPeripherals() { if (!periLister.running) periLister.running = true }
    function periIcon(d) { return icons[d.kind === "other" ? "other" : d.kind === "headset" ? "headset" : d.kind] ?? "devices_other" }
    function periKind(d) { return names[d.kind] ?? "Device" }
    function periWhere(d) { return d.dongle !== "" ? "Through " + d.dongle : d.bus === "usb" ? "USB cable or receiver" + (d.via ? " (" + d.via + ")" : "") : d.bus === "bluetooth" ? "Bluetooth" : "Connected" }
}
