pragma Singleton
import Quickshell
import Quickshell.Io
import QtQuick
import qs.config

// The on-screen keyboard (panel item "On-screen keyboard"): what is showing and what a key does.
// Keys are typed into the window you were using with wtype; the keyboard itself never takes the
// keyboard focus, so that window stays focused. The keyboard is drawn by modules/Keyboard.qml.
Singleton {
    id: root
    property bool shown: false
    function toggle() { shown = !shown }

    // what the keyboard shows: keys | emoji | gif
    property string tab: "keys"
    // keys: letters | symbols | symbols2
    property string layer: "letters"
    property bool shift: false          // one capital
    property bool caps: false           // all capitals (double-tap shift)
    // split in two halves, one at each side (remembered)
    property bool split: Config.c.oskSplit
    onSplitChanged: if (Config.c.oskSplit !== split) Config.c.oskSplit = split
    property bool ctrl: false           // held for the next key
    property bool alt: false
    // typing into the keyboard's own search box (emoji / GIF search) instead of the window
    property bool searching: false
    property string query: ""

    // ---- languages: the letters shown (what is typed is exactly the character on the key) ----
    readonly property var languages: [
        { id: "en", name: "English",    rows: ["qwertyuiop", "asdfghjkl", "zxcvbnm"] },
        { id: "fr", name: "Français",   rows: ["azertyuiop", "qsdfghjklm", "wxcvbn'éèàç"] },
        { id: "de", name: "Deutsch",    rows: ["qwertzuiopü", "asdfghjklöä", "yxcvbnmß"] },
        { id: "es", name: "Español",    rows: ["qwertyuiop", "asdfghjklñ", "zxcvbnmáéíóú"] },
        { id: "pt", name: "Português",  rows: ["qwertyuiop", "asdfghjklç", "zxcvbnmãõáéê"] },
        { id: "it", name: "Italiano",   rows: ["qwertyuiop", "asdfghjklè", "zxcvbnmàéìòù"] },
        { id: "sw", name: "Kiswahili",  rows: ["qwertyuiop", "asdfghjkl", "zxcvbnm"] },
        { id: "ru", name: "Русский",    rows: ["йцукенгшщзх", "фывапролджэ", "ячсмитьбю"] },
        { id: "uk", name: "Українська", rows: ["йцукенгшщзхї", "фівапролджє", "ячсмитьбюґ"] },
        { id: "el", name: "Ελληνικά",   rows: ["ςερτυθιοπ", "ασδφγηξκλ", "ζχψωβνμ"] },
        { id: "ar", name: "العربية",    rows: ["ضصثقفغعهخحج", "شسيبلاتنمكط", "ئءؤرىةوزظد"] },
        { id: "hi", name: "हिन्दी",      rows: ["ौैाीूबहगदजड", "ोे्िुपरकतचट", "ंमनवलसयशषञ"] },
        { id: "nl", name: "Nederlands", rows: ["qwertyuiop", "asdfghjkl", "zxcvbnmëéï"] },
        { id: "af", name: "Afrikaans",  rows: ["qwertyuiop", "asdfghjklê", "zxcvbnmëéô"] },
        { id: "zu", name: "isiZulu",    rows: ["qwertyuiop", "asdfghjkl", "zxcvbnm"] },
        { id: "ny", name: "Chichewa / Bemba", rows: ["qwertyuiop", "asdfghjklŵ", "zxcvbnm"] },
        { id: "yo", name: "Yorùbá",     rows: ["qwertyuiop", "asdfghjklẹ", "zxcvbnmọṣàá"] },
        { id: "ha", name: "Hausa",      rows: ["qwertyuiop", "asdfghjklƙ", "zxcvbnmɓɗƴ"] },
        { id: "am", name: "አማርኛ",       rows: ["ሀለሐመሠረሰሸቀበ", "ተቸነኘአከወዐዘዠ", "የደጀገጠጨጰጸፀፈ"] },
        { id: "pl", name: "Polski",     rows: ["qwertyuiopż", "asdfghjklłą", "zxcvbnmśćęńó"] },
        { id: "cs", name: "Čeština",    rows: ["qwertzuiopú", "asdfghjklůě", "yxcvbnmščřžý"] },
        { id: "sk", name: "Slovenčina", rows: ["qwertzuiopá", "asdfghjklôä", "yxcvbnmščťžľ"] },
        { id: "hu", name: "Magyar",     rows: ["qwertzuiopő", "asdfghjkléá", "yxcvbnmöüóű"] },
        { id: "ro", name: "Română",     rows: ["qwertyuiopă", "asdfghjklșț", "zxcvbnmâî"] },
        { id: "hr", name: "Hrvatski",   rows: ["qwertzuiopš", "asdfghjklčć", "yxcvbnmđž"] },
        { id: "sv", name: "Svenska",    rows: ["qwertyuiopå", "asdfghjklöä", "zxcvbnm"] },
        { id: "no", name: "Norsk",      rows: ["qwertyuiopå", "asdfghjkløæ", "zxcvbnm"] },
        { id: "da", name: "Dansk",      rows: ["qwertyuiopå", "asdfghjklæø", "zxcvbnm"] },
        { id: "fi", name: "Suomi",      rows: ["qwertyuiopå", "asdfghjklöä", "zxcvbnm"] },
        { id: "is", name: "Íslenska",   rows: ["qwertyuiopð", "asdfghjklæþ", "zxcvbnmáéíóö"] },
        { id: "tr", name: "Türkçe",     rows: ["qwertyuıopğü", "asdfghjklşi", "zxcvbnmöç"] },
        { id: "az", name: "Azərbaycan", rows: ["qwertyuıopğü", "asdfghjklşə", "zxcvbnmöç"] },
        { id: "lt", name: "Lietuvių",   rows: ["ąčęėįšųūž", "qwertyuiop", "asdfghjklzxcvbnm"] },
        { id: "lv", name: "Latviešu",   rows: ["qwertyuiopē", "asdfghjklūī", "zxcvbnmāčšņ"] },
        { id: "et", name: "Eesti",      rows: ["qwertyuiopüõ", "asdfghjklöä", "zxcvbnmšž"] },
        { id: "bg", name: "Български",  rows: ["яверътуиопч", "асдфгхйклшщ", "зьцжбнмю"] },
        { id: "sr", name: "Српски",     rows: ["љњертзуиопш", "асдфгхјклчћ", "џцвбнмђж"] },
        { id: "kk", name: "Қазақ",      rows: ["йцукенгшщзх", "фывапролджэ", "ячсмитьбюәіңғүұқөһ"] },
        { id: "he", name: "עברית",       rows: ["קראטוןםפ", "שדגכעיחלךף", "זסבהנמצתץ"] },
        { id: "fa", name: "فارسی",       rows: ["ضصثقفغعهخحج", "شسیبلاتنمکگ", "ظطزرذدپوچژ"] },
        { id: "ur", name: "اردو",        rows: ["طصھدٹپتبجح", "مورنلہاکیق", "فےسشغعژزذخ"] },
        { id: "bn", name: "বাংলা",       rows: ["ৌৈাীূবহগদজড", "োে্িুপরকতচট", "ংমনবলসযশষঞ"] },
        { id: "ta", name: "தமிழ்",       rows: ["ஆஈஊஐஏளறனடணசஞ", "அஇஉ்எகபமதநய", "ஔஓஒவஙலரழ"] },
        { id: "th", name: "ไทย",         rows: ["ๆไำพะัีรนยบลฃ", "ฟหกดเ้่าสวง", "ผปแอิืทมใฝ"] },
        { id: "vi", name: "Tiếng Việt", rows: ["qwertyuiopươ", "asdfghjklăâđ", "zxcvbnmêô"] },
        { id: "id", name: "Indonesia",  rows: ["qwertyuiop", "asdfghjkl", "zxcvbnm"] },
        { id: "tl", name: "Filipino",   rows: ["qwertyuiop", "asdfghjklñ", "zxcvbnm"] },
        { id: "ja", name: "日本語 (かな)", rows: ["あかさたなはまやらわ", "いきしちにひみゆりを", "うくすつぬふむよるん", "えけせてねへめれー", "おこそとのほもろ゛゜"] },
        { id: "ko", name: "한국어 (자모)", rows: ["ㅂㅈㄷㄱㅅㅛㅕㅑㅐㅔ", "ㅁㄴㅇㄹㅎㅗㅓㅏㅣ", "ㅋㅌㅊㅍㅠㅜㅡ"] }
    ]
    readonly property var lang: languages.find(l => l.id === (Config.c.oskLang || "en")) ?? languages[0]
    function nextLanguage() {
        const list = (Config.c.oskLangs && Config.c.oskLangs.length > 0) ? Config.c.oskLangs : languages.map(l => l.id)
        const i = list.indexOf(lang.id)
        Config.c.oskLang = list[(i + 1) % list.length]
    }
    // each row as a list of single characters (a row string can hold letters made of several code points)
    function chars(s) { return Array.from(s) }
    readonly property var letterRows: lang.rows.map(r => chars(r))
    readonly property var symbolRows: [chars("1234567890"), chars("@#$_&-+()/"), chars("*\"':;!?,.")]
    readonly property var symbol2Rows: [chars("~`|•√π÷×¶∆"), chars("£€¥^°={}\\%"), chars("©®™✓[]<>")]
    readonly property var rows: layer === "symbols" ? symbolRows : (layer === "symbols2" ? symbol2Rows : letterRows)
    readonly property bool upper: shift || caps
    function shown_(c) { return layer === "letters" && upper ? c.toLocaleUpperCase() : c }

    // ---- typing ----
    readonly property string script: Quickshell.shellDir + "/scripts/osk.sh"
    function mods() { return [ctrl ? "ctrl" : "", alt ? "alt" : ""].filter(x => x !== "").join(",") }
    function clearOneShot() { shift = false; ctrl = false; alt = false }
    // a character key
    function type(c) {
        const s = shown_(c)
        if (searching) { query += s; shift = false; return }
        if (Ui.locked) { Ui.lockEvent = { n: Ui.lockEvent.n + 1, v: "char:" + s }; clearOneShot(); return }
        if (ctrl || alt) Quickshell.execDetached(["sh", script, "char", s.toLowerCase(), mods()])
        else Quickshell.execDetached(["sh", script, "text", s])
        clearOneShot()
    }
    // any text (an emoji)
    function typeText(t) {
        if (searching) { query += t; return }
        if (Ui.locked) { Ui.lockEvent = { n: Ui.lockEvent.n + 1, v: "text:" + t }; return }
        // Emoji are mostly beyond the first 65536 characters (or joined from several). Typed as key
        // presses, browsers and many apps cut them down to some other character (the Chinese
        // characters and boxes); pasted, they arrive whole.
        const paste = /[\uD800-\uDBFF]|\uFE0F|\u200D/.test(t)
        Quickshell.execDetached(["sh", script, paste ? "paste" : "text", t])
        recent(t)
    }
    // a named key: BackSpace, Return, Tab, Escape, Left, Right, Up, Down, space, Delete, Home, End
    function key(k) {
        if (searching) {
            if (k === "BackSpace") query = query.slice(0, -1)
            else if (k === "space") query += " "
            else if (k === "Return" || k === "Escape") searching = false
            return
        }
        if (Ui.locked) { Ui.lockEvent = { n: Ui.lockEvent.n + 1, v: "key:" + k }; clearOneShot(); return }
        Quickshell.execDetached(["sh", script, "key", k, mods()])
        clearOneShot()
    }
    function tapShift() {
        // a second tap soon after the first locks capitals; a tap while locked unlocks
        if (caps) { caps = false; shift = false; return }
        const now = Date.now()
        if (shift && now - lastShift < 400) { caps = true; shift = false }
        else shift = !shift
        lastShift = now
    }
    property double lastShift: 0

    // ---- emoji ----
    property var emojiData: []
    FileView {
        path: Quickshell.shellDir + "/assets/emoji.json"
        onLoaded: { try { root.emojiData = JSON.parse(text()) } catch (e) { root.emojiData = [] } }
    }
    property int emojiCat: 0                 // -1 = recently used
    function recent(t) {
        const r = (Config.c.oskRecent || []).filter(x => x !== t)
        r.unshift(t)
        Config.c.oskRecent = r.slice(0, 32)
    }
    readonly property var emojiShown: {
        const q = query.trim().toLowerCase()
        if (tab === "emoji" && q !== "") {
            const out = []
            for (const c of emojiData) for (const e of c.emoji) if (e[1].indexOf(q) >= 0) out.push(e[0])
            return out.slice(0, 200)
        }
        if (emojiCat < 0) return Config.c.oskRecent || []
        const c = emojiData[emojiCat]
        return c ? c.emoji.map(e => e[0]) : []
    }

    // ---- GIFs (GIPHY) ----
    readonly property bool hasKey: (Config.c.giphyKey || "").trim() !== ""
    property var gifs: []                    // [{ id, title, small, full }]
    property bool gifBusy: false
    property string gifError: ""
    property string lastGifQuery: "@none"
    function loadGifs() {
        if (!hasKey) { gifs = []; return }
        const q = query.trim()
        if (q === lastGifQuery) return
        lastGifQuery = q
        const key = encodeURIComponent(Config.c.giphyKey.trim())
        const url = q === ""
            ? "https://api.giphy.com/v1/gifs/trending?api_key=" + key + "&limit=36&rating=pg-13"
            : "https://api.giphy.com/v1/gifs/search?api_key=" + key + "&q=" + encodeURIComponent(q) + "&limit=36&rating=pg-13&lang=" + lang.id
        gifBusy = true; gifError = ""
        const xhr = new XMLHttpRequest()
        xhr.onreadystatechange = function() {
            if (xhr.readyState !== XMLHttpRequest.DONE) return
            root.gifBusy = false
            if (xhr.status !== 200) {
                root.gifError = xhr.status === 401 || xhr.status === 403 ? "GIPHY did not accept the API key (Settings > Panels > On-screen keyboard)"
                                                                         : "Could not reach GIPHY (" + (xhr.status || "no connection") + ")"
                root.gifs = []
                root.lastGifQuery = "@none"
                return
            }
            try {
                const d = JSON.parse(xhr.responseText).data || []
                root.gifs = d.map(g => ({
                    id: g.id, title: g.title || "gif",
                    small: (g.images.fixed_height_small || g.images.fixed_height).url,
                    w: parseInt((g.images.fixed_height_small || g.images.fixed_height).width) || 150,
                    h: parseInt((g.images.fixed_height_small || g.images.fixed_height).height) || 100,
                    full: (g.images.original || g.images.downsized || g.images.fixed_height).url
                }))
            } catch (e) { root.gifError = "GIPHY sent something unexpected"; root.gifs = [] }
        }
        xhr.open("GET", url)
        xhr.send()
    }
    Timer { id: gifDelay; interval: 450; onTriggered: root.loadGifs() }
    onQueryChanged: if (tab === "gif") gifDelay.restart()
    onTabChanged: { query = ""; searching = false; if (tab === "gif") { lastGifQuery = "@none"; loadGifs() } }
    function gifInsert(g) { Quickshell.execDetached(["sh", script, "gif-insert", g.full]) }
    function gifCopy(g) { Quickshell.execDetached(["sh", script, "gif-copy", g.full]) }
    function gifDownload(g) { Quickshell.execDetached(["sh", script, "gif-download", g.full, g.title]) }
    function gifLink(g) { Quickshell.execDetached(["sh", script, "link", "https://giphy.com/gifs/" + g.id]) }
}
