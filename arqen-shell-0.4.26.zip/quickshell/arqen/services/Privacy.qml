pragma Singleton
import Quickshell
import Quickshell.Io
import Quickshell.Services.Pipewire
import QtQuick
import qs.config

// What is using the microphone, the camera or the screen right now, for the indicators in the panel (like a
// phone's green / orange dots). Read from PipeWire: a microphone or camera that is linked to an app's stream is
// in use; a screen being shared shows as a video stream coming from the compositor. Apps that open the camera
// directly (not through PipeWire) are found by looking at which programs have /dev/video* open.
Singleton {
    id: root

    readonly property var nodes: Pipewire.nodes.values
    PwObjectTracker { objects: root.nodes }

    function cls(n) { return String(n?.properties?.["media.class"] ?? "") }
    function appOf(n) {
        const p = n?.properties ?? {}
        return String(p["application.name"] || p["node.description"] || n?.description || n?.nickname || n?.name || "")
    }

    // links: [{ src, dst }] as PipeWire nodes; a "link group" is one connection between two nodes
    readonly property var pairs: {
        const out = []
        try {
            for (const g of Pipewire.linkGroups.values) {
                if (g.source && g.target) out.push({ src: g.source, dst: g.target })
            }
        } catch (e) {}
        return out
    }
    // names of the apps for which `test(srcClass, dstClass)` holds
    function users(test) {
        const names = []
        for (const p of pairs) {
            if (!test(cls(p.src), cls(p.dst))) continue
            // the app is the stream end of the link
            const app = appOf(p.dst.isStream ? p.dst : p.src)
            if (app !== "" && names.indexOf(app) < 0) names.push(app)
        }
        return names
    }

    readonly property var micApps: users((s, d) => s === "Audio/Source" && d === "Stream/Input/Audio")
    readonly property var cameraPw: users((s, d) => s === "Video/Source" && d === "Stream/Input/Video")
    // a screen being shared: a stream the compositor makes, taken by an app
    readonly property var screenApps: users((s, d) => s === "Stream/Output/Video" && d === "Stream/Input/Video")

    // cameras opened directly
    property var cameraDirect: []
    readonly property var cameraApps: cameraPw.concat(cameraDirect.filter(a => cameraPw.indexOf(a) < 0))

    readonly property bool mic: micApps.length > 0
    readonly property bool camera: cameraApps.length > 0
    readonly property bool screen: screenApps.length > 0
    readonly property bool any: mic || camera || screen

    Process {
        id: scan
        // (one `find` over the open files: the old loop started two programs for every running process, every 3 seconds;
        // and nothing at all when the computer has no camera device)
        command: ["sh", "-c", "ls /dev/video* >/dev/null 2>&1 || exit 0; for p in $(find /proc/[0-9]*/fd -maxdepth 1 -lname '/dev/video*' 2>/dev/null | cut -d/ -f3 | sort -u); do cat /proc/$p/comm 2>/dev/null; done | sort -u"]
        stdout: StdioCollector {
            onStreamFinished: {
                root.cameraDirect = text.split("\n").map(s => s.trim()).filter(s => s !== "" && !/^(pipewire|wireplumber|pipewire-pulse)/.test(s))
            }
        }
    }
    Timer {
        interval: 8000; repeat: true; running: Config.c.privacyIndicators
        triggeredOnStart: true
        onTriggered: if (!scan.running) scan.running = true
    }
}
