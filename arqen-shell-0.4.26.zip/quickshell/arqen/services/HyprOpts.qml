pragma Singleton
import Quickshell
import Quickshell.Io
import QtQuick
import qs.config

// The Hyprland options Settings can change (Settings > Hyprland, Mouse and keyboard): the catalogue is
// assets/hypr-schema.json (made from the Hyprland wiki by tools/gen-hypr-schema.py, options the shell sets
// itself are left out); what you picked is Config.c.hyprOpts, written into Hyprland's config by Config.qml.
Singleton {
    id: root
    property var pages: []
    readonly property bool loaded: pages.length > 0

    FileView {
        path: Quickshell.shellDir + "/assets/hypr-schema.json"
        printErrors: false
        onLoaded: { try { root.pages = JSON.parse(text()).pages } catch (e) { console.warn("[arqen] hypr-schema.json:", e) } }
    }

    function page(id) { return pages.find(p => p.id === id) || null }
    function has(key) { return (Config.c.hyprOpts || {})[key] !== undefined }
    function get(opt) { const v = (Config.c.hyprOpts || {})[opt.key]; return v !== undefined ? v : (Config.optDefaults[opt.key] !== undefined ? Config.optDefaults[opt.key] : opt.default) }
    function set(key, value) {
        const o = Object.assign({}, Config.c.hyprOpts || {})
        o[key] = value
        Config.c.hyprOpts = o
    }
    function reset(key) {
        const o = Object.assign({}, Config.c.hyprOpts || {})
        delete o[key]
        Config.c.hyprOpts = o
    }
    function resetPage(id) {
        const p = page(id)
        if (!p) return
        const o = Object.assign({}, Config.c.hyprOpts || {})
        for (const s of p.sections) for (const op of s.options) delete o[op.key]
        Config.c.hyprOpts = o
    }
    // text the Settings search matches
    function keywords(ids) {
        const out = []
        for (const id of ids) {
            const p = page(id)
            if (!p) continue
            for (const s of p.sections) for (const o of s.options) out.push(o.label, o.key.replace(/[._]/g, " "), o.desc || "")
        }
        return out.join(" ")
    }
}
