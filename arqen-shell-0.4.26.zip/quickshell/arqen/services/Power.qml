pragma Singleton
import Quickshell
import Quickshell.Io
import Quickshell.Services.UPower
import QtQuick
import qs.config

// Battery notifications (charged, low, critically low: Settings > Power) and the facts shown on that
// page: how long the computer has been up, battery health, charge cycles...
Singleton {
    id: root
    readonly property var bat: UPower.displayDevice
    readonly property bool hasBattery: bat && bat.isLaptopBattery
    readonly property int pct: hasBattery ? Math.round(bat.percentage * 100) : -1
    readonly property bool charging: hasBattery && (bat.state === UPowerDeviceState.Charging || bat.state === UPowerDeviceState.PendingCharge)
    // the lighter mode: on battery (auto), always, or never (Settings > Power > Shell saver)
    readonly property bool saving: Config.c.shellSaver === "on" || (Config.c.shellSaver !== "off" && hasBattery && !plugged)
    readonly property bool plugged: hasBattery && bat.state !== UPowerDeviceState.Discharging && bat.state !== UPowerDeviceState.Empty

    // ---- notifications: each one once, until the battery goes the other way ----
    property bool sentFull: false
    property bool sentLow: false
    property bool sentCritical: false
    property double unpluggedAt: 0           // when the charger was last taken out (this session)
    property double startedAt: Date.now()    // when the shell started (about when you logged in)

    function init() {
        if (hasBattery && !plugged) unpluggedAt = Date.now()
        // already charged when the shell starts: no "Battery full" at every login
        if (plugged && pct >= Config.c.batteryFull) sentFull = true
        check()
    }
    function notify(icon, title, body, urgency) {
        Quickshell.execDetached(["notify-send", "-a", "Arqen", "-i", icon, "-u", urgency || "normal", title, body])
    }
    function sound(names) { if (Config.c.soundPower) Sounds.playNames(names) }
    function check() {
        if (!hasBattery || pct < 0) return
        const c = Config.c
        if (plugged) {
            sentLow = false; sentCritical = false
            if (c.batteryFullOn && !sentFull && pct >= c.batteryFull) {
                sentFull = true
                notify("battery-full-charged", c.batteryFull >= 100 ? "Battery full" : "Battery at " + pct + "%",
                       "You can unplug the charger" + (c.batteryFull < 100 ? " (the limit set in Settings > Power)" : ""))
                sound(["complete", "power-plug"])
            }
            if (pct < c.batteryFull - 3) sentFull = false
            return
        }
        sentFull = false
        if (c.batteryCriticalOn && !sentCritical && pct <= c.batteryCritical) {
            sentCritical = true; sentLow = true
            const act = c.batteryCriticalAction || "none"
            notify("battery-caution", "Battery critically low: " + pct + "%",
                   act === "none" ? "Plug in the charger now" : "Plug in the charger. The computer will " + ({ suspend: "go to sleep", hibernate: "hibernate", poweroff: "shut down" })[act] + " in a minute",
                   "critical")
            sound(["battery-caution", "battery-low", "dialog-warning"])
            if (act !== "none") criticalTimer.restart()
            return
        }
        if (c.batteryLowOn && !sentLow && pct <= c.batteryLow) {
            sentLow = true
            notify("battery-low", "Battery low: " + pct + "%", "Plug in the charger soon")
            sound(["battery-low", "dialog-warning"])
        }
        if (pct > c.batteryLow + 2) sentLow = false
        if (pct > c.batteryCritical + 2) sentCritical = false
    }
    // the action at critically low: a minute's grace, and not if the charger went in meanwhile
    Timer {
        id: criticalTimer
        interval: 60000
        onTriggered: {
            if (root.plugged) return
            const act = Config.c.batteryCriticalAction
            if (act === "suspend") Quickshell.execDetached(["systemctl", "suspend"])
            else if (act === "hibernate") Quickshell.execDetached(["systemctl", "hibernate"])
            else if (act === "poweroff") Quickshell.execDetached(["systemctl", "poweroff"])
        }
    }
    Connections {
        target: root.bat
        function onPercentageChanged() { root.check() }
        function onStateChanged() {
            if (!root.plugged && root.unpluggedAt === 0) root.unpluggedAt = Date.now()
            if (root.plugged) { root.unpluggedAt = 0; criticalTimer.stop() }
            root.check()
        }
    }

    function duration(sec) {
        sec = Math.max(0, Math.round(sec))
        const d = Math.floor(sec / 86400), h = Math.floor(sec % 86400 / 3600), m = Math.floor(sec % 3600 / 60)
        return (d > 0 ? d + " d " : "") + (d > 0 || h > 0 ? h + " h " : "") + m + " min"
    }
}
