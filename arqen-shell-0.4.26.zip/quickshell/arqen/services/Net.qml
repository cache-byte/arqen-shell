pragma Singleton
import Quickshell
import Quickshell.Io
import QtQuick
import qs.config

Singleton {
    id: root
    property bool wifiOn: false
    property string ssid: ""
    property int signal: 0            // of the network in use, 0..100
    property bool wired: false        // connected by cable
    // the Wi-Fi icon for how strong it is (Material Symbols)
    readonly property string icon: !wifiOn ? (wired ? "lan" : "wifi_off")
        : ssid === "" ? (wired ? "lan" : "wifi_find")
        : signal >= 70 ? "wifi" : signal >= 45 ? "wifi_2_bar" : signal >= 20 ? "wifi_1_bar" : "signal_wifi_0_bar"
    property var networks: []         // [{ ssid, signal, secure, active, saved }], strongest first
    property bool scanning: false
    property string status: ""        // "Connecting to ...", or why a connection failed

    function refresh() { proc.running = true }
    function toggleWifi() {
        Quickshell.execDetached(["nmcli", "radio", "wifi", wifiOn ? "off" : "on"])
        wifiOn = !wifiOn
        settle.restart()
    }

    // ---- networks in range (the Wi-Fi tile's menu) ----
    // nmcli's terse output separates fields with ':' and escapes a ':' inside a value as '\:'
    function splitTerse(line) {
        const out = []
        let cur = ""
        for (let i = 0; i < line.length; i++) {
            const ch = line[i]
            if (ch === "\\" && i + 1 < line.length) cur += line[++i]
            else if (ch === ":") { out.push(cur); cur = "" }
            else cur += ch
        }
        out.push(cur)
        return out
    }
    function parseNetworks(text) {
        const parts = text.split("\n---\n")
        const savedNames = {}
        for (const line of (parts[1] || "").split("\n")) {
            const f = splitTerse(line)
            if (f.length >= 2 && (f[1] === "802-11-wireless" || f[1] === "wifi")) savedNames[f[0]] = true
        }
        const best = {}
        for (const line of (parts[0] || "").split("\n")) {
            if (line.trim() === "") continue
            const f = splitTerse(line)
            const name = f[1]
            if (!name) continue
            const sig = parseInt(f[2]) || 0
            const n = { ssid: name, signal: sig, secure: (f[3] || "") !== "" && f[3] !== "--", active: f[0] === "*", saved: savedNames[name] === true }
            const old = best[name]
            if (!old || n.active || (!old.active && sig > old.signal)) best[name] = n
        }
        const list = Object.keys(best).map(k => best[k])
        list.sort((a, b) => (b.active ? 1 : 0) - (a.active ? 1 : 0) || b.signal - a.signal)
        root.networks = list
        root.scanning = false
    }
    function scan() { if (!listProc.running) listProc.running = true }
    function rescan() {
        scanning = true
        Quickshell.execDetached(["nmcli", "dev", "wifi", "rescan"])
        scan()
        rescanTimer.restart()
    }
    function connect(name, password, saved) {
        if (connProc.running) return
        status = "Connecting to " + name + "..."
        if (saved) connProc.command = ["nmcli", "connection", "up", "id", name]
        else if (password) connProc.command = ["nmcli", "--wait", "25", "dev", "wifi", "connect", name, "password", password]
        else connProc.command = ["nmcli", "--wait", "25", "dev", "wifi", "connect", name]
        connProc.running = true
    }
    function disconnect(name) {
        Quickshell.execDetached(["nmcli", "connection", "down", "id", name])
        settle.restart()
        rescanTimer.restart()
    }

    Process {
        id: listProc
        command: ["sh", "-c", "nmcli -t -f IN-USE,SSID,SIGNAL,SECURITY dev wifi list; echo; echo ---; nmcli -t -f NAME,TYPE connection show"]
        stdout: StdioCollector { onStreamFinished: root.parseNetworks(text) }
    }
    Process {
        id: connProc
        stdout: StdioCollector { id: connOut }
        stderr: StdioCollector { id: connErr }
        onExited: (code, st) => {
            const msg = (connErr.text || connOut.text).trim().split("\n")[0]
            root.status = code === 0 ? "" : (msg || "Could not connect")
            root.refresh()
            root.scan()
        }
    }
    Timer { id: rescanTimer; interval: 2500; onTriggered: root.scan() }

    Process {
        id: proc
        // radio on/off; a cable plugged in and connected; the network in use: signal, then its name
        command: ["sh", "-c", "nmcli radio wifi; nmcli -t -f type,state dev 2>/dev/null | grep -q '^ethernet:connected' && echo wired || echo nowire; nmcli -t -f active,signal,ssid dev wifi | grep '^yes' | head -n1 | cut -d: -f2-"]
        stdout: StdioCollector {
            onStreamFinished: {
                const l = text.trim().split("\n")
                root.wifiOn = l[0] === "enabled"
                root.wired = l[1] === "wired"
                const w = l[2] ?? ""
                const c = w.indexOf(":")
                root.signal = c > 0 ? (parseInt(w.slice(0, c)) || 0) : 0
                root.ssid = c > 0 ? w.slice(c + 1).replace(/\\:/g, ":") : ""
            }
        }
    }
    // (three nmcli calls: rarely while nothing shows the network, quicker while a pop-up is open)
    Timer { interval: Ui.open !== "" ? 6000 : 30000; running: true; repeat: true; triggeredOnStart: true; onTriggered: root.refresh() }
    Timer { id: settle; interval: 1500; onTriggered: root.refresh() }
}
