pragma Singleton
import Quickshell
import Quickshell.Io
import QtQuick

// The beat of what is playing: `bars` (24 values, 0..1, low to high pitch), `bass` and `level` (0..1). Needs cava
// (optional); without it (or when it gives nothing) a made-up beat moves instead. Only listens while something shows
// it (`users` > 0) and the music plays.
// The values are SMOOTHED here once (a quick rise, a slow fall, a little blending with the neighbours), so every
// widget draws steady shapes and none of them has to animate the jitter away by itself.
Singleton {
    id: root
    property int users: 0                        // how many things on screen use it (they add / remove themselves)
    readonly property int count: 24
    property var bars: new Array(24).fill(0)
    property real bass: 0
    property real level: 0
    readonly property bool available: true       // there is always a beat to show: cava's, or a made-up one
    property bool real: true                     // cava works and gives frames
    property double startedAt: 0
    property double lastFrame: 0
    readonly property bool active: users > 0 && Media.playing
    onActiveChanged: {
        if (active) { real = true; startedAt = Date.now(); lastFrame = 0 }
        else { bars = new Array(24).fill(0); bass = 0; level = 0 }
    }

    // raw values (0..1, one per bar) in: smoothed, published
    function push(raw) {
        const n = raw.length, old = bars, b = new Array(n)
        let sum = 0
        for (let i = 0; i < n; i++) {
            // blend with the neighbours so the shape is smooth along the row
            const v = 0.5 * raw[i] + 0.25 * raw[Math.max(0, i - 1)] + 0.25 * raw[Math.min(n - 1, i + 1)]
            const o = old[i] || 0
            // quick up, slow down: the bars rise with the beat and settle back, instead of flickering
            b[i] = v > o ? o + (v - o) * 0.65 : o + (v - o) * 0.16
            sum += b[i]
        }
        bars = b
        level = sum / n
        bass = (b[0] + b[1] + b[2] + b[3]) / 4
    }

    // the value (0..1) of bar i of n: fewer bars than there are values: the loudest of its group; more: blended between neighbours
    function bar(i, n, ph) {
        const len = bars.length
        if (n === len) return bars[i] || 0
        if (n < len) {
            const per = len / n
            const a = Math.floor(i * per), b = Math.max(a + 1, Math.floor((i + 1) * per))
            let m = 0
            for (let k = a; k < b && k < len; k++) m = Math.max(m, bars[k])
            return m
        }
        const pos = Math.max(0, Math.min(len - 1, (i + 0.5) / n * len - 0.5))
        const a = Math.floor(pos), f = pos - a
        return (bars[a] || 0) * (1 - f) + (bars[Math.min(len - 1, a + 1)] || 0) * f
    }
    // the colour of bar i of n: the accent, the text colour, or a rainbow along the row
    function tint(kind, i, n, accent, text) {
        if (kind === "Rainbow") return Qt.hsla(i / Math.max(1, n), 0.75, 0.62, 1)
        return kind === "Text" ? text : accent
    }

    // cava installed but silent (no PipeWire access, wrong source ...): after 2.5 s fall back to the made-up beat
    Timer {
        interval: 700; repeat: true; running: root.active && root.real
        onTriggered: if (Date.now() - root.startedAt > 2500 && root.lastFrame < root.startedAt) root.real = false
    }
    // the made-up beat: a kick about twice a second with a little shimmer on top
    property real fakeT: 0
    Timer {
        interval: Power.saving ? 66 : 33; repeat: true; running: root.active && !root.real
        onTriggered: {
            root.fakeT += Power.saving ? 0.066 : 0.033
            const kick = Math.pow(Math.max(0, Math.sin(root.fakeT * Math.PI * 4)), 5)
            const raw = new Array(24)
            for (let i = 0; i < 24; i++) {
                const low = 1 - i / 34
                raw[i] = Math.min(1, 0.1 + kick * low * 0.9 + 0.3 * Math.abs(Math.sin(root.fakeT * (2.5 + i * 0.45) + i * 1.3)) * (0.35 + i / 40))
            }
            root.push(raw)
        }
    }

    Process {
        id: proc
        running: root.active && root.real
        command: ["sh", Quickshell.shellDir + "/scripts/beat.sh", "24", Power.saving ? "15" : "30"]
        stdout: SplitParser {
            onRead: line => {
                if (line === "missing") { root.real = false; return }
                const p = line.split(";")
                if (p.length < 4) return
                const n = p[p.length - 1] === "" ? p.length - 1 : p.length
                const raw = new Array(n)
                for (let i = 0; i < n; i++) raw[i] = Math.min(1, (parseInt(p[i]) || 0) / 100)
                root.lastFrame = Date.now()
                root.push(raw)
            }
        }
    }
}
