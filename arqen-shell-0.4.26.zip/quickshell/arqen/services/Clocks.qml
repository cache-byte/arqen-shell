pragma Singleton
import Quickshell
import Quickshell.Io
import QtQuick
import qs.config
import qs.services

// Everything behind the clock pop-up (click the clock on a panel): calendar events, reminders, alarms,
// timers, the stopwatch and the world clocks. Kept in ~/.local/state/arqen/clocks.json. Alarms,
// reminders, timed events and timers ring with a notification (and a sound) even while the pop-up
// is closed. The one-second tick below only runs while something is waiting (or the pop-up is open),
// and it never starts a program.
Singleton {
    id: root

    property double now: Date.now()
    property var events: []        // { id, title, date: "yyyy-MM-dd", time: "HH:mm" or "", fired }
    property var reminders: []     // { id, title, at (ms), fired }
    property var alarms: []        // { id, label, h, m, days: [0..6] (0 = Sunday; empty = once), on, last }
    property var timers: []        // { id, label, total (s), end (ms, while running), left (ms, while paused), running }
    property var ringing: []       // what is ringing now: { key, kind: alarm|reminder|timer, title, sub, snoozeMin, left (snoozes left, -1 = any number), since }
    property var snoozed: []       // put off: the same, plus `at` (ms) when it rings again
    property var zones: []         // time zone ids: "Europe/London"
    property var zoneOff: ({})     // id -> minutes ahead of UTC
    property var sw: ({ running: false, start: 0, base: 0, laps: [] })
    property var allZones: []      // every time zone the system knows (read when the World page first opens)
    property bool loaded: false
    property int watchers: 0       // the pop-up is open (a faster tick for the stopwatch)

    function init() { }            // touching the singleton starts it (reads the file, starts the tick)
    function watch(on) { watchers = Math.max(0, watchers + (on ? 1 : -1)) }

    // ---- small helpers
    function pad(n) { return (n < 10 ? "0" : "") + n }
    function dayKey(d) { return d.getFullYear() + "-" + pad(d.getMonth() + 1) + "-" + pad(d.getDate()) }
    function newId() { return Date.now().toString(36) + Math.floor(Math.random() * 1e6).toString(36) }
    function fmtClock(h, m) {
        if (Config.c.clock24) return pad(h) + ":" + pad(m)
        return ((h % 12) === 0 ? 12 : h % 12) + ":" + pad(m) + (h < 12 ? " AM" : " PM")
    }
    // 75 -> "1:15", 3725 -> "1:02:05"
    function fmtDur(sec) {
        sec = Math.max(0, Math.round(sec))
        const h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60), s = sec % 60
        return h > 0 ? h + ":" + pad(m) + ":" + pad(s) : m + ":" + pad(s)
    }
    function fmtWatch(ms) {
        ms = Math.max(0, ms)
        const t = Math.floor(ms / 100) % 10
        const s = Math.floor(ms / 1000)
        const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), r = s % 60
        return (h > 0 ? h + ":" + pad(m) : m) + ":" + pad(r) + "." + t
    }
    function fmtWhen(ms) {
        const d = new Date(ms), t = new Date()
        const tom = new Date(t.getFullYear(), t.getMonth(), t.getDate() + 1)
        const day = dayKey(d) === dayKey(t) ? "Today" : dayKey(d) === dayKey(tom) ? "Tomorrow" : Qt.formatDate(d, "ddd d MMM")
        return day + ", " + fmtClock(d.getHours(), d.getMinutes())
    }
    function cityOf(id) { return String(id).split("/").pop().replace(/_/g, " ") }

    // "25m", "1h30m", "90s", "10" (minutes), "in 5 min" -> seconds; -1 when it is not a length of time
    function parseDuration(str) {
        let s = String(str || "").toLowerCase().trim().replace(/^in\s+/, "")
        if (s === "") return -1
        if (/^\d+(\.\d+)?$/.test(s)) return Math.round(parseFloat(s) * 60)
        if (/^\d{1,2}:\d{2}$/.test(s)) return -1            // 14:30 is a time of day, not a length
        const re = /(\d+(?:\.\d+)?)\s*(hours?|hrs?|h|minutes?|mins?|m|seconds?|secs?|s)(?![a-z])/g
        let total = 0, found = false, mm
        while ((mm = re.exec(s)) !== null) {
            found = true
            const u = mm[2][0]
            total += parseFloat(mm[1]) * (u === "h" ? 3600 : u === "m" ? 60 : 1)
        }
        if (!found) return -1
        const rest = s.replace(re, "").replace(/\band\b|[,\s]/g, "")
        return rest === "" ? Math.round(total) : -1
    }
    // "14:30", "7pm", "7:15 am" -> { h, m } or null
    function parseClock(str) {
        const m = String(str || "").toLowerCase().trim().match(/^(\d{1,2})(?::(\d{2}))?\s*(am|pm)?$/)
        if (!m) return null
        let h = parseInt(m[1]), mi = m[2] ? parseInt(m[2]) : 0
        if (m[3]) { if (h < 1 || h > 12) return null; h = h % 12 + (m[3] === "pm" ? 12 : 0) }
        if (h > 23 || mi > 59) return null
        return { h: h, m: mi }
    }
    // when a reminder should go off: "10m", "2h", "14:30", "tomorrow 9am", "2026-12-24 18:00" -> ms, or -1
    function parseWhen(str) {
        const s = String(str || "").toLowerCase().trim()
        if (s === "") return -1
        const d = parseDuration(s)
        if (d > 0) return Date.now() + d * 1000
        const m = s.match(/^(today|tomorrow|\d{4}-\d{2}-\d{2})?\s*(?:at\s*)?(\d{1,2}(?::\d{2})?\s*(?:am|pm)?)$/)
        if (!m) return -1
        const c = parseClock(m[2])
        if (!c) return -1
        const t = new Date()
        let day = new Date(t.getFullYear(), t.getMonth(), t.getDate(), c.h, c.m, 0, 0)
        if (m[1] === "tomorrow") day = new Date(day.getTime() + 86400000)
        else if (m[1] && m[1] !== "today") {
            const p = m[1].split("-")
            day = new Date(parseInt(p[0]), parseInt(p[1]) - 1, parseInt(p[2]), c.h, c.m, 0, 0)
        } else if (!m[1] && day.getTime() <= Date.now()) day = new Date(day.getTime() + 86400000)
        return day.getTime()
    }

    // ---- events
    function addEvent(title, date, time) {
        title = String(title || "").trim()
        if (title === "") return false
        events = events.concat([{ id: newId(), title: title, date: date, time: time || "", fired: false }])
        save(); return true
    }
    function delEvent(id) { events = events.filter(e => e.id !== id); save() }
    function eventsOn(key) {
        return events.filter(e => e.date === key).sort((a, b) => (a.time || "").localeCompare(b.time || ""))
    }

    // ---- reminders
    function addReminder(title, at) {
        title = String(title || "").trim()
        if (title === "" || !(at > 0)) return false
        reminders = reminders.concat([{ id: newId(), title: title, at: at, fired: false }])
        save(); return true
    }
    function updateReminder(id, title, at) {
        title = String(title || "").trim()
        if (title === "" || !(at > 0)) return false
        reminders = reminders.map(r => r.id === id ? Object.assign({}, r, { title: title, at: at, fired: false }) : r)
        save(); return true
    }
    function delReminder(id) { reminders = reminders.filter(r => r.id !== id); save() }
    function clearDoneReminders() { reminders = reminders.filter(r => !r.fired); save() }

    // ---- alarms
    // an alarm: { h, m, label, days, snoozeMin, snoozeTimes (0 = no snooze), sound }
    function addAlarm(o) {
        alarms = alarms.concat([{ id: newId(), label: String(o.label || "").trim(), h: o.h, m: o.m, days: o.days || [], on: true, last: "",
                                  snoozeMin: o.snoozeMin ?? 5, snoozeTimes: o.snoozeTimes ?? 3, sound: o.sound !== false }])
        save()
    }
    function updateAlarm(id, o) {
        alarms = alarms.map(a => a.id === id ? Object.assign({}, a, { label: String(o.label || "").trim(), h: o.h, m: o.m, days: o.days || [], on: true, last: "",
                                  snoozeMin: o.snoozeMin ?? 5, snoozeTimes: o.snoozeTimes ?? 3, sound: o.sound !== false }) : a)
        save()
    }
    // "Tomorrow-Fri, 16 Oct" for a one-off alarm at h:m, or "Every Wed" / "Weekdays"
    function alarmWhenText(h, m, days) {
        if (days && days.length > 0) return days.length === 7 ? "Every day" : (days.length === 1 ? "Every " + ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"][days[0]] : daysText(days))
        const t = new Date(now)
        let d = new Date(t.getFullYear(), t.getMonth(), t.getDate(), h, m, 0, 0)
        if (d.getTime() <= now) d = new Date(d.getTime() + 86400000)
        const tom = new Date(t.getFullYear(), t.getMonth(), t.getDate() + 1)
        const same = dayKey(d) === dayKey(t)
        return (same ? "Today" : dayKey(d) === dayKey(tom) ? "Tomorrow" : "") + (same || dayKey(d) === dayKey(tom) ? "-" : "") + Qt.formatDate(d, "ddd, d MMM")
    }
    function setAlarmSnooze(id, min, times) {
        alarms = alarms.map(a => a.id === id ? Object.assign({}, a, { snoozeMin: min, snoozeTimes: times }) : a)
        save()
    }
    function snoozeText(a) {
        const t = a.snoozeTimes ?? 3, m = a.snoozeMin ?? 5
        return t === 0 ? "No snooze" : "Snooze " + m + " min, up to " + t + (t === 1 ? " time" : " times")
    }
    function setAlarmOn(id, on) {
        alarms = alarms.map(a => a.id === id ? Object.assign({}, a, { on: on, last: "" }) : a)
        save()
    }
    function delAlarm(id) { alarms = alarms.filter(a => a.id !== id); save() }
    function daysText(days) {
        if (!days || days.length === 0) return "Once"
        if (days.length === 7) return "Every day"
        const names = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]
        if (days.length === 5 && [1, 2, 3, 4, 5].every(d => days.indexOf(d) >= 0)) return "Weekdays"
        if (days.length === 2 && days.indexOf(0) >= 0 && days.indexOf(6) >= 0) return "Weekends"
        return days.slice().sort((a, b) => ((a + 6) % 7) - ((b + 6) % 7)).map(d => names[d]).join(", ")
    }

    // ---- timers
    function addTimer(sec, label) {
        if (!(sec > 0)) return false
        timers = timers.concat([{ id: newId(), label: String(label || "").trim(), total: sec, end: Date.now() + sec * 1000, left: sec * 1000, running: true }])
        save(); return true
    }
    function timerLeft(t) { return t.running ? Math.max(0, t.end - now) : t.left }
    function toggleTimer(id) {
        timers = timers.map(t => {
            if (t.id !== id) return t
            if (t.running) return Object.assign({}, t, { running: false, left: Math.max(0, t.end - Date.now()) })
            const left = t.left > 0 ? t.left : t.total * 1000          // finished: start over
            return Object.assign({}, t, { running: true, left: left, end: Date.now() + left })
        })
        save()
    }
    function delTimer(id) { timers = timers.filter(t => t.id !== id); save() }

    // ---- stopwatch
    function swElapsed() { return sw.base + (sw.running ? now - sw.start : 0) }
    function swToggle() {
        if (sw.running) sw = { running: false, start: 0, base: sw.base + Date.now() - sw.start, laps: sw.laps }
        else sw = { running: true, start: Date.now(), base: sw.base, laps: sw.laps }
        now = Date.now()
        save()
    }
    function swLap() {
        if (!sw.running) return
        const e = sw.base + Date.now() - sw.start
        sw = { running: true, start: sw.start, base: sw.base, laps: sw.laps.concat([e]) }
        save()
    }
    function swReset() { sw = { running: false, start: 0, base: 0, laps: [] }; save() }

    // ---- world clocks
    function addZone(id) {
        if (!id || zones.indexOf(id) >= 0) return
        zones = zones.concat([id]); save(); refreshZones()
    }
    function delZone(id) { zones = zones.filter(z => z !== id); save() }
    readonly property int localOff: -new Date(now).getTimezoneOffset()
    // the time in a zone, as a Date whose local fields read as that zone's wall clock
    function zoneDate(id) { return new Date(now + ((zoneOff[id] ?? localOff) - localOff) * 60000) }
    function zoneDiffText(id) {
        const d = (zoneOff[id] ?? localOff) - localOff
        if (d === 0) return "Same time"
        const a = Math.abs(d), h = Math.floor(a / 60), m = a % 60
        return (d > 0 ? "+" : "-") + h + (m ? ":" + pad(m) : "") + " h"
    }
    function zoneDayText(id) {
        const z = zoneDate(id), t = new Date(now)
        const k = dayKey(z), tk = dayKey(t)
        if (k === tk) return "Today"
        return k > tk ? "Tomorrow" : "Yesterday"
    }
    function refreshZones() {
        if (zones.length === 0) return
        zoneProc.running = false
        zoneProc.command = ["sh", "-c", 'for z in "$@"; do printf "%s|" "$z"; TZ="$z" date +%z; done', "sh"].concat(zones)
        zoneProc.running = true
    }
    function loadZoneList() { if (allZones.length === 0 && !listProc.running) listProc.running = true }
    Process {
        id: zoneProc
        stdout: StdioCollector {
            onStreamFinished: {
                const o = Object.assign({}, root.zoneOff)
                for (const l of text.split("\n")) {
                    const m = l.trim().match(/^(.+)\|([+-])(\d{2})(\d{2})$/)
                    if (m) o[m[1]] = (m[2] === "-" ? -1 : 1) * (parseInt(m[3]) * 60 + parseInt(m[4]))
                }
                root.zoneOff = o
            }
        }
    }
    Process {
        id: listProc
        command: ["sh", "-c", 'timedatectl list-timezones 2>/dev/null || (cd /usr/share/zoneinfo 2>/dev/null && find . -type f | sed "s|^\\./||" | grep -E "^[A-Z]" | sort)']
        stdout: StdioCollector {
            onStreamFinished: root.allZones = text.split("\n").map(s => s.trim()).filter(s => s !== "")
        }
    }
    // a zone is missing from the offsets (just added, or the file was edited): ask again
    Timer { interval: 1500; running: root.loaded && root.zones.some(z => root.zoneOff[z] === undefined); repeat: false; onTriggered: root.refreshZones() }

    // ---- what the panel clock shows: marks for what is set (the key changes only when the set of marks does)
    readonly property string cueKey: {
        const k = []
        if (ringing.length > 0) k.push("ring")
        if (snoozed.length > 0) k.push("snooze")
        if (alarms.some(a => a.on)) k.push("alarm")
        if (timers.some(t => t.running)) k.push("timer")
        if (sw.running || sw.base > 0) k.push("watch")
        if (reminders.some(r => !r.fired)) k.push("reminder")
        const today = dayKey(new Date())
        if (events.some(e => e.date === today)) k.push("event")
        return k.join(",")
    }
    function nextAlarmMs(a) {
        const t = new Date(now)
        for (let i = 0; i < 8; i++) {
            const d = new Date(t.getFullYear(), t.getMonth(), t.getDate() + i, a.h, a.m, 0, 0)
            if (d.getTime() <= now) continue
            if (a.days.length === 0 || a.days.indexOf(d.getDay()) >= 0) return d.getTime()
        }
        return -1
    }
    // the same, in words (the panel clock's tip)
    readonly property string cueTip: {
        const out = []
        for (const r of ringing) out.push("Ringing: " + r.title)
        const sn = snoozed.map(x => x.at).sort((a, b) => a - b)
        if (sn.length > 0) out.push("Snoozed: rings again in " + shortLeft((sn[0] - now) / 1000))
        const al = alarms.filter(a => a.on).map(a => nextAlarmMs(a)).filter(x => x > 0).sort((a, b) => a - b)
        if (al.length > 0) out.push("Alarm: " + fmtWhen(al[0]) + (al.length > 1 ? "  (+" + (al.length - 1) + ")" : ""))
        const tr = timers.filter(t => t.running).map(t => Math.max(0, t.end - now)).sort((a, b) => a - b)
        if (tr.length > 0) out.push("Timer: " + fmtDur(Math.ceil(tr[0] / 1000)) + " left" + (tr.length > 1 ? "  (+" + (tr.length - 1) + ")" : ""))
        if (sw.running) out.push("Stopwatch: " + fmtWatch(swElapsed()).replace(/\.\d$/, ""))
        else if (sw.base > 0) out.push("Stopwatch paused: " + fmtWatch(sw.base).replace(/\.\d$/, ""))
        const rm = reminders.filter(r => !r.fired).sort((a, b) => a.at - b.at)
        if (rm.length > 0) out.push("Reminder: " + rm[0].title + ", " + fmtWhen(rm[0].at))
        const today = dayKey(new Date())
        const ev = events.filter(e => e.date === today).sort((a, b) => (a.time || "").localeCompare(b.time || ""))
        if (ev.length > 0) out.push("Today: " + ev[0].title + (ev[0].time ? " " + ev[0].time : "") + (ev.length > 1 ? "  (+" + (ev.length - 1) + ")" : ""))
        return out.join("\n")
    }

    // ---- short texts for the panel clock's marks: a countdown (or the time on the stopwatch)
    function shortLeft(sec) {
        sec = Math.max(0, Math.ceil(sec))
        const d = Math.floor(sec / 86400), h = Math.floor((sec % 86400) / 3600), m = Math.floor((sec % 3600) / 60), r = sec % 60
        if (d > 0) return d + "d " + h + "h"
        if (h > 0) return h + "h " + pad(m) + "m"
        return m + ":" + pad(r)
    }
    function cueText(kind) {
        if (kind === "ring") return "Stop"
        if (kind === "snooze") {
            const l = snoozed.map(x => x.at).sort((a, b) => a - b)
            return l.length > 0 ? shortLeft((l[0] - now) / 1000) : ""
        }
        if (kind === "timer") {
            const l = timers.filter(t => t.running).map(t => Math.max(0, t.end - now)).sort((a, b) => a - b)
            return l.length > 0 ? shortLeft(l[0] / 1000) : ""
        }
        if (kind === "alarm") {
            const l = alarms.filter(a => a.on).map(a => nextAlarmMs(a)).filter(x => x > 0).sort((a, b) => a - b)
            return l.length > 0 ? shortLeft((l[0] - now) / 1000) : ""
        }
        if (kind === "reminder") {
            const l = reminders.filter(r => !r.fired).map(r => r.at).sort((a, b) => a - b)
            return l.length > 0 ? shortLeft((l[0] - now) / 1000) : ""
        }
        if (kind === "watch") return fmtDur(Math.floor(swElapsed() / 1000))
        if (kind === "event") {
            const today = dayKey(new Date(now))
            const l = events.filter(e => e.date === today && e.time !== "" && !e.fired).map(e => e.time).sort()
            return l.length > 0 ? l[0] : ""
        }
        return ""
    }
    property int zoneIdx: 0        // which added zone the pop-up's header shows

    // ---- ringing
    // A one-off notification (events, missed things)
    function ring(title, body, loud) {
        Quickshell.execDetached(["notify-send", "-a", "Arqen Clock", "-i", loud ? "alarm-symbolic" : "appointment-soon-symbolic", "-u", loud ? "critical" : "normal", title, body])
        if (!loud) Sounds.playNames(["message-new-instant", "message", "bell"])
    }
    // An alarm, reminder or timer going off: a card on screen (services/../modules/RingAlert.qml) and a sound that
    // repeats until it is stopped or snoozed. An alarm rings for ringSeconds, then snoozes itself (while it has
    // snoozes left) or gives up; a reminder or timer rings for a shorter while.
    readonly property int ringSeconds: 60
    readonly property int ringSecondsShort: 30
    function startRing(kind, srcId, title, sub, snoozeMin, left, sound) {
        ringing = ringing.concat([{ key: newId(), kind: kind, srcId: srcId, title: title, sub: sub, snoozeMin: snoozeMin, left: left, sound: sound !== false, since: Date.now() }])
        Quickshell.execDetached(["notify-send", "-a", "Arqen Clock", "-i", "alarm-symbolic", "-u", "normal", title, sub])
    }
    function stopRing(key) { ringing = ringing.filter(r => r.key !== key) }
    function stopAllRinging() { ringing = [] }
    function canSnooze(r) { return r.left !== 0 }
    function snoozeRing(key) {
        const r = ringing.find(x => x.key === key)
        if (!r) return
        ringing = ringing.filter(x => x.key !== key)
        if (r.left === 0) return
        snoozed = snoozed.concat([Object.assign({}, r, { left: r.left > 0 ? r.left - 1 : r.left, at: Date.now() + r.snoozeMin * 60000 })])
        save()
    }
    function cancelSnooze(i) { snoozed = snoozed.filter((x, j) => j !== i); save() }
    // the sound stops at once when nothing rings any more (the clip that is playing is cut, not left to finish)
    onRingingChanged: { if (!ringing.some(r => r.sound !== false)) Quickshell.execDetached(["pkill", "-f", "alarm-clock-elapsed"]) }
    // the sound: repeats while anything rings (killed when it stops)
    Process {
        running: root.ringing.some(r => r.sound !== false)
        command: ["sh", "-c", 'while :; do canberra-gtk-play -i alarm-clock-elapsed 2>/dev/null || paplay /usr/share/sounds/freedesktop/stereo/alarm-clock-elapsed.oga 2>/dev/null || sleep 1; sleep 0.6; done']
    }

    readonly property bool busy: alarms.some(a => a.on) || reminders.some(r => !r.fired)
        || events.some(e => !e.fired && e.time !== "") || timers.some(t => t.running) || sw.running
        || ringing.length > 0 || snoozed.length > 0
    // alarms, timers and the like ring from here: the tick is one second (a tenth while the stopwatch shows)
    Timer {
        interval: (root.watchers > 0 && root.sw.running) ? 100 : 1000
        running: root.loaded && (root.busy || root.watchers > 0)
        repeat: true
        onTriggered: root.step()
    }
    function step() {
        const t = Date.now()
        now = t
        const d = new Date(t)
        const key = dayKey(d)
        let ch = false
        // alarms (once a minute at most)
        if (alarms.some(a => a.on)) {
            const next = alarms.map(a => {
                if (!a.on || a.h !== d.getHours() || a.m !== d.getMinutes() || a.last === key) return a
                if (a.days.length > 0 && a.days.indexOf(d.getDay()) < 0) return a
                startRing("alarm", a.id, a.label || "Alarm", fmtClock(a.h, a.m), a.snoozeMin ?? 5, a.snoozeTimes ?? 3, a.sound !== false)
                ch = true
                return Object.assign({}, a, { last: key, on: a.days.length > 0 })
            })
            if (ch) alarms = next
        }
        // reminders (one that went off while the shell was off shows up when it starts again)
        if (reminders.some(r => !r.fired && r.at <= t)) {
            reminders = reminders.map(r => {
                if (r.fired || r.at > t) return r
                if (t - r.at > 120000) ring("Reminder", r.title + "  (was due " + fmtWhen(r.at) + ")", true)
                else startRing("reminder", r.id, r.title, "Reminder", 10, -1)
                return Object.assign({}, r, { fired: true })
            })
            ch = true
        }
        // events with a time
        if (events.some(e => !e.fired && e.time !== "")) {
            let any = false
            const next = events.map(e => {
                if (e.fired || e.time === "") return e
                const p = e.date.split("-"), c = e.time.split(":")
                const at = new Date(parseInt(p[0]), parseInt(p[1]) - 1, parseInt(p[2]), parseInt(c[0]), parseInt(c[1]), 0, 0).getTime()
                if (at > t) return e
                any = true
                if (t - at < 120000) ring(e.title, "Event at " + e.time, false)
                return Object.assign({}, e, { fired: true })
            })
            if (any) { events = next; ch = true }
        }
        // timers
        if (timers.some(x => x.running && x.end <= t)) {
            timers = timers.map(x => {
                if (!x.running || x.end > t) return x
                startRing("timer", x.id, x.label || "Timer", "Time is up (" + fmtDur(x.total) + ")", 1, -1)
                return Object.assign({}, x, { running: false, left: 0 })
            })
            ch = true
        }
        // put off, and due again
        if (snoozed.some(x => x.at <= t)) {
            const due = snoozed.filter(x => x.at <= t)
            snoozed = snoozed.filter(x => x.at > t)
            for (const x of due) startRing(x.kind, x.srcId, x.title, x.sub, x.snoozeMin, x.left, x.sound)
            ch = true
        }
        // ringing for long enough: an alarm snoozes itself (or gives up), the others stop
        if (ringing.some(r => t - r.since >= (r.kind === "alarm" ? ringSeconds : ringSecondsShort) * 1000)) {
            for (const r of ringing.filter(x => t - x.since >= (x.kind === "alarm" ? ringSeconds : ringSecondsShort) * 1000)) {
                if (r.kind === "alarm" && r.left !== 0) snoozeRing(r.key)
                else { stopRing(r.key); ring("Missed: " + r.title, r.sub, false) }
            }
            ch = true
        }
        if (ch) save()
    }

    // ---- saving and loading
    function save() { if (loaded) saveT.restart() }
    Timer {
        id: saveT
        interval: 400
        onTriggered: Quickshell.execDetached(["sh", "-c", 'mkdir -p "$1" && printf "%s" "$2" > "$1/clocks.json"', "clocks", root.dir,
            JSON.stringify({ events: root.events, reminders: root.reminders, alarms: root.alarms, timers: root.timers, zones: root.zones, sw: root.sw, snoozed: root.snoozed })])
    }
    readonly property string dir: (Quickshell.env("XDG_STATE_HOME") || (Quickshell.env("HOME") + "/.local/state")) + "/arqen"
    FileView {
        path: root.dir + "/clocks.json"
        printErrors: false
        onLoaded: {
            try {
                const o = JSON.parse(text()) || {}
                if (Array.isArray(o.events)) root.events = o.events
                if (Array.isArray(o.reminders)) root.reminders = o.reminders
                if (Array.isArray(o.alarms)) root.alarms = o.alarms
                if (Array.isArray(o.timers)) root.timers = o.timers
                if (Array.isArray(o.zones)) root.zones = o.zones
                if (Array.isArray(o.snoozed)) root.snoozed = o.snoozed
                if (o.sw && typeof o.sw === "object") root.sw = { running: !!o.sw.running, start: o.sw.start || 0, base: o.sw.base || 0, laps: Array.isArray(o.sw.laps) ? o.sw.laps : [] }
            } catch (e) {}
            root.loaded = true
            root.refreshZones()
            root.step()
        }
        onLoadFailed: root.loaded = true
    }
}
