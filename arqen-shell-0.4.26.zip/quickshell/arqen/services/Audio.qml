pragma Singleton
import Quickshell
import Quickshell.Services.Pipewire
import QtQuick

Singleton {
    readonly property var sink: Pipewire.defaultAudioSink
    readonly property real volume: sink?.audio?.volume ?? 0
    readonly property bool muted: sink?.audio?.muted ?? false
    readonly property var sinks: Pipewire.nodes.values.filter(n => n.isSink && !n.isStream)

    function setVolume(v) { if (sink?.audio) sink.audio.volume = Math.max(0, Math.min(1, v)) }
    function setSink(node) { if (node) Pipewire.preferredDefaultAudioSink = node }
    function toggleMute() { if (sink?.audio) sink.audio.muted = !sink.audio.muted }

    // the microphone (input)
    readonly property var source: Pipewire.defaultAudioSource
    readonly property bool hasMic: source?.audio !== undefined && source?.audio !== null
    readonly property real micVolume: source?.audio?.volume ?? 0
    readonly property bool micMuted: source?.audio?.muted ?? false
    readonly property var sources: Pipewire.nodes.values.filter(n => !n.isSink && !n.isStream && n.audio)
    function setMicVolume(v) { if (source?.audio) source.audio.volume = Math.max(0, Math.min(1, v)) }
    function setSource(node) { if (node) Pipewire.preferredDefaultAudioSource = node }
    function toggleMicMute() { if (source?.audio) source.audio.muted = !source.audio.muted }

    PwObjectTracker { objects: [Pipewire.defaultAudioSink, Pipewire.defaultAudioSource] }
}
