pragma Singleton
import Quickshell
import Quickshell.Io
import QtQuick

// Keeps the computer awake, like the GNOME Caffeine extension: while it is on, the screen does
// not lock, dim or go to sleep. Two things hold it up: a systemd inhibitor (below) and a Wayland
// idle inhibitor owned by the first panel window (see Panels.qml), because hypridle / Hyprland
// listen to one or the other depending on the setup.
Singleton {
    id: root
    property bool active: false
    property int minutes: 0            // 0 = until turned off
    property double endsAt: 0          // ms since epoch of the timer's end, 0 = no timer
    property double now: Date.now()
    readonly property int secondsLeft: endsAt > 0 ? Math.max(0, Math.ceil((endsAt - now) / 1000)) : 0
    readonly property string label: !active ? "Off" : (endsAt > 0 ? fmt(secondsLeft) + " left" : "On")

    function fmt(s) {
        const h = Math.floor(s / 3600)
        const m = Math.floor((s % 3600) / 60)
        return h > 0 ? h + " h " + m + " min" : (m > 0 ? m + " min" : s + " s")
    }
    function start(mins) {
        minutes = mins
        now = Date.now()
        endsAt = mins > 0 ? now + mins * 60000 : 0
        active = true
    }
    function stop() { active = false; endsAt = 0; minutes = 0 }
    function toggle() { if (active) stop(); else start(0) }

    Process {
        running: root.active
        command: ["systemd-inhibit", "--what=idle:sleep", "--who=Arqen shell", "--why=Caffeine is on", "--mode=block", "sleep", "infinity"]
    }
    Timer {
        interval: 1000; repeat: true
        running: root.active && root.endsAt > 0
        onTriggered: { root.now = Date.now(); if (root.now >= root.endsAt) root.stop() }
    }
}
