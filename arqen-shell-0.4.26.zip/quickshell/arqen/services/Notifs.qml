pragma Singleton
import Quickshell
import Quickshell.Wayland
import Quickshell.Hyprland
import Quickshell.Services.Notifications
import QtQuick
import Quickshell.Io
import qs.config

// Notifications. The pop-up (Toast) shows the newest one; the control centre lists them all.
// Clicking a notification shows what you can do with it (see actions / open / dismiss).
Singleton {
    id: root
    property var latest: null
    property bool toastVisible: false
    property bool toastHeld: false           // the pointer is on the pop-up: keep it up
    property bool toastPinned: false         // clicked open: stays until you click elsewhere or pick an action
    property int toastSerial: 0              // changes whenever the pop-up's time starts again (the ring in Toast)
    readonly property var list: server.trackedNotifications

    // when each one came in (by its id), and a clock for "5 min ago" that ticks every 20 seconds
    property var times: ({})
    property double now: Date.now()
    Timer { interval: 20000; repeat: true; running: true; onTriggered: root.now = Date.now() }
    readonly property string stateDir: (Quickshell.env("XDG_STATE_HOME") || (Quickshell.env("HOME") + "/.local/state")) + "/arqen"
    // kept in a file so they survive the shell reloading (the notifications themselves do)
    FileView {
        id: timesFile
        path: root.stateDir + "/notif-times.json"
        printErrors: false
        blockLoading: true      // read before the server hands the kept notifications over again, or they would all count as new
        function readNow() { try { const o = JSON.parse(text()); root.times = Object.assign(o || {}, root.times) } catch (e) {} }
        onLoaded: readNow()
        Component.onCompleted: readNow()
    }
    // by its id; failing that (the ids can start again after a reload) by who sent it and what it says
    function sigOf(n) { return "s:" + appKey(n) + "\u0001" + String(n?.summary || "") + "\u0001" + String(n?.body || "") }
    function timeOf(n) { return n ? (root.times[n.id] || root.times[sigOf(n)]) : undefined }
    function ago(n) {
        const t = root.timeOf(n)
        if (!t) return ""
        const s = Math.max(0, (root.now - t) / 1000)
        if (s < 60) return "now"
        if (s < 3600) return Math.floor(s / 60) + " min ago"
        if (s < 86400) return Math.floor(s / 3600) + " h ago"
        const d = new Date(t)
        return Qt.formatDate(d, "d MMM") + ", " + Qt.formatTime(d, Config.c.clock24 ? "HH:mm" : "h:mm AP")
    }

    // the time it came in, like a phone: "12:51" today, "Mon 12:51" this week, else the date
    function clock(n) {
        const t = root.timeOf(n)
        if (!t) return ""
        const d = new Date(t), today = new Date(root.now)
        const tm = Qt.formatTime(d, Config.c.clock24 ? "HH:mm" : "h:mm AP")
        if (d.toDateString() === today.toDateString()) return tm
        if (root.now - t < 6 * 86400000) return Qt.formatDate(d, "ddd") + " " + tm
        return Qt.formatDate(d, "d MMM")
    }

    // ---- identical notifications are one ----
    // Some senders post the same notification again and again (KDE Connect mirroring a phone's "Sending file to ..."
    // progress, one per update). Notifications from the same app with the same title and text count as one: only the
    // newest is listed, counted and popped up. The older ones stay tracked (so the sender can still close them) but are
    // not shown. Ordinary apps: two identical ones within 90 seconds are one. KDE Connect: always.
    function dupKey(n) { return appKey(n) + "\u0001" + String(n?.summary || "") + "\u0001" + String(n?.body || "") }
    function dupWindow(n) { return /kde ?connect/i.test(String(n?.appName || "") + " " + String(n?.desktopEntry || "")) ? Infinity : 90000 }
    function whenOf(n) { return n ? (root.timeOf(n) || n.id) : 0 }
    readonly property var shown: {
        const vals = root.list.values.slice(), _t = root.times
        vals.sort((a, b) => whenOf(b) - whenOf(a))
        const kept = ({}), out = []
        for (const n of vals) {
            const k = dupKey(n), t = whenOf(n)
            if (kept[k] !== undefined && kept[k] - t <= dupWindow(n)) continue
            kept[k] = t
            out.push(n)
        }
        return out
    }
    readonly property int count: shown.length

    // ---- by app (like a phone: one stack per app, newest app first) ----
    function appKey(n) { return String(n?.desktopEntry || n?.appName || "other").toLowerCase() }
    function appName(n) {
        const e = entryOf(n)
        return e?.name || n?.appName || n?.desktopEntry || "Notification"
    }
    function entryOf(n) {
        const id = n?.desktopEntry || n?.appName || ""
        return id !== "" ? Apps.byId(id) : null
    }
    readonly property var groups: {
        const vals = root.shown, _t = root.times
        const by = {}, order = []
        for (const n of vals) {
            const k = Config.c.notifGroup ? appKey(n) : "n" + n.id      // not grouped: one card each
            if (!by[k]) { by[k] = { key: k, items: [] }; order.push(k) }
            by[k].items.push(n)
        }
        const out = order.map(k => by[k])
        for (const g of out) g.items.sort((a, b) => whenOf(b) - whenOf(a))
        out.sort((a, b) => whenOf(b.items[0]) - whenOf(a.items[0]))
        return out
    }
    // which stacks and cards are open (kept here: the list's cards are made again when it changes)
    property var openGroups: ({})
    property var openCards: ({})
    // as many open as you like; a click on empty space closes them all
    function groupOpen(k) { return !!openGroups[k] }
    function toggleGroup(k) { const o = Object.assign({}, openGroups); if (o[k]) delete o[k]; else o[k] = true; openGroups = o }
    function cardOpen(n) { return !!(n && openCards[n.id]) }
    function toggleCard(n) { if (!n) return; const o = Object.assign({}, openCards); if (o[n.id]) delete o[n.id]; else o[n.id] = true; openCards = o }
    // everything back to normal (a click on empty space, the control centre closing)
    function collapseAll() { if (Object.keys(openCards).length) openCards = ({}); if (Object.keys(openGroups).length) openGroups = ({}) }
    function dismissAll(items) { for (const n of (items || []).slice()) dismiss(n) }

    // ---- pictures ----
    function fileUrl(p) { p = String(p || ""); return p.startsWith("/") ? "file://" + p : p }
    // the picture that came with it (a photo, a screenshot, the sender's picture). Not an icon name
    // ("image://icon/..."): that is drawn as the app's icon instead.
    function imageOf(n) {
        if (!n) return ""
        const h = n.hints || {}
        let p = String(n.image || "")
        if (p === "" || p.startsWith("image://icon/")) p = String(h["image-path"] || h["image_path"] || "")
        if (p === "" || p.startsWith("image://icon/") || /^[\w.+-]+$/.test(p)) return ""   // nothing, or an icon name
        return fileUrl(cachedPath(p))
    }

    // ---- pictures that apps delete soon after (browsers write them to /tmp) are copied at once ----
    readonly property string cacheDir: (Quickshell.env("XDG_CACHE_HOME") || (Quickshell.env("HOME") + "/.cache")) + "/arqen/notif"
    property var cached: ({})                 // original path -> our copy (kept in map.json across reloads)
    FileView {
        id: cachedFile
        path: root.cacheDir + "/map.json"
        printErrors: false
        onLoaded: { try { root.cached = Object.assign(JSON.parse(text()) || {}, root.cached) } catch (e) {} }
    }
    onCachedChanged: saveMap.restart()
    Timer { id: saveMap; interval: 500; onTriggered: Quickshell.execDetached(["sh", "-c", 'mkdir -p "$1" && printf "%s" "$2" > "$1/map.json"', "map", root.cacheDir, JSON.stringify(root.cached)]) }
    function cachedPath(p) {
        p = String(p || "")
        const raw = p.startsWith("file://") ? decodeURIComponent(p.slice(7)) : p
        return cached[raw] ?? p
    }
    function isTemp(p) { return /^(\/tmp\/|\/var\/tmp\/|\/run\/user\/|\/dev\/shm\/)/.test(p) }
    function keep(n) {
        const h = n.hints || {}
        const paths = [n.appIcon, n.image, h["image-path"], h["image_path"]]
            .map(x => String(x || "")).map(x => x.startsWith("file://") ? decodeURIComponent(x.slice(7)) : x)
            .filter(x => x.startsWith("/") && isTemp(x) && !cached[x])
        for (let i = 0; i < paths.length; i++) {
            const src = paths[i]
            const dst = cacheDir + "/" + n.id + "-" + i + "-" + src.replace(/^.*\//, "").replace(/[^\w.-]/g, "_")
            copier.createObject(root, { src: src, dst: dst })
        }
    }
    Component {
        id: copier
        Process {
            id: cp
            property string src
            property string dst
            running: true
            command: ["sh", "-c", 'mkdir -p "$(dirname "$2")" && cp -f -- "$1" "$2"', "keep", src, dst]
            onExited: code => {
                if (code === 0) { const c = Object.assign({}, root.cached); c[cp.src] = cp.dst; root.cached = c }
                cp.destroy()
            }
        }
    }
    // old copies go after three days
    Component.onCompleted: Quickshell.execDetached(["sh", "-c", 'find "$1" -type f -mtime +3 -delete 2>/dev/null', "clean", cacheDir])
    // a message from someone: their picture goes where the app icon is, with the app as a badge
    function isChat(n) {
        if (!n) return false
        const cat = String((n.hints || {}).category || "")
        return n.hasInlineReply || cat.indexOf("im") === 0
            || /whatsapp|telegram|signal|discord|vesktop|slack|element|messages|messenger|teams|beeper|thunderbird|geary|evolution|mail/i.test((n.appName || "") + " " + (n.desktopEntry || ""))
    }
    // the app's icon: what the app sent (a name or a file), else its desktop entry's icon
    function iconOf(n) {
        if (!n) return ""
        let i = String(n.appIcon || "")
        if (i.startsWith("image://icon/")) i = i.slice(13)
        if (i.startsWith("/") || i.startsWith("file://")) i = cachedPath(i)
        if (i !== "") return i
        const e = entryOf(n)
        return e?.icon || ""
    }
    // tidy body text (some apps send a little HTML)
    function plain(t) { return String(t || "").replace(/<br\s*\/?>/gi, "\n").replace(/<[^>]+>/g, "").replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, "\"").replace(/&#39;/g, "'") }

    // is the focused window full screen (a game, a video)? asked again whenever that may have changed
    property bool fullscreenNow: false
    Process {
        id: fsProc
        command: ["hyprctl", "-j", "activewindow"]
        stdout: StdioCollector { onStreamFinished: { try { const j = JSON.parse(text); root.fullscreenNow = (j.fullscreen || 0) >= 2 } catch (e) { root.fullscreenNow = false } } }
    }
    Timer { id: fsLater; interval: 150; onTriggered: if (!fsProc.running) fsProc.running = true }
    Connections {
        target: Hyprland
        function onRawEvent(ev) {
            if (["fullscreen", "activewindowv2", "workspacev2", "closewindow"].indexOf(ev.name) >= 0) fsLater.restart()
        }
    }

    function clearAll() { server.trackedNotifications.values.slice().forEach(n => n.dismiss()) }

    // ---- what you can do with a notification ----
    function actionsOf(n) {
        const out = []
        const a = n ? n.actions : null
        if (!a) return out
        for (let i = 0; i < a.length; i++) out.push(a[i])
        return out
    }
    // the app's own buttons ("Reply", "Mark as read", ...), without the hidden default one
    function buttons(n) { return actionsOf(n).filter(a => a.identifier !== "default" && (a.text || "") !== "") }
    // "Open": the app's default action if it has one, otherwise bring its window up (or start it)
    function open(n) {
        if (!n) return
        const d = actionsOf(n).find(a => a.identifier === "default")
        if (d) { d.invoke(); return }
        const want = (n.desktopEntry || n.appName || "").toLowerCase()
        if (want !== "") {
            const tl = ToplevelManager.toplevels.values.find(t => {
                const id = (t.appId || "").toLowerCase()
                return id === want || id.endsWith("." + want) || want.endsWith("." + id)
            })
            if (tl) { Windows.bring(tl); n.dismiss(); return }
            const e = Apps.byId(n.desktopEntry || n.appName)
            if (e) { e.execute(); n.dismiss() }
        }
    }
    function hasDefault(n) { return actionsOf(n).some(a => a.identifier === "default") }
    function invoke(n, action) { if (action) action.invoke() }
    function dismiss(n) {
        if (n === latest) toastVisible = false
        if (!n) return
        // the hidden identical ones go with it (else the next of them would show up in its place)
        const k = dupKey(n)
        for (const o of root.list.values.slice()) if (o !== n && dupKey(o) === k) o.dismiss()
        n.dismiss()
    }

    // keep the pop-up while the pointer is on it, then give it its full time again
    readonly property bool toastKept: toastHeld || toastPinned
    onToastKeptChanged: { if (toastKept) hide.stop(); else if (toastVisible) { hide.restart(); toastSerial++ } }

    NotificationServer {
        id: server
        keepOnReload: true
        bodySupported: true
        imageSupported: true
        actionsSupported: true
        onNotification: n => {
            // after a reload the server hands the kept notifications over again: same id and same sender + text as
            // saved means it is not new, so it keeps the time it came in and does not pop up or ring again
            if (root.times[n.id] && root.times["g:" + n.id] === root.sigOf(n)) { n.tracked = true; return }
            root.keep(n)
            // a repeat of one already listed: no pop-up and no sound again
            const k = root.dupKey(n)
            const repeat = server.trackedNotifications.values.some(o => o !== n && root.dupKey(o) === k
                && (Date.now() - (root.times[o.id] || 0)) <= root.dupWindow(n))
            n.tracked = true
            const t = {}
            for (const o of server.trackedNotifications.values) {
                const to = root.timeOf(o)
                if (to) { t[o.id] = to; t["g:" + o.id] = root.sigOf(o); t[root.sigOf(o)] = to }
            }
            t[n.id] = Date.now(); t["g:" + n.id] = root.sigOf(n); t[root.sigOf(n)] = Date.now(); root.times = t
            root.now = Date.now()
            // the folder may not exist yet (FileView does not make it), so write through the shell
            Quickshell.execDetached(["sh", "-c", 'mkdir -p "$1" && printf "%s" "$2" > "$1/notif-times.json"', "times", root.stateDir, JSON.stringify(t)])
            // held back (kept in the list) while a window is full screen, unless Settings says otherwise
            const quiet = root.fullscreenNow && !Config.c.toastOverFullscreen
            if (!Config.c.dnd && !quiet && !repeat) { root.latest = n; root.toastVisible = true; hide.restart(); toastSerial++; Sounds.play(n.urgency === NotificationUrgency.Critical && Config.c.soundError ? "error" : "notify") }
        }
    }
    Timer { id: hide; interval: Config.c.toastSeconds * 1000; onTriggered: if (!root.toastKept) root.toastVisible = false }
}
