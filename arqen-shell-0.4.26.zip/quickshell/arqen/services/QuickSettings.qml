pragma Singleton
import Quickshell
import Quickshell.Io
import Quickshell.Bluetooth
import Quickshell.Services.UPower
import QtQuick
import qs.config

// State and actions behind the control centre tiles that are not a service of their own.
Singleton {
    id: root
    // night light and the colour filter are kept in the settings and put back at login
    readonly property bool night: Config.c.nightOn
    readonly property int nightTemp: Config.c.nightTemp
    readonly property string filter: Config.c.screenFilter
    readonly property var filters: [
        { id: "grayscale",    name: "Grayscale",       sub: "No colour: less distracting, easier at night", icon: "filter_b_and_w" },
        { id: "reading",      name: "Reading",         sub: "Warm paper tint, almost no colour", icon: "menu_book" },
        { id: "sepia",        name: "Sepia",           sub: "Warm brown tones", icon: "filter_vintage" },
        { id: "dim",          name: "Dim",             sub: "Darker than the lowest brightness", icon: "brightness_low" },
        { id: "contrast",     name: "High contrast",   sub: "Stronger difference between light and dark", icon: "contrast" },
        { id: "invert",       name: "Invert colours",  sub: "Light becomes dark and the other way", icon: "invert_colors" },
        { id: "protanopia",   name: "Red-weak (protanopia)",     sub: "Shifts colours so reds are easier to tell apart", icon: "visibility" },
        { id: "deuteranopia", name: "Green-weak (deuteranopia)", sub: "Shifts colours so greens are easier to tell apart", icon: "visibility" },
        { id: "tritanopia",   name: "Blue-weak (tritanopia)",    sub: "Shifts colours so blues are easier to tell apart", icon: "visibility" }
    ]
    readonly property bool filterActive: night || filter !== ""
    function filterName() { const f = filters.find(x => x.id === filter); return f ? f.name : "" }
    property bool recording: false
    property real brightness: 1
    property bool hasBrightness: false

    readonly property string home: Quickshell.env("HOME")

    // ---- night light (hyprsunset) ----
    // The old process is stopped and gone before the new one starts (started on top of it, the new
    // temperature did not take). hyprsunset keeps running in the background while night light is on.
    function applyNight() {
        const on = Config.c.nightOn
        Quickshell.execDetached(["sh", "-c", "pkill -x hyprsunset 2>/dev/null; for i in 1 2 3 4 5 6 7 8 9 10; do pgrep -x hyprsunset >/dev/null || break; sleep 0.05; done; "
            + (on ? "setsid hyprsunset -t " + Config.c.nightTemp + " >/dev/null 2>&1 &" : "true")])
    }
    function setNight(on, temp) {
        if (temp) Config.c.nightTemp = temp
        Config.c.nightOn = on
        applyNight()
    }
    // Applied after a short pause so quick taps in the menu do not stack shader swaps (each swap recompiles
    // and redraws the whole screen, which showed up as glitching).
    function applyFilter() { filterTimer.restart() }
    Timer {
        id: filterTimer
        interval: 250
        onTriggered: {
            Hypr.fullRedraw(Config.c.screenFilter !== "")
            Hypr.screenShader(Config.c.screenFilter !== "" ? Quickshell.shellDir + "/assets/shaders/" + Config.c.screenFilter + ".frag" : "")
        }
    }
    function setFilter(id) { Config.c.screenFilter = id; applyFilter() }
    // put them back after login (once Hyprland's config kind is known)
    Connections {
        target: Config
        function onHyprCheckedChanged() {
            if (!Config.hyprChecked) return
            Quickshell.execDetached(["sh", Quickshell.shellDir + "/scripts/lockkeys.sh", Config.c.loginCaps || "keep", Config.c.loginNum || "keep"])
            if (Config.c.nightOn) root.applyNight()
            if (Config.c.screenFilter !== "") root.applyFilter()
        }
    }

    // ---- screenshots and recordings (scripts/capture.sh) ----
    // target: "screen" | "window" | "region" (chosen with the pointer), "geo:X,Y WxH" (from the capture
    // screen) or "output:NAME"; audio for recordings: "none" | "system" | "mic"
    function screenshot(target) {
        Ui.close()
        Captures.run(Config.captureCmd(["shot", target || "region"]))
        Sounds.play("capture")
    }
    property double recStart: 0
    property string recTarget: ""            // what is being recorded ("geo:X,Y WxH" for a selection or window)
    property int recSecs: 0                 // how long the recording has run
    Timer { interval: 500; repeat: true; running: root.recording; triggeredOnStart: true
            onTriggered: root.recSecs = Math.max(0, Math.floor((Date.now() - root.recStart) / 1000)) }
    readonly property string recText: Math.floor(recSecs / 60) + ":" + String(recSecs % 60).padStart(2, "0")
    function record(target, audio) {
        if (target === "stop") {
            Quickshell.execDetached(["pkill", "-INT", "wf-recorder"])
            return
        }
        if (recProc.running) return
        Ui.close()
        recording = true
        recTarget = target || "screen"
        recStart = Date.now() + 250
        recProc.command = Config.captureCmd(["record", target || "screen", audio || "none"])
        recProc.running = true
    }
    // search the web for part of the screen (scripts/lens.sh)
    function imageSearch(target, crop) {
        Ui.close()
        const a = ["sh", Quickshell.shellDir + "/scripts/lens.sh"]
        if (target) a.push(target)
        if (crop) a.push(crop)
        Quickshell.execDetached(a)
    }
    Process {
        id: recProc
        onExited: root.recording = false
        // "CAPTURED rec PATH" when the shell is to ask what to do with it
        stdout: SplitParser { onRead: line => Captures.heard(line) }
    }

    // ---- Bluetooth ----
    // Turning it on first lifts an rfkill soft block (airplane mode / a previous "off" can leave
    // one), otherwise the adapter refuses with "blocked by rfkill".
    function toggleBluetooth() {
        const ad = Bluetooth.defaultAdapter
        if (ad && ad.enabled) { ad.enabled = false; return }
        if (!btUnblock.running) btUnblock.running = true
    }
    Process {
        id: btUnblock
        command: ["sh", "-c", "rfkill unblock bluetooth 2>/dev/null; sleep 0.4"]
        onExited: {
            const ad = Bluetooth.defaultAdapter
            if (ad) ad.enabled = true
        }
    }

    // ---- power profiles (power-profiles-daemon, or tuned-ppd on newer Fedora) ----
    function profileName(p) {
        if (p === undefined) p = PowerProfiles.profile
        return p === PowerProfile.PowerSaver ? "Power saver" : (p === PowerProfile.Performance ? "Performance" : "Balanced")
    }
    function setProfile(p) { PowerProfiles.profile = p }
    readonly property bool powerSaver: PowerProfiles.profile === PowerProfile.PowerSaver
    function togglePowerSaver() { PowerProfiles.profile = powerSaver ? PowerProfile.Balanced : PowerProfile.PowerSaver }

    // ---- Bluetooth pairing ----
    // Pairing straight through BlueZ fails with "Authentication failed / canceled" when no pairing
    // agent is registered (most phones, headsets and keyboards need one), and often while a scan
    // is still running. So: stop the scan, then let bluetoothctl pair with its own agent
    // (NoInputNoOutput = "just works" pairing, no PIN to type), trust the device and connect it.
    property string btBusy: ""          // address being paired / connected
    property string btStatus: ""        // last result, shown in the Bluetooth menu and settings
    function btValid(a) { return /^[0-9A-Fa-f]{2}(:[0-9A-Fa-f]{2}){5}$/.test(a || "") }
    function btPair(dev) {
        if (!dev || !btValid(dev.address) || btProc.running) return
        if (Bluetooth.defaultAdapter) Bluetooth.defaultAdapter.discovering = false
        btBusy = dev.address
        btStatus = "Pairing with " + (dev.name || dev.address) + "... accept it on the device if it asks"
        btProc.mode = "pair"
        btProc.label = dev.name || dev.address
        btProc.command = ["sh", "-c", root.btPairScript, "bt-pair", dev.address]
        btProc.running = true
    }
    // connect / disconnect a paired device (also through bluetoothctl, so errors come back as text)
    function btToggleConnect(dev) {
        if (!dev || !btValid(dev.address) || btProc.running) return
        btBusy = dev.address
        const on = !dev.connected
        btStatus = (on ? "Connecting to " : "Disconnecting ") + (dev.name || dev.address) + "..."
        btProc.mode = on ? "connect" : "disconnect"
        btProc.label = dev.name || dev.address
        btProc.command = ["sh", "-c", "bluetoothctl " + (on ? "connect " : "disconnect ") + "\"$1\" 2>&1", "bt", dev.address]
        btProc.running = true
    }
    function btForget(dev) {
        if (!dev || !btValid(dev.address)) return
        Quickshell.execDetached(["bluetoothctl", "remove", dev.address])
        btStatus = (dev.name || dev.address) + " forgotten"
    }
    readonly property string btPairScript: [
        'a="$1"',
        'bluetoothctl scan off >/dev/null 2>&1',
        'bluetoothctl pairable on >/dev/null 2>&1',
        '{',
        '  echo "agent DisplayYesNo"; echo "default-agent"; sleep 1',
        '  echo "pair $a"',
        '  i=0; while [ $i -lt 25 ]; do bluetoothctl info "$a" 2>/dev/null | grep -q "Paired: yes" && break; sleep 1; i=$((i+1)); done',
        '  echo "trust $a"; sleep 1',
        '  echo "connect $a"; sleep 5',
        '  echo "quit"',
        '} | bluetoothctl 2>&1 | grep -E "Failed|Error|error" | tail -n 2',
        'if bluetoothctl info "$a" 2>/dev/null | grep -q "Paired: yes"; then echo "RESULT ok"; else echo "RESULT fail"; fi'
    ].join("\n")
    // BlueZ's errors in words, with what to do
    function btHint(err) {
        const e = String(err)
        if (/connection-key-missing|key-missing|AuthenticationFailed|Authentication Failed/i.test(e))
            return "it has forgotten this computer (or was paired with another one). Press Forget, put it in pairing mode, then Scan and Pair again"
        if (/page-timeout|host-down|le-connection-abort|not available|NotReady/i.test(e))
            return "not in reach or switched off. Turn it on, bring it closer, then Connect"
        if (/profile-unavailable|NotAvailable|unavailable/i.test(e))
            return "this computer has nothing to talk to it with (for sound devices: is PipeWire's Bluetooth support installed?)"
        if (/AlreadyConnected|already connected/i.test(e)) return "already connected"
        if (/AuthenticationRejected|rejected|Confirm passkey failed/i.test(e)) return "pairing was rejected. Keep the phone unlocked, accept the pairing prompt on both devices, then try Pair again"
        if (/org.bluez.Error.Failed|br-connection-profile-unavailable/i.test(e)) return "the phone may be paired for a different profile. Forget it on both devices, enable Bluetooth visibility on the phone, then pair again"
        if (/InProgress|in progress/i.test(e)) return "still working on it: wait a moment"
        if (/connection-refused|refused/i.test(e)) return "it refused: it may be connected to another device. Disconnect it there first"
        return e
    }
    Process {
        id: btProc
        property string mode: ""
        property string label: ""
        stdout: StdioCollector {
            onStreamFinished: {
                const t = text.trim()
                const lines = t.split("\n").filter(l => l.trim() !== "")
                const err = lines.filter(l => /Failed|Error|error/.test(l)).map(l => l.replace(/\x1b\[[0-9;]*m/g, "").replace(/^.*?(Failed|Error)/, "$1")).pop() ?? ""
                if (btProc.mode === "pair") {
                    root.btStatus = /RESULT ok/.test(t)
                        ? "Paired with " + btProc.label
                        : "Could not pair with " + btProc.label + (err ? " (" + err + ")" : "") + ". Put it in pairing mode and try again"
                } else {
                    root.btStatus = err ? btProc.label + ": " + root.btHint(err) : (btProc.mode === "connect" ? "Connected to " : "Disconnected ") + btProc.label
                }
            }
        }
        onExited: root.btBusy = ""
    }

    // ---- power ----
    // Lock, sleep, log out, restart, shut down: first a full-screen countdown (Settings > Power;
    // modules/PowerCountdown.qml) that can be cancelled (Esc) or skipped ("now", Enter).
    property string pendingPower: ""         // the action counting down ("preview" = just showing it)
    property double powerAt: 0               // when it happens (ms)
    property int powerTotal: 30              // the countdown's length (s)
    function power(action) {
        Ui.close()
        const secs = Math.max(0, Math.round(Config.c.powerCountdown ?? 30))
        if (secs <= 0) { doPower(action); return }
        powerTotal = secs
        powerAt = Date.now() + secs * 1000
        pendingPower = action
        powerTimer.interval = secs * 1000
        powerTimer.restart()
    }
    function previewCountdown() { power("preview") }
    function cancelPower() { powerTimer.stop(); pendingPower = "" }
    function powerNow() {
        const a = pendingPower
        cancelPower()
        if (a !== "" && a !== "preview") doPower(a)
    }
    Timer { id: powerTimer; interval: 30000; onTriggered: root.powerNow() }
    function doPower(action) {
        switch (action) {
        case "lock":     Ui.lock(); break
        case "suspend":  Quickshell.execDetached(["systemctl", "suspend"]); break
        case "logout":   Quickshell.execDetached(["sh", "-c", Hypr.cmdExit]); break
        case "reboot":   Quickshell.execDetached(["systemctl", "reboot"]); break
        case "poweroff": Quickshell.execDetached(["systemctl", "poweroff"]); break
        }
    }

    function openFolder(path) { Quickshell.execDetached(["sh", Quickshell.shellDir + "/scripts/open-folder.sh", path]) }

    // ---- brightness (brightnessctl) ----
    function refresh() { if (!brProc.running && Date.now() - lastSet > 600) brProc.running = true }
    property double lastSet: 0
    function setBrightness(v) {
        brightness = Math.max(0.01, Math.min(1, v))
        lastSet = Date.now()
        brTimer.restart()
    }
    // brightness keys: one step up or down, applied straight away
    function stepBrightness(up) {
        setBrightness(brightness + (up ? 0.05 : -0.05))
        brTimer.stop()
        Quickshell.execDetached(["brightnessctl", "set", Math.round(brightness * 100) + "%"])
    }
    // follows changes made elsewhere (keys, other apps) while the control centre is open
    Timer { interval: 1000; repeat: true; running: Ui.open === "quick" && root.hasBrightness; onTriggered: root.refresh() }
    Process {
        id: brProc
        command: ["brightnessctl", "-m"]
        stdout: StdioCollector {
            onStreamFinished: {
                const f = text.trim().split("\n")[0].split(",")
                if (f.length >= 5) {
                    root.hasBrightness = true
                    root.brightness = parseInt(f[3]) / 100
                }
            }
        }
        onExited: code => { if (code !== 0) root.hasBrightness = false }
    }
    // the slider fires on every pixel; only send the value once it settles
    Timer {
        id: brTimer
        interval: 70
        onTriggered: Quickshell.execDetached(["brightnessctl", "set", Math.round(root.brightness * 100) + "%"])
    }
    Component.onCompleted: refresh()
}
