pragma Singleton
import Quickshell
import Quickshell.Io
import QtQuick

// You: name (from your account), the computer's name, and your picture (~/.face, or the one
// GNOME / the login screen uses). Settings > About sets the picture.
Singleton {
    id: root
    readonly property string login: Quickshell.env("USER") || ""
    property string name: login
    property string host: ""
    property string face: ""                // file path, "" = none
    property int faceVersion: 0             // bumps when the picture changes, so images reload
    property bool faceAnimated: false       // a GIF: shown moving

    function refresh() { if (!proc.running) proc.running = true }
    // what the login screen said to the last change: "" (nothing yet), "ok" or "failed - why"
    property string loginStatus: ""
    property bool loginBusy: faceRun.running
    property var pending: []
    function runFace(args) {
        if (faceRun.running) { pending = pending.concat([args]); return }
        faceRun.command = ["sh", Quickshell.shellDir + "/scripts/set-face.sh"].concat(args)
        faceRun.running = true
    }
    function setFace(path) { runFace(["set", path]) }
    function clearFace() { runFace(["clear"]) }
    function applyFace() { loginStatus = ""; runFace(["apply"]) }
    Process {
        id: faceRun
        stdout: StdioCollector {
            onStreamFinished: {
                const m = text.split("\n").filter(l => l.indexOf("login: ") === 0).pop()
                if (m) root.loginStatus = m.slice(7).trim()
                root.refresh()
                retry.restart()
                if (root.pending.length > 0) { const n = root.pending[0]; root.pending = root.pending.slice(1); root.runFace(n) }
            }
        }
    }
    // once after the shell starts: a picture you already have, but the login screen does not, is handed over
    Timer { interval: 6000; running: true; onTriggered: root.runFace(["sync"]) }
    Timer { id: retry; interval: 400; onTriggered: root.refresh() }
    Component.onCompleted: refresh()

    Process {
        id: proc
        command: ["sh", "-c",
            "getent passwd \"$USER\" | cut -d: -f5 | cut -d, -f1; "
            + "(hostnamectl --pretty 2>/dev/null | grep . || hostname); "
            + "for f in \"$HOME/.face\" \"$HOME/.face.icon\" \"/var/lib/AccountsService/icons/$USER\"; do [ -r \"$f\" ] && [ -s \"$f\" ] && { echo \"$f\"; head -c 4 \"$f\" | grep -q GIF8 && echo gif || echo still; break; }; done; echo"]
        stdout: StdioCollector {
            onStreamFinished: {
                const l = text.split("\n")
                root.name = (l[0] || "").trim() || root.login
                root.host = (l[1] || "").trim()
                root.face = (l[2] || "").trim()
                root.faceAnimated = (l[3] || "").trim() === "gif"
                root.faceVersion++
            }
        }
    }
}
