pragma Singleton
import Quickshell
import Quickshell.Io
import Quickshell.Services.UPower
import QtQuick
import qs.config

// System sounds (Settings > Sound and notifications > System sounds): a freedesktop sound theme, like
// KDE's chooser, and for each event its own sound if you like (any sound of any installed theme, or
// none). Config.c.soundPicks: { event id: "" (the theme's) | a sound file }.
Singleton {
    id: root
    readonly property string script: Quickshell.shellDir + "/scripts/sounds.sh"
    property var themes: []                 // [{ id, name, desc }]
    property var files: []                  // every sound: [{ theme, name, file }]

    // what can play a sound, the setting that turns it on, and the theme's names for it (first found wins)
    readonly property var events: [
        { id: "notify",  key: "soundNotify",  name: "Notifications",          icon: "notifications",   sounds: ["message-new-instant", "message", "bell"] },
        { id: "volume",  key: "soundVolume",  name: "Volume keys",            icon: "volume_up",       sounds: ["audio-volume-change", "bell"] },
        { id: "capture", key: "soundCapture", name: "Screenshots",            icon: "screenshot_region", sounds: ["camera-shutter", "screen-capture"] },
        { id: "power",   key: "soundPower",   name: "Charger and battery", icon: "battery_charging_full", sounds: ["power-plug", "complete"] },
        { id: "devices", key: "soundDevices", name: "Devices connected",   icon: "bluetooth",       sounds: ["device-added", "bell"] },
        { id: "error",   key: "soundError",   name: "Urgent notifications", icon: "error",          sounds: ["dialog-warning", "dialog-error", "bell"] }
    ]

    function refresh() { lister.running = true }
    Process {
        id: lister
        command: ["sh", root.script, "list"]
        stdout: StdioCollector {
            onStreamFinished: {
                const out = []
                for (const l of text.split("\n")) {
                    const p = l.split("\t")
                    if (p[0]) out.push({ id: p[0], name: p[1] || p[0], desc: p[2] || "" })
                }
                root.themes = out
            }
        }
    }
    Process {
        id: fileLister
        command: ["sh", root.script, "files"]
        stdout: StdioCollector {
            onStreamFinished: {
                const out = []
                for (const l of text.split("\n")) {
                    const p = l.split("\t")
                    if (p.length >= 3 && p[2]) out.push({ theme: p[0], name: p[1], file: p[2] })
                }
                root.files = out
            }
        }
    }
    function refreshFiles() { fileLister.running = true }
    // a check of what is there: [{ ok: "ok" | "bad" | "warn", text }]
    property var checkLines: []
    property bool checking: false
    function check() { if (doctor.running) return; checking = true; doctor.command = ["sh", root.script, "doctor", Config.c.soundTheme || ""]; doctor.running = true }
    Process {
        id: doctor
        stdout: StdioCollector {
            onStreamFinished: {
                const out = []
                for (const l of text.split("\n")) { const p = l.split("\t"); if (p.length >= 2) out.push({ ok: p[0], text: p[1] }) }
                root.checkLines = out
                root.checking = false
            }
        }
    }
    function pickOf(id) { return (Config.c.soundPicks || {})[id] || "" }
    function setPick(id, file) { const o = Object.assign({}, Config.c.soundPicks || {}); if (file) o[id] = file; else delete o[id]; Config.c.soundPicks = o }
    function playFile(f) { if (f) Quickshell.execDetached(["sh", script, "file", f]) }
    // started with the shell (charger sounds need it running)
    function init() {
        const s = bat.state
        lastState = (s === UPowerDeviceState.Charging || s === UPowerDeviceState.FullyCharged || s === UPowerDeviceState.PendingCharge) ? 1 : 0
        refresh()
    }

    // play one of a theme's sounds (theme "" = the chosen one); quietly nothing when there is none
    function playNames(names, theme) {
        const th = theme === undefined ? (Config.c.soundTheme || "") : theme
        if (th === "") return
        Quickshell.execDetached(["sh", script, "play", th].concat(names))
    }
    // an event, if its sound is turned on
    property double lastVolume: 0
    function play(id) {
        const e = events.find(x => x.id === id)
        if (!e || !Config.c[e.key]) return
        if (id === "volume") {                       // holding a volume key: not a sound per step
            const now = Date.now()
            if (now - lastVolume < 120) return
            lastVolume = now
        }
        const pick = pickOf(id)
        if (pick !== "") playFile(pick)
        else playNames(e.sounds)
    }
    // hear one: the event's sound in a theme (the chosen sound, when it has one and no theme is given)
    function preview(id, theme) {
        const e = events.find(x => x.id === id)
        if (!e) return
        if (theme === undefined && pickOf(id) !== "") playFile(pickOf(id))
        else playNames(e.sounds, theme)
    }

    // a device connected (Bluetooth): its sound
    property int lastDevices: -1
    Connections {
        target: Gadgets
        function onConnectedChanged() {
            const n = Gadgets.connected.length
            if (root.lastDevices >= 0 && n > root.lastDevices) root.play("devices")
            root.lastDevices = n
        }
    }

    // GTK / GNOME apps use the same theme (and no sounds when there is none)
    Connections {
        target: Config.c
        function onSoundThemeChanged() { Quickshell.execDetached(["sh", root.script, "apply", Config.c.soundTheme || ""]) }
    }

    // charger in / out, and the battery running low
    readonly property var bat: UPower.displayDevice
    property int lastState: -1
    Connections {
        target: root.bat
        function onStateChanged() {
            const s = root.bat.state
            const charging = s === UPowerDeviceState.Charging || s === UPowerDeviceState.FullyCharged || s === UPowerDeviceState.PendingCharge
            const was = root.lastState
            root.lastState = charging ? 1 : 0
            if (was === -1 || was === root.lastState || !Config.c.soundPower) return
            root.playNames(charging ? ["power-plug", "device-added"] : ["power-unplug", "device-removed"])
        }
    }
}
