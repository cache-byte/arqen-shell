pragma Singleton
import Quickshell
import Quickshell.Io
import QtQuick
import qs.config

// Screenshots and recordings just taken, waiting for you to say what to do with them
// (Settings > Desktop > After a screenshot: "ask"). scripts/capture.sh writes each one hidden
// (".Screenshot_....png") and tells us; modules/CaptureAfter.qml shows it with Save / Copy / Edit /
// Rename / Delete. Saving unhides it under its name (or the one you typed). Left alone, it is saved
// after Config.c.captureAfterSecs.
Singleton {
    id: root
    // { id, kind: "shot" | "rec", tmp, dir, name, thumb, copied }
    property var pending: []
    property int serial: 0

    // runs scripts/capture.sh and listens for what it took
    function run(cmd) { runner.createObject(root, { command: cmd }) }
    Component {
        id: runner
        Process {
            id: p
            running: true
            stdout: SplitParser { onRead: line => root.heard(line) }
            onExited: p.destroy()
        }
    }
    function heard(line) {
        const m = /^CAPTURED (shot|rec) (.+)$/.exec(String(line).trim())
        if (!m) return
        const tmp = m[2]
        const i = tmp.lastIndexOf("/")
        const dir = tmp.slice(0, i)
        const name = tmp.slice(i + 1).replace(/^\./, "")
        // (a screenshot is already on the clipboard when that is on: capture.sh put it there)
        const item = { id: ++serial, kind: m[1], tmp: tmp, dir: dir, name: name, thumb: m[1] === "shot" ? tmp : "", copied: m[1] === "shot" && Config.c.shotClipboard }
        pending = [item].concat(pending).slice(0, 4)
        // older ones pushed out of the stack are saved
        if (pending.length === 4) { const old = pending[3]; pending = pending.slice(0, 3); save(old.id) }
        if (item.kind === "rec") thumbFor(item)
    }
    function find(id) { return pending.find(x => x.id === id) ?? null }
    function drop(id) { pending = pending.filter(x => x.id !== id) }
    function update(id, fields) { pending = pending.map(x => x.id === id ? Object.assign({}, x, fields) : x) }

    // a still from a recording, for its card (when ffmpeg is there)
    function thumbFor(item) {
        const out = (Quickshell.env("XDG_RUNTIME_DIR") || "/tmp") + "/arqen-rec-thumb-" + item.id + ".jpg"
        thumbProc.createObject(root, { itemId: item.id, out: out,
            command: ["sh", "-c", "command -v ffmpeg >/dev/null && ffmpeg -v quiet -y -ss 0.4 -i \"$1\" -frames:v 1 -vf scale=480:-1 \"$2\" && echo ok", "thumb", item.tmp, out] })
    }
    Component {
        id: thumbProc
        Process {
            id: tp
            property int itemId
            property string out
            running: true
            stdout: SplitParser { onRead: line => { if (line.trim() === "ok") root.update(tp.itemId, { thumb: tp.out }) } }
            onExited: tp.destroy()
        }
    }

    // ---- what you can do with it ----
    // the name it gets when saved: what you typed (with its ending), else its own
    function finalName(item, typed) {
        let n = String(typed ?? "").trim().replace(/[\/\0]/g, "-")
        if (n === "") return item.name
        const ext = item.name.slice(item.name.lastIndexOf("."))
        if (!n.toLowerCase().endsWith(ext.toLowerCase())) n += ext
        return n
    }
    // unhide it (never over another file: "name (2).png"); then = what to run on the saved file
    function save(id, typed, then) {
        const it = find(id)
        if (!it) return
        drop(id)
        const name = finalName(it, typed)
        Quickshell.execDetached(["sh", "-c",
            'tmp="$1"; dir="$2"; name="$3"; then="$4"; [ -e "$tmp" ] || exit 0\n'
            + 'base="${name%.*}"; ext="${name##*.}"; f="$dir/$name"; n=2\n'
            + 'while [ -e "$f" ]; do f="$dir/$base ($n).$ext"; n=$((n+1)); done\n'
            + 'mv -n "$tmp" "$f" || exit 1\n'
            + 'case "$then" in\n'
            + '  edit) if command -v satty >/dev/null; then exec satty --filename "$f" --output-filename "$f"\n'
            + '        elif command -v swappy >/dev/null; then exec swappy -f "$f" -o "$f"\n'
            + '        else exec xdg-open "$f"; fi ;;\n'
            + '  open) exec xdg-open "$f" ;;\n'
            + '  copyfile) exec sh "$5" set copy "$f" ;;\n'
            + '  show) exec gdbus call --session --dest org.freedesktop.FileManager1 --object-path /org/freedesktop/FileManager1 --method org.freedesktop.FileManager1.ShowItems "[\'file://$f\']" "" ;;\n'
            + 'esac',
            "save", it.tmp, it.dir, name, then || "", Quickshell.shellDir + "/scripts/file-clip.sh"])
    }
    // the picture onto the clipboard (a recording: the file, to paste in a chat or a folder)
    function copy(id) {
        const it = find(id)
        if (!it) return
        if (it.kind === "shot") { Quickshell.execDetached(["sh", "-c", 'wl-copy --type image/png < "$1"', "copy", it.tmp]); update(id, { copied: true }) }
        // a recording is copied as a file: saved first, so what is pasted is where it stays
        else save(id, "", "copyfile")
    }
    function discard(id) {
        const it = find(id)
        if (!it) return
        drop(id)
        Quickshell.execDetached(["rm", "-f", "--", it.tmp])
    }
    function saveAll() { for (const it of pending.slice()) save(it.id) }
}
