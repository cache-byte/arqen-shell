pragma Singleton
import Quickshell
import Quickshell.Io
import Quickshell.Hyprland
import QtQuick

// Reads the live keybinds from Hyprland so labels like "(Super)" always match
// what is actually bound, including anything you changed in your own config.
Singleton {
    id: root
    property string launcher: "Super"
    property string search: "Super+Space"

    function refresh() { if (!proc.running) proc.running = true }

    function keyName(k) {
        if (!k) return ""
        return k.length === 1 ? k.toUpperCase() : k.charAt(0).toUpperCase() + k.slice(1)
    }
    function label(b) {
        const isSuperKey = /^super_[lr]$/i.test(b.key || "")
        const m = isSuperKey ? (b.modmask & ~64) : b.modmask
        const parts = []
        if (isSuperKey || (m & 64)) parts.push("Super")
        if (m & 4) parts.push("Ctrl")
        if (m & 8) parts.push("Alt")
        if (m & 1) parts.push("Shift")
        if (!isSuperKey) parts.push(b.key ? keyName(b.key) : ("key " + b.keycode))
        return parts.join("+")
    }
    function labelFor(binds, fragment) {
        const seen = []
        for (const b of binds) {
            // hyprland.conf: dispatcher "exec" + the command; hyprland.lua: every bind is "__lua",
            // so Arqen's binds carry the command in their description
            const cmd = b.dispatcher === "exec" ? (b.arg || "") : (b.description || "")
            if (!cmd.includes(fragment)) continue
            const t = label(b)
            if (!seen.includes(t)) seen.push(t)
        }
        return seen.length > 0 ? seen.slice(0, 2).join(" or ") : "no keybind set"
    }
    function parse(text) {
        let binds
        try { binds = JSON.parse(text) } catch (e) { return }
        launcher = labelFor(binds, "toggle launcher")
        search = labelFor(binds, "toggle search")
    }

    Component.onCompleted: refresh()

    Process {
        id: proc
        command: ["hyprctl", "binds", "-j"]
        stdout: StdioCollector { onStreamFinished: root.parse(text) }
    }

    Connections {
        target: Hyprland
        function onRawEvent(event) { if (event.name === "configreloaded") root.refresh() }
    }
}
