pragma Singleton
import Quickshell
import QtQuick
import Quickshell.Io
import qs.config

Singleton {
    id: root
    readonly property var all: DesktopEntries.applications.values
        .filter(a => !a.noDisplay)
        .sort((a, b) => a.name.localeCompare(b.name))

    // lower-cased names etc., worked out once (not again for every app at every key press)
    readonly property var index: all.map(a => ({ a: a, n: a.name.toLowerCase(),
        o: ((a.genericName || "") + " " + (a.comment || "") + " " + Array.from(a.keywords || []).join(" ")).toLowerCase() }))
    // the last few searches, so typing back (Backspace) is instant. A plain object filled in place:
    // reading and counting it inside search() must not touch properties the launcher's binding
    // depends on (that was the "binding loop detected for results" warning)
    property var cache: ({ map: {}, n: 0 })
    function clearCache() { cache.map = {}; cache.n = 0 }
    onIndexChanged: clearCache()
    Connections { target: Config.c; function onAppUsageChanged() { root.clearCache() } }
    function search(q) {
        q = (q || "").toLowerCase().trim()
        if (q === "") return all
        const c = cache
        const hit = c.map[q]
        if (hit) return hit
        const usage = Config.c.appUsage || {}
        const hits = []
        for (const e of index) {
            const n = e.n
            let s = 0
            if (n.startsWith(q)) s = 4
            else if (n.includes(" " + q)) s = 3
            else if (n.includes(q)) s = 2
            else if (e.o.includes(q)) s = 1
            if (s > 0) hits.push({ a: e.a, s: s + Math.min(usage[e.a.id] || 0, 50) / 100 })
        }
        hits.sort((x, y) => y.s - x.s)
        const out = hits.map(h => h.a)
        if (c.n > 60) { c.map = {}; c.n = 0 }
        c.map[q] = out; c.n++
        return out
    }
    // Reading .values here makes every binding that calls byId() re-run once the
    // desktop-entry database finishes loading (it loads asynchronously at startup).
    function byId(id) {
        const _ready = DesktopEntries.applications.values
        // the Settings window is a Quickshell window: show it as "Arqen Settings"
        if (/quickshell/i.test(id || "")) return DesktopEntries.byId("arqen-settings") ?? DesktopEntries.heuristicLookup(id)
        return DesktopEntries.heuristicLookup(id) ?? looseLookup(id)
    }
    // "firefox" for org.mozilla.firefox, "code" for com.visualstudio.code, a window class, a name ...
    function looseLookup(id) {
        const w = String(id || "").toLowerCase().replace(/\.desktop$/, "")
        if (w === "") return null
        const apps = DesktopEntries.applications.values
        let hit = apps.find(a => String(a.id).toLowerCase() === w || String(a.startupClass || "").toLowerCase() === w)
        if (!hit) hit = apps.find(a => String(a.id).toLowerCase().endsWith("." + w) || String(a.name || "").toLowerCase() === w)
        if (!hit) hit = apps.find(a => String(a.id).toLowerCase().split(".").indexOf(w) >= 0)
        return hit ?? null
    }
    // Most-used first (with a bonus for recent launches), then your pinned and desktop apps, then the rest
    function suggested(n) {
        n = n || 8
        const usage = Config.c.appUsage || {}
        const recent = Config.c.recentApps || []
        const score = {}
        for (const a of all) {
            const r = recent.indexOf(a.id)
            score[a.id] = (usage[a.id] || 0) * 10 + (r >= 0 ? 8 - r : 0)
        }
        const out = all.filter(a => score[a.id] > 0).sort((x, y) => score[y.id] - score[x.id]).slice(0, n)
        const seeds = (Config.c.pinned || []).concat(Config.c.desktopApps || [])
        for (const id of seeds) { if (out.length >= n) break; const e = byId(id); if (e && !out.includes(e)) out.push(e) }
        for (const a of all) { if (out.length >= n) break; if (!out.includes(a)) out.push(a) }
        return out.slice(0, n)
    }
    // ---- icons ----
    // The image file of every app's icon, looked up in the icon folders by scripts/resolve-icons.py
    // (PNG first). Qt's own lookup is the fallback: some Quickshell builds find no icon theme, or
    // cannot draw SVG, and then the dock, launcher and desktop showed no icons at all.
    property var iconFiles: ({})
    // Qt's own lookup by name; with no name at all the plain executable icon (an empty name asked Qt for
    // the icon "?fallback=..." and logged "Could not load icon" every time)
    function themed(name) { return Quickshell.iconPath(name ? name : "application-x-executable", "application-x-executable") }
    function icon(entry) {
        const n = entry?.icon ?? ""
        const f = iconFiles[n]
        return f ? "file://" + f : themed(n)
    }
    // the same for a bare icon name (or path)
    function iconFor(name) {
        const f = iconFiles[name]
        if (!f && /^steam_(app|icon)_\d+$/.test(name || "") && extraNames.indexOf(name) < 0) Qt.callLater(() => root.wantIcon(name))
        return f ? "file://" + f : themed(name)
    }
    // names asked for that are not apps' icons (a running Steam game's window): looked up too
    // (and the desktop's file and folder icons, from the same icon theme as the apps)
    property var extraNames: ["folder", "user-desktop", "text-x-generic", "application-pdf", "text-html", "text-x-script",
        "video-x-generic", "audio-x-generic", "package-x-generic", "x-office-document", "x-office-spreadsheet",
        "x-office-presentation", "media-optical", "application-x-executable", "image-x-generic"]
    function wantIcon(name) { if (extraNames.indexOf(name) < 0) { extraNames = extraNames.concat([name]); iconTimer.restart() } }
    function refreshIcons() { iconTimer.restart() }
    onAllChanged: iconTimer.restart()
    Connections { target: Config.c; function onIconThemeChanged() { iconTimer.restart() } }
    Timer {
        id: iconTimer
        interval: 600
        onTriggered: {
            if (iconProc.running) { restart(); return }
            const names = {}
            for (const a of DesktopEntries.applications.values) if (a.icon) names[a.icon] = true
            for (const n of root.extraNames) names[n] = true
            iconProc.command = ["python3", "-I", Quickshell.shellDir + "/scripts/resolve-icons.py", "--all", Config.c.iconTheme || "", "--"].concat(Object.keys(names))
            iconProc.running = true
        }
    }
    Process {
        id: iconProc
        stdout: StdioCollector {
            onStreamFinished: { try { root.iconFiles = JSON.parse(text) } catch (e) {} }
        }
    }
}
