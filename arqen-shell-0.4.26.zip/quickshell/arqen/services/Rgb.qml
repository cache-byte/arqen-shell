pragma Singleton
import Quickshell
import Quickshell.Io
import QtQuick
import qs.config

// Lighting on keyboards, mice, fans, RAM ... through OpenRGB (https://openrgb.org). Settings > Lighting:
// leave it alone, follow the shell's accent colour (which follows the wallpaper), pick a colour, or turn the lights off.
// OpenRGB's own server (openrgb --server) is kept running in the background so a colour change is quick.
Singleton {
    id: root
    property bool found: false              // the openrgb program exists
    property string status: ""              // what the last change said
    property bool busy: applyProc.running
    readonly property string mode: Config.c.rgbMode || "off"      // off | wallpaper | custom | dark
    function hex(c) {
        const h = v => ("0" + Math.round(v * 255).toString(16)).slice(-2)
        return (h(c.r) + h(c.g) + h(c.b)).toUpperCase()
    }
    // the colour the lights should have, "" = do not touch them
    readonly property string wanted: mode === "wallpaper" ? hex(Theme.accent)
        : mode === "custom" ? hex(Qt.color(Config.c.rgbColor || "#FFFFFF"))
        : mode === "dark" ? "000000" : ""
    readonly property int brightness: Math.max(0, Math.min(100, Math.round(Config.c.rgbBrightness ?? 100)))
    readonly property bool useServer: Config.c.rgbServer !== false

    function init() { check.running = true }
    function apply() { if (found && wanted !== "") later.restart() }
    onWantedChanged: apply()
    onBrightnessChanged: apply()
    onFoundChanged: apply()

    Process {
        id: check
        command: ["sh", "-c", "command -v openrgb >/dev/null 2>&1 && echo yes || echo no"]
        stdout: StdioCollector { onStreamFinished: root.found = text.trim() === "yes" }
    }
    // OpenRGB's server: the colour commands connect to it (a server you started yourself is used the same way)
    Process {
        id: server
        command: ["openrgb", "--server", "--server-port", "6742"]
        running: root.found && root.mode !== "off" && root.useServer
        onRunningChanged: if (running) { later.interval = 4000; later.restart() }   // the server needs a few seconds to find the devices
    }
    Timer { id: later; interval: 900; onTriggered: { applyProc.running = false; applyProc.running = true; later.interval = 900 } }
    Process {
        id: applyProc
        // the brightness flag is newer than some OpenRGB versions: without it when the first try fails
        command: ["sh", "-c",
            'c="$1"; b="$2"; s="$3"; '
            + 'if [ "$s" = 1 ]; then base="openrgb --client 127.0.0.1:6742"; else base="openrgb"; fi; '
            + '$base --mode static --color "$c" --brightness "$b" >/dev/null 2>&1 || $base --mode static --color "$c" 2>&1 | tail -n 2; '
            + 'echo "@@done"', "rgb", root.wanted, String(root.brightness), root.useServer ? "1" : "0"]
        stdout: StdioCollector {
            onStreamFinished: {
                const t = text.replace("@@done", "").trim()
                root.status = t === "" ? "Sent #" + root.wanted : t
            }
        }
    }
}
