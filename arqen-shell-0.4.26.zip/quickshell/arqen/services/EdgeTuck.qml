pragma Singleton
import Quickshell
import Quickshell.Io
import Quickshell.Hyprland
import QtQuick
import qs.config

// Windows pushed (almost) off the screen. Hyprland lets a floating window be dragged until only a
// sliver of it is left on the screen, or none at all, and then it is hard to get back. So when a
// window has stayed more than Config.c.edgeTuckPart % off the screen for about a second, it is
// tucked away: moved to a hidden desktop ("special:edge") and shown as an icon in the edge panel
// (modules/EdgeDock.qml). Clicking it there brings it back to the desktop you are on, fully on the
// screen, near the edge it went out of.
//
// That makes a separate "invisible wall" around the screen unnecessary: nothing can get lost, and
// windows can still be pushed partly off the screen on purpose.
Singleton {
    id: root
    readonly property string ws: "special:edge"
    readonly property bool on: Config.c.edgeTuck

    // the tucked windows: [{ address, cls, title, at: [x, y], size: [w, h] }]
    property var tucked: []
    // which edge each one went out of: address -> "left" | "right" | "top" | "bottom"
    property var sideOf: ({})
    property var lastClients: []
    property var prevAt: ({})
    property var mons: []                    // hyprctl's screens at the last look
    // the panel's hidden desktop must never be open on a screen (Hyprland opens it when a window on it
    // gets the focus): close it whenever it is
    property double lastClose: 0
    function closeIfOpen() {
        if (Date.now() - lastClose < 800) return
        if (mons.some(m => m.specialWorkspace && m.specialWorkspace.name === ws)) { lastClose = Date.now(); Hypr.toggleSpecial("edge") }
    }
    // the desktop you are on now
    function currentDesktop() {
        const f = Hyprland.focusedWorkspace?.id ?? 0
        if (f > 0) return f
        const m = mons.find(x => x.focused)
        const id = m?.activeWorkspace?.id ?? 0
        return id > 0 ? id : 1
    }
    property var lastWs: ({})
    property var lastShown: ({})             // address -> its desktop was in view at the last look                // address -> desktop id at the last look
    property var arrived: ({})               // address -> when it came to its desktop
    property var placed: ({})                // address -> pulled onto the screen already (once per arrival)
    property double switchedAt: 0            // when the desktop was last changed
    property var restoring: ({})             // address -> when it was brought back
    property var pending: ({})               // address -> { when, item }: tucked a moment ago
    property bool anyFloating: false          // a floating window on a desktop: look more often                 // address -> "x,y" at the last look (still moving?)
    signal tuckedOne(string address)

    function screenRects() {
        return Quickshell.screens.map(s => ({ x: s.x, y: s.y, w: s.width, h: s.height, name: s.name }))
    }
    function overlap(ax, ay, aw, ah, b) {
        const w = Math.min(ax + aw, b.x + b.w) - Math.max(ax, b.x)
        const h = Math.min(ay + ah, b.y + b.h) - Math.max(ay, b.y)
        return w > 0 && h > 0 ? w * h : 0
    }
    // how much of a window is on any screen (0..1)
    function shownPart(c, rects) {
        const w = c.size[0], h = c.size[1]
        if (w <= 0 || h <= 0) return 1
        let a = 0
        for (const r of rects) a += overlap(c.at[0], c.at[1], w, h, r)
        return Math.min(1, a / (w * h))
    }
    // the screen a window is nearest to, and the edge of it the window went past
    function nearest(c, rects) {
        const cx = c.at[0] + c.size[0] / 2, cy = c.at[1] + c.size[1] / 2
        let best = rects[0], bd = Infinity
        for (const r of rects) {
            const dx = Math.max(r.x - cx, 0, cx - (r.x + r.w)), dy = Math.max(r.y - cy, 0, cy - (r.y + r.h))
            const d = dx * dx + dy * dy
            if (d < bd) { bd = d; best = r }
        }
        let side = "right"
        if (best) {
            const l = best.x - cx, rr = cx - (best.x + best.w), t = best.y - cy, b = cy - (best.y + best.h)
            const m = Math.max(l, rr, t, b)
            side = m === l ? "left" : (m === rr ? "right" : (m === t ? "top" : "bottom"))
        }
        return { rect: best, side: side }
    }

    function look(cs) {
        lastClients = cs
        const rects = screenRects()
        const limit = 1 - Math.max(50, Math.min(99, Config.c.edgeTuckPart || 75)) / 100
        const t = [], seen = {}, prev = {}
        let floating = false
        // only windows on a desktop you can see right now (one per screen): the others cannot be
        // being dragged, and while desktops slide past each other nothing is judged at all
        const shown = {}
        for (const m of mons) if (m.activeWorkspace) shown[m.activeWorkspace.id] = true
        if (mons.length === 0) for (const m of Hyprland.monitors.values) if (m.activeWorkspace) shown[m.activeWorkspace.id] = true
        const settling = Date.now() - switchedAt < 900
        const now0 = Date.now(), wsNow = {}, shownNow = {}, came = Object.assign({}, arrived)
        for (const c of cs) {
            if (!c.workspace) continue
            if (c.workspace.name === ws) {
                if (Date.now() - (restoring[c.address] || 0) < 2000) continue    // on its way back
                t.push({ address: c.address, cls: c.class || c.initialClass || "", title: c.title || "", at: c.at, size: c.size })
                continue
            }
            // a window that just came to this desktop (moved here from another one, out of this panel
            // or the minimised ones, or just opened) was not dragged off the screen by you: if it lands
            // mostly off the screen, it is pulled onto it instead of being tucked away
            wsNow[c.address] = c.workspace.id
            // (its desktop coming into view counts too: switching to it is arriving, for you)
            const inView = !!shown[c.workspace.id]
            shownNow[c.address] = inView
            if (lastWs[c.address] !== c.workspace.id || (inView && !lastShown[c.address])) came[c.address] = now0
            const fresh = now0 - (came[c.address] || 0) < 2500
            if (!on || !c.floating || !c.mapped || c.hidden || c.fullscreen > 0 || c.workspace.id <= 0) continue
            if (!c.at || !c.size || rects.length === 0) continue
            if (c.size[0] < 80 || c.size[1] < 60) continue     // tiny helper windows some apps keep off the screen
            if (!shown[c.workspace.id]) continue
            floating = true
            if (fresh) {
                if (shownPart(c, rects) <= limit && !placed[c.address]) {
                    const p = onScreenPos(c, screenOf(c))
                    Hypr.moveWindowTo(c.address, p.x, p.y)
                    placed[c.address] = true
                }
                continue
            }
            if (settling) continue
            const key = c.at[0] + "," + c.at[1]
            const was = prevAt[c.address]
            const still = was && was.key === key ? was.n + 1 : 0
            prev[c.address] = { key: key, n: still }
            // far enough off the screen, and still for a moment (let go of: about half a second)
            if (shownPart(c, rects) <= limit && still >= 2 && !pending[c.address]) tuck(c, rects)
        }
        prevAt = prev
        anyFloating = floating
        lastWs = wsNow
        lastShown = shownNow
        const keep = {}, keepP = {}
        for (const a in came) if (now0 - came[a] < 2500 && wsNow[a] !== undefined) { keep[a] = came[a]; if (placed[a]) keepP[a] = true }
        arrived = keep; placed = keepP
        // just sent away, Hyprland may not have moved them yet: keep them in the panel meanwhile
        const now = Date.now(), pend = {}
        for (const a in pending) {
            if (t.some(x => x.address === a) || now - pending[a].when > 3000) continue
            pend[a] = pending[a]
            t.push(pending[a].item)
        }
        pending = pend
        // keep the order they were tucked in (new ones last)
        const old = tucked.map(x => x.address)
        t.sort((a, b) => {
            const ia = old.indexOf(a.address), ib = old.indexOf(b.address)
            return (ia < 0 ? 1e6 : ia) - (ib < 0 ? 1e6 : ib)
        })
        if (JSON.stringify(t) !== JSON.stringify(tucked)) tucked = t
    }
    function tuck(c, rects) {
        const n = nearest(c, rects)
        const s = Object.assign({}, sideOf); s[c.address] = n.side; sideOf = s
        Hypr.moveToWorkspace(c.address, ws, false)
        // in the panel at once (not only at the next look)
        const item = { address: c.address, cls: c.class || c.initialClass || "", title: c.title || "", at: c.at, size: c.size }
        const p = Object.assign({}, pending); p[c.address] = { when: Date.now(), item: item }; pending = p
        if (!tucked.some(x => x.address === c.address)) tucked = tucked.concat([item])
        tuckedOne(c.address)
        poke.restart()
    }

    // where a window goes so all of it is on screen `scr`: as close as possible to where it is
    function onScreenPos(c, scr) {
        const m = 24 + Ui.gap
        const w = c.size[0], h = c.size[1]
        const minX = scr.x + m, maxX = scr.x + scr.width - w - m
        const minY = scr.y + m, maxY = scr.y + scr.height - h - m
        const x = maxX < minX ? scr.x + Math.max(0, (scr.width - w) / 2) : Math.max(minX, Math.min(maxX, c.at[0]))
        const y = maxY < minY ? scr.y + Math.max(0, (scr.height - h) / 2) : Math.max(minY, Math.min(maxY, c.at[1]))
        return { x: x, y: y }
    }
    function screenOf(c) {
        const m = Hyprland.monitors.values.find(x => x.id === c.monitor)
        return Quickshell.screens.find(s => s.name === m?.name) ?? Quickshell.screens[0]
    }

    // bring it back: onto the desktop you are on, all of it on the screen, by the edge it left from
    function restore(address) {
        const c = lastClients.find(x => x.address === address) || tucked.find(x => x.address === address)
        const mon = Hyprland.focusedMonitor
        const scr = Quickshell.screens.find(s => s.name === mon?.name) ?? Quickshell.screens[0]
        // the desktop you are on (never a hidden one such as this panel's own)
        const wsId = currentDesktop()
        Hypr.moveToWorkspace(address, wsId, true)
        if (c && c.at && c.size && scr) { const p = onScreenPos(c, scr); Hypr.moveWindowTo(address, p.x, p.y) }
        Hypr.focusWindow(address)
        // focused again once it has arrived (the first call can come before the move has finished)
        refocusAddr = address; refocusTries = 0; refocus.restart()
        const s = Object.assign({}, sideOf); delete s[address]; sideOf = s
        tucked = tucked.filter(x => x.address !== address)
        const r = Object.assign({}, restoring); r[address] = Date.now(); restoring = r
        const p = Object.assign({}, pending); delete p[address]; pending = p
        poke.restart()
    }
    property string refocusAddr: ""
    // focus (and raise) again a few times while it settles: the first calls can come before the move from the
    // hidden desktop has finished, and focus then stays on the window it came from
    property int refocusTries: 0
    Timer {
        id: refocus
        interval: 140; repeat: true
        onTriggered: {
            if (root.refocusAddr === "") { stop(); return }
            Hypr.focusWindow(root.refocusAddr)
            Hypr.raiseWindow(root.refocusAddr)
            if (++root.refocusTries >= 4) { stop(); root.refocusAddr = "" }
        }
    }
    function restoreAll() { for (const t of tucked.slice()) restore(t.address) }
    // tuck a window now (the window handle's button)
    function tuckWindow(address) {
        const a = "0x" + String(address || "").replace(/^0x/, "")
        const c = lastClients.find(x => x.address === a)
        if (c) tuck(c, screenRects())
    }
    // the focused window to the side panel (Super+H); false when that cannot be done (then it is minimised the plain way)
    function tuckActive() {
        const a = Hyprland.activeToplevel?.address
        if (!a || !Config.c.edgeTuck) return false
        const ad = "0x" + String(a).replace(/^0x/, "")
        const c = lastClients.find(x => x.address === ad)
        if (!c) return false
        tuck(c, screenRects())
        return true
    }
    function close(address) { Hypr.closeWindow(address); tucked = tucked.filter(x => x.address !== address); poke.restart() }
    function isTucked(address) { const a = "0x" + String(address || "").replace(/^0x/, ""); return tucked.some(x => x.address === a) }

    // ---- after a change of screen scale, resolution or turn: windows that no longer fit are made to fit ----
    // A floating window bigger than the screen's usable area is made smaller and put on the screen. One that
    // cannot be made small enough, and is not the one you are using, goes to the edge panel (click it there to
    // bring it back, it then has the focus).
    function usableRects() {
        return mons.map(m => {
            const sc = m.scale || 1
            const rot = (m.transform || 0) % 2 === 1
            const r = m.reserved || [0, 0, 0, 0]
            const w = (rot ? m.height : m.width) / sc, h = (rot ? m.width : m.height) / sc
            return { id: m.id, x: m.x + r[0], y: m.y + r[1], w: w - r[0] - r[2], h: h - r[1] - r[3] }
        })
    }
    function fitAll() {
        if (!Config.hyprChecked || lastClients.length === 0 || mons.length === 0) return
        const rects = usableRects()
        const active = Hyprland.activeToplevel?.address ? "0x" + String(Hyprland.activeToplevel.address).replace(/^0x/, "") : ""
        const pad = 12
        for (const c of lastClients) {
            if (!c.floating || !c.mapped || c.hidden || (c.fullscreen ?? 0) > 0 || !c.workspace || c.workspace.id <= 0 || !c.at || !c.size) continue
            const r = rects.find(x => x.id === c.monitor) ?? rects[0]
            if (!r) continue
            const maxW = r.w - 2 * pad, maxH = r.h - 2 * pad
            const nw = Math.min(c.size[0], maxW), nh = Math.min(c.size[1], maxH)
            const tooSmall = maxW < 220 || maxH < 160
            if (tooSmall && c.address !== active) { tuck(c, screenRects()); continue }
            const off = c.at[0] < r.x || c.at[1] < r.y || c.at[0] + nw > r.x + r.w || c.at[1] + nh > r.y + r.h
            if (nw < c.size[0] || nh < c.size[1]) Hypr.resizeWindowTo(c.address, nw, nh)
            if (off || nw < c.size[0] || nh < c.size[1]) {
                const x = Math.max(r.x + pad, Math.min(r.x + r.w - nw - pad, c.at[0]))
                const y = Math.max(r.y + pad, Math.min(r.y + r.h - nh - pad, c.at[1]))
                Hypr.moveWindowTo(c.address, x, y)
            }
        }
    }
    Timer { id: fitLater; interval: 3200; onTriggered: { if (!proc.running) proc.running = true; fitNow.restart() } }
    Timer { id: fitNow; interval: 700; onTriggered: root.fitAll() }
    Connections {
        target: Config.c
        function onMonitorsChanged() { fitLater.restart() }
        function onScaleChanged() { fitLater.restart() }
    }

    // ---- looking (hyprctl is small and quick) ----
    Timer {
        id: tick
        // often while a window floats (it can be dragged away), rarely otherwise
        interval: root.anyFloating ? 800 : 8000; repeat: true
        // (also while the window handle is on: it needs to know where the windows are)
        running: Config.hyprChecked && (root.on || root.tucked.length > 0 || Config.c.winHandle)
        triggeredOnStart: true
        onTriggered: if (!proc.running) proc.running = true
    }
    // a look soon after something changed
    Timer { id: poke; interval: 120; onTriggered: if (!proc.running) proc.running = true }
    Process {
        id: proc
        // the windows, and the screens (which desktop each one shows, and whether a hidden one is open)
        command: ["sh", "-c", "hyprctl -j clients; echo '@@@'; hyprctl -j monitors"]
        stdout: StdioCollector {
            onStreamFinished: {
                const parts = text.split("@@@")
                let cs, ms
                try { cs = JSON.parse(parts[0]); ms = JSON.parse(parts[1] || "[]") } catch (e) { return }
                if (!Array.isArray(cs)) return
                root.mons = Array.isArray(ms) ? ms : []
                root.closeIfOpen()
                root.look(cs)
            }
        }
    }
    Connections {
        target: Hyprland
        function onRawEvent(ev) {
            // the panel's hidden desktop got shown: close it again (see closeIfOpen)
            if (ev.name === "activespecial" && String(ev.data || "").split(",")[0] === root.ws) {
                root.lastClose = Date.now(); Hypr.toggleSpecial("edge")
                return
            }
            if (["workspace", "workspacev2", "focusedmon", "focusedmonv2", "activespecial", "activespecialv2"].indexOf(ev.name) >= 0) {
                // a desktop change: forget how long windows stood still, and wait for it to settle
                root.switchedAt = Date.now(); root.prevAt = ({})
                poke.restart()
                return
            }
            if (ev.name === "monitoraddedv2" || ev.name === "monitorremovedv2" || ev.name === "monitoradded" || ev.name === "monitorremoved") { fitLater.restart(); return }
            if (["closewindow", "movewindowv2", "openwindow", "changefloatingmode", "activewindowv2"].indexOf(ev.name) >= 0) poke.restart()
        }
    }
}
