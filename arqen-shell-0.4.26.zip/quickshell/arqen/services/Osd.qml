pragma Singleton
import Quickshell
import Quickshell.Io
import Quickshell.Services.Pipewire
import Quickshell.Services.Mpris
import QtQuick
import qs.config

// The keys on the keyboard that change something (volume, brightness, keyboard light, media, Caps
// Lock, Num Lock...). Hyprland sends them here (`qs -c arqen ipc call arqen key NAME`, bound in
// the file Arqen writes for Hyprland); this does the action and shows the on-screen display.
Singleton {
    id: root

    // ---- what the OSD shows ----
    property string icon: ""
    property string label: ""
    property real value: -1          // 0..1 shows a bar, -1 shows only icon and text
    property bool shown: false
    property bool off: false         // the bar is greyed out with offIcon (muted volume), like the control centre
    property string offIcon: ""
    property int serial: 0           // changes on every show, even with the same content
    function show(icon_, label_, value_, offIcon_) {
        icon = icon_; label = label_; value = value_ === undefined ? -1 : value_
        offIcon = offIcon_ || ""; off = offIcon !== ""
        shown = true; serial++
        hideTimer.restart()
    }
    Timer { id: hideTimer; interval: 1600; onTriggered: root.shown = false }

    readonly property var sink: Pipewire.defaultAudioSink
    readonly property var source: Pipewire.defaultAudioSource
    PwObjectTracker { objects: [root.sink, root.source] }

    // the player the media keys talk to: the one playing, else the first one
    readonly property var player: Mpris.players.values.find(p => p.isPlaying) ?? Mpris.players.values[0] ?? null

    function volumeIcon(v, m) { return m || v <= 0.001 ? "volume_off" : (v < 0.34 ? "volume_mute" : (v < 0.67 ? "volume_down" : "volume_up")) }

    function key(name) {
        const a = sink?.audio
        switch (name) {
        case "volume-up":
        case "volume-down": {
            if (!a) { show("volume_off", "No sound output"); return }
            if (a.muted && name === "volume-up") a.muted = false
            const v = Math.max(0, Math.min(1, Math.round((a.volume + (name === "volume-up" ? 0.05 : -0.05)) * 100) / 100))
            a.volume = v
            show(volumeIcon(v, a.muted), "Volume", v, a.muted || v <= 0 ? "music_off" : "")
            Sounds.play("volume")
            return
        }
        case "mute":
            if (!a) { show("volume_off", "No sound output"); return }
            a.muted = !a.muted
            show(volumeIcon(a.volume, a.muted), a.muted ? "Muted" : "Volume", a.volume, a.muted ? "music_off" : "")
            if (!a.muted) Sounds.play("volume")
            return
        case "mic-mute": {
            const m = source?.audio
            if (!m) { show("mic_off", "No microphone"); return }
            m.muted = !m.muted
            show(m.muted ? "mic_off" : "mic", m.muted ? "Microphone off" : "Microphone on")
            return
        }
        case "brightness-up":
        case "brightness-down":
            // no backlight to control (a desktop PC, an external screen, brightnessctl missing): say so, run nothing
            if (!QuickSettings.hasBrightness) { show("brightness_6", "No brightness control"); return }
            QuickSettings.stepBrightness(name === "brightness-up")
            show("brightness_6", "Brightness", QuickSettings.brightness)
            return
        case "kbd-up":
        case "kbd-down":
            kbdProc.command = ["sh", "-c", "d=$(brightnessctl -l -m 2>/dev/null | grep -i kbd_backlight | head -n1 | cut -d, -f1); [ -n \"$d\" ] || exit 1; "
                + "brightnessctl -q -d \"$d\" set " + (name === "kbd-up" ? "1+" : "1-") + "; brightnessctl -m -d \"$d\""]
            kbdProc.running = true
            return
        case "play-pause":
        case "play":
        case "pause":
            if (!player) { show("music_off", "Nothing playing"); return }
            // only what this player says it can do (the others logged errors on some players and keyboards)
            if (name === "pause") { if (player.canPause) player.pause() }
            else if (name === "play") { if (player.canPlay) player.play() }
            else if (player.canTogglePlaying) player.togglePlaying()
            else if (player.isPlaying) { if (player.canPause) player.pause() }
            else if (player.canPlay) player.play()
            mediaLater.what = player.isPlaying && name !== "play" ? "Paused" : "Playing"
            mediaLater.icon = mediaLater.what === "Paused" ? "pause" : "play_arrow"
            mediaLater.restart()
            return
        case "next":
        case "prev":
            if (!player) { show("music_off", "Nothing playing"); return }
            if (name === "next" ? !player.canGoNext : !player.canGoPrevious) { show(name === "next" ? "skip_next" : "skip_previous", "Not available in " + (player.identity || "this player")); return }
            if (name === "next") player.next(); else player.previous()
            mediaLater.what = ""; mediaLater.icon = name === "next" ? "skip_next" : "skip_previous"
            mediaLater.restart()
            return
        case "rewind":
        case "forward":
            if (!player) { show("music_off", "Nothing playing"); return }
            if (!player.canSeek) { show(name === "rewind" ? "fast_rewind" : "fast_forward", "Not available in " + (player.identity || "this player")); return }
            player.seek(name === "rewind" ? -10 : 10)
            show(name === "rewind" ? "fast_rewind" : "fast_forward", name === "rewind" ? "Back 10 seconds" : "Forward 10 seconds")
            return
        case "stop":
            if (player && player.canControl) player.stop()
            show("stop", player ? "Stopped" : "Nothing playing")
            return
        case "lock":
            // the screensaver / lock key some keyboards have
            Ui.lock()
            return
        case "capture":
            // Print key: the capture screen (or stop a recording)
            if (QuickSettings.recording) QuickSettings.record("stop"); else Ui.startCapture()
            return
        case "caps":
        case "num":
            // the light watcher (below) already shows it when this machine has that light
            if ((name === "caps" && root.capsLed) || (name === "num" && root.numLed)) return
            // the light changes after the key; read it a moment later
            lockLater.what = name
            lockLater.restart()
            return
        }
    }

    // the new track's name arrives a moment after the key
    Timer {
        id: mediaLater
        property string what: ""
        property string icon: ""
        interval: 250
        onTriggered: {
            const p = root.player
            const t = p ? [p.trackTitle, p.trackArtist].filter(x => x).join("  ·  ") : ""
            root.show(icon, what !== "" ? what + (t !== "" ? ": " + t : "") : (t || (p?.identity ?? "")))
        }
    }

    Process {
        id: kbdProc
        stdout: StdioCollector {
            onStreamFinished: {
                const f = text.trim().split("\n").pop().split(",")
                if (f.length >= 5) root.show("keyboard", "Keyboard light", parseInt(f[3]) / 100)
            }
        }
        onExited: code => { if (code !== 0) root.show("keyboard", "No keyboard light") }
    }

    Timer {
        id: lockLater
        property string what: ""
        interval: 120
        onTriggered: lockProc.running = true
    }
    Process {
        id: lockProc
        command: ["hyprctl", "-j", "devices"]
        stdout: StdioCollector {
            onStreamFinished: {
                let kb = null
                try {
                    const ks = JSON.parse(text).keyboards || []
                    kb = ks.find(k => k.main) ?? ks[0] ?? null
                } catch (e) {}
                if (!kb) return
                if (lockLater.what === "caps") root.show(kb.capsLock ? "keyboard_capslock_badge" : "keyboard_capslock", kb.capsLock ? "Caps Lock on" : "Caps Lock off")
                else root.show("dialpad", kb.numLock ? "Num Lock on" : "Num Lock off")
            }
        }
    }

    // ---- Caps Lock / Num Lock lights: shown whenever they change, however that happened ----
    property bool capsLed: false
    property bool numLed: false
    Process {
        id: lockWatch
        running: true
        command: ["sh", Quickshell.shellDir + "/scripts/lock-watch.sh"]
        stdout: SplitParser {
            onRead: line => {
                const w = line.trim().split(/\s+/)
                if (w[0] === "have") { root.capsLed = w.indexOf("caps") > 0; root.numLed = w.indexOf("num") > 0; return }
                if (!Config.c.osdKeys) return
                const on = w[1] !== "0"
                if (w[0] === "caps") root.show(on ? "keyboard_capslock_badge" : "keyboard_capslock", on ? "Caps Lock on" : "Caps Lock off")
                else if (w[0] === "num") root.show("dialpad", on ? "Num Lock on" : "Num Lock off")
            }
        }
        onExited: { root.capsLed = false; root.numLed = false }
    }
}
