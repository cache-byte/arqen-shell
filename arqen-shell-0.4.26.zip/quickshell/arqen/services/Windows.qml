pragma Singleton
import Quickshell
import Quickshell.Io
import Quickshell.Hyprland
import QtQuick
import qs.config

// Minimising windows. Hyprland has no minimised state of its own, so a minimised window is
// moved to a hidden desktop ("special:minimized"). It is still in the dock: click it there
// to bring it back to the desktop you are on.
//   - an app's own minimise button (GTK, Qt, browsers...) asks Hyprland, which tells us
//     with a "minimized" event
//   - `qs -c arqen ipc call arqen minimize` minimises the focused window
Singleton {
    id: root
    readonly property string hidden: "special:minimized"

    function addr(a) { a = String(a || ""); return "0x" + a.replace(/^0x/, "") }

    // the desktop showing on the focused screen (never a hidden one)
    function shownDesktop() {
        const f = Hyprland.focusedWorkspace?.id ?? 0
        if (f > 0) return f
        const id = Hyprland.focusedMonitor?.activeWorkspace?.id ?? 1
        return id > 0 ? id : 1
    }
    function minimize(address) {
        Hypr.moveToWorkspace(address, hidden, false)
    }
    function minimizeActive() {
        const a = Hyprland.activeToplevel
        if (a && a.address) minimize(a.address)
        else Hypr.moveActiveToWorkspace(hidden, false)
    }
    // the Hyprland window behind a dock / taskbar window (Wayland toplevel)
    function hyprOf(tl) { return Hyprland.toplevels.values.find(h => h.wayland === tl) ?? null }
    function isMinimized(tl) {
        const h = hyprOf(tl)
        const n = h !== null ? (h.workspace?.name ?? "") : ""
        return n === hidden || n === EdgeTuck.ws        // tucked into the edge panel counts too
    }
    // bring it back to the current desktop and focus it; false when it was not minimised
    function restore(tl) {
        const h = hyprOf(tl)
        if (h && (h.workspace?.name ?? "") === EdgeTuck.ws) { EdgeTuck.restore("0x" + String(h.address).replace(/^0x/, "")); return true }
        if (!h || (h.workspace?.name ?? "") !== hidden) return false
        const ws = root.shownDesktop()
        Hypr.moveToWorkspace(h.address, ws, true)
        Hypr.focusWindow(h.address)
        return true
    }
    // Bring a window forward and give it the keyboard: from the dock, the panel, the overview, a notification.
    // `x` is a Wayland toplevel, a Hyprland toplevel or an address. The focus is sent again a few times: a pop-up
    // that is closing hands the keyboard back to the window you came from, which used to win.
    property string bringAddr: ""
    property int bringTries: 0
    function bring(x) {
        let h = null
        if (typeof x === "string") h = Hyprland.toplevels.values.find(t => Hypr.addr(t.address) === Hypr.addr(x)) ?? null
        else if (x && x.workspace !== undefined && x.address !== undefined) h = x
        else if (x) h = hyprOf(x)
        if (!h) { if (x && typeof x.activate === "function") x.activate(); return }
        if (h.wayland && restore(h.wayland)) return
        bringAddr = h.address
        bringTries = 0
        Hypr.focusWindow(bringAddr)
        Hypr.raiseWindow(bringAddr)
        bringTimer.restart()
    }
    Timer {
        id: bringTimer
        interval: 130; repeat: true
        onTriggered: {
            if (root.bringAddr === "" || !Hyprland.toplevels.values.some(t => Hypr.addr(t.address) === Hypr.addr(root.bringAddr))) { stop(); return }
            Hypr.focusWindow(root.bringAddr)
            if (++root.bringTries >= 3) { stop(); root.bringAddr = "" }
        }
    }
    function restoreAll() {
        const ws = root.shownDesktop()
        for (const h of Hyprland.toplevels.values)
            if ((h.workspace?.name ?? "") === hidden) Hypr.moveToWorkspace(h.address, ws, false)
    }
    readonly property int count: Hyprland.toplevels.values.filter(h => (h.workspace?.name ?? "") === hidden).length

    Connections {
        target: Hyprland
        function onRawEvent(event) {
            // the hidden desktop of minimised windows got shown (a minimised window took the focus):
            // hide it again and bring that window back properly
            if (event.name === "activespecial" && String(event.data || "").split(",")[0] === root.hidden) {
                Hypr.toggleSpecial("minimized")
                return
            }
            // "minimized>>ADDRESS,1" when an app asks to be minimised (its own minimise button)
            if (event.name !== "minimized") return
            const parts = String(event.data || "").split(",")
            if (parts.length >= 2 && parts[1].trim() === "1") root.minimize(parts[0].trim())
        }
    }
}
