pragma Singleton
import Quickshell
import Quickshell.Io
import QtQuick

// Clipboard history. Uses cliphist (stores what you copy) and wl-clipboard (watches for copies);
// both are installed by install.sh. The watchers are started by the shell itself, so no
// exec-once line is needed in hyprland.conf.
Singleton {
    id: root
    property var entries: []          // [{ id, text, image }], newest first
    property bool started: false
    readonly property string cache: "/tmp/arqen-clip"

    function init() {
        if (started) return
        started = true
        Quickshell.execDetached(["sh", "-c", "rm -rf " + cache + "; mkdir -p " + cache])
        textWatch.running = true
        imageWatch.running = true
        refresh()
    }
    function refresh() { if (!listProc.running) listProc.running = true }

    function valid(id) { return /^\d+$/.test(id) }
    function copy(id) {
        if (valid(id)) Quickshell.execDetached(["sh", "-c", "cliphist decode " + id + " | wl-copy"])
    }
    // put an entry into the window you were using, without copying it by hand first
    function paste(id) {
        if (valid(id)) Quickshell.execDetached(["sh", Quickshell.shellDir + "/scripts/paste.sh", String(id)])
    }
    function remove(id) {
        if (!valid(id)) return
        Quickshell.execDetached(["sh", "-c", "printf '%s\\t\\n' " + id + " | cliphist delete"])
        settle.restart()
    }
    function wipe() {
        Quickshell.execDetached(["sh", "-c", "cliphist wipe; rm -rf " + cache + "; mkdir -p " + cache])
        entries = []
        settle.restart()
    }

    function parse(text) {
        const out = []
        for (const line of text.split("\n")) {
            const i = line.indexOf("\t")
            if (i <= 0) continue
            const id = line.substring(0, i)
            if (!valid(id)) continue
            const body = line.substring(i + 1)
            out.push({ id: id, text: body, image: body.indexOf("[[ binary data") === 0 })
            if (out.length >= 80) break
        }
        entries = out
    }

    Process {
        id: listProc
        command: ["cliphist", "list"]
        stdout: StdioCollector { onStreamFinished: root.parse(text) }
    }
    // each of these runs `cliphist store` on every copy and prints a line, which triggers a refresh
    Process {
        id: textWatch
        command: ["wl-paste", "--type", "text", "--watch", "sh", "-c", "cliphist store; echo c"]
        stdout: SplitParser { onRead: settle.restart() }
    }
    Process {
        id: imageWatch
        command: ["wl-paste", "--type", "image", "--watch", "sh", "-c", "cliphist store; echo c"]
        stdout: SplitParser { onRead: settle.restart() }
    }
    Timer { id: settle; interval: 250; onTriggered: root.refresh() }
}
