pragma Singleton
import Quickshell
import Quickshell.Io
import Quickshell.Hyprland
import QtQuick
import qs.config

// Screens (Settings > Display and windows): what is connected, what each can do, and what you
// picked for it (Config.c.monitors, written into Hyprland's config by Config.qml).
Singleton {
    id: root
    property var list: []                  // from scripts/monitors.py
    property bool checking: false
    property bool checked: false           // a check has run: list holds `extra` modes
    function refresh() { if (!proc.running) { proc.command = ["python3", Quickshell.shellDir + "/scripts/monitors.py"]; proc.running = true } }
    function check() { checking = true; proc.command = ["python3", Quickshell.shellDir + "/scripts/monitors.py", "check"]; proc.running = true }
    Process {
        id: proc
        stdout: StdioCollector {
            onStreamFinished: {
                try { root.list = JSON.parse(text) } catch (e) { return }
                root.forgetGone()
                if (root.checking) { root.checking = false; root.checked = true }
            }
        }
    }
    // a screen plugged in or out: look again
    Connections {
        target: Hyprland
        function onRawEvent(ev) { if (ev.name === "monitoradded" || ev.name === "monitorremoved" || ev.name === "monitoraddedv2" || ev.name === "monitorremovedv2") later.restart() }
    }
    Timer { id: later; interval: 800; onTriggered: root.refresh() }
    // after a change has reached Hyprland, show what the screens do now
    Connections { target: Config.c; function onMonitorsChanged() { after.restart() } }
    Timer { id: after; interval: 2500; onTriggered: root.refresh() }

    // screens that are no longer plugged in are forgotten, with what was set for them
    function forgetGone() {
        const all = Config.c.monitors || {}
        const here = list.map(m => m.name)
        if (here.length === 0) return            // nothing read: do not forget everything by mistake
        const keep = {}
        let changed = false
        for (const n of Object.keys(all)) { if (here.indexOf(n) >= 0) keep[n] = all[n]; else changed = true }
        if (changed) Config.c.monitors = keep
        if (draft) {
            const dk = {}
            for (const n of Object.keys(draft.monitors)) if (here.indexOf(n) >= 0) dk[n] = draft.monitors[n]
            if (Object.keys(dk).length !== Object.keys(draft.monitors).length) draft = { monitors: dk, scale: draft.scale }
        }
    }

    // ---- staged changes: nothing reaches the screens until Apply ----
    // The page edits a draft (the arrangement view draws from it, so it is the preview). Apply writes it into the
    // settings and starts the trial below; Discard throws it away.
    property var draft: null                 // { monitors, scale } while there are staged changes, else null
    readonly property bool hasDraft: draft !== null
    function liveCopy() { return { monitors: JSON.parse(JSON.stringify(Config.c.monitors || {})), scale: Config.c.scale } }
    function monitorsNow() { return draft ? draft.monitors : (Config.c.monitors || {}) }
    // what is set for a screen, with the staged changes (the page shows this)
    function setting(name) { return monitorsNow()[name] || {} }
    function liveSetting(name) { return (Config.c.monitors || {})[name] || {} }
    // is this screen different in the draft from what is applied now?
    function isChanged(name) { return draft !== null && JSON.stringify(setting(name)) !== JSON.stringify(liveSetting(name)) }
    readonly property bool anyChanged: draft !== null && (JSON.stringify(draft.monitors) !== JSON.stringify(Config.c.monitors || {}) || draft.scale !== Config.c.scale)
    function discard() { draft = null }
    function stage(all) {
        const base = draft ?? liveCopy()
        draft = { monitors: all, scale: base.scale }
    }
    function set(name, key, value) {
        const all = Object.assign({}, monitorsNow())
        const m = Object.assign({}, all[name] || {})
        if (value === null || value === undefined || value === "") delete m[key]
        else m[key] = value
        if (Object.keys(m).length === 0) delete all[name]
        else all[name] = m
        // a different resolution may not allow the chosen scale; a different size or rotation can make screens overlap
        if (key === "mode" || key === "scale" || key === "transform") {
            fixScale(all, name)
            relayout(all, name)
        }
        stage(all)
    }

    // ---- scales Hyprland accepts ----
    // A scale must divide the resolution into whole logical pixels (1920x1080 at 1.75 is refused), so each
    // percentage maps to the closest value that does, as GNOME does. Returns [{ label, value }].
    function validScales(w, h) {
        if (!w || !h) return [{ label: "100 %", value: 1 }]
        const nominal = [1, 1.25, 1.5, 1.75, 2, 2.25, 2.5, 2.75, 3, 3.5, 4]
        const out = [], seen = {}
        for (const n of nominal) {
            let best = 0, bd = 1e9
            const lo = Math.max(1, Math.floor(w / (n * 1.08))), hi = Math.ceil(w / (n * 0.92))
            for (let lw = lo; lw <= hi; lw++) {
                if ((h * lw) % w !== 0) continue
                const sc = w / lw, d = Math.abs(sc - n)
                if (d < bd) { bd = d; best = sc }
            }
            if (best <= 0 || bd > 0.09 * n) continue
            const key = best.toFixed(6)
            if (seen[key]) continue
            seen[key] = true
            out.push({ label: Math.round(n * 100) + " %", value: Number(best.toFixed(8)) })
        }
        return out.length ? out : [{ label: "100 %", value: 1 }]
    }
    // the mode a screen has (or will have) as [w, h]
    function modeSize(mon, set) {
        if (set && set.mode) { const p = String(set.mode).split("@")[0].split("x"); const w = Number(p[0]), h = Number(p[1]); if (w > 0 && h > 0) return [w, h] }
        return [mon.width, mon.height]
    }
    function monOf(name) { return list.find(x => x.name === name) || null }
    function scalesFor(name) {
        const mon = monOf(name)
        if (!mon) return [{ label: "100 %", value: 1 }]
        const sz = modeSize(mon, monitorsNow()[name])
        return validScales(sz[0], sz[1])
    }
    function nearestScale(opts, v) {
        let best = opts[0], bd = 1e9
        for (const o of opts) { const d = Math.abs(o.value - v); if (d < bd) { bd = d; best = o } }
        return best
    }
    // after a mode change: keep the scale valid for the new resolution
    function fixScale(all, name) {
        const m = all[name]
        if (!m || !(Number(m.scale) > 0)) return
        const mon = monOf(name)
        if (!mon) return
        const sz = modeSize(mon, m)
        const best = nearestScale(validScales(sz[0], sz[1]), Number(m.scale))
        all[name] = Object.assign({}, m, { scale: String(best.value) })
    }

    // ---- keep screens from overlapping ----
    function rectOf(mon, set) {
        const sz = modeSize(mon, set)
        let w = sz[0], h = sz[1]
        const tr = set && set.transform !== undefined ? Number(set.transform) : (mon.transform || 0)
        if (tr % 2 === 1) { const t = w; w = h; h = t }
        const sc = set && Number(set.scale) > 0 ? Number(set.scale) : (mon.scale || 1)
        let x = mon.x, y = mon.y
        if (set && /^-?\d+x-?\d+$/.test(set.position || "")) { const p = set.position.split("x"); x = Number(p[0]); y = Number(p[1]) }
        return { x: x, y: y, w: Math.round(w / sc), h: Math.round(h / sc) }
    }
    function hits(a, b) { return a.x < b.x + b.w && b.x < a.x + a.w && a.y < b.y + b.h && b.y < a.y + a.h }
    // If screens now overlap, lay them out left to right (keeping their order) so none does.
    function relayout(all, changed) {
        const rects = list.map(mon => ({ name: mon.name, r: rectOf(mon, all[mon.name]), off: !!(all[mon.name] && all[mon.name].disabled) })).filter(e => !e.off)
        if (rects.length < 2) return
        let clash = false
        for (let i = 0; i < rects.length && !clash; i++)
            for (let j = i + 1; j < rects.length; j++) if (hits(rects[i].r, rects[j].r)) { clash = true; break }
        if (!clash) return
        rects.sort((a, b) => a.r.x - b.r.x || (a.name === changed ? -1 : 0))
        let x = rects[0].r.x
        const top = Math.min.apply(null, rects.map(e => e.r.y))
        for (const e of rects) {
            const set = Object.assign({}, all[e.name] || {})
            set.position = x + "x" + (e.r.y - top < 0 ? 0 : e.r.y - top)
            all[e.name] = set
            x += e.r.w
        }
        // the first screen sits at 0,0
        const first = rects[0].name
        all[first] = Object.assign({}, all[first], { position: "0x0" })
    }
    // several screens at once (the arrangement)
    function replaceAll(all) { stage(all) }
    function reset(name) { const all = Object.assign({}, monitorsNow()); delete all[name]; stage(all) }
    function tryMode(name, mode) { set(name, "mode", mode) }

    // ---- Apply: the changes are tried; kept only when you confirm, else back after 10 seconds ----
    // (the dialog is modules/DisplayConfirm.qml, over every screen: the one you changed may have gone black)
    readonly property int trialSeconds: 10
    property bool trialOn: false
    property var trialSnap: null             // what was set before Apply
    property int trialLeft: 0
    function apply() {
        if (!draft || trialOn) return
        const d = draft
        trialSnap = liveCopy()
        trialOn = true
        trialLeft = trialSeconds
        trialTick.restart()
        draft = null
        Config.c.monitors = d.monitors
        Config.c.scale = d.scale
    }
    function keep() { trialOn = false; trialSnap = null; trialTick.stop() }
    function revert() {
        trialTick.stop()
        if (trialOn && trialSnap) { Config.c.monitors = trialSnap.monitors; Config.c.scale = trialSnap.scale }
        trialOn = false; trialSnap = null
    }
    Timer {
        id: trialTick
        interval: 1000; repeat: true
        onTriggered: { root.trialLeft--; if (root.trialLeft <= 0) root.revert() }
    }

    // helpers for the page
    function resolutions(mon) {
        const seen = {}, out = []
        for (const m of (mon.modes || []).concat(mon.extra || [])) {
            const k = m.w + "x" + m.h
            if (!seen[k]) { seen[k] = true; out.push(k) }
        }
        return out
    }
    function rates(mon, res) {
        const out = []
        for (const m of (mon.modes || []).concat(mon.extra || [])) {
            if (m.w + "x" + m.h !== res) continue
            const r = (Math.round(m.r * 100) / 100).toFixed(2).replace(/\.?0+$/, "")
            if (out.indexOf(r) < 0) out.push(r)
        }
        out.sort((a, b) => Number(b) - Number(a))
        return out
    }
}
