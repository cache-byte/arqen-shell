pragma Singleton
import Quickshell
import Quickshell.Services.Mpris
import Quickshell.Io
import QtQuick

// What is playing (any app that shows media controls: browsers, Spotify, players...), for the media
// panel item, the desktop media widget and the lock screen.
Singleton {
    id: root
    readonly property var players: Mpris.players.values
    // the one playing; else the last one that played; else the first
    property var lastPlaying: null
    readonly property var player: players.find(p => p.isPlaying) ?? (players.indexOf(lastPlaying) >= 0 ? lastPlaying : null) ?? players[0] ?? null
    onPlayerChanged: { if (player && player.isPlaying) lastPlaying = player; if (player) position = player.position }
    readonly property bool has: player !== null
    readonly property bool playing: player?.isPlaying ?? false
    readonly property string title: player?.trackTitle || player?.identity || ""
    readonly property string artist: player?.trackArtist || ""
    readonly property string album: player?.trackAlbum || ""
    // the cover; browsers write it to /tmp and delete it soon after, so it is copied first
    readonly property string artRaw: player?.trackArtUrl || ""
    property var artCopies: ({})
    readonly property string art: artCopies[artRaw] ?? (/^file:\/\/\/tmp\//.test(artRaw) ? "" : artRaw)
    onArtRawChanged: {
        if (!/^file:\/\/\/tmp\//.test(artRaw) || artCopies[artRaw]) return
        const src = decodeURIComponent(artRaw.slice(7))
        const dir = (Quickshell.env("XDG_CACHE_HOME") || (Quickshell.env("HOME") + "/.cache")) + "/arqen/art"
        const dst = dir + "/" + Date.now() + "-" + src.replace(/^.*\//, "").replace(/[^\w.-]/g, "_")
        artCopy.createObject(root, { src: artRaw, command: ["sh", "-c", 'mkdir -p "$1" && find "$1" -type f -mmin +120 -delete 2>/dev/null; cp -f -- "$2" "$3"', "art", dir, src, dst], dst: dst })
    }
    Component {
        id: artCopy
        Process {
            id: ac
            property string src
            property string dst
            running: true
            onExited: code => {
                if (code === 0) { const m = Object.assign({}, root.artCopies); m[ac.src] = "file://" + ac.dst; root.artCopies = m }
                ac.destroy()
            }
        }
    }
    readonly property string app: player?.identity || ""
    // the player app (its icon when there is no cover)
    readonly property var entry: player && (player.desktopEntry || player.identity) ? Apps.byId(player.desktopEntry || player.identity) : null
    readonly property real length: player?.length ?? 0
    property real position: 0
    readonly property real progress: length > 0 ? Math.max(0, Math.min(1, position / length)) : 0

    // the position is read again every half second while something plays (not while paused or stopped: it does not move)
    Timer {
        interval: 1000; repeat: true; triggeredOnStart: true
        running: root.player !== null && root.playing
        onTriggered: { if (root.player) { root.position = root.player.position } }
    }
    // one last reading when it pauses, and when another player or track takes over
    onPlayingChanged: { if (root.player) root.position = root.player.position }

    function toggle() { if (player && player.canTogglePlaying) player.togglePlaying() }
    function next() { if (player && player.canGoNext) player.next() }
    function prev() { if (player && player.canGoPrevious) player.previous() }
    function seek(frac) { if (player && player.canSeek && length > 0) { player.position = frac * length; position = frac * length } }
    function time(s) {
        s = Math.max(0, Math.round(s || 0))
        return Math.floor(s / 60) + ":" + String(s % 60).padStart(2, "0")
    }
}
