pragma Singleton
import Quickshell
import Quickshell.Io
import QtQuick
import qs.config

// Where the main subject of the wallpaper is (a car, a person ...), as a mask over the picture, so desktop
// widgets can stay off it (Settings > Desktop > Widgets > "Keep widgets off the subject"). A rough guess made
// from the picture by scripts/subject.py (needs Python 3 with Pillow, or ImageMagick). Pictures only, not videos.
Singleton {
    id: root
    readonly property bool on: Config.c.widgetsAvoidSubject === true
    readonly property string file: Config.c.wallpaper || ""
    readonly property bool usable: on && file !== "" && !/\.(mp4|webm|mkv|mov|m4v|avi)$/i.test(file)
    property var rows: []                  // the mask: one string of 0 / 1 per row (1 = subject), cut over the picture
    property int mw: 0
    property int mh: 0
    readonly property bool has: rows.length > 0 && mw > 0 && mh > 0
    property string status: ""
    property real imgW: 0                  // the picture's size (for how it is cropped to the screen)
    property real imgH: 0

    onUsableChanged: refresh()
    onFileChanged: refresh()
    function refresh() { if (usable) later.restart(); else { rows = []; status = "" } }
    Timer { id: later; interval: 700; onTriggered: { proc.running = false; proc.command = ["python3", "-I", Quickshell.shellDir + "/scripts/subject.py", root.file]; proc.running = true } }
    Component.onCompleted: refresh()

    Process {
        id: proc
        stdout: StdioCollector {
            onStreamFinished: {
                const lines = text.trim().split("\n")
                const d = (lines[0] || "").trim().split(/\s+/).map(Number)
                if (d.length === 2 && d[0] > 0 && d[1] > 0 && lines.length >= d[1] + 1) {
                    root.mw = d[0]; root.mh = d[1]
                    root.rows = lines.slice(1, 1 + d[1]).map(l => l.trim())
                    root.status = "found"
                } else {
                    root.rows = []
                    root.status = "none"
                }
            }
        }
    }
    // the picture's own size, to know how it is cropped to the screen
    Image {
        visible: false
        source: root.usable ? "file://" + root.file : ""
        asynchronous: true
        sourceSize.width: 64
        onStatusChanged: if (status === Image.Ready) { root.imgW = implicitWidth; root.imgH = implicitHeight }
    }
}
