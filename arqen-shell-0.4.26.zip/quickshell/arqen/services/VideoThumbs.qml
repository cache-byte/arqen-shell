pragma Singleton
import Quickshell
import Quickshell.Io
import QtQuick

// A still picture for a video (scripts/video-thumb.sh, made once and kept in ~/.cache/arqen/thumbs), so places that
// show "the wallpaper" (Settings > System, widget previews, the accent colour) have something to draw for video wallpapers.
//   VideoThumbs.pictureOf(path): the file itself for a picture; for a video its still (empty until it is made, and
//   empty when it cannot be made, e.g. no ffmpeg); empty for no wallpaper.
Singleton {
    id: root
    property var map: ({})
    property var queue: []
    property string current: ""

    function isVideo(p) { return /\.(mp4|webm|mkv|mov|m4v|avi)$/i.test(String(p)) }
    function pictureOf(p) {
        if (!p) return ""
        if (!isVideo(p)) return p
        const t = map[p]
        if (t !== undefined) return t
        Qt.callLater(() => root.ask(p))
        return ""
    }
    function ask(p) {
        if (map[p] !== undefined || current === p || queue.indexOf(p) >= 0) return
        queue.push(p)
        next()
    }
    function next() {
        if (current !== "" || queue.length === 0) return
        current = queue.shift()
    }
    Process {
        running: root.current !== ""
        command: ["sh", Quickshell.shellDir + "/scripts/video-thumb.sh", root.current]
        stdout: StdioCollector {
            onStreamFinished: {
                const m = Object.assign({}, root.map)
                m[root.current] = text.trim()
                root.map = m
                root.current = ""
                Qt.callLater(root.next)
            }
        }
    }
}
