pragma Singleton
import Quickshell
import Quickshell.Hyprland
import QtQuick
import qs.config

// Desktops = Hyprland workspaces. The list is every real workspace (id > 0) plus the
// desktops you created with the + button (kept in Config.c.desktops, which are also
// written to Hyprland as persistent workspaces so they survive while empty).
Singleton {
    id: root

    readonly property int focusedId: Hyprland.focusedWorkspace?.id ?? 1

    // sorted workspace ids, e.g. [1, 2, 5]
    readonly property var list: {
        const seen = {}
        const out = []
        for (const w of Hyprland.workspaces.values) {
            if (w.id > 0 && !seen[w.id]) { seen[w.id] = true; out.push(w.id) }
        }
        for (const id of (Config.c.desktops || [])) {
            if (id > 0 && !seen[id]) { seen[id] = true; out.push(id) }
        }
        if (!seen[focusedId] && focusedId > 0) out.push(focusedId)
        out.sort((a, b) => a - b)
        return out
    }

    // windows (HyprlandToplevel objects) that live on a desktop
    function windows(id) {
        return Hyprland.toplevels.values.filter(t => t.wayland && t.workspace && t.workspace.id === id)
    }
    function busy(id) {
        return Hyprland.toplevels.values.some(t => t.workspace && t.workspace.id === id)
    }

    // ---- labels --------------------------------------------------------
    readonly property var styles: ["dots", "numbers", "roman", "letters", "custom", "boxes"]

    function roman(n) {
        if (n <= 0 || n >= 4000) return String(n)
        const t = [[1000, "M"], [900, "CM"], [500, "D"], [400, "CD"], [100, "C"], [90, "XC"],
                   [50, "L"], [40, "XL"], [10, "X"], [9, "IX"], [5, "V"], [4, "IV"], [1, "I"]]
        let s = ""
        for (const p of t) while (n >= p[0]) { s += p[1]; n -= p[0] }
        return s
    }
    function letters(n) {   // 1 = A ... 26 = Z, 27 = AA ...
        let s = ""
        while (n > 0) { const r = (n - 1) % 26; s = String.fromCharCode(65 + r) + s; n = Math.floor((n - 1) / 26) }
        return s
    }
    function japanese(n) {  // 一 二 三 ... 十 十一 二十 九十九
        const d = ["〇", "一", "二", "三", "四", "五", "六", "七", "八", "九"]
        if (n <= 0) return d[0]
        if (n < 10) return d[n]
        if (n < 100) {
            const tens = Math.floor(n / 10), ones = n % 10
            return (tens > 1 ? d[tens] : "") + "十" + (ones > 0 ? d[ones] : "")
        }
        return String(n).split("").map(c => d[parseInt(c)]).join("")
    }
    function label(id) {
        switch (Config.c.wsStyle) {
        case "roman":    return roman(id)
        case "letters":  return letters(id)
        case "japanese": return japanese(id)
        case "custom":   return custom(id)
        default:         return String(id)
        }
    }
    // your own characters (Settings > Panels > Desktop indicator), separated by spaces; the number
    // when there are more desktops than characters
    readonly property var customChars: String(Config.c.wsCustom || "").trim().split(/\s+/).filter(s => s !== "")
    function custom(id) { return customChars[id - 1] ?? String(id) }
    readonly property bool textStyle: ["numbers", "roman", "letters", "japanese", "custom"].indexOf(Config.c.wsStyle) >= 0

    // ---- actions -------------------------------------------------------
    // Switching from a popup (the desktop view) must wait until the popup has let go of the
    // keyboard: when it does, Hyprland gives focus back to the window you came from, and focusing a
    // window on another desktop switches to that desktop: you would bounce back. So: close first,
    // switch a moment later, once. (No retries: with workspace_back_and_forth a second
    // "workspace N" sends you back again.)
    property int want: 0
    property string wantWindow: ""
    function go(id) {
        want = id
        wantWindow = ""
        if (Ui.open !== "") { Ui.close(); later.restart() }
        else Hypr.workspace(id)
    }
    // go to a window (and its desktop)
    function focusWindow(t) {
        if (!t || !t.address) return
        const a = String(t.address)
        wantWindow = a.startsWith("0x") ? a : "0x" + a
        want = 0
        if (Ui.open !== "") { Ui.close(); later.restart() }
        else Windows.bring(wantWindow)
    }
    Timer {
        id: later
        interval: 160
        onTriggered: {
            if (root.wantWindow !== "") Windows.bring(root.wantWindow)
            else if (root.want > 0 && (Hyprland.focusedWorkspace?.id ?? 0) !== root.want) Hypr.workspace(root.want)
            root.wantWindow = ""
        }
    }

    // send a window to another desktop without following it
    function moveWindow(t, id) {
        if (!t || !t.address) return
        const a = String(t.address)
        Hypr.moveToWorkspace(a, id, false)
    }

    // make a new desktop next to the last one (stays where you are)
    function add() {
        const next = (list.length > 0 ? list[list.length - 1] : 0) + 1
        Hypr.persist(next, true)
        Config.c.desktops = (Config.c.desktops || []).concat([next])
        return next
    }

    // forget an empty desktop (it disappears once nothing keeps it alive)
    function remove(id) {
        if (list.length <= 1 || busy(id)) return
        if (id === focusedId) {
            const other = list.find(x => x !== id)
            if (other !== undefined) go(other)
        }
        Hypr.persist(id, false)
        Config.c.desktops = (Config.c.desktops || []).filter(x => x !== id)
    }
}
