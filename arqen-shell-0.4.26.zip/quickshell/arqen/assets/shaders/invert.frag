#version 300 es
precision highp float;
in vec2 v_texcoord;
uniform sampler2D tex;
out vec4 fragColor;
void main() {
    vec4 c = texture(tex, v_texcoord);
    vec3 rgb = vec3(1.0) - c.rgb;
    fragColor = vec4(rgb, 1.0);
}
