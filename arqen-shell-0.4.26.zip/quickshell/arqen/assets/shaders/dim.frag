#version 300 es
precision highp float;
in vec2 v_texcoord;
uniform sampler2D tex;
out vec4 fragColor;
void main() {
    vec4 c = texture(tex, v_texcoord);
    vec3 rgb = c.rgb * 0.6;
    fragColor = vec4(rgb, 1.0);
}
