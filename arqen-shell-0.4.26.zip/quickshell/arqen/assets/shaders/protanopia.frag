#version 300 es
precision highp float;
in vec2 v_texcoord;
uniform sampler2D tex;
out vec4 fragColor;
void main() {
    vec4 c = texture(tex, v_texcoord);
    mat3 sim = mat3(0.567, 0.558, 0.0,  0.433, 0.442, 0.242,  0.0, 0.0, 0.758);
    vec3 s = sim * c.rgb;
    vec3 e = c.rgb - s;
    vec3 rgb = clamp(c.rgb + vec3(0.0, e.r * 0.7 + e.g * 1.0 * 0.0 + e.b * 0.0, e.r * 0.7 + e.b * 1.0), 0.0, 1.0);
    fragColor = vec4(rgb, 1.0);
}
