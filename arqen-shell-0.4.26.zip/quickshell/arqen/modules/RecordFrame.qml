import Quickshell
import Quickshell.Wayland
import QtQuick
import qs.config
import qs.components
import qs.services

// While a part of the screen is being recorded (a selection or a window), its edge stays marked: a red frame just
// OUTSIDE the recorded area (so it is not in the video) and a small "REC 0:12" label you can click to stop.
// Everything else is click-through.
PanelWindow {
    id: rf
    readonly property string target: QuickSettings.recTarget
    // "geo:X,Y WxH" (screen coordinates)
    readonly property var geo: {
        const m = /^geo:(-?\d+),(-?\d+) (\d+)x(\d+)$/.exec(target || "")
        return m ? { x: +m[1], y: +m[2], w: +m[3], h: +m[4] } : null
    }
    readonly property bool on: QuickSettings.recording && geo !== null
    screen: geo ? (Quickshell.screens.find(s => geo.x >= s.x && geo.x < s.x + s.width && geo.y >= s.y && geo.y < s.y + s.height) ?? Quickshell.screens[0]) : Quickshell.screens[0]
    visible: on
    color: "transparent"
    anchors { top: true; bottom: true; left: true; right: true }
    exclusionMode: ExclusionMode.Ignore
    WlrLayershell.namespace: "arqen-record-frame"
    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.keyboardFocus: WlrKeyboardFocus.None
    mask: Region { item: tag }

    readonly property real gx: geo ? geo.x - (screen?.x ?? 0) : 0
    readonly property real gy: geo ? geo.y - (screen?.y ?? 0) : 0
    readonly property real gw: geo ? geo.w : 0
    readonly property real gh: geo ? geo.h : 0

    // the frame, outside the recorded area
    Rectangle {
        x: rf.gx - 4; y: rf.gy - 4; width: rf.gw + 8; height: rf.gh + 8
        radius: 8
        color: "transparent"
        border.width: 2; border.color: "#FF4A4A"
        SequentialAnimation on opacity {
            running: rf.on; loops: Animation.Infinite
            NumberAnimation { to: 0.55; duration: 1000; easing.type: Easing.InOutSine }
            NumberAnimation { to: 1; duration: 1000; easing.type: Easing.InOutSine }
        }
    }
    // the label: above the frame (below it when there is no room above)
    Rectangle {
        id: tag
        readonly property bool above: rf.gy >= height + 12
        x: Math.max(6, Math.min(rf.width - width - 6, rf.gx - 4))
        y: above ? rf.gy - 4 - height - 6 : Math.min(rf.height - height - 6, rf.gy + rf.gh + 10)
        height: 32; width: tr.implicitWidth + 32; radius: 16
        color: Theme.cardSolid
        border.width: 1; border.color: Theme.stroke
        Row {
            id: tr
            anchors.centerIn: parent; spacing: 7
            Rectangle { width: 9; height: 9; radius: 4.5; color: "#FF4A4A"; anchors.verticalCenter: parent.verticalCenter }
            DText { text: QuickSettings.recText; font.pixelSize: 14; font.weight: Font.DemiBold; anchors.verticalCenter: parent.verticalCenter }
            DText { text: "Stop"; font.pixelSize: 14; color: Theme.subtext; anchors.verticalCenter: parent.verticalCenter; visible: stopMa.containsMouse }
        }
        scale: stopMa.pressed ? 0.95 : 1
        MouseArea { id: stopMa; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: QuickSettings.record("stop") }
    }
}
