import Quickshell
import Quickshell.Wayland
import Quickshell.Hyprland
import QtQuick
import qs.config
import qs.components
import qs.services

// The power menu: the whole screen blurred and dimmed, big round buttons in the theme's colours
// (power off, restart, log out, sleep, lock), like a phone's. Order, colours and layout: Settings > Power. Opened from the control centre's power
// button (Ui.toggle("power")). Picking one starts the countdown (Settings > Power) or does it at once.
// Esc or a click on the empty screen closes it.
PanelWindow {
    id: pm
    readonly property bool open: Ui.open === "power"
    screen: Quickshell.screens.find(s => s.name === Hyprland.focusedMonitor?.name) ?? Quickshell.screens[0]

    property real t: 0
    NumberAnimation { id: pmIn; target: pm; property: "t"; to: 1; duration: 380; easing.type: Easing.OutBack; easing.overshoot: Motion.os(1.2) }
    NumberAnimation { id: pmOut; target: pm; property: "t"; to: 0; duration: 180; easing.type: Easing.InCubic }
    property int serial: 0
    onOpenChanged: { if (open) { serial++; pmOut.stop(); pmIn.restart() } else { pmIn.stop(); pmOut.restart() } }
    visible: t > 0.001

    color: "transparent"
    anchors { top: true; bottom: true; left: true; right: true }
    exclusionMode: ExclusionMode.Ignore
    // "arqen-power" is in the shell's blur rule: Hyprland blurs everything behind it
    WlrLayershell.namespace: "arqen-power"
    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.keyboardFocus: open ? WlrKeyboardFocus.Exclusive : WlrKeyboardFocus.None

    Shortcut { sequence: "Escape"; enabled: pm.open; onActivated: Ui.close() }

    // every button there can be: id -> label, icon, and its colour pair for the "Mixed" style
    readonly property var catalogue: ({
        poweroff: { text: "Power off", icon: "power_settings_new", mix: [Theme.primary, Theme.onPrimary] },
        reboot:   { text: "Restart",   icon: "restart_alt",        mix: [Theme.tertiary, Theme.onTertiary] },
        logout:   { text: "Log out",   icon: "logout",             mix: [Theme.secondary, Theme.onSecondary] },
        suspend:  { text: "Sleep",     icon: "bedtime",            mix: [Theme.primaryContainer, Theme.onPrimaryContainer] },
        lock:     { text: "Lock",      icon: "lock",               mix: [Theme.tertiaryContainer, Theme.onTertiaryContainer] }
    })
    readonly property var allIds: ["poweroff", "reboot", "logout", "suspend", "lock"]
    // the order you set (Settings > Power), new ones last
    readonly property var order: {
        const o = (Config.c.powerOrder || []).filter(id => allIds.indexOf(id) >= 0)
        for (const id of allIds) if (o.indexOf(id) < 0) o.push(id)
        return o
    }
    readonly property var shown: order.filter(id => (Config.c.powerHidden || []).indexOf(id) < 0)
    readonly property string style: ["Accent", "Soft", "Mixed", "Outline"].indexOf(Config.c.powerStyle) >= 0 ? Config.c.powerStyle : "Accent"
    readonly property int size: Math.max(64, Math.min(160, Config.c.powerSize || 104))
    function colours(id) {
        if (style === "Soft") return [Theme.primaryContainer, Theme.onPrimaryContainer]
        if (style === "Mixed") return catalogue[id].mix
        if (style === "Outline") return ["transparent", Theme.primary]
        return [Theme.primary, Theme.onPrimary]                         // Accent
    }

    // dim (the blur comes from Hyprland)
    Rectangle { anchors.fill: parent; color: "black"; opacity: Math.max(0, Math.min(90, Config.c.powerDim ?? 45)) / 100 * pm.t }
    MouseArea { anchors.fill: parent; onClicked: Ui.close() }

    Item {
        anchors.fill: parent
        opacity: pm.t

        Grid {
            id: grid
            anchors.centerIn: parent
            anchors.verticalCenterOffset: -30
            columns: Math.max(1, Math.min(pm.shown.length, Config.c.powerCols || 2))
            columnSpacing: Math.round(pm.size * 0.8)
            rowSpacing: Math.round(pm.size * (Config.c.powerLabels ? 0.42 : 0.3))
            Repeater {
                model: pm.shown
                delegate: Item {
                    id: cell
                    required property string modelData
                    required property int index
                    readonly property var info: pm.catalogue[modelData]
                    readonly property var col: pm.colours(modelData)
                    width: Math.max(pm.size + 40, 150)
                    height: pm.size + (Config.c.powerLabels ? 46 : 8)
                    Enter { trigger: pm.serial; delay: 40 + cell.index * 45; from: 0.6 }
                    Rectangle {
                        id: disc
                        anchors.horizontalCenter: parent.horizontalCenter
                        width: pm.size; height: pm.size
                        radius: Config.c.powerShape === "Squircle" ? pm.size * 0.3 : pm.size / 2
                        color: cell.col[0]
                        border.width: pm.style === "Outline" ? 3 : 0
                        border.color: Theme.primary
                        scale: cma.pressed ? 0.9 : (cma.containsMouse ? 1.07 : 1)
                        Behavior on scale { NumberAnimation { duration: 240; easing.type: Easing.OutBack; easing.overshoot: Motion.os(2.2) } }
                        Icon {
                            anchors.centerIn: parent
                            renderType: Text.QtRendering
                            name: cell.info.icon; size: Math.round(pm.size * 0.48); color: cell.col[1]
                        }
                    }
                    DText {
                        visible: Config.c.powerLabels
                        anchors.horizontalCenter: parent.horizontalCenter
                        anchors.top: disc.bottom; anchors.topMargin: 14
                        renderType: Text.QtRendering
                        text: cell.info.text
                        color: "white"; font.pixelSize: 19; font.weight: Font.DemiBold
                    }
                    MouseArea {
                        id: cma
                        anchors.fill: disc
                        hoverEnabled: true
                        cursorShape: Qt.PointingHandCursor
                        onClicked: { const a = cell.modelData; QuickSettings.power(a) }
                    }
                }
            }
        }

        // like the phone's "Side button settings": the countdown and its look
        Rectangle {
            visible: Config.c.powerSettingsBtn
            anchors.horizontalCenter: parent.horizontalCenter
            anchors.bottom: parent.bottom; anchors.bottomMargin: 70
            width: setRow.implicitWidth + 44; height: 52; radius: 26
            color: sma.containsMouse ? Qt.rgba(1, 1, 1, 0.22) : Qt.rgba(1, 1, 1, 0.13)
            Behavior on color { ColorAnimation { duration: 120 } }
            Row {
                id: setRow
                anchors.centerIn: parent; spacing: 10
                Icon { renderType: Text.QtRendering; name: "settings"; size: 20; color: "white"; anchors.verticalCenter: parent.verticalCenter }
                DText { renderType: Text.QtRendering; text: "Power settings"; color: "white"; font.pixelSize: 16; font.weight: Font.Medium; anchors.verticalCenter: parent.verticalCenter }
            }
            MouseArea { id: sma; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: Ui.openSettings("powermenu") }
        }
    }
}
