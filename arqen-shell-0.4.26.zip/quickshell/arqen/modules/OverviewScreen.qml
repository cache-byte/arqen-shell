import Quickshell
import Quickshell.Wayland
import Quickshell.Hyprland
import QtQuick
import QtQuick.Layouts
import qs.config
import qs.components
import qs.services

// "Recents" screen: every desktop (workspace) as a card with live window thumbnails.
//  - click a desktop card      -> switch to that desktop
//  - click a window            -> switch to its desktop and focus it
//  - drag a window onto a card -> move it to that desktop
//  - drag a window onto the monitor button -> move it to a brand new desktop
//  - monitor button            -> add an empty desktop
PanelWindow {
    id: win
    readonly property bool open: Ui.open === "overview"
    property real t: open ? 1 : 0
    Behavior on t { NumberAnimation { duration: 200; easing.type: Easing.OutCubic } }
    visible: t > 0.001
    color: Qt.rgba(0, 0, 0, 0.55 * t)
    anchors { top: true; left: true; right: true; bottom: true }
    // the whole screen: the panels slide away while the overview is open
    exclusionMode: ExclusionMode.Ignore
    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.namespace: "arqen-overview"
    WlrLayershell.keyboardFocus: open ? WlrKeyboardFocus.Exclusive : WlrKeyboardFocus.None
    onOpenChanged: { if (open) { Hyprland.refreshWorkspaces(); finder.text = ""; finder.focusInput() } else cancelDrag() }
    // (Escape inside the search box clears it first; the box handles its own Escape)
    Shortcut { sequence: "Escape"; enabled: win.open && !finder.hasFocus; onActivated: Ui.close() }

    // ---- search: the apps that match glow, the others fade ----
    readonly property string query: finder.text.trim().toLowerCase()
    function matches(t) {
        if (query === "") return false
        const w = t?.wayland
        const id = w?.appId || ""
        const hay = ((w?.title || "") + " " + id + " " + (Apps.byId(id)?.name || "")).toLowerCase()
        return query.split(/\s+/).every(part => hay.indexOf(part) >= 0)
    }
    readonly property var hits: {
        if (query === "") return []
        const out = []
        for (const ws of Workspaces.list) for (const t of Workspaces.windows(ws)) if (matches(t)) out.push(t)
        return out
    }
    // slide the first match's desktop into view
    function reveal() {
        if (hits.length === 0) return
        let idx = -1
        for (let i = 0; i < wsModel.count; i++) if (wsModel.get(i).ws === (hits[0].workspace?.id ?? -1)) idx = i
        const c = idx >= 0 ? rowRep.itemAt(idx) : null
        if (!c) return
        if (horiz) strip.contentX = Math.max(0, Math.min(strip.contentWidth - strip.width, c.x))
        else strip.contentY = Math.max(0, Math.min(strip.contentHeight - strip.height, c.y))
    }
    onQueryChanged: reveal()
    MouseArea { anchors.fill: parent; onClicked: Ui.close() }

    // ---- the desktops, kept as a model that is changed one entry at a time (a new array every time rebuilt every card:
    // the thumbnails went blank and the whole grid jumped) ----
    ListModel { id: wsModel }
    function syncDesktops() {
        const want = Workspaces.list.slice()
        for (let i = wsModel.count - 1; i >= 0; i--) if (want.indexOf(wsModel.get(i).ws) < 0) wsModel.remove(i)
        for (let i = 0; i < want.length; i++) {
            if (i < wsModel.count && wsModel.get(i).ws === want[i]) continue
            let at = -1
            for (let j = i + 1; j < wsModel.count; j++) if (wsModel.get(j).ws === want[i]) { at = j; break }
            if (at >= 0) wsModel.move(at, i, 1)
            else wsModel.insert(i, { ws: want[i] })
        }
    }
    Connections { target: Workspaces; function onListChanged() { win.syncDesktops() } }
    Component.onCompleted: syncDesktops()

    // ---- drag and drop state ----
    property var dragWin: null      // the window (HyprlandToplevel) being dragged
    property real dragX: 0          // pointer position in `scene` coordinates
    property real dragY: 0
    property int dropWs: -1         // desktop under the pointer, or -1
    property bool dropAdd: false    // pointer is over the "new desktop" button
    readonly property bool horiz: Config.c.overviewDir === "horizontal"

    function wsAt(x, y) {
        const sp = strip.mapToItem(scene, 0, 0)
        if (y < sp.y || y > sp.y + strip.height || x < sp.x || x > sp.x + strip.width) return -1
        for (let i = 0; i < rowRep.count; i++) {
            const c = rowRep.itemAt(i)
            if (!c) continue
            const p = c.mapToItem(scene, 0, 0)
            if (x >= p.x && x <= p.x + c.width && y >= p.y && y <= p.y + c.height) return c.modelData
        }
        return -1
    }
    function overAdd(x, y) {
        const p = addBtn.mapToItem(scene, 0, 0)
        return x >= p.x - 12 && x <= p.x + addBtn.width + 12 && y >= p.y - 12 && y <= p.y + addBtn.height + 12
    }
    function dragTo(x, y) {
        dragX = x; dragY = y
        dropAdd = overAdd(x, y)
        dropWs = dropAdd ? -1 : wsAt(x, y)
    }
    function cancelDrag() { dragWin = null; dropWs = -1; dropAdd = false }
    function finishDrag() {
        const t = dragWin
        let target = dropWs
        const wantNew = dropAdd
        cancelDrag()
        if (!t) return
        if (wantNew) { target = Workspaces.add(); toEnd.restart() }
        if (target > 0 && t.workspace?.id !== target) Workspaces.moveWindow(t, target)
    }

    // coordinate space for dragging (also holds the floating copy of the dragged window)
    Item {
        id: scene
        anchors.fill: parent
        z: 100
        enabled: false
        Rectangle {
            visible: win.dragWin !== null
            width: Math.min(220, Math.max(120, win.width * 0.18)); height: Math.min(162, Math.max(100, win.height * 0.2)); radius: 16
            x: win.dragX - width / 2; y: win.dragY - 40
            color: Qt.rgba(0, 0, 0, 0.65); border.width: 2; border.color: Theme.accent
            ScreencopyView {
                anchors { fill: parent; margins: 8; bottomMargin: 30 }
                captureSource: win.dragWin ? win.dragWin.wayland : null
                live: true
            }
            DText { anchors { bottom: parent.bottom; bottomMargin: 7; left: parent.left; right: parent.right; leftMargin: 10; rightMargin: 10 }
                text: win.dragWin?.wayland?.title ?? ""; color: "white"; elide: Text.ElideRight; font.pixelSize: 12 }
        }
    }

    Rectangle {
        anchors { top: parent.top; left: parent.left; margins: 24 }
        height: 36; width: lbl.implicitWidth + 32; radius: 18; color: "transparent"; border.width: 1; border.color: "#88FFFFFF"
        DText { id: lbl; anchors.centerIn: parent; color: "white"; font.pixelSize: 13
            text: ToplevelManager.toplevels.values.length + " active app" + (ToplevelManager.toplevels.values.length === 1 ? "" : "s") }
    }

    ArqField {
        id: finder
        anchors { top: parent.top; topMargin: 20; horizontalCenter: parent.horizontalCenter }
        width: Math.min(420, parent.width - 340); height: Sizes.hM
        opacity: win.t
        placeholder: "Search open apps"
        iconName: "search"
        closesOnEscape: false
        onEscaped: { if (text !== "") text = ""; else Ui.close() }
        onAccepted: if (win.hits.length > 0) Workspaces.focusWindow(win.hits[0])
    }

    // let the desktop switch land first, then drop the overview
    Timer { id: closeSoon; interval: 120; onTriggered: Ui.close() }

    // after adding a desktop, slide the strip over to it
    Timer {
        id: toEnd; interval: 300
        onTriggered: {
            // slide to the new desktop only when it is out of sight
            const c = rowRep.itemAt(rowRep.count - 1)
            if (!c) return
            const h = win.horiz
            const pos = h ? c.x : c.y, size = h ? c.width : c.height, cur = h ? strip.contentX : strip.contentY, view = h ? strip.width : strip.height
            if (pos >= cur && pos + size <= cur + view + 2) return
            const max = Math.max(0, (h ? strip.contentWidth - strip.width : strip.contentHeight - strip.height))
            scrollAnim.property = h ? "contentX" : "contentY"
            scrollAnim.to = Math.max(0, Math.min(max, pos))
            scrollAnim.restart()
        }
    }
    NumberAnimation { id: scrollAnim; target: strip; duration: 320; easing.type: Easing.OutCubic }

    Flickable {
        id: strip
        anchors { fill: parent
            leftMargin: Math.min(150, Math.max(16, parent.width * 0.08))
            rightMargin: Math.min(150, Math.max(16, parent.width * 0.08))
            topMargin: Math.min(100, Math.max(84, parent.height * 0.12))
            bottomMargin: Math.min(40, Math.max(16, parent.height * 0.05))
        }
        contentWidth: row.width; contentHeight: row.height
        flickableDirection: win.horiz ? Flickable.HorizontalFlick : Flickable.VerticalFlick
        boundsBehavior: Flickable.StopAtBounds
        interactive: win.dragWin === null
        clip: true
        opacity: win.t

        // mouse wheel scrolls sideways when there are more desktops than fit
        WheelHandler {
            acceptedDevices: PointerDevice.Mouse | PointerDevice.TouchPad
            onWheel: event => {
                const d = event.angleDelta.y !== 0 ? event.angleDelta.y : event.angleDelta.x
                if (win.horiz) strip.contentX = Math.max(0, Math.min(strip.contentWidth - strip.width, strip.contentX - d))
                else strip.contentY = Math.max(0, Math.min(strip.contentHeight - strip.height, strip.contentY - d))
            }
        }

        Grid {
            id: row
            spacing: Math.min(24, Math.max(8, strip.width * 0.015))
            readonly property int n: wsModel.count
            // horizontal: one row, four cards in view, the rest to the right.
            // vertical: two columns, two rows in view, the rest below (fewer desktops fill the space)
            columns: win.horiz ? Math.max(1, n) : Math.min(2, Math.max(1, n))
            readonly property int viewCols: win.horiz ? Math.min(4, Math.max(1, n)) : columns
            readonly property int viewRows: win.horiz ? 1 : (n > 2 ? 2 : 1)
            readonly property real cardW: Math.max(220, (strip.width - spacing * (viewCols - 1)) / viewCols)
            readonly property real cardH: Math.max(200, (strip.height - spacing * (viewRows - 1)) / viewRows)

            Repeater {
                id: rowRep
                model: wsModel
                delegate: Rectangle {
                    id: card
                    required property int ws
                    readonly property int modelData: ws
                    // the windows: the list only changes when a window really comes or goes (a new list every time
                    // rebuilt the thumbnails, which went blank for a moment)
                    readonly property var winsNow: Workspaces.windows(ws)
                    property string winKey: "-"
                    property var wins: []
                    function syncWins() {
                        const k = winsNow.map(t => t.address).join(",")
                        if (k !== winKey) { winKey = k; wins = winsNow }
                    }
                    onWinsNowChanged: syncWins()
                    // a new card grows in; the others slide and resize into their new places
                    opacity: 0
                    scale: 0.92
                    Component.onCompleted: { syncWins(); grow.start() }
                    ParallelAnimation {
                        id: grow
                        NumberAnimation { target: card; property: "opacity"; to: 1; duration: 260; easing.type: Easing.OutCubic }
                        NumberAnimation { target: card; property: "scale"; to: 1; duration: 340; easing.type: Easing.OutBack; easing.overshoot: Motion.os(1.2) }
                    }
                    Behavior on width { NumberAnimation { duration: 260; easing.type: Easing.OutCubic } }
                    Behavior on height { NumberAnimation { duration: 260; easing.type: Easing.OutCubic } }
                    readonly property bool cur: modelData === Workspaces.focusedId
                    readonly property bool target: win.dragWin !== null && win.dropWs === modelData
                    // the windows share the card: the biggest tiles that all fit (so none is cut off)
                    readonly property real areaW: Math.max(60, width - 2 * Math.min(24, Math.max(8, width * 0.025)))
                    readonly property real areaH: Math.max(60, height - Math.min(80, Math.max(56, height * 0.12)) - Math.min(24, Math.max(8, width * 0.025)))
                    readonly property real gapT: Math.min(16, Math.max(6, width * 0.02))
                    readonly property var fit: {
                        const n = wins.length
                        if (n === 0) return { w: 120, h: 88, cols: 1 }
                        let best = { w: 0, h: 0, cols: 1 }
                        for (let c = 1; c <= n; c++) {
                            const r = Math.ceil(n / c)
                            const w = Math.min((areaW - gapT * (c - 1)) / c, ((areaH - gapT * (r - 1)) / r) / 0.735, 420)
                            if (w > best.w) best = { w: w, h: w * 0.735, cols: c }
                        }
                        return best
                    }
                    readonly property real tileW: Math.max(60, fit.w)
                    readonly property real tileH: Math.round(tileW * 0.735)
                    width: row.cardW; height: row.cardH
                    radius: 28
                    color: Qt.rgba(1, 1, 1, target ? 0.18 : (cur ? 0.11 : (hover.hovered ? 0.09 : 0.06)))
                    border.width: (cur || target) ? 2 : 0
                    border.color: target ? Theme.accent : "#AAFFFFFF"
                    Behavior on color { ColorAnimation { duration: 120 } }
                    HoverHandler { id: hover }

                    // clicking the card itself switches to that desktop
                    MouseArea {
                        anchors.fill: parent
                        cursorShape: Qt.PointingHandCursor
                        onClicked: {
                            Workspaces.go(card.modelData)
                        }
                    }

                    Rectangle {
                        x: 16; y: 16; height: 38; width: dl.implicitWidth + 32; radius: 19
                        color: card.cur ? "#33FFFFFF" : "transparent"; border.width: 1; border.color: "#88FFFFFF"
                        DText { id: dl; anchors.centerIn: parent; color: "white"; font.weight: Font.Medium
                            text: "Desktop " + (Workspaces.textStyle ? Workspaces.label(card.modelData) : card.modelData) }
                    }

                    Rectangle {   // remove an empty desktop
                        visible: wsModel.count > 1 && card.wins.length === 0
                        anchors { top: parent.top; right: parent.right; margins: 16 }
                        width: 32; height: 32; radius: 16
                        color: xma.containsMouse ? "#44FFFFFF" : "transparent"; border.width: 1; border.color: "#88FFFFFF"
                        Icon { anchors.centerIn: parent; name: "close"; color: "white"; size: 16 }
                        MouseArea { id: xma; anchors.fill: parent; hoverEnabled: true; onClicked: Workspaces.remove(card.modelData) }
                    }

                    DText { visible: card.wins.length === 0; anchors.centerIn: parent
                        text: card.target ? "Drop here" : "No open windows"; color: "white"; font.weight: Font.Medium }

                    Item {
                      anchors { fill: parent; topMargin: Math.min(80, Math.max(56, card.height * 0.12)); margins: Math.min(24, Math.max(8, card.width * 0.025)) }
                      Grid {
                        anchors.centerIn: parent
                        columns: card.fit.cols
                        spacing: card.gapT
                        Repeater {
                            model: card.wins
                            delegate: Item {
                                id: tc
                                required property var modelData
                                width: card.tileW; height: card.tileH
                                readonly property bool hit: win.query !== "" && win.matches(tc.modelData)
                                opacity: win.dragWin === tc.modelData ? 0.3 : (win.query !== "" && !hit ? 0.28 : 1)
                                scale: hit ? 1.04 : 1
                                Behavior on opacity { NumberAnimation { duration: 160 } }
                                Behavior on scale { NumberAnimation { duration: 260; easing.type: Easing.OutBack; easing.overshoot: Motion.os(1.6) } }
                                // the ring: a soft glow round the tile that breathes while it is the match
                                Repeater {
                                    model: tc.hit ? 3 : 0
                                    delegate: Rectangle {
                                        required property int index
                                        anchors { fill: parent; margins: -(3 + index * 5) }
                                        radius: 18 + 3 + index * 5
                                        color: "transparent"
                                        border.width: index === 0 ? 3 : 4
                                        border.color: Theme.accent
                                        opacity: index === 0 ? 1 : 0.28 / index
                                        SequentialAnimation on opacity {
                                            running: tc.hit && index > 0; loops: Animation.Infinite
                                            NumberAnimation { to: 0.5 / index; duration: 700; easing.type: Easing.InOutSine }
                                            NumberAnimation { to: 0.12 / index; duration: 700; easing.type: Easing.InOutSine }
                                        }
                                    }
                                }
                                Rectangle { anchors.fill: parent; radius: 18; color: Qt.rgba(0, 0, 0, 0.35); border.width: ma.containsMouse ? 2 : 0; border.color: Theme.accent }
                                ScreencopyView {
                                    anchors { fill: parent; margins: 8; bottomMargin: 36 }
                                    captureSource: tc.modelData.wayland
                                    live: true
                                }
                                DText { anchors { bottom: parent.bottom; bottomMargin: 8; left: parent.left; right: parent.right; leftMargin: 12; rightMargin: 12 }
                                    text: tc.modelData.wayland?.title ?? ""; color: "white"; elide: Text.ElideRight; font.pixelSize: 12 }
                                MouseArea {
                                    id: ma
                                    anchors.fill: parent; hoverEnabled: true
                                    preventStealing: true
                                    acceptedButtons: Qt.LeftButton | Qt.MiddleButton
                                    cursorShape: pressed && dragging ? Qt.ClosedHandCursor : Qt.PointingHandCursor
                                    property real sx: 0
                                    property real sy: 0
                                    property bool dragging: false
                                    property bool wasDrag: false
                                    onPressed: mouse => { sx = mouse.x; sy = mouse.y; dragging = false; wasDrag = false }
                                    onPositionChanged: mouse => {
                                        if (!pressed) return
                                        if (!dragging && Math.abs(mouse.x - sx) + Math.abs(mouse.y - sy) > 12) {
                                            dragging = true
                                            win.dragWin = tc.modelData
                                        }
                                        if (dragging) {
                                            const p = ma.mapToItem(scene, mouse.x, mouse.y)
                                            win.dragTo(p.x, p.y)
                                        }
                                    }
                                    onReleased: {
                                        wasDrag = dragging
                                        if (dragging) win.finishDrag()
                                        dragging = false
                                    }
                                    onCanceled: { dragging = false; win.cancelDrag() }
                                    onClicked: mouse => {
                                        if (wasDrag) { wasDrag = false; return }
                                        if (mouse.button === Qt.MiddleButton) { Hypr.closeWindow(tc.modelData.address); return }
                                        Workspaces.focusWindow(tc.modelData)
                                    }
                                }
                                // close this app (middle click does the same)
                                Rectangle {
                                    id: xb
                                    visible: ma.containsMouse || xbMa.containsMouse
                                    anchors { top: parent.top; right: parent.right; margins: 10 }
                                    width: 28; height: 28; radius: 14
                                    z: 5
                                    color: xbMa.containsMouse ? "#E5484D" : Qt.rgba(0, 0, 0, 0.6)
                                    border.width: 1; border.color: "#88FFFFFF"
                                    Icon { anchors.centerIn: parent; name: "close"; color: "white"; size: 16 }
                                    MouseArea { id: xbMa; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor
                                                onClicked: Hypr.closeWindow(tc.modelData.address) }
                                }
                            }
                        }
                      }
                    }
                }
            }
        }
    }

    Rectangle {   // new desktop (also a drop target: drop a window here to give it its own desktop)
        id: addBtn
        anchors { right: parent.right; rightMargin: 40; verticalCenter: parent.verticalCenter }
        width: 58; height: 58; radius: 29
        color: win.dropAdd ? Theme.accent : (addMa.containsMouse ? Qt.rgba(0, 0, 0, 0.65) : Qt.rgba(0, 0, 0, 0.45))
        border.width: 1; border.color: win.dropAdd ? "white" : "#66FFFFFF"
        scale: win.dropAdd ? 1.15 : 1
        Behavior on scale { NumberAnimation { duration: 120 } }
        Icon { anchors.centerIn: parent; name: "add_to_queue"; color: "white"; size: 26 }
        MouseArea { id: addMa; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor
            onClicked: { Workspaces.add(); toEnd.restart() } }
    }
}
