import Quickshell
import QtQuick
import QtQuick.Layouts
import qs.config
import qs.components
import qs.settings

// Edit a panel right on the screen (right-click a panel to get here). While this is open the
// panel shows handles and remove buttons: drag its items to move them, x removes one, the bars
// at its ends change the length and the one on its inner edge the thickness.
// This card picks the panel, its edge and alignment, adds items, and adds / removes panels.
ArqPopup {
    id: p
    open: Ui.open === "paneledit"
    position: "center"
    cardWidth: 460
    cardHeight: col.implicitHeight + 40

    readonly property var pnl: Config.panel(Ui.editPanel)
    readonly property string pid: pnl ? pnl.id : ""
    readonly property int count: Config.panelsNow.length
    readonly property var addable: pid !== "" ? Config.unplaced(pid) : []

    function label(id) { return "Panel " + (Config.panelIndex(id) + 1) }

    ColumnLayout {
        id: col
        anchors { left: parent.left; right: parent.right; top: parent.top; margins: 20 }
        spacing: 12

        RowLayout {
            Layout.fillWidth: true
            Icon { name: "dock_to_bottom"; size: 24 }
            DText { text: "Edit panels"; font.pixelSize: 20; font.weight: Font.Medium; Layout.fillWidth: true }
            ArqButton { text: "Done"; primary: true; onClicked: Ui.close() }
        }
        DText {
            Layout.fillWidth: true; wrapMode: Text.WordWrap; color: Theme.subtext; font.pixelSize: 12
            text: "On the highlighted panel: drag an item to move it, the red x removes it. Pull the bars at its ends to change its length, the one on its inner edge to change its thickness."
        }

        // which panel
        Flow {
            Layout.fillWidth: true
            spacing: 8
            Repeater {
                model: Config.panelIds
                delegate: Rectangle {
                    id: pc
                    required property string modelData
                    readonly property bool cur: modelData === p.pid
                    height: 34; width: pcRow.implicitWidth + 26; radius: 17
                    color: cur ? Theme.pillOn : (pcMa.containsMouse ? Theme.hover : Theme.tile)
                    Row {
                        id: pcRow; anchors.centerIn: parent; spacing: 6
                        DText { text: p.label(pc.modelData); font.pixelSize: 13; color: pc.cur ? Theme.pillOnText : Theme.text; anchors.verticalCenter: parent.verticalCenter }
                        DText { text: Config.panel(pc.modelData)?.edge ?? ""; font.pixelSize: 11; color: pc.cur ? Theme.pillOnText : Theme.subtext; opacity: 0.8; anchors.verticalCenter: parent.verticalCenter }
                    }
                    MouseArea { id: pcMa; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: Ui.editPanel = pc.modelData }
                }
            }
            Rectangle {
                height: 32; width: 12 + 16 + 4 + addTxt.implicitWidth + 16; radius: 16
                color: addMa.containsMouse ? Theme.hover : Theme.tile
                Icon { name: "add"; size: 16; color: Theme.accent; x: 12; anchors.verticalCenter: parent.verticalCenter }
                DText { id: addTxt; text: "Add panel"; font.pixelSize: 14; font.weight: Font.Medium; x: 32; anchors.verticalCenter: parent.verticalCenter }
                MouseArea { id: addMa; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor
                    onClicked: { const id = Config.addPanel(); if (id) Ui.editPanel = id } }
            }
        }

        // placement
        GridLayout {
            Layout.fillWidth: true
            visible: p.pid !== ""
            columns: 2; columnSpacing: 12; rowSpacing: 10
            DText { text: "Edge"; color: Theme.subtext; font.pixelSize: 12 }
            SChoices { model: ["top", "bottom", "left", "right"]; current: p.pnl?.edge ?? ""; onPicked: v => Config.setPanel(p.pid, "edge", v) }
            DText { text: "Align"; color: Theme.subtext; font.pixelSize: 12 }
            SChoices { model: ["start", "center", "end"]; current: p.pnl?.align ?? ""; onPicked: v => Config.setPanel(p.pid, "align", v) }
            DText { text: "Length " + (p.pnl?.length ?? 0) + "%"; color: Theme.subtext; font.pixelSize: 12 }
            ArqSlider { Layout.fillWidth: true; from: 15; to: 100; stepSize: 1; value: p.pnl?.length ?? 100
                onMoved: v => Config.setPanel(p.pid, "length", Math.round(v)) }
            DText { text: "Thickness " + (p.pnl?.thickness ?? 0) + " px"; color: Theme.subtext; font.pixelSize: 12 }
            ArqSlider { Layout.fillWidth: true; from: 32; to: 120; stepSize: 1; value: p.pnl?.thickness ?? 56
                onMoved: v => Config.setPanel(p.pid, "thickness", Math.round(v)) }
        }

        // items that are not on this panel yet
        DText { visible: p.addable.length > 0; text: "Add to " + p.label(p.pid); color: Theme.subtext; font.pixelSize: 12 }
        Flow {
            visible: p.addable.length > 0
            Layout.fillWidth: true
            spacing: 8
            Repeater {
                model: p.addable
                delegate: Rectangle {
                    id: chip
                    required property var modelData
                    height: 36; width: chipRow.implicitWidth + 24; radius: 18
                    color: chipMa.containsMouse ? Theme.hover : Theme.tile
                    Row {
                        id: chipRow; anchors.centerIn: parent; spacing: 6
                        Icon { name: "add"; size: 16; color: Theme.accent; anchors.verticalCenter: parent.verticalCenter }
                        Icon { name: chip.modelData.icon; size: 16; anchors.verticalCenter: parent.verticalCenter }
                        DText { text: chip.modelData.name; font.pixelSize: 13; anchors.verticalCenter: parent.verticalCenter }
                    }
                    MouseArea { id: chipMa; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor
                        onClicked: Config.addElement(p.pid, chip.modelData.id) }
                }
            }
        }

        RowLayout {
            Layout.fillWidth: true
            Layout.topMargin: 4
            spacing: 8
            ArqButton { text: "Reset items"; onClicked: Config.resetLayout(p.pid) }
            ArqButton { text: "More settings"; onClicked: { Ui.settingsPanel = p.pid; Ui.openSettings("panels") } }
            Item { Layout.fillWidth: true }
            ArqButton {
                visible: p.count > 1
                text: "Remove " + p.label(p.pid)
                onClicked: {
                    const id = p.pid
                    const others = Config.panelIds.filter(x => x !== id)
                    Ui.editPanel = others.length > 0 ? others[0] : ""
                    Config.removePanel(id)
                }
            }
        }
    }
}
