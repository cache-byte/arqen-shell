import Quickshell
import QtQuick
import qs.config
import qs.components
import qs.services

// The clock's pop-up (click the clock on a panel, or `qs -c arqen ipc call arqen toggle calendar`):
// calendar and events, reminders, alarms, timers and stopwatch, world clocks.
ArqPopup {
    id: p
    open: Ui.open === "calendar"
    position: "tray"
    wantsKeyboard: true
    cardWidth: 440
    cardHeight: Math.min(660, Math.max(380, height - 2 * Ui.gap))

    onOpenChanged: {
        Clocks.watch(open)
        if (!open) return
        panel.reset()
        Clocks.refreshZones()
    }

    ClockPanel {
        id: panel
        anchors.fill: parent
    }
}
