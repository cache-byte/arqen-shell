import Quickshell
import Quickshell.Wayland
import Quickshell.Hyprland
import QtQuick
import qs.config
import qs.components
import qs.services

// The pop-up for a new notification. Click it for its options; it stays while the pointer is on it.
PanelWindow {
    id: tw
    // springs in, slips out
    // opening springs in (a small overshoot), closing is quick and plain; started explicitly each
    // time (a Behavior with changing settings only animated the first time)
    property real show: 0                  // everything starts closed
    NumberAnimation { id: toastIn; target: tw; property: "show"; to: 1; duration: 360; easing.type: Easing.OutBack; easing.overshoot: Motion.os(1.2) }
    NumberAnimation { id: toastOut; target: tw; property: "show"; to: 0; duration: 180; easing.type: Easing.InCubic }
    readonly property bool toastWant: (Notifs.toastVisible && Notifs.latest !== null)
    onToastWantChanged: { if (toastWant) { toastOut.stop(); toastIn.restart() } else { toastIn.stop(); toastOut.restart() } }
    visible: show > 0.001 && Notifs.latest !== null
    // where pop-ups appear: Settings > Sound and notifications > Where pop-ups appear (Ui.toastPlace)
    readonly property bool atTop: Ui.toastTop
    readonly property bool atBottom: Ui.toastBottom
    readonly property bool atLeft: Ui.toastLeft
    readonly property bool atRight: Ui.toastRight
    anchors { top: tw.atTop; bottom: tw.atBottom; left: tw.atLeft; right: tw.atRight }
    // when the "screenshot saved" card is in the same corner, this one sits next to it (above it, or below at the top)
    property real lift: Ui.ringH + Ui.captureH          // what shows nearer the edge (the ringing card, the "screenshot saved" card)
    Behavior on lift { NumberAnimation { duration: 200; easing.type: Easing.OutCubic } }
    margins { top: Ui.rTop + Ui.gap + Ui.offTop(lift); bottom: Ui.rBottom + Ui.gap + Ui.offBottom(lift); left: Ui.rLeft + Ui.gap; right: Ui.rRight + Ui.gap }
    implicitWidth: 420          // the same width as the "screenshot saved" card
    implicitHeight: box.implicitHeight
    color: "transparent"
    exclusionMode: ExclusionMode.Ignore
    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.namespace: "arqen-toast"
    // typing a reply needs the keyboard (only while it is opened out)
    WlrLayershell.keyboardFocus: card.expanded ? WlrKeyboardFocus.OnDemand : WlrKeyboardFocus.None

    onVisibleChanged: if (!visible) { card.expanded = false; Notifs.toastHeld = false; Notifs.toastPinned = false }
    // Clicked open (its options showing): it stays put until you click somewhere else (then its
    // time runs again) or pick one of its options.
    Connections { target: card; function onExpandedChanged() { Notifs.toastPinned = card.expanded } }
    HyprlandFocusGrab {
        windows: [tw]
        active: card.expanded && tw.visible
        onCleared: card.expanded = false
    }
    // a new one while showing: a small nudge
    Connections { target: Notifs; function onToastSerialChanged() { if (tw.show > 0.9) nudge.restart() } }
    SequentialAnimation {
        id: nudge
        NumberAnimation { target: box; property: "scale"; to: 0.96; duration: 80; easing.type: Easing.OutQuad }
        NumberAnimation { target: box; property: "scale"; to: 1; duration: 300; easing.type: Easing.OutBack; easing.overshoot: Motion.os(3) }
    }

    // the card itself is the pop-up (its own rounded background, like the phone's heads-up)
    Item {
        id: box
        anchors.fill: parent
        implicitHeight: card.implicitHeight
        opacity: Math.min(1, tw.show)
        transform: Translate { y: (1 - tw.show) * (tw.atTop ? -24 : (tw.atBottom ? 24 : 0)) }
        HoverHandler { onHoveredChanged: Notifs.toastHeld = hovered }
        // how long the pop-up stays: a ring round the app icon that empties (full while the pointer is on it)
        property real timeLeft: 1
        NumberAnimation {
            id: countdown
            target: box; property: "timeLeft"
            from: 1; to: 0
            duration: Config.c.toastSeconds * 1000
        }
        Connections {
            target: Notifs
            function onToastSerialChanged() { countdown.restart() }
            function onToastKeptChanged() { if (Notifs.toastKept) { countdown.stop(); box.timeLeft = 1 } }
        }
        NotifCard {
            id: card
            anchors { left: parent.left; right: parent.right; top: parent.top }
            popup: true
            notif: Notifs.latest
            ring: box.timeLeft
            onDone: Notifs.toastVisible = false
        }
    }
    Connections { target: Notifs; function onLatestChanged() { card.expanded = false } }
}
