import Quickshell
import Quickshell.Io
import Quickshell.Wayland
import Quickshell.Hyprland
import QtQuick
import QtQuick.Layouts
import qs.config
import qs.components
import qs.services

// The capture screen (Print key, or the Screenshot tile): choose a region, the whole screen or a
// window, a picture or a recording, then press the round button (or Enter). Esc cancels.
//  - region: drag to draw a box; drag inside it to move it; pull its corners or edges to resize
//  - window: click a window (double-click captures straight away)
PanelWindow {
    id: cap
    readonly property bool open: Ui.open === "capture"
    screen: Quickshell.screens.find(s => s.name === Hyprland.focusedMonitor?.name) ?? Quickshell.screens[0]
    // a picture is taken from the screen frozen at the moment you asked (begin()): exactly what was
    // there, panels and pop-ups included, and nothing changes while you choose; recordings use the live screen
    visible: open && !hideForFreeze && (frozenReady || kind === "record")
    property string frozenFile: ""
    property bool frozenReady: false
    property bool hideForFreeze: false      // the overlay steps aside for a moment while the screen is frozen again (after a window is picked)
    property bool freezing: false           // begin() is taking the frozen picture; opens when done
    readonly property string frozenPath: (Quickshell.env("XDG_RUNTIME_DIR") || "/tmp") + "/arqen-freeze.png"
    Component.onCompleted: Ui.capture = cap

    function begin() {
        if (open) { Ui.close(); return }
        if (freezing) return
        if (kind === "record") { Ui.toggle("capture"); return }
        frozenReady = false; frozenFile = ""
        freezing = true
        freezeGiveUp.restart()
        freezeProc.running = true
    }
    function frozenDone() {
        frozenReady = true
        freezeGiveUp.stop()
        if (freezing) { freezing = false; if (!open) Ui.toggle("capture") }
        keyCatcher.forceActiveFocus()
    }
    Process {
        id: freezeProc
        command: ["sh", Quickshell.shellDir + "/scripts/capture.sh", "freeze", Hyprland.focusedMonitor?.name ?? (cap.screen?.name ?? ""), cap.frozenPath]
        onExited: (code, status) => {
            if (code === 0) cap.frozenFile = "file://" + cap.frozenPath + "?" + Date.now()
            if (cap.hideForFreeze) {
                cap.hideForFreeze = false
                if (code === 0) cap.live = false
                else cap.freezeFailed = true
                if (cap.goAfterFreeze) { cap.goAfterFreeze = false; Qt.callLater(() => cap.go()) }
            }
            if (code === 0) {}
            else console.warn("arqen capture: could not freeze the screen (grim exit " + code + "), using the live screen")
            cap.frozenDone()
        }
    }
    // never get stuck if freezing hangs: open on the live screen
    Timer { id: freezeGiveUp; interval: 2000; onTriggered: if (!cap.frozenReady) { console.warn("arqen capture: freezing took too long"); cap.frozenDone() } }
    // opened some other way (not through begin()): freeze once whatever was open has gone
    Timer { id: freezeLater; interval: 260; onTriggered: freezeProc.running = true }
    color: "transparent"
    anchors { top: true; left: true; right: true; bottom: true }
    exclusionMode: ExclusionMode.Ignore
    WlrLayershell.namespace: "arqen-capture"
    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.keyboardFocus: open ? WlrKeyboardFocus.Exclusive : WlrKeyboardFocus.None

    // choices (kept between uses)
    property string mode: "region"          // region | screen | window
    property string kind: "shot"            // shot | record | search (look the selected part up on the web)
    property string audio: "none"           // none | system | mic
    // the selection, in this window's coordinates
    property real sx: width * 0.25
    property real sy: height * 0.25
    property real sw: width * 0.5
    property real sh: height * 0.5
    property bool haveSel: false
    property var wins: []                   // windows on this screen: { x, y, w, h, title }

    onOpenChanged: {
        if (!open) { if (!freezing) { frozenReady = false; frozenFile = "" } live = false; freezeFailed = false; goAfterFreeze = false; hideForFreeze = false; pickedAddr = ""; drawing = false; annot.clear(); return }
        if (!haveSel) { sx = width * 0.25; sy = height * 0.25; sw = width * 0.5; sh = height * 0.5 }
        winProc.running = true
        allProc.running = true
        if (kind !== "record" && !frozenReady && !freezing) { freezeGiveUp.restart(); freezeLater.restart() }
        keyCatcher.forceActiveFocus()
    }
    // only when the frozen picture really loaded; otherwise the screenshot is taken live as before
    readonly property bool useFrozen: (kind === "shot" || kind === "search") && frozenReady && frozenImg.status === Image.Ready && !live

    // the frozen screen, under everything, with what you draw on it (both go into the picture)
    property bool drawing: false            // the pencil is on: the pointer draws (a picture), or drawing starts with the recording
    property bool drawAfter: false          // recording: open the draw overlay when it starts
    readonly property string annotPath: (Quickshell.env("XDG_RUNTIME_DIR") || "/tmp") + "/arqen-annot.png"
    Item {
        id: shotStack
        visible: cap.useFrozen || (cap.kind === "shot" && cap.live)
        anchors.fill: parent
        Image {
            id: frozenImg
            visible: cap.useFrozen
            anchors.fill: parent
            source: cap.frozenFile
            fillMode: Image.Stretch
            cache: false
            smooth: true
            asynchronous: false
            onStatusChanged: if (status === Image.Error) console.warn("arqen capture: could not load the frozen screen " + source)
        }
        AnnotCanvas { id: annot; anchors.fill: parent }
    }

    // every open window (all desktops), for picking one to record: it is brought here, on top
    property var allWins: []
    Process {
        id: allProc
        command: ["hyprctl", "-j", "clients"]
        stdout: StdioCollector {
            onStreamFinished: {
                let cls = []
                try { cls = JSON.parse(text) } catch (e) { return }
                cap.allWins = cls.filter(c => c.mapped !== false && (c.workspace?.id ?? 0) !== 0)
                                 .map(c => ({ address: c.address, cls: c.class || c.initialClass || "", title: c.title || "" }))
            }
        }
    }
    property string wantAddr: ""
    // a window picked (its icon below, or clicked on the screen): brought to this desktop, focused and
    // put above every other window, and from then on the screen is shown live (not the frozen picture)
    // so it can be seen as it will be captured
    property bool live: false
    property string pickedAddr: ""
    function bringWindow(w) {
        const ws = Hyprland.focusedWorkspace?.id ?? 1
        Hypr.moveToWorkspace(w.address, ws, false)
        Hypr.focusWindow(w.address)
        Hypr.raiseWindow(w.address)
        wantAddr = w.address
        pickedAddr = w.address
        mode = "window"
        live = true
        afterBring.restart()
    }
    // look again once Hyprland has moved it (and once more, in case it was still settling)
    Timer { id: afterBring; interval: 300; onTriggered: { winProc.running = true; afterBring2.restart() } }
    Timer { id: afterBring2; interval: 500; onTriggered: { if (cap.pickedAddr !== "") cap.wantAddr = cap.pickedAddr; winProc.running = true } }
    // a picture with a drawing on a picked window: the overlay steps aside, the screen is frozen again with that window in front,
    // then the picture is taken from that (drawing included). Only when the button is pressed, so nothing flickers while choosing.
    property bool goAfterFreeze: false
    property bool freezeFailed: false
    Timer { id: refreeze2; interval: 200; onTriggered: if (cap.hideForFreeze) freezeProc.running = true }

    // windows on the desktop(s) shown on this screen
    Process {
        id: winProc
        command: ["sh", "-c", "hyprctl -j monitors; echo '@@@'; hyprctl -j clients"]
        stdout: StdioCollector {
            onStreamFinished: {
                const parts = text.split("@@@")
                let mons = [], cls = []
                try { mons = JSON.parse(parts[0]); cls = JSON.parse(parts[1]) } catch (e) { return }
                const m = mons.find(x => x.name === cap.screen?.name)
                if (!m) return
                const shown = [m.activeWorkspace?.id, m.specialWorkspace?.id].filter(x => x)
                const sc = m.scale || 1
                const out = []
                for (const c of cls) {
                    if (c.hidden || !shown.includes(c.workspace?.id)) continue
                    // the window with its border (drawn just outside what Hyprland reports), kept on this screen
                    const b = Math.max(0, Config.c.borderSize || 0)
                    const x0 = Math.max(0, c.at[0] - m.x - b), y0 = Math.max(0, c.at[1] - m.y - b)
                    const x1 = Math.min(cap.width, c.at[0] - m.x + c.size[0] + b), y1 = Math.min(cap.height, c.at[1] - m.y + c.size[1] + b)
                    if (x1 - x0 < 4 || y1 - y0 < 4) continue
                    out.push({ x: x0, y: y0, w: x1 - x0, h: y1 - y0, title: c.title || c.class || "", address: c.address })
                }
                // the one on top last in Hyprland's list is not guaranteed: smaller ones first wins on overlap
                out.sort((a, b) => a.w * a.h - b.w * b.h)
                cap.wins = out
                if (cap.wantAddr !== "") {
                    const i = out.findIndex(w => w.address === cap.wantAddr)
                    cap.wantAddr = ""
                    if (i >= 0) cap.pickWin(i)
                }
            }
        }
    }

    function geometry() {
        const ox = screen?.x ?? 0, oy = screen?.y ?? 0
        if (mode === "screen") return "output:" + (screen?.name ?? "")
        return "geo:" + Math.round(ox + sx) + "," + Math.round(oy + sy) + " " + Math.max(1, Math.round(sw)) + "x" + Math.max(1, Math.round(sh))
    }
    function go() {
        if (mode !== "screen" && (sw < 2 || sh < 2)) return
        if (kind === "search") { search(); return }
        if (kind === "record") {
            QuickSettings.record(geometry(), audio)
            if (drawAfter) startDraw.restart()
            return
        }
        if (kind === "shot" && live && annot.hasAny && !freezeFailed) {
            goAfterFreeze = true; hideForFreeze = true; refreeze2.restart()
            return
        }
        if (useFrozen) {
            // the part of the frozen picture, in its real pixels
            const k = screen?.devicePixelRatio ?? 1
            const r = mode === "screen" ? [0, 0, width, height] : [sx, sy, sw, sh]
            const crop = Math.round(r[2] * k) + "x" + Math.round(r[3] * k) + "+" + Math.round(r[0] * k) + "+" + Math.round(r[1] * k)
            const finish = file => {
                Captures.run(Config.captureCmd(["crop", file, crop]))
                Sounds.play("capture")
                Ui.close()
            }
            if (annot.hasAny) {
                // with a drawing: the frozen picture and the drawing together, at the screen's real pixels
                const ok = shotStack.grabToImage(res => { if (res.saveToFile(cap.annotPath)) finish(cap.annotPath); else finish(frozenPath) },
                                                 Qt.size(Math.round(width * k), Math.round(height * k)))
                if (!ok) finish(frozenPath)
                return
            }
            finish(frozenPath)
            return
        }
        if (mode === "window") { Ui.hideChrome = true; chromeBack.restart() }
        QuickSettings.screenshot(geometry())
    }
    function search() {
        if (mode === "window" && !haveSel) return
        if (mode !== "screen" && (sw < 2 || sh < 2)) return
        if (useFrozen) {
            // search what you see: the chosen part of the frozen picture (a selection, a window or the whole screen)
            const k = screen?.devicePixelRatio ?? 1
            const r = mode === "screen" ? [0, 0, width, height] : [sx, sy, sw, sh]
            QuickSettings.imageSearch("frozen:" + frozenPath, Math.round(r[2] * k) + "x" + Math.round(r[3] * k) + "+" + Math.round(r[0] * k) + "+" + Math.round(r[1] * k))
        } else {
            if (mode === "window") { Ui.hideChrome = true; chromeBack.restart() }
            QuickSettings.imageSearch(geometry())
        }
    }
    // recording with drawing: the draw overlay opens once the recording is under way (paused: click the pencil to draw)
    Timer { id: startDraw; interval: 900; onTriggered: { Ui.drawing = false; Ui.drawOpen = true } }
    Timer { id: chromeBack; interval: 1600; onTriggered: Ui.hideChrome = false }
    function winAt(x, y) {
        for (let i = 0; i < wins.length; i++) { const w = wins[i]; if (x >= w.x && x < w.x + w.w && y >= w.y && y < w.y + w.h) return i }
        return -1
    }
    function pickWin(i) {
        if (i < 0) return
        const w = wins[i]
        sx = w.x; sy = w.y; sw = w.w; sh = w.h; haveSel = true
        // clicked on the screen: bring it in front of the others too
        if (w.address && w.address !== pickedAddr) bringWindow(w)
    }

    Item {
        id: keyCatcher
        anchors.fill: parent
        focus: true
        Keys.onEscapePressed: Ui.close()
        Keys.onReturnPressed: cap.go()
        Keys.onEnterPressed: cap.go()
        Keys.onSpacePressed: cap.go()
    }

    // ---- dim everything but the selection ----
    readonly property bool showSel: mode !== "screen" && (mode === "region" || haveSel)
    // around a picked window everything else is pushed far back, so the window stands out
    readonly property color dim: mode === "window" && haveSel ? Qt.rgba(0, 0, 0, 0.82) : Qt.rgba(0, 0, 0, 0.5)
    Rectangle { visible: !cap.showSel; anchors.fill: parent; color: cap.mode === "screen" ? Qt.rgba(1, 1, 1, 0.06) : cap.dim
                border.width: cap.mode === "screen" ? 3 : 0; border.color: "white" }
    Rectangle { visible: cap.showSel; x: 0; y: 0; width: parent.width; height: cap.sy; color: cap.dim }
    Rectangle { visible: cap.showSel; x: 0; y: cap.sy + cap.sh; width: parent.width; height: parent.height - cap.sy - cap.sh; color: cap.dim }
    Rectangle { visible: cap.showSel; x: 0; y: cap.sy; width: cap.sx; height: cap.sh; color: cap.dim }
    Rectangle { visible: cap.showSel; x: cap.sx + cap.sw; y: cap.sy; width: parent.width - cap.sx - cap.sw; height: cap.sh; color: cap.dim }

    // ---- drawing / moving / resizing ----
    MouseArea {
        id: area
        anchors.fill: parent
        hoverEnabled: true
        cursorShape: cap.mode === "region" ? Qt.CrossCursor : Qt.PointingHandCursor
        property real ax: 0
        property real ay: 0
        property string drag: ""            // new | move
        property real ox: 0
        property real oy: 0
        onPositionChanged: mouse => {
            // window mode: nothing lights up under the pointer; a window is picked by clicking it
            if (cap.mode === "window") return
            if (!pressed || cap.mode !== "region") return
            if (drag === "new") {
                cap.sx = Math.min(ax, mouse.x); cap.sy = Math.min(ay, mouse.y)
                cap.sw = Math.abs(mouse.x - ax); cap.sh = Math.abs(mouse.y - ay)
            } else if (drag === "move") {
                cap.sx = Math.max(0, Math.min(cap.width - cap.sw, mouse.x - ox))
                cap.sy = Math.max(0, Math.min(cap.height - cap.sh, mouse.y - oy))
            }
        }
        onPressed: mouse => {
            if (cap.mode !== "region") return
            if (mouse.x >= cap.sx && mouse.x <= cap.sx + cap.sw && mouse.y >= cap.sy && mouse.y <= cap.sy + cap.sh) {
                drag = "move"; ox = mouse.x - cap.sx; oy = mouse.y - cap.sy
            } else {
                drag = "new"; ax = mouse.x; ay = mouse.y; cap.sx = ax; cap.sy = ay; cap.sw = 0; cap.sh = 0
            }
            cap.haveSel = true
        }
        onReleased: drag = ""
        onClicked: mouse => { if (cap.mode === "window") cap.pickWin(cap.winAt(mouse.x, mouse.y)) }
        onDoubleClicked: mouse => { if (cap.mode === "window") { cap.pickWin(cap.winAt(mouse.x, mouse.y)); cap.go() } }
    }

    // the selection's frame and its eight handles
    Rectangle {
        id: selFrame
        visible: cap.showSel
        readonly property bool winMode: cap.mode === "window"
        readonly property real out: winMode ? 3 : 0          // a window: the line sits just outside it
        x: cap.sx - out; y: cap.sy - out; width: cap.sw + 2 * out; height: cap.sh + 2 * out
        radius: winMode ? Config.c.winRounding + out : 0
        color: "transparent"; border.width: 2; border.color: winMode ? Theme.primary : "white"
        Behavior on x { enabled: selFrame.winMode; NumberAnimation { duration: 180; easing.type: Easing.OutCubic } }
        Behavior on y { enabled: selFrame.winMode; NumberAnimation { duration: 180; easing.type: Easing.OutCubic } }
        Behavior on width { enabled: selFrame.winMode; NumberAnimation { duration: 180; easing.type: Easing.OutCubic } }
        Behavior on height { enabled: selFrame.winMode; NumberAnimation { duration: 180; easing.type: Easing.OutCubic } }
    }
    DText {
        visible: cap.showSel && cap.sw > 0
        x: cap.sx + 6; y: Math.max(4, cap.sy - 22)
        text: Math.round(cap.sw) + " × " + Math.round(cap.sh)
        color: "white"; font.pixelSize: 12
        style: Text.Outline; styleColor: Qt.rgba(0, 0, 0, 0.6)
    }
    Repeater {
        // [x share, y share, which edges it moves]
        model: cap.mode === "region" ? [[0, 0, "lt"], [0.5, 0, "t"], [1, 0, "rt"], [1, 0.5, "r"], [1, 1, "rb"], [0.5, 1, "b"], [0, 1, "lb"], [0, 0.5, "l"]] : []
        delegate: Rectangle {
            required property var modelData
            readonly property string e: modelData[2]
            width: 14; height: 14; radius: 7
            color: "white"; border.width: 1; border.color: Qt.rgba(0, 0, 0, 0.3)
            x: cap.sx + cap.sw * modelData[0] - 7
            y: cap.sy + cap.sh * modelData[1] - 7
            MouseArea {
                anchors { fill: parent; margins: -6 }
                cursorShape: (parent.e === "t" || parent.e === "b") ? Qt.SizeVerCursor : (parent.e === "l" || parent.e === "r") ? Qt.SizeHorCursor
                           : (parent.e === "lt" || parent.e === "rb") ? Qt.SizeFDiagCursor : Qt.SizeBDiagCursor
                preventStealing: true
                onPositionChanged: mouse => {
                    if (!pressed) return
                    const p = mapToItem(area, mouse.x, mouse.y)
                    const e = parent.e
                    let l = cap.sx, t = cap.sy, r = cap.sx + cap.sw, b = cap.sy + cap.sh
                    if (e.includes("l")) l = Math.min(p.x, r - 8)
                    if (e.includes("r")) r = Math.max(p.x, l + 8)
                    if (e.includes("t")) t = Math.min(p.y, b - 8)
                    if (e.includes("b")) b = Math.max(p.y, t + 8)
                    cap.sx = Math.max(0, l); cap.sy = Math.max(0, t)
                    cap.sw = Math.min(cap.width, r) - cap.sx; cap.sh = Math.min(cap.height, b) - cap.sy
                }
            }
        }
    }

    // ---- the toolbar ----
    component Seg: Rectangle {
        property string icon: ""
        property string label: ""
        property bool on: false
        signal picked()
        width: segRow.implicitWidth + 40; height: 40; radius: 20
        color: on ? Theme.primary : (sm.containsMouse ? Theme.hover : "transparent")
        Behavior on color { ColorAnimation { duration: 120 } }
        Row {
            id: segRow
            anchors.centerIn: parent; spacing: 8
            Icon { name: parent.parent.icon; size: 20; color: parent.parent.on ? Theme.onPrimary : Theme.text; anchors.verticalCenter: parent.verticalCenter }
            DText { text: parent.parent.label; font.pixelSize: 14; font.weight: Font.Medium; color: parent.parent.on ? Theme.onPrimary : Theme.text; anchors.verticalCenter: parent.verticalCenter }
        }
        MouseArea { id: sm; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: parent.picked() }
    }
    component Chip: Rectangle {
        property string label: ""
        property string icon: ""
        property bool on: false
        signal picked()
        height: 32; width: cr.implicitWidth + 32; radius: 16
        color: on ? Theme.primary : (cm.containsMouse ? Theme.hover : Theme.tile)
        Row { id: cr; anchors.centerIn: parent; spacing: 4
            Icon { visible: parent.parent.icon !== ""; name: parent.parent.icon; size: 16; color: parent.parent.on ? Theme.onPrimary : Theme.text; anchors.verticalCenter: parent.verticalCenter }
            DText { text: parent.parent.label; font.pixelSize: 14; color: parent.parent.on ? Theme.onPrimary : Theme.text; anchors.verticalCenter: parent.verticalCenter } }
        MouseArea { id: cm; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: parent.picked() }
    }

    // the pencil is on (a picture): the pointer draws on the frozen screen
    MouseArea {
        anchors.fill: parent
        enabled: cap.drawing && cap.kind === "shot" && (cap.useFrozen || cap.live)
        visible: enabled
        cursorShape: Qt.CrossCursor
        preventStealing: true
        onPressed: mouse => annot.press(mouse.x, mouse.y)
        onPositionChanged: mouse => annot.move(mouse.x, mouse.y)
        onReleased: annot.release()
        onCanceled: annot.release()
    }
    AnnotBar {
        visible: cap.drawing && cap.kind === "shot" && (cap.useFrozen || cap.live)
        canvas: annot
        x: (parent.width - width) / 2
        y: bar.onTop ? bar.y + bar.height + 12 : bar.y - height - 12
    }

    Rectangle {
        id: bar
        // at the bottom; at the top when the chosen window reaches down there (out of its way)
        readonly property bool onTop: cap.mode === "window" && cap.haveSel && cap.sy + cap.sh > cap.height - height - 60 && cap.sy > height + 60
        x: (parent.width - width) / 2
        y: onTop ? 48 : parent.height - height - 48
        Behavior on y { NumberAnimation { duration: 260; easing.type: Easing.OutCubic } }
        width: barCol.implicitWidth + 28; height: barCol.implicitHeight + 24
        radius: 30
        color: Theme.cardSolid
        border.width: 1; border.color: Theme.stroke
        MouseArea { anchors.fill: parent }          // clicks on the bar do not draw a selection

        ColumnLayout {
            id: barCol
            anchors.centerIn: parent
            spacing: 10
            Rectangle {
                Layout.alignment: Qt.AlignHCenter
                width: modeRow.implicitWidth + 4; height: 44; radius: 22; color: Theme.tile
                Row {
                    id: modeRow
                    anchors.centerIn: parent; spacing: 2
                    Seg { icon: "screenshot_region"; label: "Selection"; on: cap.mode === "region"; onPicked: cap.mode = "region" }
                    Seg { icon: "desktop_windows"; label: "Screen"; on: cap.mode === "screen"; onPicked: cap.mode = "screen" }
                    Seg { icon: "select_window"; label: "Window"; on: cap.mode === "window"; onPicked: { cap.mode = "window"; cap.haveSel = false } }
                }
            }
            RowLayout {
                Layout.alignment: Qt.AlignHCenter
                spacing: 14
                // picture or video
                Rectangle {
                    width: 124; height: 44; radius: 22; color: Theme.tile
                    Row {
                        anchors.centerIn: parent
                        Repeater {
                            model: [["shot", "photo_camera", "Picture"], ["record", "videocam", "Video"], ["search", "image_search", "Search the web with the selected part (Google Lens)"]]
                            delegate: Rectangle {
                                required property var modelData
                                width: 40; height: 40; radius: 20
                                color: cap.kind === modelData[0] ? Theme.primary : "transparent"
                                Behavior on color { ColorAnimation { duration: 120 } }
                                Icon { anchors.centerIn: parent; name: parent.modelData[1]; size: 20; color: cap.kind === parent.modelData[0] ? Theme.onPrimary : Theme.text }
                                MouseArea { id: kMa; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: cap.kind = parent.modelData[0]
                                    HoverTip { hovered: kMa.containsMouse; text: parent.parent.modelData[2] } }
                            }
                        }
                    }
                }
                // the button
                Rectangle {
                    width: 52; height: 52; radius: 26
                    color: "transparent"; border.width: 3; border.color: cap.kind === "record" ? "#FF4A4A" : Theme.primary
                    Rectangle {
                        anchors.centerIn: parent
                        width: cap.kind === "record" ? 22 : 40; height: width; radius: width / 2
                        color: cap.kind === "record" ? "#FF4A4A" : Theme.primary
                        scale: goMa.pressed ? 0.9 : 1
                        Behavior on width { NumberAnimation { duration: 120 } }
                        Icon { anchors.centerIn: parent; visible: cap.kind === "search"; name: "image_search"; size: 22; color: Theme.onPrimary }
                    }
                    MouseArea { id: goMa; anchors.fill: parent; cursorShape: Qt.PointingHandCursor; onClicked: cap.go() }
                }
                // draw on the picture (arrows, circles, notes...) before it is taken; for a recording: draw while it runs
                Rectangle {
                    readonly property bool usable: cap.kind === "record" || (cap.kind === "shot" && (cap.useFrozen || cap.live))
                    visible: usable
                    readonly property bool lit: cap.kind === "record" ? cap.drawAfter : cap.drawing
                    width: 44; height: 44; radius: 22
                    color: lit ? Theme.primary : (drMa.containsMouse ? Theme.hover : Theme.tile)
                    Icon { anchors.centerIn: parent; name: "draw"; size: 20; color: parent.lit ? Theme.onPrimary : Theme.text }
                    MouseArea { id: drMa; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor
                        onClicked: { if (cap.kind === "record") cap.drawAfter = !cap.drawAfter; else cap.drawing = !cap.drawing }
                        HoverTip { hovered: drMa.containsMouse; text: cap.kind === "record" ? "Draw while recording (pencil in the corner)" : "Draw on the picture: arrows, circles, pen" } }
                }
                // close
                Rectangle {
                    width: 44; height: 44; radius: 22; color: xMa.containsMouse ? Theme.hover : Theme.tile
                    Icon { anchors.centerIn: parent; name: "close"; size: 20; color: Theme.text }
                    MouseArea { id: xMa; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: Ui.close() }
                }
            }
            // a window (picture or recording): pick it here; it is brought to this desktop, in front, so it can be seen
            Flow {
                visible: cap.mode === "window" && cap.allWins.length > 0
                Layout.alignment: Qt.AlignHCenter
                // exactly as wide as its icons (up to 9 a line), so the row is centred
                readonly property int perLine: Math.min(9, Math.max(1, cap.allWins.length))
                Layout.preferredWidth: perLine * 44 + (perLine - 1) * 6
                spacing: 6
                Repeater {
                    model: cap.mode === "window" ? cap.allWins : []
                    delegate: Rectangle {
                        id: wcell
                        required property var modelData
                        width: 44; height: 44; radius: 12
                        color: cap.pickedAddr === wcell.modelData.address ? Theme.primary : (wma.containsMouse ? Theme.hover : Theme.tile)
                        AppIcon { anchors.centerIn: parent; size: 30; entry: Apps.byId(wcell.modelData.cls); source: Apps.byId(wcell.modelData.cls) ? "" : "application-x-executable" }
                        MouseArea { id: wma; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: cap.bringWindow(wcell.modelData) }
                        HoverTip { hovered: wma.containsMouse; text: wcell.modelData.title || wcell.modelData.cls }
                    }
                }
            }
            // what sound a recording gets
            RowLayout {
                visible: cap.kind === "record"
                Layout.alignment: Qt.AlignHCenter
                spacing: 6
                DText { text: "Sound"; color: Theme.subtext; font.pixelSize: 12 }
                Chip { label: "None"; icon: "music_off"; on: cap.audio === "none"; onPicked: cap.audio = "none" }
                Chip { label: "System"; icon: "music_note"; on: cap.audio === "system"; onPicked: cap.audio = "system" }
                Chip { label: "Microphone"; icon: "mic"; on: cap.audio === "mic"; onPicked: cap.audio = "mic" }
            }
            DText {
                Layout.alignment: Qt.AlignHCenter
                text: cap.mode === "window" ? "Pick a window (its icon above, or click it), then the button (double-click: at once)"
                    : cap.mode === "screen" ? "The whole screen" : (cap.kind === "search" ? "Drag to select · Enter to search the web · Esc to cancel" : "Drag to select · Enter to capture · Esc to cancel")
                color: Theme.subtext; font.pixelSize: 11
            }
        }
    }
}
