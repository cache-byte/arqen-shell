import Quickshell
import Quickshell.Wayland
import Quickshell.Hyprland
import QtQuick
import QtQuick.Shapes
import qs.config
import qs.components
import qs.services

// "Keep these display settings?" after any change to a screen (resolution, refresh rate, scale, orientation,
// arrangement, a screen turned off). Shown over every screen, because the one you changed may have gone black.
// Nothing pressed for 10 seconds: everything goes back as it was (Monitors.revert). Esc = go back, Enter = keep.
Variants {
    model: Quickshell.screens
    PanelWindow {
        id: w
        required property var modelData
        screen: modelData
        readonly property bool on: Monitors.trialOn
        readonly property bool main: (Hyprland.focusedMonitor?.name ?? "") === modelData.name || Quickshell.screens.length === 1

        property real t: 0
        NumberAnimation { id: tIn; target: w; property: "t"; to: 1; duration: 340; easing.type: Easing.OutBack; easing.overshoot: Motion.os(1.4) }
        NumberAnimation { id: tOut; target: w; property: "t"; to: 0; duration: 160; easing.type: Easing.InCubic }
        onOnChanged: { if (on) { tOut.stop(); tIn.restart() } else { tIn.stop(); tOut.restart() } }
        visible: t > 0.001

        color: "transparent"
        anchors { top: true; bottom: true; left: true; right: true }
        exclusionMode: ExclusionMode.Ignore
        WlrLayershell.namespace: "arqen-display-confirm"
        WlrLayershell.layer: WlrLayer.Overlay
        WlrLayershell.keyboardFocus: on && main ? WlrKeyboardFocus.Exclusive : WlrKeyboardFocus.None

        Shortcut { sequence: "Escape"; enabled: w.on && w.main; onActivated: Monitors.revert() }
        Shortcut { sequence: "Return"; enabled: w.on && w.main; onActivated: Monitors.keep() }
        Shortcut { sequence: "Enter"; enabled: w.on && w.main; onActivated: Monitors.keep() }

        Rectangle { anchors.fill: parent; color: "black"; opacity: 0.45 * w.t }
        MouseArea { anchors.fill: parent }

        Rectangle {
            id: card
            width: Math.min(440, Math.max(1, parent.width - 32))
            height: Math.min(col.implicitHeight + 56, Math.max(1, parent.height - 32))
            anchors.centerIn: parent
            clip: true
            radius: Theme.radius + 8
            color: Theme.cardSolid
            border.width: 1; border.color: Theme.stroke
            opacity: w.t
            scale: 0.94 + 0.06 * w.t

            Column {
                id: col
                x: Math.min(28, Math.max(12, parent.width * 0.06)); y: 28
                width: Math.max(1, parent.width - 2 * x)
                spacing: 18

                Row {
                    spacing: 16
                    // the ring running down, the seconds in it
                    Item {
                        width: 72; height: 72
                        Shape {
                            anchors.fill: parent
                            preferredRendererType: Shape.CurveRenderer
                            antialiasing: true
                            ShapePath {
                                strokeColor: Theme.tile; strokeWidth: 6; fillColor: "transparent"
                                PathAngleArc { centerX: 36; centerY: 36; radiusX: 31; radiusY: 31; startAngle: 0; sweepAngle: 360 }
                            }
                            ShapePath {
                                strokeColor: Monitors.trialLeft <= 3 ? "#FF5A5A" : Theme.primary; strokeWidth: 6; fillColor: "transparent"; capStyle: ShapePath.RoundCap
                                PathAngleArc { centerX: 36; centerY: 36; radiusX: 31; radiusY: 31; startAngle: -90; sweepAngle: 360 * Math.max(0, Monitors.trialLeft) / Monitors.trialSeconds
                                               Behavior on sweepAngle { NumberAnimation { duration: 900 } } }
                            }
                        }
                        DText { anchors.centerIn: parent; text: Monitors.trialLeft; font.pixelSize: 26; font.weight: Font.DemiBold }
                    }
                    Column {
                        anchors.verticalCenter: parent.verticalCenter
                        width: col.width - 88
                        spacing: 4
                        DText { text: "Keep these display settings?"; font.pixelSize: 18; font.weight: Font.DemiBold }
                        DText {
                            width: parent.width; wrapMode: Text.WordWrap
                            text: "Reverting in " + Monitors.trialLeft + (Monitors.trialLeft === 1 ? " second" : " seconds") + ". If you can't see this on the screen you changed, just wait."
                            color: Theme.subtext; font.pixelSize: 13
                        }
                    }
                }
                Row {
                    anchors.right: parent.right
                    spacing: 10
                    ArqButton { text: "Revert"; onClicked: Monitors.revert() }
                    ArqButton { text: "Keep changes"; primary: true; onClicked: Monitors.keep() }
                }
                DText { anchors.right: parent.right; text: "Esc: revert  ·  Enter: keep"; color: Theme.subtext; font.pixelSize: 11 }
            }
        }
    }
}
