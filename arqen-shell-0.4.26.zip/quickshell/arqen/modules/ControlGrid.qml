import Quickshell
import Quickshell.Bluetooth
import Quickshell.Services.UPower
import QtQuick
import QtQuick.Layouts
import QtQuick.Shapes
import qs.config
import qs.components
import qs.services

// The control centre's tiles on a grid of square cells, 6 columns. Every tile keeps its own place
// (Config.c.ccTiles) and can be 1 to 6 cells wide and tall (a tall slider stands upright).
//   click = the tile's action        right-click = its options (Wi-Fi networks, Bluetooth devices, ...)
//   long-press / pencil button = edit mode: the grid's cells show; drag a tile onto free cells (or
//   onto a tile to swap the two), pull its corner to resize it, the red button hides it, and hidden
//   tiles can be added back from the tray underneath. Nothing else moves.
ColumnLayout {
    id: grid
    spacing: 10

    property bool editing: false
    property int enterSerial: 0               // the control centre opened: the tiles come in again
    property var work: null                       // working copy while a drag or resize is in progress
    readonly property bool gesturing: work !== null
    signal menuRequested(string tileId, Item tileItem)

    readonly property int cols: CcTiles.maxSpan
    readonly property real gap: 6
    readonly property real cellW: (width - (cols - 1) * gap) / cols
    readonly property real cellH: cellW

    readonly property var saved: CcTiles.current()
    readonly property var tiles: work !== null ? work : saved
    readonly property var display: tiles.filter(t => CcTiles.available(t.id))
    readonly property int rows: CcTiles.rows(display)
    // while editing, one empty row more to drop tiles into
    readonly property int shownRows: !editing ? rows
        : Math.min(CcTiles.maxRows, Math.max(rows + 1, dragId !== "" ? dropR + (slot(dragId)?.h ?? 1) : 0))
    readonly property var addable: CcTiles.addable(saved)
    readonly property real step: cellW + gap

    // The tiles that exist, in a fixed order. Moving or resizing a tile must not rebuild the
    // delegates (that would drop the drag in progress), so this only changes when a tile is
    // added or hidden.
    property var ids: []
    property string idsKey: ""
    function syncIds() {
        const key = display.map(t => t.id).slice().sort().join(",")
        if (key === idsKey) return
        idsKey = key
        ids = display.map(t => t.id)
    }
    onDisplayChanged: syncIds()
    Component.onCompleted: syncIds()

    function slot(id) { return display.find(t => t.id === id) ?? null }

    // ---------- edit gestures ----------
    // dragging: the tile follows the pointer; where it would land is outlined (accent = it fits,
    // red = it does not), and it only moves there when let go
    property string dragId: ""
    property int dropC: 0
    property int dropR: 0
    readonly property var dropResult: dragId !== "" ? CcTiles.moveTo(saved, dragId, dropC, dropR) : null
    readonly property bool dropSame: { const s = slot(dragId); return !!s && s.c === dropC && s.r === dropR }
    function dragOver(id, x, y) {
        const s = slot(id)
        if (!s) return
        dragId = id
        dropC = Math.max(0, Math.min(cols - s.w, Math.round(x / step)))
        // a tile can go anywhere down to just below the last row
        dropR = Math.max(0, Math.min(Math.min(rows, CcTiles.maxRows - s.h), Math.round(y / step)))
    }
    function drop() {
        if (dragId !== "" && dropResult !== null) CcTiles.commit(dropResult)
        dragId = ""
    }
    // resizing: live, as far as the free cells allow, saved when let go
    function beginGesture() { if (work === null) work = CcTiles.current() }
    function endGesture() {
        if (work === null) return
        CcTiles.commit(work)
        work = null
    }
    function resizeTo(id, w, h) {
        if (work === null) return
        const r = CcTiles.resized(work, id, w, h)
        if (r !== null) work = r
    }
    function hide(id) { CcTiles.commit(CcTiles.remove(saved, id)) }
    function add(id) { CcTiles.commit(CcTiles.append(saved, id)) }
    function reset() { CcTiles.commit(CcTiles.placed(CcTiles.defaults)) }

    // ---------- what each tile shows and does ----------
    readonly property bool charging: UPower.displayDevice.state === UPowerDeviceState.Charging
    readonly property int batteryPct: Math.round(UPower.displayDevice.percentage * 100)
    readonly property var btDevice: Bluetooth.devices.values.find(d => d.connected)

    function isOn(id) {
        switch (id) {
        case "wifi":      return Net.wifiOn
        case "bluetooth": return Bluetooth.defaultAdapter?.enabled ?? false
        case "sound":     return !Audio.muted
        case "dnd":       return Config.c.dnd
        case "dark":      return Config.c.darkMode
        case "night":     return QuickSettings.filterActive
        case "capture":   return QuickSettings.recording
        case "caffeine":  return Caffeine.active
        case "battery":   return PowerProfiles.profile !== PowerProfile.Balanced      // saver and performance light it, balanced does not
        default:          return false
        }
    }
    function iconOf(id) {
        switch (id) {
        case "wifi":    return Net.icon
        case "bluetooth": return !(Bluetooth.defaultAdapter?.enabled ?? false) ? "bluetooth_disabled" : (btDevice ? "bluetooth_connected" : "bluetooth")
        case "sound":
        case "volume":  return Audio.muted ? "volume_off" : (Audio.volume <= 0.001 ? "volume_mute" : (Audio.volume < 0.5 ? "volume_down" : "volume_up"))
        case "dnd":     return Config.c.dnd ? "notifications_off" : "notifications"
        case "battery": {
            if (PowerProfiles.profile === PowerProfile.PowerSaver) return "battery_saver"
            if (PowerProfiles.profile === PowerProfile.Performance) return "speed"
            if (charging) return "battery_charging_full"
            const p = Power.pct
            return p < 0 || p >= 95 ? "battery_full" : "battery_" + Math.max(0, Math.min(6, Math.floor(p / 100 * 7))) + "_bar"
        }
        case "capture": return QuickSettings.recording ? "stop_circle" : "screenshot_region"
        case "brightness": return "brightness_6"
        case "mic":     return Audio.micMuted ? "mic_off" : "mic"
        default:        return CcTiles.info(id).icon
        }
    }
    function sub(id) {
        switch (id) {
        case "wifi":      return Net.wifiOn ? (Net.ssid || "On") : "Off"
        case "bluetooth": return !(Bluetooth.defaultAdapter?.enabled ?? false) ? "Off" : (btDevice ? btDevice.name : "On")
        case "sound":     return Audio.muted ? "Muted" : Math.round(Audio.volume * 100) + "%"
        case "dnd":       return Config.c.dnd ? "On" : "Off"
        case "dark":      return Config.c.darkMode ? "Dark" : "Light"
        case "night":     return QuickSettings.filterActive ? ((QuickSettings.night ? QuickSettings.nightTemp + " K" : "") + (QuickSettings.night && QuickSettings.filter !== "" ? " · " : "") + QuickSettings.filterName()) : "Off"
        case "capture":   return QuickSettings.recording ? "Recording · stop" : "Screen, window, region"
        case "caffeine":  return Caffeine.label
        case "output":    return Audio.sink?.description ?? ""
        case "battery":   return batteryPct + "%" + (charging ? " · charging" : "") + " · " + QuickSettings.profileName()
        case "desktops":  return "Overview"
        case "lock":      return "Lock screen"
        case "power":     return "Options"
        default:          return ""
        }
    }
    function click(id) {
        switch (id) {
        case "wifi":       Net.toggleWifi(); break
        case "bluetooth":  QuickSettings.toggleBluetooth(); break
        case "sound":      Audio.toggleMute(); break
        case "dnd":        Config.c.dnd = !Config.c.dnd; break
        case "dark":       Config.c.darkMode = !Config.c.darkMode; break
        case "night":      if (QuickSettings.filterActive) { QuickSettings.setNight(false); QuickSettings.setFilter("") } else QuickSettings.setNight(true); break
        case "desktops":   Ui.toggle("overview"); break
        case "lock":       QuickSettings.power("lock"); break
        case "caffeine":   Caffeine.toggle(); break
        case "battery":    QuickSettings.togglePowerSaver(); break
        case "output":     Ui.openSettings("sounds"); break
        }
    }
    // tiles with an on / off and a menu: the round icon switches it, the rest of the tile opens the
    // menu (the same as a right-click). A 1 x 1 tile is all icon: it switches; right-click = menu.
    readonly property var toggleIds: ["wifi", "bluetooth", "sound", "dnd", "dark", "night", "caffeine", "battery"]
    function sliderValue(id) { return id === "brightness" ? QuickSettings.brightness : id === "mic" ? Audio.micVolume : Audio.volume }
    function setSlider(id, v) {
        if (id === "brightness") QuickSettings.setBrightness(v)
        else if (id === "mic") Audio.setMicVolume(v)
        else Audio.setVolume(v)
    }

    // ---------- edit mode bar ----------
    RowLayout {
        visible: grid.editing
        Layout.fillWidth: true
        spacing: 8
        DText { text: "Drag onto free cells or onto a tile to swap; pull a corner to resize"; color: Theme.subtext; font.pixelSize: 12; Layout.fillWidth: true; elide: Text.ElideRight }
        ArqButton { text: "Reset"; onClicked: grid.reset() }
        ArqButton { text: "Done"; primary: true; onClicked: grid.editing = false }
    }

    // ---------- the tiles ----------
    Item {
        id: area
        Layout.fillWidth: true
        Layout.preferredHeight: grid.shownRows > 0 ? grid.shownRows * grid.cellH + (grid.shownRows - 1) * grid.gap : 0
        Behavior on Layout.preferredHeight { NumberAnimation { duration: 170; easing.type: Easing.OutCubic } }

        // the grid's cells, while editing
        Repeater {
            model: grid.editing ? grid.cols * grid.shownRows : 0
            delegate: Rectangle {
                required property int index
                x: (index % grid.cols) * grid.step
                y: Math.floor(index / grid.cols) * grid.step
                width: grid.cellW; height: grid.cellH
                radius: Math.min(Config.c.tileRadius, width / 2)
                color: Qt.rgba(Theme.text.r, Theme.text.g, Theme.text.b, 0.04)
                border.width: 1
                border.color: Qt.rgba(Theme.text.r, Theme.text.g, Theme.text.b, 0.16)
            }
        }
        // where the dragged tile would land
        Rectangle {
            readonly property var s: grid.slot(grid.dragId)
            visible: grid.dragId !== "" && !!s && !grid.dropSame
            x: grid.dropC * grid.step
            y: grid.dropR * grid.step
            width: s ? s.w * grid.cellW + (s.w - 1) * grid.gap : 0
            height: s ? s.h * grid.cellH + (s.h - 1) * grid.gap : 0
            radius: Config.c.tileRadius
            readonly property color tint: grid.dropResult !== null ? Theme.primary : "#E5484D"
            color: Qt.rgba(tint.r, tint.g, tint.b, 0.18)
            border.width: 2; border.color: tint
            z: 10
        }

        Repeater {
            model: grid.ids
            delegate: Item {
                id: tile
                required property string modelData
                readonly property var def: CcTiles.info(modelData)
                readonly property var s: grid.slot(modelData)
                readonly property bool isSlider: def.kind === "slider"
                readonly property bool on: grid.isOn(modelData)
                // the battery tile takes a colour from the power profile: power saver = the tertiary colour, performance = the accent,
                // balanced = no colour (the plain tile)
                readonly property bool saverTile: modelData === "battery" && PowerProfiles.profile === PowerProfile.PowerSaver
                readonly property color onBg: saverTile ? Theme.tertiaryContainer : Theme.ccOn
                readonly property color badgeBg: on ? (saverTile ? Theme.tertiary : Theme.ccBadge) : Theme.tile
                readonly property color badgeFg: on ? (saverTile ? Theme.onTertiary : Theme.ccBadgeIcon) : Theme.text
                readonly property color onTxt: saverTile ? Theme.onTertiaryContainer : Theme.ccOnText
                readonly property bool tall: !!s && s.h >= 2
                readonly property bool vert: !!s && (s.w === 1 || s.h >= 2)
                readonly property bool small: !!s && s.w === 1 && s.h === 1      // just the icon
                property bool dragging: false
                property real dragX: 0
                property real dragY: 0

                visible: !!s
                // comes in a moment after the one before it, top-left first
                Enter { trigger: grid.enterSerial; delay: 50 + (tile.s ? (tile.s.r * 6 + tile.s.c) * 14 : 0) }
                width: s ? s.w * grid.cellW + (s.w - 1) * grid.gap : 0
                height: s ? s.h * grid.cellH + (s.h - 1) * grid.gap : 0
                x: dragging ? dragX : (s ? s.c * grid.step : 0)
                y: dragging ? dragY : (s ? s.r * grid.step : 0)
                z: dragging ? 20 : 1
                Behavior on x { enabled: !tile.dragging; NumberAnimation { duration: 170; easing.type: Easing.OutCubic } }
                Behavior on y { enabled: !tile.dragging; NumberAnimation { duration: 170; easing.type: Easing.OutCubic } }
                Behavior on width { NumberAnimation { duration: 170; easing.type: Easing.OutCubic } }
                Behavior on height { NumberAnimation { duration: 170; easing.type: Easing.OutCubic } }

                Rectangle {
                    anchors.fill: parent
                    radius: Config.c.tileRadius
                    color: tile.on ? tile.onBg : ((ma.containsMouse && !grid.editing) ? Theme.hover : Theme.card)
                    border.width: grid.editing ? 1.5 : 0
                    border.color: Theme.accent
                    scale: tile.dragging ? 1.04 : (ma.pressed && !grid.editing ? 0.95 : 1)
                    opacity: tile.dragging ? 0.92 : 1
                    Behavior on color { ColorAnimation { duration: 140 } }
                    Behavior on scale { NumberAnimation { duration: 260; easing.type: Easing.OutBack; easing.overshoot: Motion.os(2.5) } }
                }

                // Declared before the tile's content so that a slider on top of it still gets its
                // own clicks; in edit mode the slider is disabled and this area takes the drag.
                MouseArea {
                    id: ma
                    anchors.fill: parent
                    hoverEnabled: true
                    acceptedButtons: Qt.LeftButton | Qt.RightButton
                    preventStealing: grid.editing
                    cursorShape: grid.editing ? Qt.SizeAllCursor : Qt.PointingHandCursor
                    property real offX: 0
                    property real offY: 0

                    onPressed: mouse => {
                        if (!grid.editing || mouse.button !== Qt.LeftButton) return
                        const p = ma.mapToItem(area, mouse.x, mouse.y)
                        offX = p.x - tile.x
                        offY = p.y - tile.y
                        tile.dragX = tile.x
                        tile.dragY = tile.y
                        tile.dragging = true
                    }
                    onPositionChanged: mouse => {
                        if (!tile.dragging) return
                        const p = ma.mapToItem(area, mouse.x, mouse.y)
                        tile.dragX = p.x - offX
                        tile.dragY = p.y - offY
                        grid.dragOver(tile.modelData, tile.dragX, tile.dragY)
                    }
                    function finish() {
                        if (!tile.dragging) return
                        grid.drop()
                        tile.dragging = false
                    }
                    onReleased: finish()
                    onCanceled: finish()
                    onPressAndHold: mouse => { if (!grid.editing && mouse.button === Qt.LeftButton) grid.editing = true }
                    onClicked: mouse => {
                        if (grid.editing) return
                        // these have nothing to toggle, so a plain click opens their options too
                        if (tile.modelData === "capture" && mouse.button === Qt.LeftButton) { if (QuickSettings.recording) QuickSettings.record("stop"); else Ui.startCapture() }
                        else if (mouse.button === Qt.RightButton || tile.modelData === "power" || (grid.toggleIds.includes(tile.modelData) && !tile.small)) grid.menuRequested(tile.modelData, tile)
                        else grid.click(tile.modelData)
                    }
                }

                HoverTip { hovered: ma.containsMouse && !grid.editing; text: tile.def.name }

                // ---- 1 x 1: the icon alone (its name shows on hover) ----
                Rectangle {
                    visible: !tile.isSlider && tile.small
                    anchors.centerIn: parent
                    width: Math.min(parent.width, parent.height) * 0.62; height: width; radius: width / 2
                    color: tile.badgeBg
                    LiveIcon { anchors.centerIn: parent; name: grid.iconOf(tile.modelData); size: Math.round(parent.width * 0.55); color: tile.badgeFg }
                    MouseArea {   // the icon: switch it on / off
                        anchors { fill: parent; margins: -3 }
                        enabled: !grid.editing && grid.toggleIds.includes(tile.modelData)
                        hoverEnabled: true
                        cursorShape: Qt.PointingHandCursor
                        onClicked: grid.click(tile.modelData)
                        Rectangle { anchors.fill: parent; anchors.margins: 3; radius: width / 2; color: Theme.text; opacity: parent.containsMouse ? 0.12 : 0 }
                    }
                }
                // ---- icon tile, tall or narrow: icon above the label ----
                Column {
                    visible: !tile.isSlider && tile.vert && !tile.small
                    anchors.centerIn: parent
                    width: parent.width - 12
                    spacing: 3
                    Rectangle {
                        anchors.horizontalCenter: parent.horizontalCenter
                        width: tile.tall ? 40 : 30; height: width; radius: width / 2
                        color: tile.badgeBg
                        LiveIcon { anchors.centerIn: parent; name: grid.iconOf(tile.modelData); size: tile.tall ? 21 : 17; color: tile.badgeFg }
                        MouseArea {   // the icon: switch it on / off
                            anchors { fill: parent; margins: -3 }
                            enabled: !grid.editing && grid.toggleIds.includes(tile.modelData)
                            hoverEnabled: true
                            cursorShape: Qt.PointingHandCursor
                            onClicked: grid.click(tile.modelData)
                            Rectangle { anchors.fill: parent; anchors.margins: 3; radius: width / 2; color: Theme.text; opacity: parent.containsMouse ? 0.12 : 0 }
                        }
                    }
                    DText { width: parent.width; horizontalAlignment: Text.AlignHCenter; text: tile.def.name; font.pixelSize: 10; color: tile.on ? tile.onTxt : Theme.subtext; elide: Text.ElideRight }
                    DText { visible: tile.tall; width: parent.width; horizontalAlignment: Text.AlignHCenter; text: grid.sub(tile.modelData); font.pixelSize: 11; color: tile.on ? tile.onTxt : Theme.subtext; opacity: tile.on ? 0.8 : 1; elide: Text.ElideRight }
                }

                // ---- icon tile, wide: icon left, name and state right ----
                RowLayout {
                    visible: !tile.isSlider && !tile.vert
                    anchors { fill: parent; margins: 8 }
                    spacing: 8
                    Rectangle {
                        Layout.preferredWidth: 30; Layout.preferredHeight: 30; radius: 15
                        color: tile.badgeBg
                        LiveIcon { anchors.centerIn: parent; name: grid.iconOf(tile.modelData); size: 17; color: tile.badgeFg }
                        MouseArea {   // the icon: switch it on / off
                            anchors { fill: parent; margins: -3 }
                            enabled: !grid.editing && grid.toggleIds.includes(tile.modelData)
                            hoverEnabled: true
                            cursorShape: Qt.PointingHandCursor
                            onClicked: grid.click(tile.modelData)
                            Rectangle { anchors.fill: parent; anchors.margins: 3; radius: width / 2; color: Theme.text; opacity: parent.containsMouse ? 0.12 : 0 }
                        }
                    }
                    ColumnLayout {
                        Layout.fillWidth: true; spacing: 0
                        DText { text: tile.def.name; font.weight: Font.Medium; font.pixelSize: 13; color: tile.on ? tile.onTxt : Theme.text; Layout.fillWidth: true; elide: Text.ElideRight }
                        DText { text: grid.sub(tile.modelData); font.pixelSize: 10; color: tile.on ? tile.onTxt : Theme.subtext; opacity: tile.on ? 0.8 : 1; elide: Text.ElideRight; Layout.fillWidth: true }
                    }
                }

                // ---- slider tile: upright when the tile is taller than wide. Muted / at zero the
                // volume bar shows a crossed-out note in grey.
                ArqSlider {
                    visible: tile.isSlider
                    enabled: !grid.editing
                    anchors { fill: parent; margins: 6 }
                    vertical: !!tile.s && tile.s.h > tile.s.w
                    pill: true
                    stepSize: 0.01
                    icon: grid.iconOf(tile.modelData)
                    off: (tile.modelData === "volume" && Audio.muted) || (tile.modelData === "mic" && Audio.micMuted)
                    offIcon: tile.modelData === "volume" ? "music_off" : (tile.modelData === "mic" ? "mic_off" : "")
                    value: grid.sliderValue(tile.modelData)
                    onMoved: v => { if (tile.modelData === "volume" && Audio.muted && v > 0) Audio.toggleMute(); if (tile.modelData === "mic" && Audio.micMuted && v > 0) Audio.toggleMicMute(); grid.setSlider(tile.modelData, v) }
                }

                // ---- edit mode: remove (top-left) and the arc to pull for size (bottom-right) ----
                Rectangle {
                    visible: grid.editing
                    width: 20; height: 20; radius: 10
                    x: -6; y: -6; z: 5
                    color: "white"
                    border.width: 1; border.color: Qt.rgba(0, 0, 0, 0.15)
                    Rectangle { anchors.centerIn: parent; width: 10; height: 2.5; radius: 1; color: "#E5484D" }
                    MouseArea { anchors { fill: parent; margins: -4 } cursorShape: Qt.PointingHandCursor; onClicked: grid.hide(tile.modelData) }
                }
                Item {
                    visible: grid.editing
                    width: 26; height: 26; z: 5
                    anchors { bottom: parent.bottom; right: parent.right; bottomMargin: -4; rightMargin: -4 }
                    Shape {
                        anchors.fill: parent
                        layer.enabled: true; layer.samples: 4
                        ShapePath {
                            strokeColor: "white"; strokeWidth: 3.5; fillColor: "transparent"; capStyle: ShapePath.RoundCap
                            PathAngleArc {
                                centerX: 4; centerY: 4
                                radiusX: 19; radiusY: 19
                                startAngle: 10; sweepAngle: 70
                            }
                        }
                    }
                    MouseArea {
                        id: rma
                        anchors.fill: parent
                        preventStealing: true
                        cursorShape: Qt.SizeFDiagCursor
                        property real sx: 0
                        property real sy: 0
                        property int sw: 1
                        property int sh: 1
                        onPressed: mouse => {
                            grid.beginGesture()
                            const p = rma.mapToItem(area, mouse.x, mouse.y)
                            sx = p.x; sy = p.y
                            sw = tile.s ? tile.s.w : 1
                            sh = tile.s ? tile.s.h : 1
                        }
                        onPositionChanged: mouse => {
                            if (!pressed) return
                            const p = rma.mapToItem(area, mouse.x, mouse.y)
                            grid.resizeTo(tile.modelData,
                                sw + Math.round((p.x - sx) / grid.step),
                                sh + Math.round((p.y - sy) / grid.step))
                        }
                        onReleased: grid.endGesture()
                        onCanceled: grid.endGesture()
                    }
                }
            }
        }
    }

    // ---------- tray of tiles that can be added ----------
    ColumnLayout {
        visible: grid.editing && grid.addable.length > 0
        Layout.fillWidth: true
        spacing: 6
        DText { text: "Add tiles"; color: Theme.subtext; font.pixelSize: 12 }
        Flow {
            Layout.fillWidth: true
            spacing: 8
            Repeater {
                model: grid.addable
                delegate: Rectangle {
                    id: chip
                    required property var modelData
                    height: 38; width: chipRow.implicitWidth + 28; radius: 19
                    color: chipMa.containsMouse ? Theme.hover : Theme.tile
                    Row {
                        id: chipRow
                        anchors.centerIn: parent
                        spacing: 8
                        Icon { name: "add"; size: 18; color: Theme.accent; anchors.verticalCenter: parent.verticalCenter }
                        Icon { name: chip.modelData.icon; size: 18; anchors.verticalCenter: parent.verticalCenter }
                        DText { text: chip.modelData.name; font.pixelSize: 13; anchors.verticalCenter: parent.verticalCenter }
                    }
                    MouseArea { id: chipMa; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: grid.add(chip.modelData.id) }
                }
            }
        }
    }
}
