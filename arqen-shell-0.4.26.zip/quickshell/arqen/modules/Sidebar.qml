import Quickshell
import Quickshell.Wayland
import Quickshell.Hyprland
import Quickshell.Widgets
import Quickshell.Io
import QtQuick
import QtQuick.Layouts
import qs.config
import qs.components
import qs.services

// Control centre as a sidebar: tiles (see ControlGrid), and the notification list underneath.
// It opens on the side of the screen where the panel's control centre button is, and slides in
// from there. It floats with the shared panel gap (Ui.gap) from the screen edges and the panel.
// The clipboard history is its own panel button / popup now (ClipboardPopup).
PanelWindow {
    id: win

    readonly property bool open: Ui.open === "quick"
    // opening springs in (a small overshoot), closing is quick and plain; started explicitly each
    // time (a Behavior with changing settings only animated the first time)
    property real t: 0                  // everything starts closed
    NumberAnimation { id: sbIn; target: win; property: "t"; to: 1; duration: 380; easing.type: Easing.OutBack; easing.overshoot: Motion.os(0.7) }
    NumberAnimation { id: sbOut; target: win; property: "t"; to: 0; duration: 180; easing.type: Easing.InCubic }
    readonly property bool sbWant: open
    onSbWantChanged: { if (sbWant) { sbOut.stop(); sbIn.restart(); openSerial++ } else { sbIn.stop(); sbOut.restart() } }
    // goes up each time it opens: what is inside comes in again, one after another (Enter)
    property int openSerial: 0

    // Which side it docks to. Chosen when it opens and kept while it slides away.
    property string side: "right"
    function pickSide() {
        if (Ui.vertical) return Ui.edge                       // next to a vertical panel
        if (Ui.popAlong >= 0) return Ui.popAlong - Ui.rLeft < win.width / 2 ? "left" : "right"   // where the button is
        const s = Config.sectionOf("control")                 // opened by a key: use the layout
        return s === "left" ? "left" : "right"
    }
    onOpenChanged: {
        if (open) { side = pickSide(); QuickSettings.refresh() }
        else { menu.close(); grid.editing = false; Notifs.collapseAll() }
    }

    screen: Quickshell.screens.find(s => s.name === Hyprland.focusedMonitor?.name) ?? Quickshell.screens[0]
    visible: t > 0.001
    color: "transparent"
    anchors { top: true; left: true; right: true; bottom: true }
    // the window stops where the panel starts, so the cards keep `gap` from it too
    margins { top: Ui.rTop; bottom: Ui.rBottom; left: Ui.rLeft; right: Ui.rRight }
    exclusionMode: ExclusionMode.Ignore
    WlrLayershell.namespace: "arqen-sidebar"
    WlrLayershell.layer: WlrLayer.Overlay
    // clicking into the panel gives it the keyboard (Wi-Fi password)
    WlrLayershell.keyboardFocus: open ? WlrKeyboardFocus.OnDemand : WlrKeyboardFocus.None

    Shortcut { sequence: "Escape"; enabled: win.open; onActivated: { if (menu.tileId !== "") menu.close(); else if (grid.editing) grid.editing = false; else Ui.close() } }
    MouseArea { anchors.fill: parent; onClicked: Ui.close() }

    readonly property real ccW: Math.min(400, win.width - 2 * Ui.gap)
    readonly property real span: ccW + Ui.gap
    // how far the card is pushed off the screen edge while closed
    readonly property real slide: (1 - t) * (span + Ui.gap + 2) * (side === "right" ? 1 : -1)

    SystemClock { id: clk; precision: SystemClock.Minutes }

    // ---- how long the computer has been up, and the battery's health (under your name) ----
    property string upText: ""
    property string batHealth: ""
    function fmtUp(sec) {
        const d = Math.floor(sec / 86400), h = Math.floor(sec % 86400 / 3600), m = Math.floor(sec % 3600 / 60)
        return d > 0 ? d + "d " + h + "h" : (h > 0 ? h + "h " + m + "m" : m + "m")
    }
    Process {
        id: upProc
        command: ["sh", "-c", "cut -d' ' -f1 /proc/uptime; b=$(ls -d /sys/class/power_supply/BAT* 2>/dev/null | head -n1); [ -n \"$b\" ] && { f=$(cat $b/energy_full $b/charge_full 2>/dev/null | head -n1); d=$(cat $b/energy_full_design $b/charge_full_design 2>/dev/null | head -n1); [ -n \"$f\" ] && [ -n \"$d\" ] && [ \"$d\" -gt 0 ] && echo $((f * 100 / d)); }"]
        stdout: StdioCollector {
            onStreamFinished: {
                const l = text.trim().split("\n")
                if (l[0]) win.upText = win.fmtUp(parseFloat(l[0]))
                win.batHealth = l[1] ? l[1] + "%" : ""
            }
        }
    }
    Timer { interval: 60000; repeat: true; running: win.open; triggeredOnStart: true; onTriggered: if (!upProc.running) upProc.running = true }

    // ---------- control centre ----------
    Rectangle {
        id: card
        // a floating card with a gap all round
        readonly property real g: Ui.gap
        width: win.ccW
        anchors { top: parent.top; bottom: parent.bottom; topMargin: g; bottomMargin: g }
        x: (win.side === "right" ? win.width - width - g : g) + win.slide
        radius: Theme.radius
        // the same see-through surface as everything else in the shell, with cards on it
        color: Theme.glass
        border.color: Theme.stroke
        border.width: 1
        MouseArea { anchors.fill: parent }   // swallow clicks inside the card

        ColumnLayout {
            anchors { fill: parent; margins: 14 }
            spacing: 10

            // ---- header: you (picture, name, computer), buttons ----
            RowLayout {
                Layout.fillWidth: true
                spacing: 6
                Enter { trigger: win.openSerial; delay: 30 }
                Rectangle {
                    Layout.fillWidth: true
                    Layout.rightMargin: 6
                    implicitHeight: Sizes.hL; radius: height / 2
                    color: meMa.containsMouse ? Theme.hover : Theme.card
                    Row {
                        id: me
                        spacing: 12
                        x: 6; width: parent.width - 18
                        anchors.verticalCenter: parent.verticalCenter
                        Avatar { size: 40; anchors.verticalCenter: parent.verticalCenter }
                        Column {
                            anchors.verticalCenter: parent.verticalCenter
                            width: parent.width - 52
                            spacing: 2
                            DText { width: parent.width; text: User.name; font.pixelSize: 15; font.weight: Font.DemiBold; elide: Text.ElideRight }
                            // small facts as chips, so nothing gets cut off: how long the computer has been on, and the battery's health
                            Flow {
                                width: parent.width
                                spacing: 6
                                visible: win.upText !== ""
                                Repeater {
                                    model: [
                                        { icon: "schedule", text: "Up " + win.upText, show: win.upText !== "", tip: "Time since the computer started" }
                                    ].filter(c => c.show)
                                    delegate: Rectangle {
                                        required property var modelData
                                        height: 18; radius: 9
                                        width: chipRow.implicitWidth + 12
                                        color: Qt.rgba(Theme.text.r, Theme.text.g, Theme.text.b, 0.08)
                                        Row {
                                            id: chipRow
                                            anchors.centerIn: parent
                                            spacing: 4
                                            Icon { name: modelData.icon; size: 12; color: Theme.subtext; anchors.verticalCenter: parent.verticalCenter }
                                            DText { text: modelData.text; font.pixelSize: 11; color: Theme.subtext; anchors.verticalCenter: parent.verticalCenter }
                                        }
                                    }
                                }
                            }
                            DText { visible: win.upText === ""; width: parent.width; text: User.host; font.pixelSize: 11; color: Theme.subtext; elide: Text.ElideRight }
                        }
                    }
                    MouseArea { id: meMa; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: Ui.openSettings("about") }
                    HoverTip { hovered: meMa.containsMouse; text: "Your picture and account" + (win.upText !== "" ? "\nUp " + win.upText + " (time since the computer started)" : "") + (win.batHealth !== "" ? "\nBattery health " + win.batHealth + " (how much of its original capacity is left)" : ""); side: "bottom" }
                }
                TrayButton { round: true; restColor: Theme.card; icon: "edit"; size: 18; tip: "Edit tiles"; tipSide: "bottom"; active: grid.editing; onClicked: grid.editing = !grid.editing }
                // reload the whole shell (re-reads the config files, rebuilds every window)
                TrayButton { round: true; restColor: Theme.card; icon: "refresh"; size: 18; tip: "Reload the shell"; tipSide: "bottom"; onClicked: Quickshell.reload(true) }
                TrayButton { round: true; restColor: Theme.card; icon: "settings"; size: 18; tip: "Settings"; tipSide: "bottom"; onClicked: Ui.openSettings("") }
                // power menu: lock, sleep, log out, restart, shut down
                TrayButton {
                    id: powerBtn
                    round: true; restColor: Theme.card
                    icon: "power_settings_new"; size: 18
                    tip: "Power"; tipSide: "bottom"
                    // the full-screen power menu (modules/PowerMenu.qml)
                    onClicked: Ui.toggle("power")
                }
            }

            // ---- tiles (scrolls if you make them taller than the panel) ----
            Flickable {
                id: gridFlick
                Layout.fillWidth: true
                Layout.preferredHeight: Math.min(grid.implicitHeight, card.height * (grid.editing ? 0.72 : 0.58))
                contentWidth: width
                contentHeight: grid.implicitHeight
                clip: true
                interactive: !grid.gesturing
                boundsBehavior: Flickable.StopAtBounds

                ControlGrid {
                    id: grid
                    enterSerial: win.openSerial
                    width: gridFlick.width
                    onMenuRequested: (tid, titem) => {
                        const p = titem.mapToItem(card, 0, 0)
                        menu.tileTop = p.y
                        menu.tileBottom = p.y + titem.height
                        menu.tileId = tid
                    }
                }
            }

            // ---- notifications ----
            RowLayout {
                Enter { trigger: win.openSerial; delay: 200 }
                Layout.fillWidth: true
                Layout.topMargin: 4
                // a section title like the ones in Settings
                DText { text: "Notifications" + (Notifs.count > 0 ? "  ·  " + Notifs.count : ""); font.pixelSize: 13; font.weight: Font.Medium; color: Theme.subtext; leftPadding: 12 }
                Item { Layout.fillWidth: true }
                ArqButton { text: "Settings"; onClicked: Ui.openSettings("notifications") }
                ArqButton { visible: notifList.count > 0; text: "Clear"; onClicked: Notifs.clearAll() }
            }

            ListView {
                id: notifList
                Enter { target: notifList; trigger: win.openSerial; delay: 220 }
                Layout.fillWidth: true
                Layout.fillHeight: true
                Layout.minimumHeight: 120
                clip: true
                spacing: 10
                topMargin: 4; bottomMargin: 8
                boundsBehavior: Flickable.StopAtBounds
                // a click on empty space closes whatever is open (a notification, a stack)
                MouseArea { z: -1; parent: notifList; anchors.fill: parent; onClicked: Notifs.collapseAll() }
                // one stack per app, newest first (like a phone); click the number to open a stack,
                // the arrow to open a notification, swipe one (or a stack) away to clear it
                model: Notifs.groups
                delegate: NotifGroup {
                    required property var modelData
                    width: notifList.width
                    group: modelData
                }
                DText { visible: notifList.count === 0; anchors.centerIn: parent; text: "No notifications"; color: Theme.subtext }
            }
        }

        // ---- tile options (right-click): a click anywhere else closes it ----
        MouseArea {
            anchors.fill: parent
            z: 90
            visible: menu.tileId !== ""
            acceptedButtons: Qt.AllButtons
            onClicked: menu.close()
        }
        CcMenu {
            id: menu
            z: 100
            visible: tileId !== ""
            property real tileTop: 0
            property real tileBottom: 0
            x: 18
            width: card.width - 36
            // below the tile, or above it when there is no room underneath
            y: (tileBottom + 6 + height > card.height - 12) ? Math.max(12, tileTop - 6 - height) : tileBottom + 6
            onEditRequested: { menu.close(); grid.editing = true }
        }
    }
}
