import Quickshell
import Quickshell.Wayland
import Quickshell.Hyprland
import QtQuick
import qs.config
import qs.components
import qs.services

// Draw on the screen (Super + Shift + D, or the pencil in the recording screen): pen, highlighter, arrows,
// rectangles and circles over everything, so they are also in a screen recording.
//  - drawing: the pointer draws
//  - paused (the little pencil): the drawing stays on the screen and the pointer goes through to the windows
// Clear (the bin) removes it all; the cross removes it and closes.
PanelWindow {
    id: win
    screen: Quickshell.screens.find(s => s.name === Hyprland.focusedMonitor?.name) ?? Quickshell.screens[0]
    visible: Ui.drawOpen
    color: "transparent"
    anchors { top: true; left: true; right: true; bottom: true }
    exclusionMode: ExclusionMode.Ignore
    WlrLayershell.namespace: "arqen-draw"
    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.keyboardFocus: Ui.drawOpen && Ui.drawing ? WlrKeyboardFocus.OnDemand : WlrKeyboardFocus.None
    // drawing: everything; paused: only the small control
    mask: Region { item: Ui.drawing ? everything : pill }

    Connections {
        target: Ui
        function onDrawOpenChanged() { if (!Ui.drawOpen) canvas.clear() }
    }

    Item { id: everything; anchors.fill: parent }

    AnnotCanvas {
        id: canvas
        anchors.fill: parent
        interactive: Ui.drawing
    }
    // a faint frame while drawing, so it is clear the screen is in drawing mode
    Rectangle { anchors.fill: parent; visible: Ui.drawing; color: "transparent"; border.width: 3; border.color: Qt.rgba(1, 1, 1, 0.22); radius: 2 }

    Item {
        anchors.fill: parent
        focus: Ui.drawing
        Keys.onEscapePressed: Ui.drawing = false
        Keys.onPressed: event => { if (event.key === Qt.Key_Z && (event.modifiers & Qt.ControlModifier)) { canvas.undo(); event.accepted = true } }
    }

    // the tools (while drawing)
    AnnotBar {
        id: tools
        visible: Ui.drawing
        canvas: canvas
        anchors { horizontalCenter: parent.horizontalCenter; bottom: parent.bottom; bottomMargin: 28 }
        extra: [
            Rectangle {
                width: 32; height: 32; radius: 16
                color: pma.containsMouse ? Qt.rgba(1, 1, 1, 0.12) : "transparent"
                Icon { anchors.centerIn: parent; name: "pause_circle"; size: 16; color: "white" }
                MouseArea { id: pma; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: Ui.drawing = false }
                HoverTip { hovered: pma.containsMouse; text: "Stop drawing, keep it on the screen"; side: "top" }
            },
            Rectangle {
                width: 32; height: 32; radius: 16
                color: xma.containsMouse ? Qt.rgba(1, 0.3, 0.3, 0.3) : "transparent"
                Icon { anchors.centerIn: parent; name: "close"; size: 16; color: "white" }
                MouseArea { id: xma; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: { Ui.drawOpen = false } }
                HoverTip { hovered: xma.containsMouse; text: "Close and remove the drawing"; side: "top" }
            }
        ]
    }
    // paused: a small pill to go on drawing or remove it
    Rectangle {
        id: pill
        visible: !Ui.drawing
        width: pr.implicitWidth + 8; height: 40; radius: 20
        anchors { right: parent.right; rightMargin: 18; bottom: parent.bottom; bottomMargin: 18 }
        color: Qt.rgba(0.08, 0.08, 0.1, 0.8); border.width: 1; border.color: Qt.rgba(1, 1, 1, 0.14)
        Row {
            id: pr
            anchors.centerIn: parent
            spacing: 2
            Rectangle {
                width: 32; height: 32; radius: 16; color: ema.containsMouse ? Qt.rgba(1, 1, 1, 0.14) : "transparent"
                Icon { anchors.centerIn: parent; name: "edit"; size: 16; color: "white" }
                MouseArea { id: ema; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: Ui.drawing = true }
                HoverTip { hovered: ema.containsMouse; text: "Draw again"; side: "top" }
            }
            Rectangle {
                width: 32; height: 32; radius: 16; color: cma.containsMouse ? Qt.rgba(1, 0.3, 0.3, 0.3) : "transparent"
                Icon { anchors.centerIn: parent; name: "close"; size: 16; color: "white" }
                MouseArea { id: cma; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: Ui.drawOpen = false }
                HoverTip { hovered: cma.containsMouse; text: "Remove the drawing"; side: "top" }
            }
        }
    }
}
