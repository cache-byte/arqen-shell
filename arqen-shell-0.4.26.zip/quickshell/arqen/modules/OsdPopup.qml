import Quickshell
import Quickshell.Wayland
import Quickshell.Hyprland
import QtQuick
import qs.config
import qs.components
import qs.services

// The on-screen display for volume, brightness, keyboard light, media and lock keys.
// Where it sits and which way it lies: Settings > Display and windows > On-screen display.
PanelWindow {
    id: osd

    readonly property string pos: Config.c.osdPos || "bottom"
    readonly property bool vertical: Config.c.osdVertical === true
    readonly property bool hasBar: Osd.value >= 0

    screen: Quickshell.screens.find(s => s.name === Hyprland.focusedMonitor?.name) ?? Quickshell.screens[0]
    visible: card.opacity > 0.01
    color: "transparent"
    exclusionMode: ExclusionMode.Ignore
    WlrLayershell.namespace: "arqen-popup"
    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.keyboardFocus: WlrKeyboardFocus.None
    mask: Region {}                       // never takes clicks

    anchors {
        top: pos.indexOf("top") >= 0
        bottom: pos.indexOf("bottom") >= 0
        left: pos.indexOf("left") >= 0
        right: pos.indexOf("right") >= 0
    }
    margins { top: Ui.rTop + 24; bottom: Ui.rBottom + 24; left: Ui.rLeft + 24; right: Ui.rRight + 24 }
    implicitWidth: card.width
    implicitHeight: card.height

    // Drawn like the control centre: a card with the same pill slider (icon at the start of the
    // fill; muted volume greys out with a crossed-out note), or, for keys without a level (Caps
    // Lock, media), the round icon badge with its name, like a toggle tile.
    Rectangle {
        id: card
        readonly property real pad: 8
        width: osd.vertical ? 62 : 320
        height: osd.vertical ? 250 : 62
        radius: Config.c.tileRadius + pad
        color: Theme.glass
        border.width: 1; border.color: Theme.stroke
        opacity: Osd.shown ? 1 : 0
        scale: Osd.shown ? 1 : 0.92
        Behavior on opacity { NumberAnimation { duration: 160 } }
        Behavior on scale { NumberAnimation { duration: 300; easing.type: Easing.OutBack; easing.overshoot: Motion.os(1.6) } }

        // ---- a level: the control centre's slider, with the number beside it ----
        Item {
            visible: osd.hasBar
            anchors { fill: parent; margins: card.pad }
            ArqSlider {
                id: bar
                enabled: false
                pill: true
                vertical: osd.vertical
                icon: Osd.icon
                off: Osd.off
                offIcon: Osd.offIcon
                value: Math.max(0, Math.min(1, Osd.value))
                x: 0; y: osd.vertical ? 30 : 0
                width: osd.vertical ? parent.width : parent.width - 42
                height: osd.vertical ? parent.height - 30 : parent.height
                Behavior on value { NumberAnimation { duration: 90 } }
            }
            DText {
                x: osd.vertical ? 0 : parent.width - 38
                y: osd.vertical ? 4 : (parent.height - height) / 2
                width: osd.vertical ? parent.width : 38
                horizontalAlignment: Text.AlignHCenter
                text: Osd.off ? "–" : Math.round(Osd.value * 100)
                font.pixelSize: 14; font.weight: Font.DemiBold
                color: Osd.off ? Theme.subtext : Theme.text
            }
        }

        // ---- no level: badge and name (standing up: badge, name turned sideways) ----
        Rectangle {
            id: badge
            visible: !osd.hasBar
            width: 42; height: 42; radius: 21
            x: osd.vertical ? (parent.width - width) / 2 : card.pad + 2
            y: osd.vertical ? parent.height - height - card.pad - 2 : (parent.height - height) / 2
            color: Theme.ccBadge
            Icon { anchors.centerIn: parent; name: Osd.icon; size: 22; color: Theme.ccBadgeIcon }
        }
        DText {
            visible: !osd.hasBar && !osd.vertical
            x: badge.x + badge.width + 12
            anchors.verticalCenter: parent.verticalCenter
            width: parent.width - x - 16
            text: Osd.label; elide: Text.ElideRight
            font.pixelSize: 14; font.weight: Font.Medium
        }
        DText {
            visible: !osd.hasBar && osd.vertical
            x: (parent.width - width) / 2
            y: (badge.y - height) / 2
            rotation: -90
            text: Osd.label; font.pixelSize: 13; font.weight: Font.Medium
        }
    }
}
