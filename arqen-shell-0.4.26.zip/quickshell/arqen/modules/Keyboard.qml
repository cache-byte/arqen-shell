import Quickshell
import Quickshell.Wayland
import Quickshell.Hyprland
import QtQuick
import QtQuick.Layouts
import qs.config
import qs.components
import qs.services

// The on-screen keyboard: keys, emoji and GIFs, in the shell's colours. It sits along the bottom of
// the screen (windows make room for it) and never takes the keyboard focus, so what you type goes
// to the window you were using. Opened from its panel item, or `qs -c arqen ipc call arqen toggle keyboard`.
Scope {
// Moving it: the keyboard itself stays put while you drag (moving a screen-edge window on every
// mouse step flickers); an outline follows the pointer on a see-through layer over the screen,
// and the keyboard jumps there when you let go.
PanelWindow {
    id: ghostWin
    screen: kb.screen
    visible: kb.dragging
    color: "transparent"
    anchors { top: true; bottom: true; left: true; right: true }
    exclusionMode: ExclusionMode.Ignore
    WlrLayershell.namespace: "arqen-osk-drag"
    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.keyboardFocus: WlrKeyboardFocus.None
    mask: Region {}
    Rectangle {
        x: kb.gx; y: kb.gy
        width: kb.kbW; height: kb.kbH
        radius: Theme.radius
        color: Qt.rgba(Theme.primary.r, Theme.primary.g, Theme.primary.b, 0.14)
        border.width: 2; border.color: Theme.primary
        Row {
            anchors.centerIn: parent
            spacing: 8
            Icon { name: "open_with"; size: 22; color: Theme.primary; anchors.verticalCenter: parent.verticalCenter }
            DText { text: "Let go to put the keyboard here"; color: Theme.primary; font.pixelSize: 15; anchors.verticalCenter: parent.verticalCenter }
        }
    }
}
PanelWindow {
    id: kb
    screen: Quickshell.screens.find(s => s.name === Hyprland.focusedMonitor?.name) ?? Quickshell.screens[0]
    // rises in with a little bounce, drops away when hidden
    // opening springs in (a small overshoot), closing is quick and plain; started explicitly each
    // time (a Behavior with changing settings only animated the first time)
    property real show: 0                  // everything starts closed
    NumberAnimation { id: oskIn; target: kb; property: "show"; to: 1; duration: 380; easing.type: Easing.OutBack; easing.overshoot: Motion.os(1) }
    NumberAnimation { id: oskOut; target: kb; property: "show"; to: 0; duration: 170; easing.type: Easing.InCubic }
    // not while locked: the lock screen draws its own keyboard (this window would be under the lock)
    readonly property bool oskWant: Osk.shown && !Ui.locked
    onOskWantChanged: { if (oskWant) { oskOut.stop(); oskIn.restart() } else { oskIn.stop(); oskOut.restart() } }
    visible: show > 0.001
    color: "transparent"
    // Docked along the bottom (windows make room), or floating where you dragged it (remembered,
    // Config.c.oskPos; the dock button puts it back).
    readonly property real kbH: Math.max(220, Config.c.oskHeight || 320)
    // split: the full width of the screen, a half under each hand
    readonly property real kbW: Osk.split ? (screen?.width ?? 1920) - 2 * Ui.gap : Math.min((screen?.width ?? 1920) - 2 * Ui.gap, 1180)
    readonly property bool floating: Config.c.oskPos && Config.c.oskPos.x !== undefined
    property bool dragging: false
    property real gx: 0                    // the outline while dragging
    property real gy: 0
    property real fx: Config.c.oskPos?.x ?? 0
    property real fy: Config.c.oskPos?.y ?? 0
    function clampPos() {
        fx = Math.max(0, Math.min((screen?.width ?? 1920) - kbW, fx))
        fy = Math.max(0, Math.min((screen?.height ?? 1080) - kbH, fy))
    }
    function dock() { Config.c.oskPos = ({}) }
    anchors { bottom: !floating; top: floating; left: true; right: !floating }
    margins { left: floating ? fx : 0; top: floating ? fy : 0 }
    implicitWidth: floating ? kbW : 0
    implicitHeight: floating ? kbH : kbH + Ui.gap
    exclusionMode: floating ? ExclusionMode.Ignore : ExclusionMode.Auto
    WlrLayershell.namespace: "arqen-popup"
    // above everything (password prompts, dialogs that grey the screen out), and still making room
    // for windows when docked (its exclusive zone)
    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.keyboardFocus: WlrKeyboardFocus.None
    // Clicks are taken where the keyboard is, measured from a box that never moves: the card slides
    // in with a transform, and a mask taken from the sliding card was still lowered by the slide, so
    // the top row (tabs, search, language, hide) got no clicks.
    mask: Region { item: hitBox }
    Item { id: hitBox; x: card.x; y: 0; width: card.width; height: card.height }

    // key colours, from the theme
    readonly property color keyC: Theme.dark ? Qt.rgba(1, 1, 1, 0.10) : Qt.rgba(1, 1, 1, 0.85)
    readonly property color modC: Theme.dark ? Qt.rgba(1, 1, 1, 0.05) : Qt.rgba(0, 0, 0, 0.07)

    Rectangle {
        id: card
        width: kb.kbW
        height: kb.kbH
        x: kb.floating ? 0 : (kb.width - width) / 2
        y: 0
        opacity: (kb.dragging ? 0.45 : 1) * Math.min(1, kb.show)
        transform: Translate { y: (1 - kb.show) * 60 }
        radius: Theme.radius
        color: Theme.glass
        border.width: 1; border.color: Theme.stroke

        ColumnLayout {
            anchors { fill: parent; margins: 10 }
            spacing: 8

            // ---------- top bar: what to show, search, language, close ----------
            RowLayout {
                Layout.fillWidth: true
                Layout.preferredHeight: 38
                spacing: 6
                // drag here to move the keyboard anywhere on the screen
                Rectangle {
                    Layout.preferredWidth: 30; Layout.preferredHeight: 36; radius: 12
                    color: grip.pressed ? Theme.secondaryContainer : (grip.containsMouse ? Theme.hover : "transparent")
                    Icon { anchors.centerIn: parent; name: "drag_indicator"; size: 22; color: Theme.subtext }
                    MouseArea {
                        id: grip
                        anchors.fill: parent
                        hoverEnabled: true
                        preventStealing: true
                        cursorShape: pressed ? Qt.ClosedHandCursor : Qt.OpenHandCursor
                        property real px: 0
                        property real py: 0
                        property real sx: 0
                        property real sy: 0
                        onPressed: mouse => {
                            // where the keyboard is now, on the screen
                            sx = kb.floating ? kb.fx : (kb.width - kb.kbW) / 2
                            sy = kb.floating ? kb.fy : (kb.screen?.height ?? 1080) - kb.kbH - Ui.gap
                            kb.gx = sx; kb.gy = sy
                            const p = grip.mapToItem(card, mouse.x, mouse.y)
                            px = p.x; py = p.y
                            kb.dragging = true
                        }
                        // the keyboard does not move while dragging, so the pointer's offset from where
                        // it was pressed is exactly how far to move
                        onPositionChanged: mouse => {
                            if (!pressed) return
                            const p = grip.mapToItem(card, mouse.x, mouse.y)
                            kb.gx = Math.max(0, Math.min((kb.screen?.width ?? 1920) - kb.kbW, sx + p.x - px))
                            kb.gy = Math.max(0, Math.min((kb.screen?.height ?? 1080) - kb.kbH, sy + p.y - py))
                        }
                        onReleased: {
                            kb.fx = kb.gx; kb.fy = kb.gy
                            Config.c.oskPos = { x: Math.round(kb.gx), y: Math.round(kb.gy) }
                            kb.dragging = false
                        }
                        onCanceled: kb.dragging = false
                    }
                    HoverTip { hovered: grip.containsMouse && !grip.pressed; text: "Drag to move" }
                }
                Repeater {
                    model: [{ t: "keys", i: "keyboard" }, { t: "emoji", i: "mood" }, { t: "gif", i: "gif_box" }]
                    delegate: Rectangle {
                        required property var modelData
                        readonly property bool on: Osk.tab === modelData.t
                        Layout.preferredWidth: 52; Layout.preferredHeight: 36; radius: 18
                        color: on ? Theme.secondaryContainer : (tabMa.containsMouse ? Theme.hover : "transparent")
                        Icon { anchors.centerIn: parent; name: parent.modelData.i; size: 22; color: parent.on ? Theme.onSecondaryContainer : Theme.text }
                        MouseArea { id: tabMa; anchors.fill: parent; hoverEnabled: true; onClicked: Osk.tab = parent.modelData.t }
                    }
                }
                // search (emoji and GIFs): tap it, then type with the keys below
                Rectangle {
                    visible: Osk.tab !== "keys"
                    Layout.fillWidth: true; Layout.preferredHeight: 36
                    radius: 18
                    color: Theme.tile
                    border.width: Osk.searching ? 2 : 0; border.color: Theme.primary
                    Row {
                        anchors { fill: parent; leftMargin: 14; rightMargin: 14 }
                        spacing: 8
                        Icon { name: "search"; size: 18; color: Theme.subtext; anchors.verticalCenter: parent.verticalCenter }
                        DText {
                            anchors.verticalCenter: parent.verticalCenter
                            width: parent.width - 60
                            elide: Text.ElideLeft
                            text: Osk.query !== "" ? Osk.query + (Osk.searching ? "│" : "")
                                : (Osk.searching ? "│" : (Osk.tab === "gif" ? "Search GIPHY" : "Search emoji"))
                            color: Osk.query !== "" || Osk.searching ? Theme.text : Theme.subtext
                        }
                    }
                    MouseArea { anchors.fill: parent; onClicked: Osk.searching = !Osk.searching }
                    Icon {
                        visible: Osk.query !== ""
                        anchors { right: parent.right; rightMargin: 10; verticalCenter: parent.verticalCenter }
                        name: "close"; size: 18; color: Theme.subtext
                        MouseArea { anchors.fill: parent; anchors.margins: -6; onClicked: Osk.query = "" }
                    }
                }
                Item { visible: Osk.tab === "keys"; Layout.fillWidth: true }
                // language: tap for the next one
                Rectangle {
                    Layout.preferredHeight: 36; Layout.preferredWidth: langRow.implicitWidth + 24; radius: 18
                    color: langMa.containsMouse ? Theme.hover : "transparent"
                    Row {
                        id: langRow; anchors.centerIn: parent; spacing: 6
                        Icon { name: "language"; size: 18; color: Theme.subtext; anchors.verticalCenter: parent.verticalCenter }
                        DText { text: Osk.lang.name; font.pixelSize: 13; anchors.verticalCenter: parent.verticalCenter }
                    }
                    MouseArea { id: langMa; anchors.fill: parent; hoverEnabled: true; onClicked: Osk.nextLanguage() }
                }
                TrayButton { round: true; icon: Osk.split ? "keyboard" : "vertical_split"; size: 20; active: Osk.split
                             tip: Osk.split ? "Join the keyboard" : "Split the keyboard"; onClicked: Osk.split = !Osk.split }
                TrayButton { visible: kb.floating && !kb.dragging; round: true; icon: "vertical_align_bottom"; size: 20; tip: "Back to the bottom"; onClicked: kb.dock() }
                TrayButton { round: true; icon: "keyboard_hide"; size: 20; tip: "Hide"; onClicked: Osk.shown = false }
            }

            // ---------- the keys (also while typing a search) ----------
            Item {
                id: keysArea
                visible: Osk.tab === "keys" || Osk.searching
                Layout.fillWidth: true; Layout.fillHeight: true

                // one key: { t: label, c: character | k: key name | a: action, w: width in units, i: icon, mod }
                readonly property var rowsSpec: {
                    const r = Osk.rows
                    const ch = a => a.map(c => ({ c: c, w: 1 }))
                    const out = []
                    if (Osk.layer === "letters")
                        out.push(Osk.chars("1234567890").map(c => ({ c: c, w: 1 })).concat([{ k: "BackSpace", i: "backspace", w: 1.5, mod: true }]))
                    else
                        out.push([{ k: "Escape", t: "Esc", w: 1.2, mod: true }].concat(ch(r[0])).concat([{ k: "BackSpace", i: "backspace", w: 1.5, mod: true }]))
                    out.push([{ k: "Tab", i: "keyboard_tab", w: 1.3, mod: true }].concat(ch(Osk.layer === "letters" ? r[0] : r[1])))
                    if (Osk.layer === "letters") {
                        out.push(ch(r[1]).concat([{ k: "Return", i: "keyboard_return", w: 1.8, enter: true }]))
                        out.push([{ a: "shift", i: "shift", w: 1.5, mod: true }].concat(ch(r[2])).concat([{ a: "shift", i: "shift", w: 1.5, mod: true }]))
                        for (let i = 3; i < r.length; i++) out.push(ch(r[i]))
                    } else {
                        out.push([{ a: Osk.layer === "symbols" ? "sym2" : "sym1", t: Osk.layer === "symbols" ? "=\\<" : "?123", w: 1.5, mod: true }].concat(ch(r[2])).concat([{ k: "Return", i: "keyboard_return", w: 1.8, enter: true }]))
                    }
                    out.push([
                        { a: "ctrl", t: "Ctrl", w: 1.2, mod: true },
                        { a: "alt", t: "Alt", w: 1.1, mod: true },
                        { a: Osk.layer === "letters" ? "sym1" : "abc", t: Osk.layer === "letters" ? "?123" : "ABC", w: 1.3, mod: true },
                        { a: "emoji", i: "mood", w: 1, mod: true }
                    ].concat(Osk.split
                        // split: a space bar on each side, under each thumb
                        ? [{ k: "space", t: Osk.lang.name, w: 2.4, space: true }, { k: "space", t: Osk.lang.name, w: 2.4, space: true }]
                        : [{ k: "space", t: Osk.lang.name, w: 5, space: true }]).concat([
                        { k: "Left", i: "chevron_left", w: 1, mod: true },
                        { k: "Up", i: "keyboard_arrow_up", w: 1, mod: true },
                        { k: "Down", i: "keyboard_arrow_down", w: 1, mod: true },
                        { k: "Right", i: "chevron_right", w: 1, mod: true }
                    ]))
                    return out
                }
                function act(s) {
                    if (s.c !== undefined) Osk.type(s.c)
                    else if (s.k !== undefined) Osk.key(s.k)
                    else if (s.a === "shift") Osk.tapShift()
                    else if (s.a === "ctrl") Osk.ctrl = !Osk.ctrl
                    else if (s.a === "alt") Osk.alt = !Osk.alt
                    else if (s.a === "sym1") Osk.layer = "symbols"
                    else if (s.a === "sym2") Osk.layer = "symbols2"
                    else if (s.a === "abc") Osk.layer = "letters"
                    else if (s.a === "emoji") { Osk.searching = false; Osk.tab = "emoji" }
                }
                function lit(s) {
                    return (s.a === "shift" && (Osk.shift || Osk.caps)) || (s.a === "ctrl" && Osk.ctrl) || (s.a === "alt" && Osk.alt)
                }

                Column {
                    anchors.fill: parent
                    spacing: 6
                    Repeater {
                        model: keysArea.rowsSpec
                        delegate: Item {
                            id: rowItem
                            required property var modelData
                            readonly property real units: modelData.reduce((a, s) => a + s.w, 0)
                            // split keyboard: a gap in the middle of every row, each half at its edge
                            readonly property real gapW: Osk.split ? width * 0.34 : 0
                            readonly property real unit: (width - (modelData.length - 1) * 6 - gapW) / Math.max(1, units)
                            // where the gap goes: before the first key that starts past half the row
                            readonly property int splitAt: {
                                // rows of letters: half the letters on each side (q w e r t | y u i o p)
                                const ci = []
                                for (let i = 0; i < modelData.length; i++) if (modelData[i].c !== undefined) ci.push(i)
                                if (ci.length >= 4) return ci[Math.ceil(ci.length / 2)]
                                let acc = 0
                                for (let i = 0; i < modelData.length; i++) { if (acc >= units / 2 - 0.01) return i; acc += modelData[i].w }
                                return modelData.length
                            }
                            // each key's x
                            readonly property var xs: {
                                const out = []
                                let x = 0
                                for (let i = 0; i < modelData.length; i++) {
                                    if (i === splitAt && gapW > 0) x += gapW
                                    out.push(x)
                                    x += unit * modelData[i].w + 6
                                }
                                return out
                            }
                            width: keysArea.width
                            height: (keysArea.height - (keysArea.rowsSpec.length - 1) * 6) / keysArea.rowsSpec.length
                            Item {
                                anchors.fill: parent
                                Repeater {
                                    model: rowItem.modelData
                                    delegate: Rectangle {
                                        id: key
                                        required property var modelData
                                        required property int index
                                        x: rowItem.xs[index] ?? 0
                                        Behavior on x { NumberAnimation { duration: 260; easing.type: Easing.OutCubic } }
                                        Behavior on width { NumberAnimation { duration: 260; easing.type: Easing.OutCubic } }
                                        readonly property bool lit: keysArea.lit(modelData)
                                        width: rowItem.unit * modelData.w + (modelData.w - 1) * 0
                                        height: rowItem.height
                                        radius: Math.min(12, height / 3)
                                        color: keyMa.pressed ? Theme.primary
                                             : modelData.enter ? Theme.primary
                                             : lit ? Theme.secondaryContainer
                                             : modelData.mod ? kb.modC : kb.keyC
                                        Behavior on color { ColorAnimation { duration: 70 } }
                                        SharpText {
                                            visible: !key.modelData.i
                                            anchors.centerIn: parent
                                            text: key.modelData.c !== undefined ? Osk.shown_(key.modelData.c) : (key.modelData.t || "")
                                            size: key.modelData.c !== undefined ? Math.min(22, key.height * 0.42) : 13
                                            color: keyMa.pressed || key.modelData.enter ? Theme.onPrimary : (key.lit ? Theme.onSecondaryContainer : (key.modelData.space ? Theme.subtext : Theme.text))
                                        }
                                        Icon {
                                            visible: !!key.modelData.i
                                            anchors.centerIn: parent
                                            name: key.modelData.a === "shift" && Osk.caps ? "keyboard_capslock_badge" : (key.modelData.i || "")
                                            size: Math.min(24, key.height * 0.45)
                                            color: keyMa.pressed || key.modelData.enter ? Theme.onPrimary : (key.lit ? Theme.onSecondaryContainer : Theme.text)
                                        }
                                        // the character, bigger, above the key while it is held
                                        Rectangle {
                                            visible: keyMa.pressed && key.modelData.c !== undefined
                                            width: key.width + 10; height: key.height * 1.2
                                            x: -5; y: -height - 4
                                            radius: 12; color: Theme.cardSolid
                                            border.width: 1; border.color: Theme.stroke
                                            SharpText { anchors.centerIn: parent; text: key.modelData.c !== undefined ? Osk.shown_(key.modelData.c) : ""; size: 26 }
                                        }
                                        MouseArea {
                                            id: keyMa
                                            anchors.fill: parent
                                            // characters and keys go on press (held: repeat); the switches (shift, ?123,
                                            // ABC, emoji, Ctrl, Alt) on release and just after it: they can rebuild
                                            // the keys, and a key taken away while it was held down left the
                                            // keyboard not taking clicks any more
                                            onPressed: {
                                                if (key.modelData.a !== undefined) return
                                                keysArea.act(key.modelData)
                                                if (key.modelData.k === "BackSpace" || key.modelData.k === "space" || key.modelData.c !== undefined) hold.start()
                                            }
                                            onReleased: {
                                                hold.stop(); rep.stop()
                                                if (key.modelData.a !== undefined && containsMouse) { const s = key.modelData; Qt.callLater(() => keysArea.act(s)) }
                                            }
                                            onCanceled: { hold.stop(); rep.stop() }
                                            // holding a key repeats it
                                            Timer { id: hold; interval: 450; onTriggered: rep.start() }
                                            Timer { id: rep; interval: 55; repeat: true; onTriggered: keysArea.act(key.modelData) }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // ---------- emoji ----------
            Item {
                visible: Osk.tab === "emoji" && !Osk.searching
                Layout.fillWidth: true; Layout.fillHeight: true
                // categories
                Row {
                    id: cats
                    width: parent.width; height: 36
                    spacing: 4
                    Repeater {
                        model: [{ i: "schedule", n: "Recently used", k: -1 }].concat(Osk.emojiData.map((c, j) => ({ i: c.icon, n: c.name, k: j })))
                        delegate: Rectangle {
                            required property var modelData
                            readonly property bool on: Osk.emojiCat === modelData.k && Osk.query === ""
                            width: 44; height: 34; radius: 17
                            color: on ? Theme.secondaryContainer : (cm.containsMouse ? Theme.hover : "transparent")
                            Icon { anchors.centerIn: parent; name: parent.modelData.i; size: 20; color: parent.on ? Theme.onSecondaryContainer : Theme.subtext }
                            MouseArea { id: cm; anchors.fill: parent; hoverEnabled: true; onClicked: { Osk.query = ""; Osk.emojiCat = parent.modelData.k } }
                            HoverTip { hovered: cm.containsMouse; text: parent.modelData.n }
                        }
                    }
                }
                GridView {
                    id: eg
                    anchors { top: cats.bottom; topMargin: 6; left: parent.left; right: parent.right; bottom: parent.bottom }
                    clip: true
                    cellWidth: Math.max(44, width / Math.max(1, Math.floor(width / 50)))
                    cellHeight: 46
                    model: Osk.emojiShown
                    boundsBehavior: Flickable.StopAtBounds
                    delegate: Rectangle {
                        required property string modelData
                        width: eg.cellWidth - 4; height: eg.cellHeight - 4
                        radius: 12
                        color: em.pressed ? Theme.secondaryContainer : (em.containsMouse ? Theme.hover : "transparent")
                        SharpText { anchors.centerIn: parent; text: parent.modelData; size: 26; font.family: "Noto Color Emoji" }
                        MouseArea { id: em; anchors.fill: parent; hoverEnabled: true; onClicked: Osk.typeText(parent.modelData) }
                    }
                    DText {
                        anchors.centerIn: parent
                        visible: eg.count === 0
                        text: Osk.query !== "" ? "No emoji called “" + Osk.query + "”" : (Osk.emojiCat < 0 ? "Emoji you use show up here" : "")
                        color: Theme.subtext
                    }
                }
            }

            // ---------- GIFs ----------
            Item {
                id: gifArea
                visible: Osk.tab === "gif" && !Osk.searching
                Layout.fillWidth: true; Layout.fillHeight: true
                property var menuGif: null
                property real menuX: 0
                property real menuY: 0

                Column {   // no API key yet
                    visible: !Osk.hasKey
                    anchors.centerIn: parent
                    width: Math.min(parent.width - 40, 520)
                    spacing: 12
                    DText { width: parent.width; horizontalAlignment: Text.AlignHCenter; wrapMode: Text.WordWrap; font.pixelSize: 15; text: "GIFs come from GIPHY, which needs a free API key" }
                    DText { width: parent.width; horizontalAlignment: Text.AlignHCenter; wrapMode: Text.WordWrap; color: Theme.subtext; font.pixelSize: 12
                        text: "Make one at developers.giphy.com (Create an app, API), then paste it in Settings > Panels > On-screen keyboard." }
                    Row {
                        anchors.horizontalCenter: parent.horizontalCenter
                        spacing: 8
                        ArqButton { text: "Get a key"; onClicked: Quickshell.execDetached(["xdg-open", "https://developers.giphy.com/dashboard/?create=true"]) }
                        ArqButton { text: "Settings"; primary: true; onClicked: Ui.openSettings("input") }
                    }
                }
                GridView {
                    id: gg
                    visible: Osk.hasKey
                    anchors { fill: parent; bottomMargin: 18 }
                    clip: true
                    readonly property int perRow: Math.max(2, Math.floor(width / 170))
                    cellWidth: width / perRow
                    cellHeight: 112
                    model: Osk.gifs
                    boundsBehavior: Flickable.StopAtBounds
                    delegate: Item {
                        id: gi
                        required property var modelData
                        width: gg.cellWidth; height: gg.cellHeight
                        Rectangle {
                            anchors { fill: parent; margins: 3 }
                            radius: 12
                            color: Theme.tile
                            clip: true
                            AnimatedImage {
                                anchors.fill: parent
                                source: gi.modelData.small
                                fillMode: Image.PreserveAspectCrop
                                playing: gg.visible && kb.visible
                                asynchronous: true
                                cache: true
                            }
                            Rectangle { anchors.fill: parent; radius: 12; color: "transparent"; border.width: gm.containsMouse ? 2 : 0; border.color: Theme.primary }
                        }
                        MouseArea {
                            id: gm
                            anchors.fill: parent
                            hoverEnabled: true
                            acceptedButtons: Qt.LeftButton | Qt.RightButton
                            cursorShape: Qt.PointingHandCursor
                            onClicked: mouse => {
                                if (mouse.button === Qt.RightButton) {
                                    const p = gm.mapToItem(gifArea, mouse.x, mouse.y)
                                    gifArea.menuX = p.x; gifArea.menuY = p.y; gifArea.menuGif = gi.modelData
                                } else Osk.gifInsert(gi.modelData)
                            }
                        }
                    }
                    DText {
                        anchors.centerIn: parent
                        visible: gg.count === 0
                        text: Osk.gifBusy ? "Loading…" : (Osk.gifError !== "" ? Osk.gifError : "Nothing found")
                        color: Theme.subtext
                    }
                }
                DText {   // GIPHY asks for this
                    visible: Osk.hasKey
                    anchors { bottom: parent.bottom; right: parent.right }
                    text: "Powered by GIPHY  ·  click: insert  ·  right-click: download, copy"
                    font.pixelSize: 10; color: Theme.subtext
                }
                // right-click menu
                MouseArea { visible: gifArea.menuGif !== null; anchors.fill: parent; z: 9; onClicked: gifArea.menuGif = null }
                Rectangle {
                    visible: gifArea.menuGif !== null
                    z: 10
                    width: 190; height: menuCol.implicitHeight + 12
                    x: Math.min(gifArea.menuX, gifArea.width - width)
                    y: Math.min(gifArea.menuY, gifArea.height - height)
                    radius: 14; color: Theme.cardSolid
                    border.width: 1; border.color: Theme.stroke
                    Column {
                        id: menuCol
                        anchors { left: parent.left; right: parent.right; top: parent.top; margins: 6 }
                        Repeater {
                            model: [{ t: "Download", i: "download", f: "dl" }, { t: "Copy GIF", i: "content_copy", f: "copy" }, { t: "Copy link", i: "link", f: "link" }]
                            delegate: Rectangle {
                                required property var modelData
                                width: menuCol.width; height: 38; radius: 10
                                color: mm.containsMouse ? Theme.hover : "transparent"
                                Row {
                                    anchors { left: parent.left; leftMargin: 10; verticalCenter: parent.verticalCenter }
                                    spacing: 10
                                    Icon { name: parent.parent.modelData.i; size: 18; anchors.verticalCenter: parent.verticalCenter }
                                    DText { text: parent.parent.modelData.t; font.pixelSize: 13; anchors.verticalCenter: parent.verticalCenter }
                                }
                                MouseArea {
                                    id: mm
                                    anchors.fill: parent; hoverEnabled: true
                                    onClicked: {
                                        const g = gifArea.menuGif
                                        const f = parent.modelData.f
                                        if (f === "dl") Osk.gifDownload(g)
                                        else if (f === "copy") Osk.gifCopy(g)
                                        else Osk.gifLink(g)
                                        gifArea.menuGif = null
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
}
