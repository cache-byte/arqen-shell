import Quickshell
import Quickshell.Io
import QtQuick
import QtQuick.Layouts
import qs.config
import qs.components
import qs.services

// Clipboard history (shown in ClipboardPopup, opened from its panel button). Click an entry to
// copy it again (it closes the popup so you can paste straight away), the x removes it.
Rectangle {
    id: p
    property string query: ""
    property bool framed: true            // false = no card of its own (it sits inside a popup)
    function reset() { query = ""; search.text = ""; list.positionViewAtBeginning() }
    function focusSearch() { search.focusInput() }
    readonly property var shown: {
        const q = query.trim().toLowerCase()
        const all = Clipboard.entries
        return q === "" ? all : all.filter(e => !e.image && e.text.toLowerCase().indexOf(q) >= 0)
    }

    radius: Theme.radius
    color: framed ? Theme.panel : "transparent"
    border.color: Theme.stroke
    border.width: framed ? 1 : 0
    MouseArea { anchors.fill: parent }   // swallow clicks inside the card

    ColumnLayout {
        anchors { fill: parent; margins: 18 }
        spacing: 12

        RowLayout {
            Layout.fillWidth: true
            spacing: 8
            Icon { name: "content_paste"; size: 24 }
            DText { text: "Clipboard"; font.pixelSize: 20; font.weight: Font.Medium }
            DText { visible: Clipboard.entries.length > 0; text: Clipboard.entries.length; color: Theme.subtext; font.pixelSize: 13 }
            Item { Layout.fillWidth: true }
            ArqButton { visible: Clipboard.entries.length > 0; text: "Clear"; onClicked: Clipboard.wipe() }
        }

        ArqField {
            id: search
            Layout.fillWidth: true
            placeholder: "Search clipboard"
            iconName: "search"
            onEdited: p.query = search.text
        }

        ListView {
            id: list
            Layout.fillWidth: true
            Layout.fillHeight: true
            clip: true
            spacing: 8
            boundsBehavior: Flickable.StopAtBounds
            model: p.shown

            delegate: Rectangle {
                id: e
                required property var modelData
                property bool ready: false
                width: list.width
                height: modelData.image ? 124 : Math.max(52, txt.implicitHeight + 26)
                radius: 18
                color: ema.containsMouse ? Theme.hover : Theme.tile

                // pictures are decoded to a temp file once, then shown from there
                Process {
                    id: dec
                    // a small PNG preview, whatever the picture's format (WebP, AVIF, BMP, SVG ...): decodes faster and
                    // always shows; without ImageMagick the picture is used as it is
                    command: ["sh", "-c", "d=" + Clipboard.cache + "; id=" + e.modelData.id + "; f=\"$d/$id.png\"; [ -s \"$f\" ] && exit 0; "
                        + "cliphist decode $id > \"$d/$id.raw\" || exit 1; "
                        + "if command -v magick >/dev/null 2>&1; then magick \"$d/$id.raw\"[0] -thumbnail 640x320\\> \"png:$f\" 2>/dev/null; "
                        + "elif command -v convert >/dev/null 2>&1; then convert \"$d/$id.raw\"[0] -thumbnail 640x320\\> \"png:$f\" 2>/dev/null; fi; "
                        + "[ -s \"$f\" ] || mv \"$d/$id.raw\" \"$f\"; rm -f \"$d/$id.raw\""]
                    onExited: e.ready = true
                }
                Component.onCompleted: if (modelData.image) dec.running = true

                DText {
                    id: txt
                    visible: !e.modelData.image
                    anchors { left: parent.left; right: parent.right; top: parent.top; margins: 13; rightMargin: 38 }
                    text: e.modelData.text
                    font.pixelSize: 13
                    wrapMode: Text.WrapAnywhere
                    maximumLineCount: 3
                    elide: Text.ElideRight
                }
                Image {
                    id: pic
                    visible: e.modelData.image && status !== Image.Error
                    anchors { fill: parent; margins: 8; rightMargin: 38 }
                    source: e.ready ? "file://" + Clipboard.cache + "/" + e.modelData.id + ".png" : ""
                    fillMode: Image.PreserveAspectFit
                    horizontalAlignment: Image.AlignLeft
                    asynchronous: true
                    cache: false
                }
                // a picture that cannot be shown: say what it is instead
                Row {
                    visible: e.modelData.image && pic.status === Image.Error
                    anchors { left: parent.left; leftMargin: 14; verticalCenter: parent.verticalCenter }
                    spacing: 10
                    Icon { name: "image"; size: 28; color: Theme.subtext; anchors.verticalCenter: parent.verticalCenter }
                    DText { text: "Picture (no preview)"; color: Theme.subtext; font.pixelSize: 13; anchors.verticalCenter: parent.verticalCenter }
                }
                MouseArea {
                    id: ema
                    anchors.fill: parent
                    hoverEnabled: true
                    cursorShape: Qt.PointingHandCursor
                    onClicked: { Ui.close(); Clipboard.paste(e.modelData.id) }
                }
                TrayButton {
                    anchors { top: parent.top; right: parent.right; margins: 6 }
                    icon: "close"; size: 16; tip: "Delete\nRemove it from the history"; tipSide: "left"
                    onClicked: Clipboard.remove(e.modelData.id)
                }
                TrayButton {
                    anchors { bottom: parent.bottom; right: parent.right; margins: 6 }
                    icon: "content_copy"; size: 16; tip: "Copy only\nPut it on the clipboard, paste it yourself"; tipSide: "left"
                    onClicked: { Clipboard.copy(e.modelData.id); Ui.close() }
                }
            }

            DText {
                visible: list.count === 0
                anchors.centerIn: parent
                width: parent.width - 20
                horizontalAlignment: Text.AlignHCenter
                wrapMode: Text.WordWrap
                color: Theme.subtext
                text: p.query !== "" ? "Nothing matches" : "Nothing copied yet. Needs cliphist and wl-clipboard."
            }
        }
    }
}
