import Quickshell
import QtQuick
import qs.config
import qs.components
import qs.services

// The clock pop-up: a calendar with your events, reminders, alarms, timers with a stopwatch, and
// the time in other places. Everything is kept by services/Clocks.qml (which also rings them).
Item {
    id: p
    property int tab: 0
    readonly property var tabs: [["calendar_month", "Calendar"], ["notifications", "Reminders"], ["alarm", "Alarms"], ["timer", "Timers"], ["public", "World"]]
    readonly property date nowD: new Date(Clocks.now)

    function reset() {
        tab = 0
        cal.offset = 0
        cal.selKey = Clocks.dayKey(new Date())
        cal.msg = ""
    }
    function focusFirst() {
        if (tab === 0) calTitle.focusInput()
    }
    onTabChanged: if (tab === 4) { Clocks.loadZoneList(); Clocks.refreshZones() }

    // ---- top: the time, the date, the tabs
    Item {
        id: head
        x: 18; y: 14; width: p.width - 36; height: 48
        DText {
            id: bigT
            anchors.verticalCenter: parent.verticalCenter
            text: Qt.formatDateTime(p.nowD, Config.c.clock24 ? "HH:mm" : "h:mm AP")
            font.pixelSize: 32; font.weight: Font.DemiBold
        }
        // the time in an added place, small, beside the time here; click or swipe to see the next one
        Rectangle {
            id: zc
            readonly property var zs: Clocks.zones
            readonly property int n: zs.length
            readonly property int idx: n > 0 ? Math.min(Clocks.zoneIdx, n - 1) : 0
            readonly property string zid: n > 0 ? zs[idx] : ""
            readonly property date zd: Clocks.zoneDate(zid)
            property real slide: 0
            function step(dir) {
                if (n < 2) return
                Clocks.zoneIdx = ((idx + dir) % n + n) % n
                slideAnim.stop(); slide = dir * 22; slideAnim.start()
            }
            visible: n > 0
            x: bigT.x + bigT.width + 14
            anchors.verticalCenter: parent.verticalCenter
            width: Math.min(150, head.width - bigT.width - 14 - dateCol.width - 12)
            height: 42; radius: 16
            color: zma.containsMouse ? Theme.hover : Theme.tile
            clip: true
            Behavior on color { ColorAnimation { duration: 120 } }
            scale: zma.pressed ? 0.94 : 1
            Behavior on scale { NumberAnimation { duration: 260; easing.type: Easing.OutBack; easing.overshoot: Motion.os(2.4) } }
            NumberAnimation { id: slideAnim; target: zc; property: "slide"; to: 0; duration: 320; easing.type: Easing.OutBack; easing.overshoot: Motion.os(1.6) }
            Item {
                x: zc.slide; width: parent.width; height: parent.height
                opacity: 1 - Math.min(1, Math.abs(zc.slide) / 30)
                DText {
                    x: 12; y: 5; width: parent.width - 24
                    text: Clocks.cityOf(zc.zid) + (Clocks.zoneDayText(zc.zid) !== "Today" ? " · " + Clocks.zoneDayText(zc.zid).replace("Tomorrow", "+1d").replace("Yesterday", "-1d") : "")
                    elide: Text.ElideRight; color: Theme.subtext; font.pixelSize: 11
                }
                DText {
                    x: 12; y: 20
                    text: Clocks.zoneOff[zc.zid] !== undefined ? Clocks.fmtClock(zc.zd.getHours(), zc.zd.getMinutes()) : "…"
                    font.pixelSize: 16; font.weight: Font.DemiBold
                }
            }
            // which of several (dots)
            Row {
                visible: zc.n > 1
                anchors.right: parent.right; anchors.rightMargin: 9; y: parent.height - 11
                spacing: 3
                Repeater {
                    model: zc.n > 1 ? Math.min(zc.n, 6) : 0
                    delegate: Rectangle { required property int index; width: index === zc.idx ? 8 : 4; height: 4; radius: 2; color: index === zc.idx ? Theme.primary : Theme.subtext; opacity: index === zc.idx ? 1 : 0.5
                                          Behavior on width { NumberAnimation { duration: 200; easing.type: Easing.OutBack } } }
                }
            }
            MouseArea {
                id: zma
                anchors.fill: parent; hoverEnabled: true; cursorShape: zc.n > 1 ? Qt.PointingHandCursor : Qt.ArrowCursor
                property real px: 0
                onPressed: mouse => px = mouse.x
                onReleased: mouse => {
                    const dx = mouse.x - px
                    if (Math.abs(dx) > 18) zc.step(dx < 0 ? 1 : -1)
                    else zc.step(1)
                }
            }
        }
        DText {
            id: dateCol
            anchors.right: parent.right; anchors.verticalCenter: parent.verticalCenter
            horizontalAlignment: Text.AlignRight
            text: Qt.formatDate(p.nowD, "dddd") + "\n" + Qt.formatDate(p.nowD, "d MMMM yyyy")
            color: Theme.subtext; font.pixelSize: 13
        }
    }
    // the tabs: one pill that slides to the chosen tab, which shows its name; the others are icons
    Rectangle {
        id: tabRow
        x: 18; y: head.y + head.height + 10
        width: p.width - 36; height: 48; radius: 24
        color: Theme.tile
        readonly property real selW: 128
        readonly property real otherW: (width - 8 - selW) / 4
        function xOf(i) { return 4 + i * otherW + (i > p.tab ? selW - otherW : 0) }
        Rectangle {
            id: selPill
            y: 4; height: parent.height - 8; radius: height / 2
            x: tabRow.xOf(p.tab); width: tabRow.selW
            color: Theme.tileOn
            Behavior on x { NumberAnimation { duration: 340; easing.type: Easing.OutBack; easing.overshoot: Motion.os(1.3) } }
        }
        Repeater {
            model: p.tabs
            delegate: Item {
                id: tb
                required property var modelData
                required property int index
                readonly property bool on: p.tab === index
                x: tabRow.xOf(index); y: 4
                width: on ? tabRow.selW : tabRow.otherW; height: tabRow.height - 8
                Behavior on x { NumberAnimation { duration: 340; easing.type: Easing.OutBack; easing.overshoot: Motion.os(1.3) } }
                Behavior on width { NumberAnimation { duration: 340; easing.type: Easing.OutBack; easing.overshoot: Motion.os(1.3) } }
                scale: tma.pressed ? 0.9 : 1
                Behavior on scale { NumberAnimation { duration: 240; easing.type: Easing.OutBack; easing.overshoot: Motion.os(2.2) } }
                Row {
                    anchors.centerIn: parent
                    spacing: 6
                    Item {
                        width: 22; height: 22; anchors.verticalCenter: parent.verticalCenter
                        Icon { anchors.centerIn: parent; name: tb.modelData[0]; size: 22; color: tb.on ? Theme.onSecondaryContainer : (tma.containsMouse ? Theme.text : Theme.subtext)
                               Behavior on color { ColorAnimation { duration: 140 } } }
                        // a dot while something here is waiting to ring
                        Rectangle {
                            visible: (tb.index === 2 && Clocks.alarms.some(a => a.on)) || (tb.index === 3 && (Clocks.timers.some(t => t.running) || Clocks.sw.running))
                            x: parent.width - 6; y: -2; width: 9; height: 9; radius: 5; color: Theme.primary
                            border.width: 2; border.color: tb.on ? Theme.tileOn : Theme.tile
                        }
                    }
                    DText {
                        anchors.verticalCenter: parent.verticalCenter
                        visible: opacity > 0.05
                        opacity: tb.on ? 1 : 0
                        Behavior on opacity { NumberAnimation { duration: 200 } }
                        text: tb.modelData[1]; font.pixelSize: 13; font.weight: Font.DemiBold
                        color: Theme.onSecondaryContainer
                    }
                }
                MouseArea { id: tma; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: p.tab = tb.index }
            }
        }
    }
    readonly property real pageX: 18
    readonly property real pageY: tabRow.y + tabRow.height + 12
    readonly property real pageW: p.width - 36
    readonly property real pageH: p.height - pageY - 14

    // ================= Calendar
    Item {
        id: cal
        visible: opacity > 0.01
        opacity: p.tab === 0 ? 1 : 0
        Behavior on opacity { NumberAnimation { duration: 200 } }
        x: p.pageX; y: p.pageY; width: p.pageW; height: p.pageH
        property int offset: 0
        property string selKey: Clocks.dayKey(new Date())
        property string msg: ""
        readonly property date shownMonth: new Date(p.nowD.getFullYear(), p.nowD.getMonth() + offset, 1)
        readonly property int first: 1          // weeks start on Monday, like the desktop calendar
        readonly property real cellW: (width - 24) / 7
        readonly property real cellH: 34
        readonly property var days: {
            const m = shownMonth
            const lead = (m.getDay() - first + 7) % 7
            const out = []
            for (let i = 0; i < 42; i++) out.push(new Date(m.getFullYear(), m.getMonth(), 1 - lead + i))
            return out
        }
        // how many things each day has (a dot under the number)
        readonly property var marks: {
            const m = {}
            for (const e of Clocks.events) m[e.date] = (m[e.date] || 0) + 1
            for (const r of Clocks.reminders) { const k = Clocks.dayKey(new Date(r.at)); m[k] = (m[k] || 0) + 1 }
            return m
        }
        readonly property var dayItems: {
            const out = []
            for (const e of Clocks.eventsOn(selKey)) out.push({ kind: "event", id: e.id, title: e.title, sub: e.time })
            for (const r of Clocks.reminders) {
                const d = new Date(r.at)
                if (Clocks.dayKey(d) === selKey) out.push({ kind: "reminder", id: r.id, title: r.title, sub: Clocks.fmtClock(d.getHours(), d.getMinutes()) })
            }
            return out
        }
        readonly property date selDate: { const q = selKey.split("-"); return new Date(parseInt(q[0]), parseInt(q[1]) - 1, parseInt(q[2])) }

        function add() {
            const t = calTime.text.trim()
            let tm = ""
            if (t !== "") {
                const c = Clocks.parseClock(t)
                if (!c) { msg = "Time like 14:30 or 7pm"; return }
                tm = Clocks.pad(c.h) + ":" + Clocks.pad(c.m)
            }
            if (calTitle.text.trim() === "") { msg = "Give it a name"; return }
            msg = ""
            Clocks.addEvent(calTitle.text, selKey, tm)
            calTitle.text = ""; calTime.text = ""
            calTitle.focusInput()
        }

        // the month sits on a card
        Rectangle {
            id: monthCard
            width: parent.width; height: 66 + 6 * cal.cellH + 10
            radius: 24; color: Theme.tile
        }
        // what is on the chosen day, on a card of its own
        Rectangle {
            id: dayCard
            y: monthCard.height + 8
            width: parent.width; height: Math.max(0, addRow.y - 8 - y)
            radius: 22; color: Theme.tile
        }
        Item {
            id: calHead
            x: 12; y: 8
            width: parent.width - 24; height: 34
            DText {
                anchors.verticalCenter: parent.verticalCenter
                text: Qt.formatDate(cal.shownMonth, "MMMM yyyy")
                font.pixelSize: 17; font.weight: Font.DemiBold
                color: cal.offset === 0 ? Theme.text : Theme.primary
                MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor; onClicked: { cal.offset = 0; cal.selKey = Clocks.dayKey(new Date()) } }
            }
            Row {
                anchors.right: parent.right; anchors.verticalCenter: parent.verticalCenter
                Repeater {
                    model: [["chevron_left", -1], ["chevron_right", 1]]
                    delegate: Item {
                        id: chv
                        required property var modelData
                        width: 34; height: 34
                        scale: chMa.pressed ? 0.85 : (chMa.containsMouse ? 1.12 : 1)
                        Behavior on scale { NumberAnimation { duration: 240; easing.type: Easing.OutBack; easing.overshoot: Motion.os(2.5) } }
                        Icon { anchors.centerIn: parent; name: chv.modelData[0]; size: 24; color: chMa.containsMouse ? Theme.primary : Theme.text }
                        MouseArea { id: chMa; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: cal.offset += chv.modelData[1] }
                    }
                }
            }
        }
        Row {
            id: wk
            x: 12; y: 46
            Repeater {
                model: 7
                delegate: DText {
                    required property int index
                    width: cal.cellW; height: 18
                    horizontalAlignment: Text.AlignHCenter
                    text: Qt.locale().dayName((cal.first + index) % 7, Locale.NarrowFormat).substring(0, 1).toUpperCase()
                    color: Theme.subtext; font.pixelSize: 12; font.weight: Font.Medium
                }
            }
        }
        Grid {
            id: grid
            x: 12; y: 66
            columns: 7
            WheelHandler { onWheel: ev => cal.offset += ev.angleDelta.y > 0 ? -1 : 1 }
            Repeater {
                model: cal.days
                delegate: Item {
                    id: cell
                    required property var modelData
                    readonly property bool inMonth: modelData.getMonth() === cal.shownMonth.getMonth()
                    readonly property string key: Clocks.dayKey(modelData)
                    readonly property bool isToday: key === Clocks.dayKey(p.nowD)
                    readonly property bool isSel: key === cal.selKey
                    width: cal.cellW; height: cal.cellH
                    readonly property bool weekend: modelData.getDay() === 0 || modelData.getDay() === 6
                    // the chosen day: a soft round tile
                    Rectangle {
                        anchors.centerIn: parent
                        width: 32; height: 32; radius: 16
                        color: cell.isSel ? Theme.tileOn : (cma.containsMouse ? Theme.hover : "transparent")
                        scale: cell.isSel ? 1 : 0.85
                        Behavior on scale { NumberAnimation { duration: 260; easing.type: Easing.OutBack; easing.overshoot: Motion.os(2.2) } }
                        Behavior on color { ColorAnimation { duration: 120 } }
                    }
                    // today: the accent bar under the number, as on the desktop calendar
                    Rectangle {
                        visible: cell.isToday
                        x: (parent.width - width) / 2; y: parent.height - 6
                        width: parent.width * 0.5; height: 3; radius: 1.5; color: Theme.primary
                    }
                    DText {
                        anchors.centerIn: parent
                        anchors.verticalCenterOffset: -2
                        text: cell.modelData.getDate()
                        font.pixelSize: 14
                        font.weight: cell.isToday ? Font.Bold : Font.Normal
                        color: cell.weekend ? Theme.primary : Theme.text
                        opacity: cell.inMonth ? 1 : 0.3
                    }
                    // something on this day: a small dot at the corner
                    Rectangle {
                        visible: (cal.marks[cell.key] || 0) > 0
                        x: parent.width / 2 + 8; y: 3
                        width: 6; height: 6; radius: 3
                        color: Theme.tertiary
                        opacity: cell.inMonth ? 1 : 0.4
                    }
                    MouseArea {
                        id: cma
                        anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor
                        onClicked: {
                            cal.selKey = cell.key
                            if (!cell.inMonth) cal.offset += cell.modelData < cal.shownMonth ? -1 : 1
                        }
                    }
                }
            }
        }
        Item {
            id: dayHead
            x: 14; y: dayCard.y + 8
            width: parent.width - 28; height: 24
            DText {
                anchors.verticalCenter: parent.verticalCenter
                text: Qt.formatDate(cal.selDate, "dddd d MMMM")
                font.pixelSize: 14; font.weight: Font.DemiBold
            }
            DText {
                anchors.right: parent.right; anchors.verticalCenter: parent.verticalCenter
                visible: cal.msg !== ""
                text: cal.msg; color: "#FF6B6B"; font.pixelSize: 12
            }
        }
        Item {
            id: addRow
            anchors.bottom: parent.bottom
            width: parent.width; height: 46
            ArqField {
                id: calTitle
                width: parent.width - calTime.width - addBtn.width - 16
                placeholder: "Add an event"
                iconName: "event"
                closesOnEscape: true
                onAccepted: cal.add()
                onEdited: cal.msg = ""
            }
            ArqField {
                id: calTime
                x: calTitle.width + 8
                width: 96
                placeholder: "Time"
                onAccepted: cal.add()
                onEdited: cal.msg = ""
            }
            ArqButton {
                id: addBtn
                x: parent.width - width
                anchors.verticalCenter: parent.verticalCenter
                icon: "add"; size: "M"; primary: true
                onClicked: cal.add()
            }
        }
        Flickable {
            id: dayList
            x: 8; y: dayHead.y + dayHead.height + 4
            width: parent.width - 16
            height: Math.max(0, dayCard.y + dayCard.height - 8 - y)
            clip: true
            contentHeight: dayCol.implicitHeight
            boundsBehavior: Flickable.StopAtBounds
            Column {
                visible: cal.dayItems.length === 0
                anchors.horizontalCenter: parent.horizontalCenter
                y: Math.max(0, (dayList.height - height) / 2 - 4)
                spacing: 4
                Icon { anchors.horizontalCenter: parent.horizontalCenter; name: "event_available"; size: 26; color: Theme.subtext; opacity: 0.6 }
                DText { text: "Nothing on this day"; color: Theme.subtext; font.pixelSize: 13 }
            }
            Column {
                id: dayCol
                width: dayList.width
                spacing: 6
                Repeater {
                    model: cal.dayItems
                    delegate: Rectangle {
                        id: dr
                        required property var modelData
                        width: dayCol.width; height: 40; radius: 14
                        color: Theme.card
                        Icon { x: 12; anchors.verticalCenter: parent.verticalCenter; name: dr.modelData.kind === "event" ? "event" : "notifications"; size: 18; color: Theme.primary }
                        DText {
                            id: drTime
                            x: 38; anchors.verticalCenter: parent.verticalCenter
                            text: dr.modelData.sub !== "" ? dr.modelData.sub : "All day"
                            color: Theme.subtext; font.pixelSize: 12
                            width: 58
                        }
                        DText {
                            x: 98; anchors.verticalCenter: parent.verticalCenter
                            width: parent.width - 98 - 44
                            text: dr.modelData.title; elide: Text.ElideRight; font.pixelSize: 14
                        }
                        ArqButton {
                            x: parent.width - width - 4; anchors.verticalCenter: parent.verticalCenter
                            icon: "close"
                            onClicked: dr.modelData.kind === "event" ? Clocks.delEvent(dr.modelData.id) : Clocks.delReminder(dr.modelData.id)
                        }
                    }
                }
            }
        }
    }

    // ================= Reminders (a list; + opens a page with number wheels for the time)
    Item {
        id: remPage
        visible: opacity > 0.01
        opacity: p.tab === 1 ? 1 : 0
        Behavior on opacity { NumberAnimation { duration: 200 } }
        x: p.pageX; y: p.pageY; width: p.pageW; height: p.pageH
        property bool editing: false
        property string editId: ""
        property int rh: 9
        property int rm: 0
        property int rday: 0                // 0 = today ... 6
        property string err: ""
        readonly property var dayList: {
            const out = [], t = new Date(Clocks.now)
            for (let i = 0; i < 7; i++) {
                const d = new Date(t.getFullYear(), t.getMonth(), t.getDate() + i)
                out.push({ i: i, date: d, label: i === 0 ? "Today" : i === 1 ? "Tomorrow" : Qt.formatDate(d, "ddd d") })
            }
            return out
        }
        readonly property double atMs: {
            // (computed from the day number itself: no lookup that can come back empty while the page is made)
            const t = new Date(Clocks.now)
            const d = new Date(t.getFullYear(), t.getMonth(), t.getDate() + Math.max(0, Math.min(6, rday || 0)))
            return new Date(d.getFullYear(), d.getMonth(), d.getDate(), rh, rm, 0, 0).getTime()
        }
        function openNew() {
            const t = new Date()
            editId = ""; rh = (t.getHours() + 1) % 24; rm = 0; rday = (t.getHours() + 1) >= 24 ? 1 : 0; err = ""
            remTitle.text = ""; editing = true; remTitle.focusInput()
        }
        function openReminder(r) {
            const d = new Date(r.at), t = new Date()
            const diff = Math.round((new Date(d.getFullYear(), d.getMonth(), d.getDate()) - new Date(t.getFullYear(), t.getMonth(), t.getDate())) / 86400000)
            editId = r.id; rh = d.getHours(); rm = d.getMinutes(); rday = Math.max(0, Math.min(6, diff)); err = ""
            remTitle.text = r.title; editing = true
        }
        function save() {
            if (remTitle.text.trim() === "") { err = "Say what to remind you of"; return }
            if (atMs <= Date.now()) { err = "That time has already passed. Pick a later time or day"; return }
            if (editId === "") Clocks.addReminder(remTitle.text, atMs); else Clocks.updateReminder(editId, remTitle.text, atMs)
            editing = false
        }

        // ---- the list
        Item {
            anchors.fill: parent
            opacity: remPage.editing ? 0 : 1
            visible: opacity > 0.01
            transform: Translate { x: remPage.editing ? -40 : 0; Behavior on x { NumberAnimation { duration: 260; easing.type: Easing.OutCubic } } }
            Behavior on opacity { NumberAnimation { duration: 200 } }
            Item {
                id: remTop
                width: parent.width; height: 48
                DText { x: 4; anchors.verticalCenter: parent.verticalCenter; text: "Reminders"; font.pixelSize: 18; font.weight: Font.DemiBold }
                ArqButton { anchors.right: parent.right; anchors.verticalCenter: parent.verticalCenter; icon: "add"; text: "New"; primary: true; onClicked: remPage.openNew() }
            }
            Flickable {
                y: remTop.height + 6
                width: parent.width; height: parent.height - y
                clip: true
                contentHeight: remCol.implicitHeight
                boundsBehavior: Flickable.StopAtBounds
                Column {
                    id: remCol
                    width: parent.width
                    spacing: 8
                    EmptyState { visible: Clocks.reminders.length === 0; width: remCol.width; height: 160; icon: "notifications_off"; text: "No reminders. Press New to add one" }
                    Repeater {
                        model: Clocks.reminders.slice().sort((a, b) => (a.fired - b.fired) || (a.at - b.at))
                        delegate: Rectangle {
                            id: rr
                            required property var modelData
                            width: remCol.width; height: 60; radius: 18
                            color: Theme.tile
                            opacity: modelData.fired ? 0.55 : 1
                            scale: rrMa.pressed ? 0.98 : 1
                            Behavior on scale { NumberAnimation { duration: 220; easing.type: Easing.OutBack; easing.overshoot: Motion.os(2) } }
                            MouseArea { id: rrMa; anchors.fill: parent; cursorShape: modelData.fired ? Qt.ArrowCursor : Qt.PointingHandCursor; onClicked: if (!rr.modelData.fired) remPage.openReminder(rr.modelData) }
                            Rectangle { x: 12; anchors.verticalCenter: parent.verticalCenter; width: 38; height: 38; radius: 19; color: Theme.tileOn
                                Icon { anchors.centerIn: parent; name: rr.modelData.fired ? "check" : "notifications_active"; size: 20; color: Theme.onSecondaryContainer } }
                            Column {
                                x: 62; anchors.verticalCenter: parent.verticalCenter
                                width: parent.width - 62 - 52
                                DText { width: parent.width; text: rr.modelData.title; elide: Text.ElideRight; font.pixelSize: 14; font.weight: Font.Medium }
                                DText { text: Clocks.fmtWhen(rr.modelData.at); color: Theme.subtext; font.pixelSize: 12 }
                            }
                            ArqButton { x: parent.width - width - 8; anchors.verticalCenter: parent.verticalCenter; icon: "close"; onClicked: Clocks.delReminder(rr.modelData.id) }
                        }
                    }
                    ArqButton { visible: Clocks.reminders.some(r => r.fired); text: "Clear finished"; icon: "done_all"; onClicked: Clocks.clearDoneReminders() }
                }
            }
        }

        // ---- new / change
        Flickable {
            id: remEdit
            anchors.fill: parent
            opacity: remPage.editing ? 1 : 0
            visible: opacity > 0.01
            clip: true
            contentHeight: remEditCol.implicitHeight + 8
            boundsBehavior: Flickable.StopAtBounds
            transform: Translate { x: remPage.editing ? 0 : 40; Behavior on x { NumberAnimation { duration: 260; easing.type: Easing.OutCubic } } }
            Behavior on opacity { NumberAnimation { duration: 200 } }
            Column {
                id: remEditCol
                width: remEdit.width
                spacing: 12
                DText { text: remPage.editId === "" ? "New reminder" : "Change reminder"; font.pixelSize: 18; font.weight: Font.DemiBold; x: 4 }
                ArqField { id: remTitle; width: parent.width; placeholder: "Remind me to…"; iconName: "notifications"; onAccepted: remPage.save(); onEdited: remPage.err = ""; closesOnEscape: false; onEscaped: remPage.editing = false }
                DText { text: "At what time"; color: Theme.subtext; font.pixelSize: 12; x: 4 }
                WheelCard {
                    width: parent.width
                    counts: [24, 60]; units: ["hr", "min"]
                    values: [remPage.rh, remPage.rm]
                    onMoved: (i, v) => { if (i === 0) remPage.rh = v; else remPage.rm = v; remPage.err = "" }
                }
                DText { text: "On which day"; color: Theme.subtext; font.pixelSize: 12; x: 4 }
                Flow {
                    width: parent.width; spacing: 6
                    Repeater {
                        model: remPage.dayList
                        delegate: ArqButton { required property var modelData; text: modelData.label; primary: remPage.rday === modelData.i; onClicked: { remPage.rday = modelData.i; remPage.err = "" } }
                    }
                }
                DText {
                    width: parent.width; wrapMode: Text.WordWrap; font.pixelSize: 13; x: 4
                    text: remPage.err !== "" ? remPage.err : "Rings " + Clocks.fmtWhen(remPage.atMs)
                    color: remPage.err !== "" || remPage.atMs <= Clocks.now ? "#FF6B6B" : Theme.subtext
                }
                Row {
                    spacing: 8
                    ArqButton { size: "M"; text: "Cancel"; onClicked: remPage.editing = false }
                    ArqButton { size: "M"; primary: true; icon: "check"; text: "Save"; onClicked: remPage.save() }
                }
            }
        }
    }

    // ================= Alarms (a list; + opens a page with number wheels for the time)
    Item {
        id: alPage
        visible: opacity > 0.01
        opacity: p.tab === 2 ? 1 : 0
        Behavior on opacity { NumberAnimation { duration: 200 } }
        x: p.pageX; y: p.pageY; width: p.pageW; height: p.pageH
        property bool editing: false
        property string editId: ""           // "" = a new alarm
        property int eh: 7
        property int em: 0
        property var edays: []
        property bool esound: true
        property int esnMin: 5
        property int esnTimes: 3
        property bool snoozeOpen: false
        readonly property var order: [1, 2, 3, 4, 5, 6, 0]
        readonly property var names: ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
        readonly property real nextMs: {
            const l = Clocks.alarms.filter(a => a.on).map(a => Clocks.nextAlarmMs(a)).filter(x => x > 0).sort((a, b) => a - b)
            return l.length > 0 ? l[0] : -1
        }
        function leftText(ms) {
            const mins = Math.max(1, Math.round((ms - Clocks.now) / 60000))
            const d = Math.floor(mins / 1440), h = Math.floor((mins % 1440) / 60), m = mins % 60
            const parts = []
            if (d > 0) parts.push(d + (d === 1 ? " day" : " days"))
            if (h > 0) parts.push(h + (h === 1 ? " hour" : " hours"))
            if (m > 0 && d === 0) parts.push(m + (m === 1 ? " minute" : " minutes"))
            return parts.join(" ")
        }
        function openNew() {
            const t = new Date()
            editId = ""; eh = (t.getHours() + 1) % 24; em = 0; edays = []; esound = true; esnMin = 5; esnTimes = 3
            snoozeOpen = false; alName.text = ""; editing = true
        }
        function openAlarm(a) {
            editId = a.id; eh = a.h; em = a.m; edays = (a.days || []).slice(); esound = a.sound !== false
            esnMin = a.snoozeMin ?? 5; esnTimes = a.snoozeTimes ?? 3
            snoozeOpen = false; alName.text = a.label || ""; editing = true
        }
        function save() {
            const o = { h: eh, m: em, label: alName.text, days: edays, sound: esound, snoozeMin: esnMin, snoozeTimes: esnTimes }
            if (editId === "") Clocks.addAlarm(o); else Clocks.updateAlarm(editId, o)
            editing = false
        }

        // ---- the list
        Item {
            id: alList
            anchors.fill: parent
            opacity: alPage.editing ? 0 : 1
            visible: opacity > 0.01
            transform: Translate { x: alPage.editing ? -40 : 0; Behavior on x { NumberAnimation { duration: 260; easing.type: Easing.OutCubic } } }
            Behavior on opacity { NumberAnimation { duration: 200 } }
            Item {
                id: alTop
                width: parent.width; height: 48
                Column {
                    x: 4; anchors.verticalCenter: parent.verticalCenter
                    DText { text: "Alarms"; font.pixelSize: 18; font.weight: Font.DemiBold }
                    DText { text: alPage.nextMs > 0 ? "Next one in " + alPage.leftText(alPage.nextMs) : "None is on"; font.pixelSize: 12; color: alPage.nextMs > 0 ? Theme.primary : Theme.subtext }
                }
                ArqButton { anchors.right: parent.right; anchors.verticalCenter: parent.verticalCenter; icon: "add"; text: "New"; primary: true; onClicked: alPage.openNew() }
            }
            Flickable {
                y: alTop.height + 6
                width: parent.width; height: parent.height - y
                clip: true
                contentHeight: alCol.implicitHeight
                boundsBehavior: Flickable.StopAtBounds
                Column {
                    id: alCol
                    width: parent.width
                    spacing: 8
                    EmptyState { visible: Clocks.alarms.length === 0; width: alCol.width; height: 160; icon: "alarm_off"; text: "No alarms. Press New to add one" }
                    Repeater {
                        model: Clocks.alarms.slice().sort((a, b) => (a.h * 60 + a.m) - (b.h * 60 + b.m))
                        delegate: Rectangle {
                            id: ar
                            required property var modelData
                            width: alCol.width; height: 74; radius: 20
                            color: ar.modelData.on ? Theme.tileOn : Theme.tile
                            Behavior on color { ColorAnimation { duration: 160 } }
                            scale: arMa.pressed ? 0.98 : 1
                            Behavior on scale { NumberAnimation { duration: 220; easing.type: Easing.OutBack; easing.overshoot: Motion.os(2) } }
                            MouseArea { id: arMa; anchors.fill: parent; cursorShape: Qt.PointingHandCursor; onClicked: alPage.openAlarm(ar.modelData) }
                            DText {
                                x: 18; y: 0; height: parent.height; verticalAlignment: Text.AlignVCenter
                                text: Clocks.fmtClock(ar.modelData.h, ar.modelData.m)
                                font.pixelSize: 28; font.weight: Font.DemiBold
                                color: ar.modelData.on ? Theme.onSecondaryContainer : Theme.subtext
                            }
                            Column {
                                x: 150; y: (parent.height - height) / 2
                                width: parent.width - 150 - 70
                                DText { visible: ar.modelData.label !== ""; width: parent.width; text: ar.modelData.label; elide: Text.ElideRight; font.pixelSize: 14; font.weight: Font.Medium; color: ar.modelData.on ? Theme.onSecondaryContainer : Theme.text }
                                DText { width: parent.width; text: Clocks.alarmWhenText(ar.modelData.h, ar.modelData.m, ar.modelData.days); elide: Text.ElideRight; font.pixelSize: 12; color: ar.modelData.on ? Theme.onSecondaryContainer : Theme.subtext; opacity: 0.8 }
                            }
                            ArqToggle {
                                x: parent.width - width - 16; anchors.verticalCenter: parent.verticalCenter
                                checked: ar.modelData.on
                                onToggled: v => Clocks.setAlarmOn(ar.modelData.id, v)
                            }
                        }
                    }
                }
            }
        }

        // ---- new / change
        Flickable {
            id: alEdit
            anchors.fill: parent
            opacity: alPage.editing ? 1 : 0
            visible: opacity > 0.01
            clip: true
            contentHeight: alEditCol.implicitHeight + 8
            boundsBehavior: Flickable.StopAtBounds
            transform: Translate { x: alPage.editing ? 0 : 40; Behavior on x { NumberAnimation { duration: 260; easing.type: Easing.OutCubic } } }
            Behavior on opacity { NumberAnimation { duration: 200 } }
            Column {
                id: alEditCol
                width: alEdit.width
                spacing: 12
                Item {
                    width: parent.width; height: 34
                    DText { x: 4; anchors.verticalCenter: parent.verticalCenter; text: alPage.editId === "" ? "New alarm" : "Change alarm"; font.pixelSize: 18; font.weight: Font.DemiBold }
                    ArqButton { visible: alPage.editId !== ""; anchors.right: parent.right; anchors.verticalCenter: parent.verticalCenter; icon: "delete"; onClicked: { Clocks.delAlarm(alPage.editId); alPage.editing = false } }
                }
                WheelCard {
                    width: parent.width
                    counts: [Config.c.clock24 ? 24 : 12, 60]
                    units: Config.c.clock24 ? ["hr", "min"] : ["hr", "min"]
                    twelveFirst: !Config.c.clock24
                    values: [Config.c.clock24 ? alPage.eh : alPage.eh % 12, alPage.em]
                    onMoved: (i, v) => {
                        if (i === 1) alPage.em = v
                        else alPage.eh = Config.c.clock24 ? v : (alPage.eh >= 12 ? 12 + v : v)
                    }
                    Column {
                        visible: !Config.c.clock24
                        anchors.right: parent.right; anchors.rightMargin: 12; anchors.verticalCenter: parent.verticalCenter
                        spacing: 6
                        ArqButton { text: "AM"; primary: alPage.eh < 12; onClicked: if (alPage.eh >= 12) alPage.eh -= 12 }
                        ArqButton { text: "PM"; primary: alPage.eh >= 12; onClicked: if (alPage.eh < 12) alPage.eh += 12 }
                    }
                }
                // repeat: a chip for each day
                DText { x: 4; text: "Repeat · " + Clocks.alarmWhenText(alPage.eh, alPage.em, alPage.edays); color: Theme.subtext; font.pixelSize: 12 }
                Row {
                    width: parent.width; spacing: 4
                    Repeater {
                        model: 7
                        delegate: Rectangle {
                            id: dy
                            required property int index
                            readonly property int dayNo: alPage.order[index]
                            readonly property bool on: alPage.edays.indexOf(dayNo) >= 0
                            width: (parent.width - 24) / 7; height: 36; radius: 12
                            color: on ? Theme.primary : (dyMa.containsMouse ? Theme.hover : Theme.tile)
                            Behavior on color { ColorAnimation { duration: 140 } }
                            scale: dyMa.pressed ? 0.9 : 1
                            Behavior on scale { NumberAnimation { duration: 220; easing.type: Easing.OutBack; easing.overshoot: Motion.os(2.4) } }
                            DText { anchors.centerIn: parent; text: alPage.names[dy.index]; font.pixelSize: 12; font.weight: dy.on ? Font.DemiBold : Font.Normal; color: dy.on ? Theme.onPrimary : Theme.text }
                            MouseArea {
                                id: dyMa; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor
                                onClicked: {
                                    const a = alPage.edays.slice(), i = a.indexOf(dy.dayNo)
                                    if (i >= 0) a.splice(i, 1); else a.push(dy.dayNo)
                                    alPage.edays = a
                                }
                            }
                        }
                    }
                }
                ArqField { id: alName; width: parent.width; placeholder: "Name (optional)"; iconName: "label"; onAccepted: alPage.save(); closesOnEscape: false; onEscaped: alPage.editing = false }
                // sound and snooze, as rows with an icon
                Rectangle {
                    width: parent.width; height: 64; radius: 20; color: Theme.tile
                    Rectangle { x: 12; anchors.verticalCenter: parent.verticalCenter; width: 38; height: 38; radius: 19; color: Theme.tileOn
                        Icon { anchors.centerIn: parent; name: alPage.esound ? "volume_up" : "volume_off"; size: 20; color: Theme.onSecondaryContainer } }
                    Column {
                        x: 62; anchors.verticalCenter: parent.verticalCenter
                        DText { text: "Sound"; font.pixelSize: 14; font.weight: Font.Medium }
                        DText { text: alPage.esound ? "Plays the alarm sound until you stop it" : "A notification only"; font.pixelSize: 12; color: Theme.subtext }
                    }
                    ArqToggle { x: parent.width - width - 14; anchors.verticalCenter: parent.verticalCenter; checked: alPage.esound; onToggled: v => alPage.esound = v }
                }
                Rectangle {
                    width: parent.width; height: alPage.snoozeOpen && alPage.esnTimes > 0 ? 64 + snzEd.implicitHeight + 20 : 64; radius: 20; color: Theme.tile
                    clip: true
                    Behavior on height { NumberAnimation { duration: 260; easing.type: Easing.OutBack; easing.overshoot: Motion.os(1.1) } }
                    MouseArea { width: parent.width - 80; height: 64; cursorShape: Qt.PointingHandCursor; onClicked: if (alPage.esnTimes > 0) alPage.snoozeOpen = !alPage.snoozeOpen }
                    Rectangle { x: 12; y: 13; width: 38; height: 38; radius: 19; color: Theme.tileOn
                        Icon { anchors.centerIn: parent; name: "snooze"; size: 20; color: Theme.onSecondaryContainer } }
                    Column {
                        x: 62; y: 12
                        DText { text: "Snooze"; font.pixelSize: 14; font.weight: Font.Medium }
                        DText { text: alPage.esnTimes === 0 ? "Off" : alPage.esnMin + (alPage.esnMin === 1 ? " minute" : " minutes") + ", up to " + alPage.esnTimes + (alPage.esnTimes === 1 ? " time" : " times") + (alPage.snoozeOpen ? "" : "  ·  tap to change"); font.pixelSize: 12; color: Theme.subtext }
                    }
                    ArqToggle { x: parent.width - width - 14; y: 16; checked: alPage.esnTimes > 0; onToggled: v => { alPage.esnTimes = v ? 3 : 0; alPage.snoozeOpen = v } }
                    SnoozeEditor {
                        id: snzEd
                        x: 14; y: 68; width: parent.width - 28
                        minutes: alPage.esnMin
                        times: alPage.esnTimes
                        onEdited: (m, t) => { alPage.esnMin = m; alPage.esnTimes = t }
                    }
                }
                Row {
                    spacing: 8
                    ArqButton { size: "M"; text: "Cancel"; onClicked: alPage.editing = false }
                    ArqButton { size: "M"; primary: true; icon: "check"; text: "Save"; onClicked: alPage.save() }
                }
            }
        }
    }

    // ================= Timers and the stopwatch
    Flickable {
        id: tmPage
        visible: opacity > 0.01
        opacity: p.tab === 3 ? 1 : 0
        Behavior on opacity { NumberAnimation { duration: 200 } }
        x: p.pageX; y: p.pageY; width: p.pageW; height: p.pageH
        clip: true
        contentHeight: tmCol.implicitHeight + 8
        boundsBehavior: Flickable.StopAtBounds
        property int th: 0
        property int tm: 5
        property int ts: 0
        function start() {
            const sec = th * 3600 + tm * 60 + ts
            if (!(sec > 0)) return
            Clocks.addTimer(sec, tmLabel.text)
            tmLabel.text = ""
        }
        function preset(sec) { th = Math.floor(sec / 3600); tm = Math.floor((sec % 3600) / 60); ts = sec % 60 }
        Column {
            id: tmCol
            width: tmPage.width
            spacing: 10
            // the stopwatch
            Rectangle {
                width: parent.width; height: 138; radius: 26
                color: Theme.tile
                border.width: Clocks.sw.running ? 2 : 0; border.color: Theme.primary
                Behavior on border.width { NumberAnimation { duration: 200 } }
                DText {
                    anchors.horizontalCenter: parent.horizontalCenter; y: 14
                    text: Clocks.fmtWatch(Clocks.swElapsed())
                    font.pixelSize: 44; font.weight: Font.Medium
                    color: Clocks.sw.running ? Theme.primary : Theme.text
                }
                Row {
                    anchors.horizontalCenter: parent.horizontalCenter; y: 78
                    spacing: 8
                    ArqButton {
                        size: "M"; primary: true
                        icon: Clocks.sw.running ? "pause" : "play_arrow"
                        text: Clocks.sw.running ? "Pause" : (Clocks.sw.base > 0 ? "Resume" : "Start")
                        onClicked: Clocks.swToggle()
                    }
                    ArqButton { size: "M"; icon: "flag"; text: "Lap"; enabled: Clocks.sw.running; onClicked: Clocks.swLap() }
                    ArqButton { size: "M"; icon: "restart_alt"; enabled: Clocks.sw.base > 0 || Clocks.sw.running; onClicked: Clocks.swReset() }
                }
            }
            Column {
                width: parent.width; spacing: 2
                visible: Clocks.sw.laps.length > 0
                Repeater {
                    model: Clocks.sw.laps.map((v, i) => i).reverse().slice(0, 5)
                    delegate: Item {
                        id: lp
                        required property int modelData
                        width: tmCol.width; height: 22
                        readonly property double at: Clocks.sw.laps[modelData]
                        readonly property double prev: modelData > 0 ? Clocks.sw.laps[modelData - 1] : 0
                        DText { x: 8; anchors.verticalCenter: parent.verticalCenter; text: "Lap " + (lp.modelData + 1); color: Theme.subtext; font.pixelSize: 13 }
                        DText { x: 90; anchors.verticalCenter: parent.verticalCenter; text: "+" + Clocks.fmtWatch(lp.at - lp.prev); font.pixelSize: 13 }
                        DText { anchors.right: parent.right; anchors.rightMargin: 8; anchors.verticalCenter: parent.verticalCenter; text: Clocks.fmtWatch(lp.at); color: Theme.subtext; font.pixelSize: 13 }
                    }
                }
            }
            // a new timer: number wheels for hours, minutes and seconds
            DText { text: "New timer"; font.pixelSize: 14; font.weight: Font.DemiBold }
            WheelCard {
                width: parent.width
                rowH: 44
                counts: [24, 60, 60]; units: ["hr", "min", "sec"]
                values: [tmPage.th, tmPage.tm, tmPage.ts]
                onMoved: (i, v) => { if (i === 0) tmPage.th = v; else if (i === 1) tmPage.tm = v; else tmPage.ts = v }
            }
            Flow {
                width: parent.width; spacing: 6
                Repeater {
                    model: [["1 min", 60], ["5 min", 300], ["10 min", 600], ["15 min", 900], ["30 min", 1800], ["1 hour", 3600]]
                    delegate: ArqButton { required property var modelData; text: modelData[0]; onClicked: tmPage.preset(modelData[1]) }
                }
            }
            Item {
                width: parent.width; height: 46
                ArqField { id: tmLabel; width: parent.width - 110; placeholder: "Label (optional)"; iconName: "label"; onAccepted: tmPage.start() }
                ArqButton { x: parent.width - width; anchors.verticalCenter: parent.verticalCenter; size: "M"; primary: true; icon: "play_arrow"; text: "Start"; enabled: tmPage.th + tmPage.tm + tmPage.ts > 0; onClicked: tmPage.start() }
            }
            EmptyState { visible: Clocks.timers.length === 0; width: parent.width; height: 80; icon: "hourglass_empty"; text: "No timers running" }
            Repeater {
                model: Clocks.timers
                delegate: Rectangle {
                    id: tr
                    required property var modelData
                    readonly property double remain: Clocks.timerLeft(modelData)
                    readonly property bool done: !modelData.running && modelData.left <= 0
                    width: tmCol.width; height: 72; radius: 18
                    color: Theme.tile
                    DText {
                        x: 16; y: 10
                        text: tr.done ? "Done" : Clocks.fmtDur(Math.ceil(tr.remain / 1000))
                        font.pixelSize: 24; font.weight: Font.DemiBold
                        color: tr.done ? Theme.primary : Theme.text
                    }
                    DText {
                        x: 16; y: 42
                        width: parent.width - 16 - 100
                        text: (tr.modelData.label !== "" ? tr.modelData.label + " · " : "") + Clocks.fmtDur(tr.modelData.total)
                        elide: Text.ElideRight; color: Theme.subtext; font.pixelSize: 12
                    }
                    Rectangle {
                        x: 16; y: parent.height - 8; height: 3; radius: 2
                        width: parent.width - 32
                        color: Theme.stroke
                        Rectangle {
                            height: parent.height; radius: 2; color: Theme.primary
                            width: parent.width * Math.max(0, Math.min(1, tr.remain / (tr.modelData.total * 1000)))
                        }
                    }
                    Row {
                        anchors.right: parent.right; anchors.rightMargin: 8
                        anchors.verticalCenter: parent.verticalCenter
                        spacing: 4
                        ArqButton { icon: tr.done ? "restart_alt" : (tr.modelData.running ? "pause" : "play_arrow"); primary: !tr.modelData.running; onClicked: Clocks.toggleTimer(tr.modelData.id) }
                        ArqButton { icon: "close"; onClicked: Clocks.delTimer(tr.modelData.id) }
                    }
                }
            }
        }
    }

    // ================= World clocks
    Flickable {
        id: wPage
        visible: opacity > 0.01
        opacity: p.tab === 4 ? 1 : 0
        Behavior on opacity { NumberAnimation { duration: 200 } }
        x: p.pageX; y: p.pageY; width: p.pageW; height: p.pageH
        clip: true
        contentHeight: wCol.implicitHeight
        boundsBehavior: Flickable.StopAtBounds
        readonly property string q: wSearch.text.trim().toLowerCase().replace(/[\s_]+/g, "_")
        readonly property var presets: ["America/Los_Angeles", "America/New_York", "America/Sao_Paulo", "Europe/London", "Europe/Paris", "Africa/Lagos", "Africa/Johannesburg", "Asia/Dubai", "Asia/Kolkata", "Asia/Shanghai", "Asia/Tokyo", "Australia/Sydney", "Pacific/Auckland"]
        readonly property var suggestions: {
            const have = Clocks.zones
            let list
            if (q.length >= 2) list = Clocks.allZones.filter(z => z.toLowerCase().indexOf(q) >= 0)
            else list = presets
            return list.filter(z => have.indexOf(z) < 0).slice(0, 8)
        }
        Column {
            id: wCol
            width: wPage.width
            spacing: 10
            ArqField {
                id: wSearch
                width: parent.width
                placeholder: "Add a city or time zone (Tokyo, London…)"
                iconName: "search"
                onAccepted: { if (wPage.suggestions.length > 0) { Clocks.addZone(wPage.suggestions[0]); wSearch.text = "" } }
            }
            Flow {
                width: parent.width; spacing: 6
                Repeater {
                    model: wPage.suggestions
                    delegate: ArqButton { required property string modelData; icon: "add"; text: Clocks.cityOf(modelData); onClicked: { Clocks.addZone(modelData); wSearch.text = "" } }
                }
            }
            DText { visible: wPage.q.length >= 2 && wPage.suggestions.length === 0; text: Clocks.allZones.length === 0 ? "Reading the list of time zones…" : (Clocks.allZones.some(z => z.toLowerCase().indexOf(wPage.q) >= 0) ? "Already added" : "No time zone like that"); color: Theme.subtext; font.pixelSize: 13 }
            // here
            Rectangle {
                width: parent.width; height: 64; radius: 18
                color: Theme.tileOn
                Icon { x: 16; anchors.verticalCenter: parent.verticalCenter; name: "home"; size: 22; color: Theme.onSecondaryContainer }
                Column {
                    x: 52; anchors.verticalCenter: parent.verticalCenter
                    DText { text: "Here"; font.pixelSize: 15; font.weight: Font.DemiBold; color: Theme.onSecondaryContainer }
                    DText { text: Qt.formatDate(p.nowD, "ddd d MMM"); font.pixelSize: 12; color: Theme.onSecondaryContainer; opacity: 0.75 }
                }
                DText {
                    anchors.right: parent.right; anchors.rightMargin: 18; anchors.verticalCenter: parent.verticalCenter
                    text: Clocks.fmtClock(p.nowD.getHours(), p.nowD.getMinutes())
                    font.pixelSize: 24; font.weight: Font.DemiBold; color: Theme.onSecondaryContainer
                }
            }
            Repeater {
                model: Clocks.zones
                delegate: Rectangle {
                    id: zr
                    required property string modelData
                    readonly property date zd: Clocks.zoneDate(modelData)
                    width: wCol.width; height: 64; radius: 18
                    color: Theme.tile
                    Icon { x: 16; anchors.verticalCenter: parent.verticalCenter; name: (zd.getHours() >= 6 && zd.getHours() < 18) ? "light_mode" : "dark_mode"; size: 22; color: Theme.primary }
                    Column {
                        x: 52; anchors.verticalCenter: parent.verticalCenter
                        width: parent.width - 52 - 150
                        DText { width: parent.width; text: Clocks.cityOf(zr.modelData); elide: Text.ElideRight; font.pixelSize: 15; font.weight: Font.DemiBold }
                        DText { width: parent.width; text: Clocks.zoneDayText(zr.modelData) + " · " + Clocks.zoneDiffText(zr.modelData); elide: Text.ElideRight; font.pixelSize: 12; color: Theme.subtext }
                    }
                    DText {
                        anchors.right: parent.right; anchors.rightMargin: 52; anchors.verticalCenter: parent.verticalCenter
                        text: Clocks.fmtClock(zr.zd.getHours(), zr.zd.getMinutes())
                        font.pixelSize: 22; font.weight: Font.DemiBold
                        visible: Clocks.zoneOff[zr.modelData] !== undefined
                    }
                    DText {
                        anchors.right: parent.right; anchors.rightMargin: 52; anchors.verticalCenter: parent.verticalCenter
                        text: "…"; color: Theme.subtext; font.pixelSize: 20
                        visible: Clocks.zoneOff[zr.modelData] === undefined
                    }
                    ArqButton { x: parent.width - width - 8; anchors.verticalCenter: parent.verticalCenter; icon: "close"; onClicked: Clocks.delZone(zr.modelData) }
                }
            }
        }
    }
}
