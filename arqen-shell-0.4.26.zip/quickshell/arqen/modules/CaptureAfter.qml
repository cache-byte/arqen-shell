import Quickshell
import Quickshell.Wayland
import Quickshell.Hyprland
import Quickshell.Widgets
import QtQuick
import QtQuick.Layouts
import qs.config
import qs.components
import qs.services

// After a screenshot or recording (Settings > Desktop > After a screenshot: "Ask"): a card in the
// control centre's corner, in the control centre's style: what was taken, the picture (click it to
// open), and tiles like the control centre's: Copy · Edit (Play) · Rename · Folder · Copy path · Delete,
// with Save at the top. It saves by itself after a few seconds (the line under the picture runs
// down; resting the pointer on the card waits). Several in a row: the newest is the big card, the
// ones before it wait in small rows (save or delete them there).
PanelWindow {
    id: ca
    readonly property bool on: Captures.pending.length > 0
    readonly property var newest: Captures.pending[0] ?? null
    readonly property var older: Captures.pending.slice(1)

    // ---- where: the same place as notifications (Settings > Sound and notifications > Where pop-ups appear),
    // stacked under the ringing card if one shows ----
    readonly property bool atTop: !Ui.toastBottom
    readonly property bool atLeft: Ui.toastLeft
    property real lift: Ui.ringH
    Behavior on lift { NumberAnimation { duration: 200; easing.type: Easing.OutCubic } }
    screen: Quickshell.screens.find(s => s.name === Hyprland.focusedMonitor?.name) ?? Quickshell.screens[0]
    anchors { top: Ui.toastTop; bottom: Ui.toastBottom; left: Ui.toastLeft; right: Ui.toastRight }
    margins { top: Ui.rTop + Ui.gap + Ui.offTop(ca.lift); bottom: Ui.rBottom + Ui.gap + Ui.offBottom(ca.lift); left: Ui.rLeft + Ui.gap; right: Ui.rRight + Ui.gap }

    visible: on || leaving.running
    color: "transparent"
    exclusionMode: ExclusionMode.Ignore
    WlrLayershell.namespace: "arqen-capture-after"
    WlrLayershell.layer: WlrLayer.Overlay
    // the keyboard only while a name is being typed
    WlrLayershell.keyboardFocus: renaming >= 0 ? WlrKeyboardFocus.Exclusive : WlrKeyboardFocus.None
    implicitWidth: 420          // as wide as a notification pop-up
    implicitHeight: Math.max(1, stack.implicitHeight)
    property int renaming: -1                 // the id of the one being renamed
    Timer { id: leaving; interval: 320 }
    Binding { target: Ui; property: "captureH"; value: ca.visible ? ca.implicitHeight + 10 : 0 }
    onOnChanged: if (!on) leaving.restart()

    // ---- each saves by itself after a while, unless the pointer rests on the card or it is being
    // renamed. Kept here, not in the cards: the cards are made again whenever the list changes ----
    readonly property int secs: Config.c.captureAfterSecs || 0
    property var lefts: ({})                  // id -> time left, 1 .. 0
    property var born: ({})                   // id -> when it first showed (slides in once)
    property bool held: false                 // the pointer is on the card
    property int tick: 0
    function leftOf(id) { tick; return lefts[id] ?? 1 }
    Timer {
        interval: 100; repeat: true
        running: ca.on && ca.secs > 0
        onTriggered: {
            for (const it of Captures.pending) {
                if (ca.held || it.id === ca.renaming) continue
                const l = (ca.lefts[it.id] ?? 1) - 0.1 / ca.secs
                ca.lefts[it.id] = l
                if (l <= 0) { const id = it.id; Qt.callLater(() => Captures.save(id)) }
            }
            ca.tick++
        }
    }
    function act(id, what) {
        if (what === "save") Captures.save(id)
        else if (what === "copy") Captures.copy(id)
        else if (what === "edit") Captures.save(id, "", "edit")
        else if (what === "open") Captures.save(id, "", "open")
        else if (what === "show") Captures.save(id, "", "show")
        else if (what === "delete") Captures.discard(id)
    }

    Column {
        id: stack
        width: parent.width
        spacing: 8
        HoverHandler { onHoveredChanged: ca.held = hovered }
        // the big card nearest the panel, the small rows further away
        Repeater {
            model: (ca.atTop ? [ca.newest].concat(ca.older) : ca.older.slice().reverse().concat([ca.newest])).filter(x => x)
            delegate: Loader {
                required property var modelData
                width: stack.width
                sourceComponent: modelData === ca.newest ? bigC : smallC
                onLoaded: item.it = modelData
            }
        }
    }

    // the notification cards' colour (components/NotifCard.qml), so this looks like one of them
    // follows the theme: its colour, the see-through setting (so the blur shows) and the corner roundness
    readonly property color base: Qt.rgba(Theme.cardSolid.r, Theme.cardSolid.g, Theme.cardSolid.b, Math.max(0.6, Config.c.opacity))
    readonly property real corner: Math.max(14, Math.min(28, Config.c.panelRadius))

    // ---------- the newest: like an opened notification ----------
    Component {
        id: bigC
        Rectangle {
            id: card
            property var it: null
            readonly property int cid: it ? it.id : -1
            readonly property bool shot: it ? it.kind === "shot" : true
            readonly property bool editing: ca.renaming === cid
            readonly property real timeLeft: ca.leftOf(cid)
            width: parent ? parent.width : 380
            height: col.implicitHeight + 28
            radius: ca.corner
            color: ca.base
            border.width: Theme.dark ? 0 : 1; border.color: Theme.stroke

            // slides in from its side (the first time only)
            property real t: 1
            onCidChanged: {
                if (cid < 0 || ca.born[cid] !== undefined) return
                ca.born[cid] = Date.now()
                t = 0; slideIn.restart()
            }
            NumberAnimation { id: slideIn; target: card; property: "t"; to: 1; duration: 380; easing.type: Easing.OutBack; easing.overshoot: Motion.os(0.9) }
            transform: Translate { x: (ca.atLeft ? -1 : 1) * (card.width + 30) * (1 - card.t) }
            opacity: Math.min(1, card.t * 1.5)

            ColumnLayout {
                id: col
                x: 14; y: 14; width: parent.width - 24
                spacing: 10

                // like a notification: icon · where and when · title · what happens next · save
                RowLayout {
                    Layout.fillWidth: true
                    spacing: 12
                    Rectangle {
                        Layout.preferredWidth: 44; Layout.preferredHeight: 44
                        radius: 12
                        color: Theme.ccBadge
                        Icon { anchors.centerIn: parent; name: card.shot ? "screenshot_monitor" : "videocam"; size: 24; color: Theme.ccBadgeIcon }
                    }
                    ColumnLayout {
                        Layout.fillWidth: true
                        spacing: 1
                        DText { Layout.fillWidth: true; elide: Text.ElideRight; text: (card.shot ? "Screenshot" : "Screen recording") + "  ·  now"; font.pixelSize: 11; color: Theme.subtext }
                        DText { Layout.fillWidth: true; elide: Text.ElideRight; text: card.shot ? "Screenshot taken" : "Recording finished"; font.pixelSize: 14; font.weight: Font.DemiBold }
                        DText {
                            Layout.fillWidth: true; elide: Text.ElideRight
                            text: (card.editing ? "Type a name, Enter to save"
                                 : ca.secs > 0 ? (ca.held ? "Waiting while you look" : "Saves in " + Math.max(1, Math.ceil(card.timeLeft * ca.secs)) + " s")
                                 : "Not saved yet") + (card.it && card.it.copied ? "  ·  copied" : "")
                            font.pixelSize: 13; color: Theme.subtext
                        }
                    }
                    // save now
                    Rectangle {
                        Layout.preferredWidth: 38; Layout.preferredHeight: 38; Layout.alignment: Qt.AlignTop
                        radius: 19
                        color: doneMa.containsMouse ? Qt.lighter(Theme.primary, 1.08) : Theme.primary
                        Icon { anchors.centerIn: parent; name: "check"; size: 20; color: Theme.onPrimary }
                        MouseArea {
                            id: doneMa; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor
                            onClicked: {
                                const id = card.cid
                                if (card.editing) { const n = nameField.text; ca.renaming = -1; Captures.save(id, n) }
                                else Captures.save(id)
                            }
                        }
                        HoverTip { hovered: doneMa.containsMouse; text: "Save now" }
                    }
                }

                // the picture, like a notification's big picture; click = open it
                ClippingRectangle {
                    Layout.fillWidth: true
                    Layout.rightMargin: 2
                    Layout.preferredHeight: Math.round(width * 9 / 16)
                    radius: 18
                    color: Theme.tile
                    Image {
                        id: pic
                        anchors.fill: parent
                        source: card.it && card.it.thumb !== "" ? "file://" + card.it.thumb : ""
                        fillMode: Image.PreserveAspectCrop
                        asynchronous: true
                        cache: false
                        sourceSize.width: 760
                    }
                    Icon { anchors.centerIn: parent; visible: pic.status !== Image.Ready; name: card.shot ? "image" : "movie"; size: 40; color: Theme.subtext }
                    Rectangle {
                        visible: !card.shot
                        anchors.centerIn: parent
                        width: 56; height: 56; radius: 28; color: Qt.rgba(0, 0, 0, 0.5)
                        Icon { anchors.centerIn: parent; name: "play_arrow"; size: 36; color: "white" }
                    }
                    Rectangle {
                        anchors.right: parent.right; anchors.bottom: parent.bottom; anchors.margins: 10
                        visible: picMa.containsMouse
                        width: openRow.implicitWidth + 20; height: 30; radius: 15
                        color: Qt.rgba(0, 0, 0, 0.6)
                        Row {
                            id: openRow
                            anchors.centerIn: parent; spacing: 5
                            Icon { name: "open_in_new"; size: 15; color: "white"; anchors.verticalCenter: parent.verticalCenter }
                            DText { text: card.shot ? "Open" : "Play"; color: "white"; font.pixelSize: 12; anchors.verticalCenter: parent.verticalCenter }
                        }
                    }
                    MouseArea { id: picMa; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: ca.act(card.cid, "open") }
                    Rectangle {
                        visible: ca.secs > 0
                        anchors.left: parent.left; anchors.right: parent.right; anchors.bottom: parent.bottom
                        height: 4
                        color: Qt.rgba(0, 0, 0, 0.25)
                        Rectangle {
                            width: parent.width * card.timeLeft; height: parent.height; color: Theme.primary
                            Behavior on width { NumberAnimation { duration: 100 } }
                        }
                    }
                }

                // a new name
                ArqField {
                    id: nameField
                    visible: card.editing
                    Layout.fillWidth: true
                    Layout.rightMargin: 2
                    iconName: "edit"
                    closesOnEscape: false
                    onEscaped: ca.renaming = -1
                    onAccepted: { const id = card.cid, n = text; ca.renaming = -1; Captures.save(id, n) }
                }

                // what to do, across the bottom like a notification's buttons
                RowLayout {
                    Layout.fillWidth: true
                    Layout.rightMargin: 2
                    spacing: 4
                    Repeater {
                        model: [["content_copy", card.shot ? "Copy" : "Copy file", "copy"],
                                card.shot ? ["edit", "Edit", "edit"] : ["play_arrow", "Play", "open"],
                                ["drive_file_rename_outline", card.editing ? "Cancel" : "Rename", "rename"],
                                ["folder_open", "Folder", "show"],
                                ["delete", "Delete", "delete"]]
                        delegate: Rectangle {
                            id: tl
                            required property var modelData
                            readonly property bool danger: modelData[2] === "delete"
                            readonly property bool lit: modelData[2] === "copy" && card.it !== null && card.it.copied
                            Layout.fillWidth: true
                            Layout.preferredHeight: 52
                            radius: 18
                            color: tm.containsMouse ? Theme.hover : Qt.rgba(Theme.text.r, Theme.text.g, Theme.text.b, 0.05)
                            Behavior on color { ColorAnimation { duration: 120 } }
                            scale: tm.pressed ? 0.95 : 1
                            Behavior on scale { NumberAnimation { duration: 140; easing.type: Easing.OutBack } }
                            Column {
                                anchors.centerIn: parent
                                spacing: 2
                                Icon {
                                    anchors.horizontalCenter: parent.horizontalCenter
                                    name: tl.lit ? "check" : tl.modelData[0]; size: 18
                                    color: tl.danger ? "#FF5A5A" : (tl.lit ? Theme.primary : Theme.text)
                                }
                                DText {
                                    anchors.horizontalCenter: parent.horizontalCenter
                                    text: tl.lit ? "Copied" : tl.modelData[1]; font.pixelSize: 11; font.weight: Font.DemiBold
                                    color: tl.danger ? "#FF5A5A" : Theme.text
                                }
                            }
                            MouseArea {
                                id: tm
                                anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor
                                onClicked: {
                                    const id = card.cid, what = tl.modelData[2]
                                    if (what === "rename") {
                                        if (card.editing) { ca.renaming = -1; return }
                                        ca.renaming = id
                                        nameField.text = card.it.name.replace(/\.[^.]*$/, "")
                                        Qt.callLater(() => nameField.focusInput())
                                    } else ca.act(id, what)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // ---------- the ones before it: like closed notifications ----------
    Component {
        id: smallC
        Rectangle {
            id: row
            property var it: null
            readonly property real timeLeft: ca.leftOf(it ? it.id : -1)
            readonly property bool shot: it ? it.kind === "shot" : true
            width: parent ? parent.width : 380
            height: 72
            radius: 36
            color: ca.base
            border.width: Theme.dark ? 0 : 1; border.color: Theme.stroke
            RowLayout {
                anchors.fill: parent; anchors.leftMargin: 14; anchors.rightMargin: 12
                spacing: 12
                // the picture where a notification's icon is
                ClippingRectangle {
                    Layout.preferredWidth: 44; Layout.preferredHeight: 44; radius: 22
                    color: Theme.tile
                    Image { anchors.fill: parent; source: row.it && row.it.thumb !== "" ? "file://" + row.it.thumb : ""; fillMode: Image.PreserveAspectCrop; asynchronous: true; sourceSize.width: 120 }
                    Icon { anchors.centerIn: parent; visible: !row.it || row.it.thumb === ""; name: row.shot ? "image" : "movie"; size: 20; color: Theme.subtext }
                }
                ColumnLayout {
                    Layout.fillWidth: true
                    spacing: 1
                    DText {
                        Layout.fillWidth: true; elide: Text.ElideRight
                        text: (row.shot ? "Screenshot" : "Screen recording") + "  ·  " + (ca.secs > 0 && !ca.held ? "saves in " + Math.max(1, Math.ceil(row.timeLeft * ca.secs)) + " s" : "waiting")
                        font.pixelSize: 11; color: Theme.subtext
                    }
                    DText { Layout.fillWidth: true; elide: Text.ElideMiddle; text: row.it ? row.it.name : ""; font.pixelSize: 14; font.weight: Font.DemiBold }
                }
                Repeater {
                    model: [["check", "save", "Save"], ["delete", "delete", "Delete"]]
                    delegate: Rectangle {
                        id: sb
                        required property var modelData
                        Layout.preferredWidth: 34; Layout.preferredHeight: 34; radius: 17
                        color: sm.containsMouse ? Theme.hover : Qt.rgba(Theme.text.r, Theme.text.g, Theme.text.b, 0.09)
                        Icon { anchors.centerIn: parent; name: sb.modelData[0]; size: 18; color: sb.modelData[1] === "delete" ? "#FF5A5A" : Theme.text }
                        MouseArea {
                            id: sm; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor
                            onClicked: { const id = row.it.id; ca.act(id, sb.modelData[1]) }
                        }
                        HoverTip { hovered: sm.containsMouse; text: sb.modelData[2] }
                    }
                }
            }
        }
    }
}
