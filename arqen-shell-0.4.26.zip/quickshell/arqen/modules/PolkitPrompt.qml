import Quickshell
import Quickshell.Wayland
import Quickshell.Services.Polkit
import QtQuick
import QtQuick.Layouts
import qs.config
import qs.components

// The password prompt for anything that needs admin rights (renaming the computer, showing serial
// numbers, installing, changing system settings...): Arqen is the session's polkit agent.
// If another agent already runs (hyprpolkitagent, a GNOME / KDE one), that one keeps doing it.
// Loaded by shell.qml through a Loader, so a Quickshell built without polkit support just skips it.
Scope {
    id: root
    PolkitAgent { id: agent }
    readonly property var flow: agent.flow
    readonly property bool active: agent.isActive && flow !== null

    PanelWindow {
        id: win
        visible: root.active
        color: Qt.rgba(0, 0, 0, 0.45)
        anchors { top: true; left: true; right: true; bottom: true }
        exclusionMode: ExclusionMode.Ignore
        WlrLayershell.namespace: "arqen-popup"
        WlrLayershell.layer: WlrLayer.Overlay
        WlrLayershell.keyboardFocus: root.active ? WlrKeyboardFocus.Exclusive : WlrKeyboardFocus.None
        onVisibleChanged: if (visible) { pw.text = ""; focusLater.restart() }
        Timer { id: focusLater; interval: 60; onTriggered: pw.focusInput() }

        function submit() { if (root.flow && root.flow.isResponseRequired) { root.flow.submit(pw.text); pw.text = "" } }
        function cancel() { if (root.flow) root.flow.cancelAuthenticationRequest() }

        Rectangle {
            anchors.centerIn: parent
            width: Math.min(440, parent.width - 40)
            height: col.implicitHeight + 48
            radius: Theme.radius
            color: Theme.cardSolid
            border.width: 1; border.color: Theme.stroke

            ColumnLayout {
                id: col
                anchors { left: parent.left; right: parent.right; top: parent.top; margins: 24 }
                spacing: 14
                Rectangle {
                    Layout.alignment: Qt.AlignHCenter
                    width: 56; height: 56; radius: 28
                    color: Theme.primaryContainer
                    Icon { anchors.centerIn: parent; name: "lock"; size: 28; color: Theme.onPrimaryContainer }
                }
                DText {
                    Layout.fillWidth: true; horizontalAlignment: Text.AlignHCenter
                    text: "Password needed"; font.pixelSize: 20; font.weight: Font.Medium
                }
                DText {
                    Layout.fillWidth: true; horizontalAlignment: Text.AlignHCenter; wrapMode: Text.Wrap
                    text: root.flow?.message ?? ""; color: Theme.subtext; font.pixelSize: 13
                }
                DText {
                    visible: (root.flow?.selectedIdentity?.displayName ?? "") !== ""
                    Layout.fillWidth: true; horizontalAlignment: Text.AlignHCenter
                    text: "As " + (root.flow?.selectedIdentity?.displayName ?? ""); font.pixelSize: 13
                }
                ArqField {
                    id: pw
                    Layout.fillWidth: true
                    password: !(root.flow?.responseVisible ?? false)
                    closesOnEscape: false
                    iconName: "key"
                    placeholder: (root.flow?.inputPrompt ?? "").replace(/:\s*$/, "") || "Password"
                    onAccepted: win.submit()
                    onEscaped: win.cancel()
                }
                DText {
                    visible: (root.flow?.supplementaryMessage ?? "") !== "" || (root.flow?.failed ?? false)
                    Layout.fillWidth: true; horizontalAlignment: Text.AlignHCenter; wrapMode: Text.Wrap
                    text: (root.flow?.supplementaryMessage ?? "") !== "" ? root.flow.supplementaryMessage : "That password did not work. Try again."
                    color: (root.flow?.supplementaryIsError ?? true) ? "#FF6B6B" : Theme.subtext; font.pixelSize: 12
                }
                RowLayout {
                    Layout.alignment: Qt.AlignHCenter
                    spacing: 10
                    ArqButton { text: "Cancel"; onClicked: win.cancel() }
                    ArqButton { text: "Unlock"; primary: true; onClicked: win.submit() }
                }
            }
        }
    }
}
