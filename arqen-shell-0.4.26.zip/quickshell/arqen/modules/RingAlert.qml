import Quickshell
import Quickshell.Wayland
import Quickshell.Hyprland
import QtQuick
import qs.config
import qs.components
import qs.services

// What is ringing (an alarm, a reminder, a timer that ran out): a card at the top of the screen, with
// Snooze (when it still may) and Stop. The sound is played by services/Clocks.qml until it is stopped.
PanelWindow {
    id: win
    readonly property var items: Clocks.ringing
    visible: items.length > 0
    screen: Quickshell.screens.find(s => s.name === Hyprland.focusedMonitor?.name) ?? Quickshell.screens[0]
    color: "transparent"
    // where pop-ups go (Settings > Sound and notifications > Where pop-ups appear)
    anchors { top: Ui.toastTop; bottom: Ui.toastBottom; left: Ui.toastLeft; right: Ui.toastRight }
    margins { top: Ui.rTop + Ui.gap + Ui.offTop(0); bottom: Ui.rBottom + Ui.gap;  left: Ui.rLeft + Ui.gap; right: Ui.rRight + Ui.gap }
    implicitWidth: 420
    implicitHeight: Math.max(1, col.implicitHeight + 8)
    exclusionMode: ExclusionMode.Ignore
    Binding { target: Ui; property: "ringH"; value: win.visible ? win.implicitHeight + 10 : 0 }
    WlrLayershell.namespace: "arqen-ring"
    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.keyboardFocus: WlrKeyboardFocus.None

    Column {
        id: col
        width: parent.width
        spacing: 10
        Repeater {
            model: win.items
            delegate: Rectangle {
                id: card
                required property var modelData
                width: col.width; height: 128
                radius: 26
                color: Theme.cardSolid
                border.width: 1; border.color: Theme.stroke
                // springs in from above
                property real t: 0
                Component.onCompleted: inAnim.start()
                NumberAnimation { id: inAnim; target: card; property: "t"; to: 1; duration: 520; easing.type: Easing.OutBack; easing.overshoot: Motion.os(1.6) }
                opacity: Math.min(1, card.t)
                transform: Translate { y: (1 - card.t) * (Ui.toastTop ? -50 : (Ui.toastBottom ? 50 : 0)) }
                // a soft glow in the accent colour
                Rectangle { anchors.fill: parent; radius: parent.radius; color: Theme.primary; opacity: 0.10 }
                Rectangle {
                    id: badge
                    x: 18; y: 18; width: 52; height: 52; radius: 26
                    color: Theme.primary
                    Icon {
                        id: bell
                        anchors.centerIn: parent
                        size: 28; color: Theme.onPrimary
                        name: card.modelData.kind === "alarm" ? "alarm" : card.modelData.kind === "timer" ? "hourglass_bottom" : "notifications_active"
                        // rings: shakes side to side, with a pause
                        SequentialAnimation on rotation {
                            running: win.visible
                            loops: Animation.Infinite
                            NumberAnimation { to: 14; duration: 90 }
                            NumberAnimation { to: -14; duration: 160 }
                            NumberAnimation { to: 12; duration: 150 }
                            NumberAnimation { to: -10; duration: 140 }
                            NumberAnimation { to: 0; duration: 100 }
                            PauseAnimation { duration: 600 }
                        }
                    }
                    // a ring that spreads out
                    Rectangle {
                        anchors.centerIn: parent
                        width: parent.width; height: width; radius: width / 2
                        color: "transparent"; border.width: 2; border.color: Theme.primary
                        SequentialAnimation on scale { running: win.visible; loops: Animation.Infinite; NumberAnimation { from: 1; to: 1.7; duration: 1100; easing.type: Easing.OutCubic } }
                        SequentialAnimation on opacity { running: win.visible; loops: Animation.Infinite; NumberAnimation { from: 0.7; to: 0; duration: 1100 } }
                    }
                }
                Column {
                    x: 86; y: 18; width: parent.width - 86 - 18
                    spacing: 2
                    DText { width: parent.width; text: card.modelData.title; elide: Text.ElideRight; font.pixelSize: 20; font.weight: Font.DemiBold }
                    DText { width: parent.width; text: card.modelData.sub + (card.modelData.kind === "alarm" && card.modelData.left > 0 ? "  ·  " + card.modelData.left + " snooze" + (card.modelData.left === 1 ? "" : "s") + " left" : ""); elide: Text.ElideRight; color: Theme.subtext; font.pixelSize: 13 }
                }
                Row {
                    anchors.right: parent.right; anchors.rightMargin: 18
                    anchors.bottom: parent.bottom; anchors.bottomMargin: 16
                    spacing: 8
                    ArqButton {
                        visible: Clocks.canSnooze(card.modelData)
                        size: "M"; icon: "snooze"
                        text: card.modelData.kind === "timer" ? "+1 min" : "Snooze " + card.modelData.snoozeMin + " min"
                        onClicked: Clocks.snoozeRing(card.modelData.key)
                    }
                    ArqButton {
                        size: "M"; primary: true; icon: "stop_circle"
                        text: card.modelData.kind === "alarm" ? "Stop" : "Done"
                        onClicked: Clocks.stopRing(card.modelData.key)
                    }
                }
            }
        }
    }
}
