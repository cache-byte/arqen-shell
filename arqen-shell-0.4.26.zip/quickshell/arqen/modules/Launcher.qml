import Quickshell
import Quickshell.Widgets
import Quickshell.Io
import QtQuick
import qs.config
import qs.components
import qs.services

// Launcher (Super key by default). Grid (big icons, name below, rows centred) or list.
// Its size is a fraction of the screen, so it can never leave it.
// Press and hold an app to pick it up: the launcher fades, drag the app onto the desktop, let go.
ArqPopup {
    id: p
    open: Ui.open === "launcher"
    wantsKeyboard: true
    liveContent: true

    readonly property bool grid: Config.c.launcherLayout !== "list"
    readonly property int iconPx: Config.c.launcherIconSize

    position: Config.c.launcherPos
    readonly property real usableWidth: Math.max(1, p.width - 2 * Ui.gap)
    readonly property real usableHeight: Math.max(1, p.height - 2 * Ui.gap)
    cardWidth: Math.min(usableWidth, Math.max(Math.min(360, usableWidth), p.width * Config.c.launcherWidth / 100))
    cardHeight: Math.min(usableHeight, Math.max(Math.min(300, usableHeight), p.height * Config.c.launcherHeight / 100))

    property int cur: 0
    readonly property var results: Apps.search(field.text)
    readonly property int cols: Math.max(2, Math.floor(gf.width / (iconPx + 56)))
    readonly property int cellW: Math.floor(gf.width / cols)
    readonly property int cellH: iconPx + 62      // icon + two lines of name

    onOpenChanged: if (open) { field.text = ""; cur = 0; keyNav = false; gf.positionViewAtBeginning(); lv.positionViewAtBeginning(); field.focusInput() } else { carry = null; ctxEntry = null }

    // the highlighted app follows the keyboard only; the mouse just gets a hover
    property bool keyNav: false

    // ---- an app being dragged out to the desktop ----
    property var carry: null
    property real carryX: 0
    property real carryY: 0
    cardOpacity: carry ? 0 : 1
    function startCarry(entry, item, mx, my) {
        if (!entry) return
        const q = item.mapToItem(null, mx, my)
        carryX = q.x; carryY = q.y
        carry = entry
    }
    function moveCarry(item, mx, my) {
        const q = item.mapToItem(null, mx, my)
        carryX = q.x; carryY = q.y
    }
    function endCarry() {
        const e = carry
        carry = null
        if (!e) return
        const d = Ui.desktop
        // this window starts after the panels; the desktop window a panel gap further in
        if (d) d.addAppAt(e.id, carryX - Ui.gap - d.cellW / 2, carryY - Ui.gap - d.cellH / 2)
        Ui.close()
    }
    // ---- right-click menu on an app ----
    property var ctxEntry: null
    property real ctxX: 0
    property real ctxY: 0
    property var ctxInfo: null              // where the app came from (scripts/app-info.py)
    function openCtx(entry, item, mx, my) {
        const q = item.mapToItem(null, mx, my)
        ctxX = q.x; ctxY = q.y; ctxInfo = null; ctxEntry = entry
        infoP.command = ["python3", "-I", Quickshell.shellDir + "/scripts/app-info.py", "info", entry.id]
        infoP.running = true
    }
    function closeCtx() { ctxEntry = null }
    Process {
        id: infoP
        stdout: StdioCollector { onStreamFinished: { try { p.ctxInfo = JSON.parse(text) } catch (e) { p.ctxInfo = null } } }
    }
    readonly property bool ctxPinned: ctxEntry !== null && (Config.c.pinned || []).indexOf(ctxEntry.id) >= 0
    readonly property bool ctxOnDesktop: ctxEntry !== null && (Config.c.desktopApps || []).indexOf(ctxEntry.id) >= 0
    readonly property var ctxItems: {
        const e = ctxEntry
        if (!e) return []
        const out = [{ icon: "open_in_new", text: "Open", act: () => Ui.launch(e) }]
        for (const a of Array.from(e.actions || []))
            out.push({ icon: "play_arrow", text: a.name, act: () => { a.execute(); Ui.close() } })
        out.push({ sep: true })
        out.push({ icon: ctxPinned ? "keep_off" : "keep", text: ctxPinned ? "Remove from the dock" : "Pin to the dock",
                   act: () => { const l = (Config.c.pinned || []).filter(x => x !== e.id); if (!ctxPinned) l.push(e.id); Config.c.pinned = l } })
        out.push({ icon: "desktop_windows", text: ctxOnDesktop ? "Remove from the desktop" : "Add to the desktop",
                   act: () => { const l = (Config.c.desktopApps || []).filter(x => x !== e.id); if (!ctxOnDesktop) l.push(e.id); Config.c.desktopApps = l; Config.c.desktopIcons = true } })
        out.push({ icon: "rocket_launch", text: "Start at login",
                   act: () => Quickshell.execDetached(["python3", "-I", Quickshell.shellDir + "/scripts/autostart.py", "add", e.id]) })
        out.push({ sep: true })
        const u = ctxInfo ? ctxInfo.uninstall : ""
        out.push({ icon: "delete", text: "Uninstall…", sub: ctxInfo ? (u !== "" ? "From " + (ctxInfo.source === "rpm" ? "system packages" : ctxInfo.source) + ", you confirm in a terminal" : "Cannot be removed from here") : "Looking…",
                   off: u === "", danger: true,
                   act: () => Quickshell.execDetached(["sh", Quickshell.shellDir + "/scripts/run-in-terminal.sh", "Uninstall " + e.name, u]) })
        out.push({ icon: "info", text: "About this app", act: () => Ui.openSettings("apps") })
        return out
    }
    above: Item {
        anchors.fill: parent
        AppIcon {
            visible: p.carry !== null
            entry: p.carry
            size: p.iconPx
            x: p.carryX - size / 2
            y: p.carryY - size / 2
            opacity: 0.9
        }
        // a click anywhere else closes the menu
        MouseArea { anchors.fill: parent; visible: p.ctxEntry !== null; acceptedButtons: Qt.AllButtons; onPressed: p.closeCtx() }
        Rectangle {
            id: ctxMenu
            visible: p.ctxEntry !== null
            width: 270; height: ctxCol.implicitHeight + 12
            x: Math.max(8, Math.min(parent.width - width - 8, p.ctxX))
            y: Math.max(8, Math.min(parent.height - height - 8, p.ctxY))
            radius: 16
            color: Theme.cardSolid
            border.width: 1; border.color: Theme.stroke
            Column {
                id: ctxCol
                x: 6; y: 6; width: parent.width - 12
                spacing: 1
                Repeater {
                    model: p.ctxItems
                    delegate: Item {
                        id: ci
                        required property var modelData
                        width: ctxCol.width
                        height: modelData.sep ? 9 : (modelData.sub ? 50 : 40)
                        Rectangle { visible: ci.modelData.sep === true; anchors.centerIn: parent; width: parent.width - 16; height: 1; color: Theme.stroke }
                        Rectangle {
                            visible: !ci.modelData.sep
                            anchors.fill: parent; radius: 10
                            color: cma.containsMouse && !ci.modelData.off ? Theme.hover : "transparent"
                            Icon { id: cic; x: 10; anchors.verticalCenter: parent.verticalCenter; size: 20; name: ci.modelData.icon || ""
                                   color: ci.modelData.danger && !ci.modelData.off ? "#E5484D" : Theme.text; opacity: ci.modelData.off ? 0.4 : 1 }
                            Column {
                                anchors { left: cic.right; leftMargin: 12; right: parent.right; rightMargin: 8; verticalCenter: parent.verticalCenter }
                                DText { width: parent.width; elide: Text.ElideRight; text: ci.modelData.text || ""; font.pixelSize: 14; opacity: ci.modelData.off ? 0.4 : 1
                                        color: ci.modelData.danger && !ci.modelData.off ? "#E5484D" : Theme.text }
                                DText { visible: !!ci.modelData.sub; width: parent.width; elide: Text.ElideRight; text: ci.modelData.sub || ""; font.pixelSize: 11; color: Theme.subtext }
                            }
                            MouseArea {
                                id: cma
                                anchors.fill: parent; hoverEnabled: true
                                cursorShape: ci.modelData.off ? Qt.ArrowCursor : Qt.PointingHandCursor
                                onClicked: { if (ci.modelData.off) return; const f = ci.modelData.act; p.closeCtx(); if (f) f() }
                            }
                        }
                    }
                }
            }
        }
    }

    function go(d) {
        if (results.length === 0) return
        keyNav = true
        cur = Math.max(0, Math.min(results.length - 1, cur + d))
        if (grid) {
            gf.positionViewAtIndex(Math.floor(cur / cols), ListView.Contain)
        } else {
            lv.positionViewAtIndex(cur, ListView.Contain)
        }
    }

    ArqField {
        id: field
        anchors.left: parent.left; anchors.right: parent.right; anchors.margins: 16
        height: Sizes.hM
        // positioned with y (not by swapping top/bottom anchors) so switching layout live can't stretch it
        y: p.grid ? parent.height - height - 16 : 16
        placeholder: "Search apps"
        navSideways: p.grid
        iconName: "search"
        onEdited: { p.cur = 0; p.keyNav = text !== ""; gf.positionViewAtBeginning(); lv.positionViewAtBeginning() }
        onAccepted: if (p.results.length > 0) Ui.launch(p.results[Math.min(p.cur, p.results.length - 1)])
        onNav: key => {
            if (key === Qt.Key_Down) p.go(p.grid ? p.cols : 1)
            else if (key === Qt.Key_Up) p.go(p.grid ? -p.cols : -1)
            else if (key === Qt.Key_Right) p.go(1)
            else if (key === Qt.Key_Left) p.go(-1)
        }
    }

    // ---------------- grid (every row centred, including the last, shorter one) ----------------
    // A ListView of rows: only the rows you can see are made (with a few hundred apps, making
    // every icon at every key press was what made the launcher slow to open and to type in)
    ListView {
        id: gf
        visible: p.grid
        anchors.left: parent.left; anchors.right: parent.right; anchors.margins: 16
        anchors.top: parent.top
        anchors.bottom: parent.bottom
        anchors.bottomMargin: 16 + field.height + 12
        clip: true
        boundsBehavior: Flickable.StopAtBounds
        cacheBuffer: p.cellH * 2
        reuseItems: false
        model: p.grid ? Math.ceil(p.results.length / p.cols) : 0
        delegate: Item {
            id: rowItem
            required property int index
            width: gf.width
            height: p.cellH
            // comes in (fades, slides up a little) when the launcher opens or the results change
            opacity: 0
            property real slide: 0
            transform: Translate { y: rowItem.slide }
            Component.onCompleted: {
                if (p.fresh() && index < 8) { rowIn.delay = index * 28; rowIn.start() }
                else opacity = 1
            }
            Connections { target: p; function onOpenSerialChanged() { if (rowItem.index < 8) { rowIn.delay = rowItem.index * 28 + 40; rowIn.restart() } } }
            SequentialAnimation {
                id: rowIn
                property int delay: 0
                ScriptAction { script: { rowItem.opacity = 0; rowItem.slide = 18 } }
                PauseAnimation { duration: rowIn.delay }
                ParallelAnimation {
                    NumberAnimation { target: rowItem; property: "opacity"; to: 1; duration: 200; easing.type: Easing.OutCubic }
                    NumberAnimation { target: rowItem; property: "slide"; to: 0; duration: 380; easing.type: Easing.OutBack; easing.overshoot: Motion.os(1.4) }
                }
            }
            Row {
                anchors.horizontalCenter: parent.horizontalCenter
                Repeater {
                    model: Math.max(0, Math.min(p.cols, p.results.length - rowItem.index * p.cols))
                    delegate: Item {
                        id: gd
                        required property int index
                        readonly property int idx: rowItem.index * p.cols + index
                        readonly property var entry: p.results[idx]
                        width: p.cellW; height: p.cellH
                        Rectangle {
                            anchors.fill: parent; anchors.margins: 2; radius: 16
                            color: ((p.keyNav && gd.idx === p.cur) || gma.containsMouse) && !p.carry ? Theme.hover : "transparent"
                            Behavior on color { ColorAnimation { duration: 90 } }
                        }
                        AppIcon {
                            anchors.horizontalCenter: parent.horizontalCenter
                            y: 10
                            size: p.iconPx
                            entry: gd.entry
                            scale: gma.pressed ? 0.88 : (gma.containsMouse ? 1.06 : 1)
                            Behavior on scale { NumberAnimation { duration: 220; easing.type: Easing.OutBack; easing.overshoot: Motion.os(2) } }
                        }
                        DText {
                            anchors.left: parent.left; anchors.right: parent.right
                            anchors.leftMargin: 6; anchors.rightMargin: 6
                            y: 10 + p.iconPx + 6
                            text: gd.entry ? gd.entry.name : ""
                            horizontalAlignment: Text.AlignHCenter
                            wrapMode: Text.Wrap
                            maximumLineCount: 2
                            elide: Text.ElideRight
                            lineHeight: 0.95
                            font.pixelSize: 12
                        }
                        HoverTip { hovered: gma.containsMouse; text: gd.entry ? gd.entry.name : "" }
                        MouseArea {
                            id: gma
                            anchors.fill: parent
                            hoverEnabled: true
                            cursorShape: Qt.PointingHandCursor
                            pressAndHoldInterval: 400
                            preventStealing: true
                            onPositionChanged: mouse => {
                                if (p.carry) { p.moveCarry(gma, mouse.x, mouse.y); return }
                                p.keyNav = false; p.cur = gd.idx
                            }
                            onPressAndHold: mouse => p.startCarry(gd.entry, gma, mouse.x, mouse.y)
                            onReleased: if (p.carry) p.endCarry()
                            onCanceled: p.carry = null
                            acceptedButtons: Qt.LeftButton | Qt.RightButton
                            onClicked: mouse => { if (!gd.entry) return; if (mouse.button === Qt.RightButton) p.openCtx(gd.entry, gma, mouse.x, mouse.y); else Ui.launch(gd.entry) }
                        }
                    }
                }
            }
        }
    }

    // ---------------- list ----------------
    ListView {
        id: lv
        visible: !p.grid
        anchors.left: parent.left; anchors.right: parent.right; anchors.margins: 16
        anchors.top: parent.top
        anchors.topMargin: 16 + field.height + 12
        anchors.bottom: parent.bottom
        clip: true
        boundsBehavior: Flickable.StopAtBounds
        model: p.grid ? [] : p.results
        delegate: Item {
            id: ld
            required property var modelData
            required property int index
            width: lv.width
            height: Math.max(46, p.iconPx + 14)
            opacity: 0
            property real slide: 0
            transform: Translate { x: ld.slide }
            Component.onCompleted: {
                if (p.fresh() && index < 10) { ldIn.delay = index * 22; ldIn.start() }
                else opacity = 1
            }
            Connections { target: p; function onOpenSerialChanged() { if (ld.index < 10) { ldIn.delay = ld.index * 22 + 40; ldIn.restart() } } }
            SequentialAnimation {
                id: ldIn
                property int delay: 0
                ScriptAction { script: { ld.opacity = 0; ld.slide = -16 } }
                PauseAnimation { duration: ldIn.delay }
                ParallelAnimation {
                    NumberAnimation { target: ld; property: "opacity"; to: 1; duration: 180; easing.type: Easing.OutCubic }
                    NumberAnimation { target: ld; property: "slide"; to: 0; duration: 340; easing.type: Easing.OutBack; easing.overshoot: Motion.os(1.4) }
                }
            }
            Rectangle {
                anchors.fill: parent; anchors.topMargin: 1; anchors.bottomMargin: 1; radius: 14
                color: ((p.keyNav && ld.index === p.cur) || lma.containsMouse) && !p.carry ? Theme.hover : "transparent"
            }
            AppIcon {
                anchors.left: parent.left; anchors.leftMargin: 12
                anchors.verticalCenter: parent.verticalCenter
                size: p.iconPx
                entry: ld.modelData
            }
            DText {
                anchors.left: parent.left; anchors.leftMargin: 24 + p.iconPx
                anchors.right: parent.right; anchors.rightMargin: 12
                anchors.verticalCenter: parent.verticalCenter
                text: ld.modelData.name
                elide: Text.ElideRight
                font.pixelSize: 15
            }
            MouseArea {
                id: lma
                anchors.fill: parent
                hoverEnabled: true
                cursorShape: Qt.PointingHandCursor
                pressAndHoldInterval: 400
                preventStealing: true
                onPositionChanged: mouse => {
                    if (p.carry) { p.moveCarry(lma, mouse.x, mouse.y); return }
                    p.keyNav = false; p.cur = ld.index
                }
                onPressAndHold: mouse => p.startCarry(ld.modelData, lma, mouse.x, mouse.y)
                onReleased: if (p.carry) p.endCarry()
                onCanceled: p.carry = null
                acceptedButtons: Qt.LeftButton | Qt.RightButton
                onClicked: mouse => { if (mouse.button === Qt.RightButton) p.openCtx(ld.modelData, lma, mouse.x, mouse.y); else Ui.launch(ld.modelData) }
            }
        }
    }
}
