import Quickshell
import Quickshell.Io
import Quickshell.Wayland
import Quickshell.Hyprland
import QtQuick
import qs.config
import qs.components
import qs.services

// The window handle (like the bar at the top of a phone's pop-up windows): the window you are using
// has a short line at its top. Drag the line to move the window, or click it and a small bar opens there
// with: move (hold and drag), maximise, full screen, snap (halves, corners, centre), minimise to the side
// panel, close. Other windows show a fainter line too: click it and that window comes forward, above the rest.
// Click the line again, press Esc or use another window to close it; left alone (pointer off the bar) it closes after 0.6 s. Colour and size:
// Settings > Display and windows. The windows' places come from EdgeTuck's look.
Scope {
    id: root
    readonly property bool on: Config.c.winHandle && (Config.c.windowMode || "floating") === "floating" && !Ui.locked && Config.hyprChecked && Ui.open === ""
    // Configurable anchor on the active window. Side anchors use a vertical grab line.
    readonly property string position: Config.c.winHandlePosition || "top-center"
    readonly property bool verticalHandle: position.startsWith("left-") || position.startsWith("right-")
    readonly property real fx: position.endsWith("start") ? 0.15 : (position.endsWith("end") ? 0.85 : 0.5)
    readonly property real fy: position.startsWith("bottom-") ? -1 : (position.startsWith("left-") || position.startsWith("right-") ? 0.5 : 2)
    readonly property real k: Math.max(0.6, Math.min(1.6, (Config.c.winHandleSize || 100) / 100))

    // ---- the window it is for: the one you are using ----
    readonly property string activeAddr: Hyprland.activeToplevel?.address ? "0x" + String(Hyprland.activeToplevel.address).replace(/^0x/, "") : ""
    property var target: null
    property bool fsTarget: false             // the window is in full screen
    function pickTarget() {
        if (dragging) return
        const shownWs = EdgeTuck.mons.map(m => m.activeWorkspace?.id ?? -999)
        const c = EdgeTuck.lastClients.find(x => x.address === activeAddr)
        // full screen and maximised windows have the handle too: on a full screen one it hides itself and
        // comes back where it was when the pointer goes there
        const ok = c && c.mapped !== false && !c.hidden && shownWs.indexOf(c.workspace?.id) >= 0 && c.size[0] > 120
        if (!ok) { target = null; shown = false; fsTarget = false; return }
        fsTarget = (c.fullscreen ?? 0) === 2
        if (target && target.address !== c.address) shown = false
        target = c
        if (target) hw.placeNow()
    }
    onActiveAddrChanged: { pickTarget(); refreshOthers() }
    Connections { target: EdgeTuck; function onLastClientsChanged() { root.pickTarget() } }
    Component.onCompleted: pickTarget()

    // ---- the other windows' lines: a click brings that window forward, above the others ----
    property var others: []
    function refreshOthers() {
        if (!on || dragging) { others = []; return }
        const shownWs = EdgeTuck.mons.map(m => m.activeWorkspace?.id ?? -999)
        const vis = EdgeTuck.lastClients.filter(x => x.mapped !== false && !x.hidden && shownWs.indexOf(x.workspace?.id) >= 0 && x.size[0] > 120)
        const lw = verticalHandle ? Math.round(20 * k) : Math.round(48 * k) + 24
        const lh = verticalHandle ? Math.round(48 * k) + 16 : Math.round(20 * k)
        const out = []
        for (const c of vis) {
            if (c.address === activeAddr || (c.fullscreen ?? 0) > 0) continue
            const b = barPos(c, lw, lh)
            const px = b.x + lw / 2, py = b.y + lh / 2
            // hidden behind a window used more recently (and so probably above it)
            const covered = vis.some(d => d.address !== c.address && (d.focusHistoryID ?? 99) < (c.focusHistoryID ?? 99)
                && px >= d.at[0] && px < d.at[0] + d.size[0] && py >= d.at[1] && py < d.at[1] + d.size[1])
            if (!covered) out.push({ address: c.address, x: b.x, y: b.y, w: lw, h: lh })
        }
        others = out
    }
    Connections { target: EdgeTuck; function onLastClientsChanged() { root.refreshOthers() } }
    // focus a window and put it above the others; its own bar opens
    function bringForward(a) {
        Hypr.focusWindow(a)
        raiseLater.addr = a
        raiseLater.restart()
    }
    Timer {
        id: raiseLater
        property string addr: ""
        interval: 60
        onTriggered: { Hypr.raiseWindow(addr); root.shown = true }
    }

    // the bar is open (after a click on the line)
    property bool shown: false
    function hide() { shown = false }
    onOnChanged: { if (!on) hide(); refreshOthers() }

    // the bar's place on a window (its top-left corner), kept inside the window
    function barPos(c, w, h) {
        const px = position.startsWith("left-") ? 2 : (position.startsWith("right-") ? c.size[0] - w - 2 : c.size[0] * fx - w / 2)
        const py = position.startsWith("top-") ? 2 : (position.startsWith("bottom-") ? c.size[1] - h - 2 : c.size[1] * fx - h / 2)
        return { x: c.at[0] + Math.max(0, Math.min(c.size[0] - w, px)), y: c.at[1] + Math.max(0, Math.min(c.size[1] - h, py)) }
    }
    property real barW: 200
    property real barH: 52
    // ---- dragging the window: by the line itself, or by the move button in the open bar ----
    // The pointer is read from Hyprland quickly while dragging (whole-desktop positions), so the handle can
    // travel with the window without its own moving throwing the numbers off.
    property bool dragging: false
    property bool fromLine: false             // the drag began on the closed line (a short click still opens the bar)
    property bool moved: false                // the pointer has gone far enough for it to be a drag, not a click
    property var dragStart: null              // { px, py, wx, wy, bx, by }
    property point dragTo: Qt.point(0, 0)
    property point barTo: Qt.point(0, 0)
    Process {
        running: root.dragging
        command: ["python3", "-u", Quickshell.shellDir + "/scripts/cursor-watch.py", "0.016"]
        stdout: SplitParser {
            onRead: line => {
                const p = line.trim().split(/\s+/)
                if (p.length < 2 || !root.dragStart) return
                const x = +p[0], y = +p[1]
                if (root.dragStart.px < -9999) { root.dragStart.px = x; root.dragStart.py = y; return }   // the first reading: where it starts
                const dx = x - root.dragStart.px, dy = y - root.dragStart.py
                if (!root.moved) {
                    if (Math.abs(dx) + Math.abs(dy) < 6) return                  // still a click
                    root.moved = true
                }
                root.dragTo = Qt.point(root.dragStart.wx + dx, root.dragStart.wy + dy)
                root.barTo = Qt.point(root.dragStart.bx + dx, root.dragStart.by + dy)
            }
        }
    }
    function startDrag(fromTheLine) {
        const t = target
        if (!t) return
        fromLine = fromTheLine === true
        moved = !fromLine                      // from the button it is a drag at once; from the line, once it has moved
        // Do not turn tiled windows into floating windows when dragging the Arqen handle.
        // Native Hyprland Super+mouse bindings remain responsible for moving tiled windows.
        if (!t.floating) {
            if (fromLine) { shown = true; return }
            return
        }
        dragStart = { px: -99999, py: -99999, wx: t.at[0], wy: t.at[1], bx: hw.gx, by: hw.gy }
        dragTo = Qt.point(t.at[0], t.at[1])
        barTo = Qt.point(hw.gx, hw.gy)
        dragging = true
    }
    function endDrag() {
        if (!dragging) return
        const t = target
        const wasClick = fromLine && !moved
        if (!wasClick && t) {
            Hypr.moveWindowTo(t.address, dragTo.x, dragTo.y)
            // the window's new place, until the next look says so
            target = Object.assign({}, t, { at: [Math.round(dragTo.x), Math.round(dragTo.y)], floating: true })
        }
        dragging = false
        fromLine = false
        moved = false
        if (wasClick) shown = true             // a click on the line: open the bar
        hw.placeNow()
    }
    Timer {
        id: dragSend
        interval: 16; repeat: true
        running: root.dragging && root.moved
        property point last: Qt.point(-99999, -99999)
        onTriggered: {
            if (root.dragTo.x === last.x && root.dragTo.y === last.y) return
            last = root.dragTo
            Hypr.moveWindowTo(root.target.address, root.dragTo.x, root.dragTo.y)
        }
    }

    function act(what) {
        const t = target
        if (!t) return
        const a = t.address
        hide()
        if (what === "close") Hypr.closeWindow(a)
        else if (what === "tuck") EdgeTuck.tuckWindow(a)
        else if (what.indexOf("snap:") === 0) snapTo(t, what.slice(5))
        else if (what === "max" || what === "full") { Hypr.focusWindow(a); Qt.callLater(() => Hypr.fullscreenActive(what === "max")) }
        else if (what === "focus") bringForward(a)
    }

    // ---- snap: a floating window to a half of the screen it is on (or a centred, comfortable size) ----
    property var snapJob: null
    function snapTo(t, kind) {
        // the screen it is on, minus the panels
        const cx = t.at[0] + t.size[0] / 2, cy = t.at[1] + t.size[1] / 2
        const mons = EdgeTuck.mons.map(m => {
            const sc = m.scale || 1
            const rot = (m.transform || 0) % 2 === 1
            return { x: m.x, y: m.y, w: (rot ? m.height : m.width) / sc, h: (rot ? m.width : m.height) / sc, r: m.reserved || [0, 0, 0, 0] }
        })
        const m = mons.find(q => cx >= q.x && cx < q.x + q.w && cy >= q.y && cy < q.y + q.h) ?? mons[0]
        if (!m) return
        const g = 8
        const ax = m.x + m.r[0] + g, ay = m.y + m.r[1] + g
        const aw = m.w - m.r[0] - m.r[2] - 2 * g, ah = m.h - m.r[1] - m.r[3] - 2 * g
        let r
        if (kind === "left") r = [ax, ay, (aw - g) / 2, ah]
        else if (kind === "right") r = [ax + (aw + g) / 2, ay, (aw - g) / 2, ah]
        else if (kind === "top") r = [ax, ay, aw, (ah - g) / 2]
        else if (kind === "bottom") r = [ax, ay + (ah + g) / 2, aw, (ah - g) / 2]
        else if (kind === "topleft") r = [ax, ay, (aw - g) / 2, (ah - g) / 2]
        else if (kind === "topright") r = [ax + (aw + g) / 2, ay, (aw - g) / 2, (ah - g) / 2]
        else if (kind === "bottomleft") r = [ax, ay + (ah + g) / 2, (aw - g) / 2, (ah - g) / 2]
        else if (kind === "bottomright") r = [ax + (aw + g) / 2, ay + (ah + g) / 2, (aw - g) / 2, (ah - g) / 2]
        else r = [ax + aw * 0.15, ay + ah * 0.1, aw * 0.7, ah * 0.8]          // centre
        // out of full screen / maximised first
        const fs = t.fullscreen ?? 0
        if (fs > 0) { Hypr.focusWindow(t.address); Hypr.fullscreenActive(fs === 1) }
        if (!t.floating) Hypr.toggleFloat(t.address)
        snapJob = { addr: t.address, r: r }
        snapTimer.interval = fs > 0 ? 300 : 90
        snapTimer.restart()
    }
    Timer {
        id: snapTimer
        interval: 90                                   // after it has become floating
        onTriggered: {
            const j = root.snapJob
            if (!j) return
            Hypr.resizeWindowTo(j.addr, j.r[2], j.r[3])
            Hypr.moveWindowTo(j.addr, j.r[0], j.r[1])
            Hypr.raiseWindow(j.addr)
            root.snapJob = null
        }
    }

    PanelWindow {
        id: hw
        readonly property var scr: {
            const t = root.target
            if (!t) return Quickshell.screens[0]
            const cx = t.at[0] + t.size[0] / 2, cy = t.at[1] + 10
            return Quickshell.screens.find(s => cx >= s.x && cx < s.x + s.width && cy >= s.y && cy < s.y + s.height) ?? Quickshell.screens[0]
        }
        screen: scr
        visible: (root.on && root.target !== null) || root.dragging
        color: "transparent"
        exclusionMode: ExclusionMode.Ignore
        anchors { top: true; left: true }
        WlrLayershell.namespace: "arqen-window-handle"
        // a full screen window covers the Top layer, the Overlay layer stays above it
        WlrLayershell.layer: root.fsTarget ? WlrLayer.Overlay : WlrLayer.Top
        WlrLayershell.keyboardFocus: root.shown ? WlrKeyboardFocus.OnDemand : WlrKeyboardFocus.None
        readonly property bool open: root.shown || (root.dragging && !root.fromLine)
        property bool snapOpen: false
        onOpenChanged: if (!open) snapOpen = false
        // Side handles use a genuinely tall, narrow layer surface. Keep the content
        // inside the layer's dimensions so the compositor does not clip it.
        implicitWidth: root.verticalHandle ? (open ? pill.height + 16 : Math.round(20 * root.k)) : (open ? pill.width + 16 : line.width + 24)
        implicitHeight: root.verticalHandle ? (open ? pill.width + 16 : line.height + 16) : (open ? pill.height + 16 : Math.round(20 * root.k))
        // its place on the window (kept on the screen); while dragging it goes where the drag takes it
        property real gx: 0
        property real gy: 0
        readonly property real ax: root.dragging ? root.barTo.x : gx
        readonly property real ay: root.dragging ? root.barTo.y : gy
        function placeNow() {
            const t = root.target
            if (!t || root.dragging) return
            root.barW = implicitWidth; root.barH = implicitHeight
            const b = root.barPos(t, implicitWidth, implicitHeight)
            // the line sits just inside the window's top; the open bar where it was set
            const by = open ? b.y : Math.max(b.y, t.at[1] + 2)
            gx = Math.max(scr.x, Math.min(scr.x + scr.width - implicitWidth, b.x))
            gy = Math.max(scr.y, Math.min(scr.y + scr.height - implicitHeight, by))
        }
        onImplicitWidthChanged: placeNow()
        onImplicitHeightChanged: placeNow()
        Connections {
            target: root
            function onTargetChanged() { hw.placeNow() }
            function onShownChanged() { hw.placeNow(); if (root.shown) openAnim.restart() }
            function onPositionChanged() { hw.placeNow() }
            function onKChanged() { hw.placeNow() }
        }
        margins { left: Math.round(Math.max(0, Math.min(scr.width - implicitWidth, ax - scr.x))); top: Math.round(Math.max(0, Math.min(scr.height - implicitHeight, ay - scr.y))) }

        // the accent colour, or one you picked (Settings > Display and windows)
        readonly property string look: Config.c.winHandleColor === "custom" && /^#[0-9a-fA-F]{6}$/.test(Config.c.winHandleCustom || "") ? "custom" : "accent"
        readonly property color bg: look === "custom" ? Config.c.winHandleCustom : Theme.primary
        // dark marks on a light colour, light on a dark one
        readonly property color fg: look === "accent" ? Theme.onPrimary : (0.299 * bg.r + 0.587 * bg.g + 0.114 * bg.b > 0.6 ? "#16161A" : "#FFFFFF")

        // ---- closed: a short line; click it to open the bar ----
        Item {
            anchors.fill: parent
            visible: !hw.open
            // on a full screen window the line is out of sight until the pointer is on it
            opacity: root.fsTarget && !lma.containsMouse ? 0 : 1
            Behavior on opacity { NumberAnimation { duration: 140 } }
            Rectangle {
                id: line
                anchors.centerIn: parent
                width: root.verticalHandle ? Math.round((lma.containsMouse ? 7 : 5) * root.k) : Math.round((lma.containsMouse ? 64 : 48) * root.k)
                height: root.verticalHandle ? Math.round((lma.containsMouse ? 64 : 48) * root.k) : Math.round((lma.containsMouse ? 7 : 5) * root.k)
                radius: height / 2
                color: hw.bg
                opacity: lma.containsMouse ? 1 : 0.75
                border.width: hw.look === "accent" ? 0 : 1
                border.color: Theme.stroke
                Behavior on width { NumberAnimation { duration: 140; easing.type: Easing.OutCubic } }
            }
            // drag the line to move the window; a click (no movement) opens the bar
            MouseArea {
                id: lma
                anchors.fill: parent
                hoverEnabled: true
                preventStealing: true
                cursorShape: pressed && root.moved ? Qt.ClosedHandCursor : Qt.OpenHandCursor
                onPressed: root.startDrag(true)
                onReleased: root.endDrag()
                onCanceled: root.endDrag()
            }
            HoverTip { hovered: lma.containsMouse && !root.dragging; text: "Drag: move the window  ·  click: window options"; side: "bottom" }
        }

        // ---- open: the bar ----
        property real t: 1
        NumberAnimation { id: openAnim; target: hw; property: "t"; from: 0; to: 1; duration: 180; easing.type: Easing.OutCubic }
        Rectangle {
            id: pill
            visible: hw.open
            x: root.verticalHandle ? 8 - 6 * (1 - hw.t) : 8; y: root.verticalHandle ? 8 : 8 - 6 * (1 - hw.t)
            opacity: hw.t
            width: root.verticalHandle ? Math.max(row.implicitWidth, snapRow.implicitWidth) + 12 * root.k : (hw.snapOpen ? snapRow.implicitWidth : row.implicitWidth) + 12 * root.k
            height: root.verticalHandle ? (hw.snapOpen ? snapRow.implicitHeight : row.implicitHeight) + 12 * root.k : Math.round(36 * root.k)
            radius: height / 2
            color: hw.bg
            border.width: hw.look === "accent" ? 0 : 1
            border.color: Theme.stroke
            focus: root.shown
            Keys.onEscapePressed: root.hide()
            HoverHandler { id: pillHover }
            // left alone for a while: closes again
            Timer { interval: 600; running: root.shown && !pillHover.hovered && !root.dragging; onTriggered: root.hide() }
            Grid {
                id: row
                columns: root.verticalHandle ? 1 : 99
                visible: !hw.snapOpen
                anchors.centerIn: parent
                spacing: Math.round(2 * root.k)
                Repeater {
                    // icons people already know: arrows = move, square = maximise, corners = full screen,
                    // little screen = snap / tile, dash = minimise (to the side panel), cross = close
                    model: [["open_with", "Move: hold and drag", "move"],
                            ["crop_square", "Maximise", "max"], ["fullscreen", "Full screen", "full"], ["snapglyph", "Snap and tile: halves, corners, centre", "snap"], ["remove", "Minimise to the side panel", "tuck"],
                            ["close", "Close the window", "close"]]
                    delegate: Rectangle {
                        id: b
                        required property var modelData
                        visible: modelData[2] !== "tuck" || Config.c.edgeTuck
                        readonly property bool mover: modelData[2] === "move"
                        width: Math.round(30 * root.k); height: width; radius: width / 2
                        color: bm.containsMouse || (mover && root.dragging) ? Qt.rgba(hw.fg.r, hw.fg.g, hw.fg.b, 0.16) : "transparent"
                        Icon {
                            visible: b.modelData[0] !== "snapglyph"
                            anchors.centerIn: parent
                            name: b.modelData[0] === "snapglyph" ? "" : b.modelData[0]; size: Math.round(18 * root.k)
                            color: b.modelData[2] === "close" && bm.containsMouse ? "#FF5A5A" : hw.fg
                        }
                        // snap: a little screen with the window in one corner
                        Rectangle {
                            visible: b.modelData[0] === "snapglyph"
                            anchors.centerIn: parent
                            width: Math.round(17 * root.k); height: Math.round(13 * root.k)
                            radius: 2; color: "transparent"; border.width: 1.5; border.color: hw.fg
                            Rectangle { x: 1.5; y: 1.5; width: (parent.width - 3) / 2; height: (parent.height - 3) / 2; color: hw.fg; opacity: 0.85 }
                        }
                        MouseArea {
                            id: bm
                            anchors.fill: parent; hoverEnabled: true
                            cursorShape: b.mover ? (pressed ? Qt.ClosedHandCursor : Qt.OpenHandCursor) : Qt.PointingHandCursor
                            preventStealing: true
                            onPressed: if (b.mover) root.startDrag(false)
                            onReleased: if (b.mover) root.endDrag()
                            onCanceled: if (b.mover) root.endDrag()
                            onClicked: { if (b.modelData[2] === "hide") root.hide(); else if (b.modelData[2] === "snap") hw.snapOpen = true; else if (!b.mover) root.act(b.modelData[2]) }
                        }
                        HoverTip { hovered: bm.containsMouse && !root.dragging; text: b.modelData[1]; side: "bottom" }
                    }
                }
            }
            // ---- snap: where to put the window ----
            Grid {
                id: snapRow
                columns: root.verticalHandle ? 1 : 99
                visible: hw.snapOpen
                anchors.centerIn: parent
                spacing: Math.round(2 * root.k)
                Rectangle {
                    width: Math.round(30 * root.k); height: width; radius: width / 2
                    color: bkm.containsMouse ? Qt.rgba(hw.fg.r, hw.fg.g, hw.fg.b, 0.16) : "transparent"
                    Icon { anchors.centerIn: parent; name: "chevron_left"; size: Math.round(18 * root.k); color: hw.fg }
                    MouseArea { id: bkm; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: hw.snapOpen = false }
                    HoverTip { hovered: bkm.containsMouse; text: "Back"; side: "bottom" }
                }
                Repeater {
                    // [which, name, filled part: x, y, w, h as shares of the little screen]
                    model: [["topleft", "Top-left corner", 0, 0, 0.5, 0.5], ["topright", "Top-right corner", 0.5, 0, 0.5, 0.5],
                            ["bottomleft", "Bottom-left corner", 0, 0.5, 0.5, 0.5], ["bottomright", "Bottom-right corner", 0.5, 0.5, 0.5, 0.5],
                            ["left", "Left half", 0, 0, 0.5, 1], ["right", "Right half", 0.5, 0, 0.5, 1], ["top", "Top half", 0, 0, 1, 0.5],
                            ["bottom", "Bottom half", 0, 0.5, 1, 0.5], ["center", "Centred", 0.2, 0.2, 0.6, 0.6]]
                    delegate: Rectangle {
                        id: sb
                        required property var modelData
                        width: Math.round(30 * root.k); height: width; radius: width / 2
                        color: sm.containsMouse ? Qt.rgba(hw.fg.r, hw.fg.g, hw.fg.b, 0.16) : "transparent"
                        // a little screen with the part the window takes filled
                        Rectangle {
                            anchors.centerIn: parent
                            width: Math.round(18 * root.k); height: Math.round(13 * root.k)
                            radius: 2; color: "transparent"
                            border.width: 1.5; border.color: hw.fg
                            Rectangle {
                                x: 1.5 + (parent.width - 3) * sb.modelData[2]; y: 1.5 + (parent.height - 3) * sb.modelData[3]
                                width: (parent.width - 3) * sb.modelData[4]; height: (parent.height - 3) * sb.modelData[5]
                                color: hw.fg; opacity: 0.85
                            }
                        }
                        MouseArea { id: sm; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: root.act("snap:" + sb.modelData[0]) }
                        HoverTip { hovered: sm.containsMouse; text: sb.modelData[1]; side: "bottom" }
                    }
                }
            }
        }
    }

    // ---- a faint line on every other window: click to bring it forward ----
    Repeater {
        model: root.others
        delegate: PanelWindow {
            id: ow
            required property var modelData
            readonly property var scr: Quickshell.screens.find(q => modelData.x + modelData.w / 2 >= q.x && modelData.x + modelData.w / 2 < q.x + q.width
                                                                    && modelData.y + modelData.h / 2 >= q.y && modelData.y + modelData.h / 2 < q.y + q.height) ?? Quickshell.screens[0]
            screen: scr
            visible: root.on
            color: "transparent"
            exclusionMode: ExclusionMode.Ignore
            anchors { top: true; left: true }
            implicitWidth: modelData.w; implicitHeight: modelData.h
            margins { left: Math.round(Math.max(0, modelData.x - scr.x)); top: Math.round(Math.max(0, modelData.y - scr.y)) }
            WlrLayershell.namespace: "arqen-window-handle-other"
            WlrLayershell.layer: WlrLayer.Top
            WlrLayershell.keyboardFocus: WlrKeyboardFocus.None
            Rectangle {
                anchors.centerIn: parent
                width: root.verticalHandle ? Math.round((oma.containsMouse ? 7 : 4) * root.k) : Math.round((oma.containsMouse ? 56 : 36) * root.k)
                height: root.verticalHandle ? Math.round((oma.containsMouse ? 56 : 36) * root.k) : Math.round((oma.containsMouse ? 7 : 4) * root.k)
                radius: Math.min(width, height) / 2
                color: hw.bg
                opacity: oma.containsMouse ? 0.95 : 0.4
                Behavior on opacity { NumberAnimation { duration: 120 } }
            }
            MouseArea {
                id: oma
                anchors.fill: parent
                hoverEnabled: true
                cursorShape: Qt.PointingHandCursor
                onClicked: root.bringForward(ow.modelData.address)
            }
            HoverTip { hovered: oma.containsMouse; text: "Click: bring this window to the front"; side: "bottom" }
        }
    }
}
