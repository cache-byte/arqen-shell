import Quickshell
import Quickshell.Widgets
import QtQuick
import QtQuick.Layouts
import qs.config
import qs.components
import qs.services

// Search: apps AND settings. Before you type it shows suggestions, settings topics and folders.
ArqPopup {
    id: p
    open: Ui.open === "search"
    wantsKeyboard: true
    liveContent: true
    position: Config.c.searchPos

    readonly property bool grid: Config.c.searchLayout !== "list"
    readonly property bool querying: field.text !== ""
    readonly property int iconPx: 44

    readonly property real usableWidth: Math.max(1, p.width - 2 * Ui.gap)
    readonly property real usableHeight: Math.max(1, p.height - 2 * Ui.gap)
    cardWidth: Math.min(usableWidth, Math.max(Math.min(380, usableWidth), p.width * Config.c.searchWidth / 100))
    cardHeight: Math.min(usableHeight,
                         Math.min(Math.max(Math.min(240, usableHeight), p.height * Config.c.searchHeight / 100),
                                  body.implicitHeight + field.height + 44))
    // grows and shrinks smoothly as results come and go (not while it opens: it starts at its size)
    Behavior on cardHeight { enabled: p.open && !p.moving; NumberAnimation { duration: 200; easing.type: Easing.OutCubic } }

    readonly property var apps: querying ? Apps.search(field.text).slice(0, 8)
                                         : (Config.c.searchSuggestions ? Apps.suggested(grid ? 8 : 6) : [])
    readonly property var sets: querying ? SettingsIndex.search(field.text).slice(0, 6) : []
    readonly property int total: querying ? apps.length + sets.length : 0
    property int cur: 0

    readonly property var topics: [
        { t: "Connections", k: "connections", i: "wifi" },
        { t: "Sounds", k: "sounds", i: "volume_up" },
        { t: "Display", k: "display", i: "brightness_6" },
        { t: "Wallpaper", k: "wallpaper", i: "wallpaper" },
        { t: "Panels", k: "panels", i: "dock_to_bottom" },
        { t: "Launcher", k: "launcher", i: "apps" },
        { t: "About", k: "about", i: "info" }
    ]

    onOpenChanged: if (open) { field.text = ""; cur = 0; field.focusInput() }

    function activate(i) {
        if (total === 0) return
        i = Math.max(0, Math.min(total - 1, i))
        if (i < apps.length) Ui.launch(apps[i])
        else Ui.openSettings(sets[i - apps.length].p)
    }

    Flickable {
        id: fl
        anchors.left: parent.left; anchors.right: parent.right; anchors.top: parent.top
        anchors.margins: 16
        anchors.bottom: parent.bottom
        anchors.bottomMargin: 16 + field.height + 12
        contentHeight: body.implicitHeight
        clip: true
        boundsBehavior: Flickable.StopAtBounds

        ColumnLayout {
            id: body
            width: fl.width
            spacing: 12

            // ---------- apps: suggestions or results ----------
            Rectangle {
                visible: p.apps.length > 0
                Layout.fillWidth: true
                implicitHeight: appsCol.implicitHeight + 28
                radius: 22; color: Theme.tile
                Enter { trigger: p.openSerial; delay: 30; from: 0.94 }
                ColumnLayout {
                    id: appsCol
                    anchors.left: parent.left; anchors.right: parent.right; anchors.top: parent.top
                    anchors.margins: 14
                    spacing: 6
                    DText { text: p.querying ? "Apps" : "Suggested apps"; font.weight: Font.Medium }

                    Flow {
                        visible: p.grid
                        Layout.fillWidth: true
                        spacing: 0
                        Repeater {
                            model: p.grid ? p.apps : []
                            delegate: Item {
                                id: td
                                required property var modelData
                                required property int index
                                width: 92; height: p.iconPx + 58
                                Rectangle {
                                    anchors.fill: parent; anchors.margins: 2; radius: 16
                                    color: (p.querying && td.index === p.cur) ? Theme.hover : (tma.containsMouse ? Theme.hover : "transparent")
                                }
                                AppIcon {
                                    anchors.horizontalCenter: parent.horizontalCenter
                                    y: 8
                                    size: p.iconPx
                                    entry: td.modelData
                                }
                                DText {
                                    anchors.left: parent.left; anchors.right: parent.right
                                    anchors.leftMargin: 5; anchors.rightMargin: 5
                                    y: 8 + p.iconPx + 6
                                    text: td.modelData.name
                                    horizontalAlignment: Text.AlignHCenter
                                    wrapMode: Text.Wrap
                                    maximumLineCount: 2
                                    elide: Text.ElideRight
                                    lineHeight: 0.95
                                    font.pixelSize: 12
                                }
                                HoverTip { hovered: tma.containsMouse; text: td.modelData.name }
                                MouseArea {
                                    id: tma
                                    anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor
                                    onClicked: Ui.launch(td.modelData)
                                }
                            }
                        }
                    }

                    ColumnLayout {
                        visible: !p.grid
                        Layout.fillWidth: true
                        spacing: 0
                        Repeater {
                            model: p.grid ? [] : p.apps
                            delegate: Item {
                                id: ad
                                required property var modelData
                                required property int index
                                Layout.fillWidth: true
                                implicitHeight: 48
                                Rectangle {
                                    anchors.fill: parent; anchors.topMargin: 1; anchors.bottomMargin: 1; radius: 14
                                    color: (p.querying && ad.index === p.cur) ? Theme.hover : (ama.containsMouse ? Theme.hover : "transparent")
                                }
                                AppIcon {
                                    anchors.left: parent.left; anchors.leftMargin: 10
                                    anchors.verticalCenter: parent.verticalCenter
                                    size: 32
                                    entry: ad.modelData
                                }
                                DText {
                                    anchors.left: parent.left; anchors.leftMargin: 54
                                    anchors.right: parent.right; anchors.rightMargin: 12
                                    anchors.verticalCenter: parent.verticalCenter
                                    text: ad.modelData.name
                                    elide: Text.ElideRight
                                    font.pixelSize: 14
                                }
                                MouseArea {
                                    id: ama
                                    anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor
                                    onClicked: Ui.launch(ad.modelData)
                                }
                            }
                        }
                    }
                }
            }

            // ---------- settings that match what you typed ----------
            Rectangle {
                visible: p.sets.length > 0
                Layout.fillWidth: true
                implicitHeight: setsCol.implicitHeight + 28
                radius: 22; color: Theme.tile
                Enter { trigger: p.openSerial; delay: 70; from: 0.94 }
                ColumnLayout {
                    id: setsCol
                    anchors.left: parent.left; anchors.right: parent.right; anchors.top: parent.top
                    anchors.margins: 14
                    spacing: 2
                    DText { text: "Settings"; font.weight: Font.Medium; Layout.bottomMargin: 4 }
                    Repeater {
                        model: p.sets
                        delegate: Item {
                            id: sd
                            required property var modelData
                            required property int index
                            Layout.fillWidth: true
                            implicitHeight: 54
                            Rectangle {
                                anchors.fill: parent; anchors.topMargin: 1; anchors.bottomMargin: 1; radius: 16
                                color: (p.apps.length + sd.index === p.cur) ? Theme.hover : (sma.containsMouse ? Theme.hover : "transparent")
                            }
                            Row {
                                x: 10
                                anchors.verticalCenter: parent.verticalCenter
                                spacing: 12
                                Rectangle {
                                    width: 36; height: 36; radius: 18
                                    color: SettingsIndex.pageColor(sd.modelData.p)
                                    Icon { anchors.centerIn: parent; name: sd.modelData.i; size: 20; color: "white" }
                                }
                                Column {
                                    anchors.verticalCenter: parent.verticalCenter
                                    DText { text: sd.modelData.t; font.pixelSize: 14 }
                                    DText { text: "Settings  ›  " + SettingsIndex.pageTitle(sd.modelData.p); font.pixelSize: 11; color: Theme.subtext }
                                }
                            }
                            MouseArea {
                                id: sma
                                anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor
                                onClicked: Ui.openSettings(sd.modelData.p)
                            }
                        }
                    }
                }
            }

            DText {
                visible: p.querying && p.total === 0
                text: "Nothing found for \"" + field.text + "\""
                color: Theme.subtext
                Layout.alignment: Qt.AlignHCenter
                Layout.topMargin: 8; Layout.bottomMargin: 8
            }

            // ---------- settings topics ----------
            Rectangle {
                visible: !p.querying && Config.c.searchTopics
                Layout.fillWidth: true
                implicitHeight: topicsCol.implicitHeight + 28
                radius: 22; color: Theme.tile
                Enter { trigger: p.openSerial; delay: 80; from: 0.94 }
                ColumnLayout {
                    id: topicsCol
                    anchors.left: parent.left; anchors.right: parent.right; anchors.top: parent.top
                    anchors.margins: 14
                    spacing: 10
                    DText { text: "Settings topics"; font.weight: Font.Medium }
                    Flow {
                        Layout.fillWidth: true; spacing: 8
                        Repeater {
                            model: p.topics
                            delegate: Rectangle {
                                id: chipBox
                                required property var modelData
                                height: 36; width: chip.implicitWidth + 32; radius: 18
                                color: cma.containsMouse ? Theme.hover : Theme.tile
                                Row {
                                    id: chip
                                    anchors.centerIn: parent; spacing: 6
                                    Icon { name: chipBox.modelData.i; size: 18; anchors.verticalCenter: parent.verticalCenter }
                                    DText { text: chipBox.modelData.t; font.pixelSize: 13; anchors.verticalCenter: parent.verticalCenter }
                                }
                                MouseArea {
                                    id: cma
                                    anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor
                                    onClicked: Ui.openSettings(chipBox.modelData.k)
                                }
                            }
                        }
                    }
                }
            }

            // ---------- quick folders ----------
            GridLayout {
                visible: !p.querying && Config.c.searchFolders
                Layout.fillWidth: true; columnSpacing: 12; rowSpacing: 12
                columns: 2
                Enter { trigger: p.openSerial; delay: 130; from: 0.94 }
                Repeater {
                    model: (Config.c.quickFolders && Config.c.quickFolders.length > 0)
                        ? Config.c.quickFolders.map(f => ({ n: f.n, d: f.d, i: p.folderIcon(f.n) }))
                        : [{ n: "Downloads", d: Config.home + "/Downloads", i: "download" }, { n: "Screenshots", d: Config.shotDir, i: "photo_camera" }]
                    delegate: Rectangle {
                        id: fBox
                        required property var modelData
                        Layout.fillWidth: true
                        implicitHeight: 56; radius: 22
                        color: fma.containsMouse ? Theme.hover : Theme.tile
                        Row {
                            anchors.verticalCenter: parent.verticalCenter; x: 16; spacing: 12
                            Icon { name: fBox.modelData.i; size: 24; color: Theme.tertiary; anchors.verticalCenter: parent.verticalCenter }
                            DText { text: fBox.modelData.n; font.weight: Font.Medium; anchors.verticalCenter: parent.verticalCenter }
                        }
                        MouseArea {
                            id: fma
                            anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor
                            onClicked: { Ui.close(); QuickSettings.openFolder(fBox.modelData.d) }
                        }
                    }
                }
            }
        }
    }

    function folderIcon(n) {
        const l = String(n).toLowerCase()
        return /down/.test(l) ? "download" : /shot|screen/.test(l) ? "photo_camera" : /pic|photo|image/.test(l) ? "image" : /video|movie/.test(l) ? "movie" : /music|audio/.test(l) ? "music_note" : /doc/.test(l) ? "description" : /desk/.test(l) ? "desktop_windows" : "folder"
    }

    ArqField {
        id: field
        anchors.left: parent.left; anchors.right: parent.right; anchors.bottom: parent.bottom
        anchors.margins: 16
        implicitHeight: Sizes.hL
        height: Sizes.hL
        placeholder: "Search apps and settings"
        iconName: "search"
        onEdited: p.cur = 0
        onAccepted: p.activate(p.cur)
        onNav: key => {
            if (key === Qt.Key_Down) p.cur = Math.min(Math.max(0, p.total - 1), p.cur + 1)
            else if (key === Qt.Key_Up) p.cur = Math.max(0, p.cur - 1)
        }
    }
}
