import Quickshell
import Quickshell.Wayland
import QtQuick
import QtQuick.Shapes
import qs.config

// Rounded screen corners (Settings > Appearance > Rounded corners > Screen corners): a small black
// curve in each corner of every screen, above everything, that never takes clicks.
// Four tiny windows per screen, not one full-screen one, so nothing else has to be redrawn.
Variants {
    model: Config.c.screenCorners > 0 ? Quickshell.screens : []
    Scope {
        id: sc
        required property var modelData
        Variants {
            model: ["tl", "tr", "bl", "br"]
            PanelWindow {
                id: cw
                required property string modelData
                readonly property bool atTop: modelData[0] === "t"
                readonly property bool atLeft: modelData[1] === "l"
                readonly property int r: Config.c.screenCorners
                screen: sc.modelData
                anchors { top: cw.atTop; bottom: !cw.atTop; left: cw.atLeft; right: !cw.atLeft }
                implicitWidth: r
                implicitHeight: r
                exclusionMode: ExclusionMode.Ignore
                color: "transparent"
                mask: Region {}
                WlrLayershell.layer: WlrLayer.Overlay
                WlrLayershell.namespace: "arqen-corners"
                WlrLayershell.keyboardFocus: WlrKeyboardFocus.None

                Shape {
                    anchors.fill: parent
                    layer.enabled: true
                    layer.samples: 8
                    // the corner is drawn for the top-left and mirrored for the others
                    transform: Scale {
                        origin.x: cw.r / 2; origin.y: cw.r / 2
                        xScale: cw.atLeft ? 1 : -1
                        yScale: cw.atTop ? 1 : -1
                    }
                    ShapePath {
                        fillColor: "black"
                        strokeWidth: -1
                        startX: 0; startY: 0
                        PathLine { x: cw.r; y: 0 }
                        PathArc { x: 0; y: cw.r; radiusX: cw.r; radiusY: cw.r; direction: PathArc.Counterclockwise }
                        PathLine { x: 0; y: 0 }
                    }
                }
            }
        }
    }
}
