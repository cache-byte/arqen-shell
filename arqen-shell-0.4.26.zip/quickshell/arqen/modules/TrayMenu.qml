import Quickshell
import QtQuick
import QtQuick.Layouts
import qs.config
import qs.components

// Right-click menu for an app status icon (Steam, Heroic, ...). Drawn by the shell
// in the shell's own style instead of the app's own toolkit menu, so it matches everything
// else. Sub-menus open in place with a Back row.
ArqPopup {
    id: p
    open: Ui.open === "traymenu" && Ui.trayItem !== null
    position: "tray"
    cardWidth: 280
    cardHeight: Math.min(col.implicitHeight + 16, 620)

    // sub-menus we have drilled into (each one is a menu entry that has children)
    property var stack: []
    readonly property var current: stack.length > 0 ? stack[stack.length - 1] : (Ui.trayItem?.menu ?? null)
    onOpenChanged: if (open) stack = []
    Connections { target: Ui; function onTrayItemChanged() { p.stack = [] } }

    QsMenuOpener { id: opener; menu: p.current }

    Flickable {
        anchors { fill: parent; margins: 8 }
        contentWidth: width
        contentHeight: col.implicitHeight
        clip: true
        boundsBehavior: Flickable.StopAtBounds

        ColumnLayout {
            id: col
            width: parent.width
            spacing: 2

            // Back row (only inside a sub-menu)
            Item {
                visible: p.stack.length > 0
                Layout.fillWidth: true
                implicitHeight: visible ? 42 : 0
                Rectangle { anchors.fill: parent; radius: 14; color: backMa.containsMouse ? Theme.hover : "transparent" }
                Row {
                    anchors { verticalCenter: parent.verticalCenter; left: parent.left; leftMargin: 12 }
                    spacing: 10
                    Icon { name: "arrow_back"; size: 20 }
                    DText { text: p.stack.length > 0 ? p.stack[p.stack.length - 1].text : ""; font.weight: Font.Medium; anchors.verticalCenter: parent.verticalCenter }
                }
                MouseArea { id: backMa; anchors.fill: parent; hoverEnabled: true; onClicked: p.stack = p.stack.slice(0, -1) }
            }

            Repeater {
                model: opener.children
                delegate: Item {
                    id: en
                    required property var modelData
                    Layout.fillWidth: true
                    implicitHeight: modelData.isSeparator ? 9 : 42

                    Rectangle {
                        visible: en.modelData.isSeparator
                        anchors.centerIn: parent
                        width: parent.width - 20; height: 1; color: Theme.divider
                    }
                    Rectangle {
                        visible: !en.modelData.isSeparator
                        anchors.fill: parent; radius: 14
                        color: (ema.containsMouse && en.modelData.enabled) ? Theme.hover : "transparent"
                    }
                    RowLayout {
                        visible: !en.modelData.isSeparator
                        anchors { fill: parent; leftMargin: 12; rightMargin: 12 }
                        spacing: 10
                        opacity: en.modelData.enabled ? 1 : 0.4

                        // check mark / radio dot for toggle entries
                        Icon {
                            visible: en.modelData.buttonType > 0
                            name: en.modelData.buttonType === 2
                                  ? (en.modelData.checkState === Qt.Checked ? "radio_button_checked" : "radio_button_unchecked")
                                  : (en.modelData.checkState === Qt.Checked ? "check_box" : "check_box_outline_blank")
                            size: 20
                        }
                        Image {
                            visible: en.modelData.buttonType === 0 && en.modelData.icon !== ""
                            source: en.modelData.icon
                            sourceSize: Qt.size(40, 40)
                            fillMode: Image.PreserveAspectFit
                            Layout.preferredWidth: 20; Layout.preferredHeight: 20
                        }
                        DText { text: en.modelData.text; Layout.fillWidth: true; elide: Text.ElideRight }
                        Icon { visible: en.modelData.hasChildren; name: "chevron_right"; size: 20; color: Theme.subtext }
                    }
                    MouseArea {
                        id: ema
                        anchors.fill: parent; hoverEnabled: true
                        enabled: !en.modelData.isSeparator
                        cursorShape: Qt.PointingHandCursor
                        onClicked: {
                            const m = en.modelData
                            if (!m.enabled) return
                            if (m.hasChildren) { p.stack = p.stack.concat([m]) }
                            else { const it = m; Ui.close(); it.triggered() }
                        }
                    }
                }
            }
        }
    }
}
