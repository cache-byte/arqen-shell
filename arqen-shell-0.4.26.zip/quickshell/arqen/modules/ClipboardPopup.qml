import Quickshell
import QtQuick
import qs.config
import qs.components
import qs.services

// Clipboard history as its own popup, opened by the clipboard button on a panel
// (or `qs -c arqen ipc call arqen toggle clipboard`). It lines up with the button like the calendar.
ArqPopup {
    id: p
    open: Ui.open === "clipboard"
    position: "tray"
    wantsKeyboard: true          // type straight away to search
    cardWidth: 380
    cardHeight: Math.min(620, Math.max(320, height - 2 * Ui.gap))

    onOpenChanged: {
        if (!open) return
        Clipboard.refresh()
        panel.reset()
        Qt.callLater(panel.focusSearch)
    }

    ClipboardPanel {
        id: panel
        anchors.fill: parent
        framed: false
    }
}
