import Quickshell
import Quickshell.Wayland
import Quickshell.Io
import Quickshell.Services.Pam
import QtQuick
import qs.config
import qs.components
import qs.services

// The lock screen, like a phone's: what it shows and how is set in Settings > Lock screen
// (components/LockFace.qml draws it). Your password is checked with the system's login rules (PAM).
// Ui.lock() locks; it is also what idle locking, the power menu and `loginctl lock-session` use.
// Loaded by shell.qml through a Loader: a Quickshell built without the lock or PAM parts only loses this.
Scope {
    id: root
    Component.onCompleted: Ui.lockAvailable = true
    Component.onDestruction: Ui.lockAvailable = false

    // ---- checking the password (PAM, with the system's normal login rules) ----
    function log(m) { Ui.lockInfo = Qt.formatTime(new Date(), "HH:mm:ss") + "  " + m; console.log("arqen lock: " + m) }
    property string status: ""              // "", "checking", "wrong"
    property string typed: ""
    PamContext {
        id: pam
        configDirectory: Quickshell.shellDir + "/assets/pam"
        config: "arqen-lock"
        onResponseRequiredChanged: if (responseRequired) { respond(root.typed); root.typed = "" }
        onCompleted: result => {
            if (result === PamResult.Success) { root.log("password accepted, unlocked"); root.status = ""; lock.unlocking = true; Ui.locked = false }
            else { root.log("password not accepted (PAM result " + result + ")"); root.status = "wrong"; root.shake++ }
        }
        onError: err => { root.log("the password check could not run (PAM error " + err + "); " + (root.pamHint)); root.status = "wrong"; root.shake++ }
    }
    readonly property string pamHint: "is /etc/pam.d/system-auth there? (Fedora) and is the file assets/pam/arqen-lock in the shell folder?"
    function tryPassword(pw) {
        if (pw === "" || pam.active) return
        typed = pw
        status = "checking"
        pam.start()
    }
    property int shake: 0

    // `loginctl lock-session` (and anything else that asks the login manager to lock) locks too.
    // logind sends Lock / Unlock from this session's own object path (not "session/auto"), so find it first.
    Process {
        running: Ui.lockAvailable
        command: ["sh", "-c", "sid=\"${XDG_SESSION_ID:-$(loginctl show-user \"$USER\" -p Display --value 2>/dev/null)}\"; "
                  + "p=$(gdbus call --system --dest org.freedesktop.login1 --object-path /org/freedesktop/login1 "
                  + "--method org.freedesktop.login1.Manager.GetSession \"$sid\" 2>/dev/null | sed -n \"s/.*'\\(\\/[^']*\\)'.*/\\1/p\"); "
                  + "[ -n \"$p\" ] || p=/org/freedesktop/login1/session/auto; "
                  + "exec gdbus monitor --system --dest org.freedesktop.login1 --object-path \"$p\""]
        stdout: SplitParser { onRead: line => { if (/\.Lock \(\)/.test(line)) Ui.lock(); else if (/\.Unlock \(\)/.test(line)) Ui.locked = false } }
    }

    // Sleep started by anything (the power key, `systemctl suspend`, a closed lid handled by logind, an app):
    // lock first. A "delay" inhibitor makes logind wait a moment for the lock before it sleeps; it is let go
    // once the lock is up, and taken again after waking.
    property bool holdSleep: true
    Process {
        running: Ui.lockAvailable && Config.c.lockBeforeSleep && root.holdSleep
        command: ["systemd-inhibit", "--what=sleep", "--mode=delay", "--who=Arqen shell", "--why=Locking the screen before sleep", "sleep", "infinity"]
    }
    Timer { id: letSleep; interval: 900; onTriggered: root.holdSleep = false }
    Process {
        running: Ui.lockAvailable && Config.c.lockBeforeSleep
        command: ["gdbus", "monitor", "--system", "--dest", "org.freedesktop.login1", "--object-path", "/org/freedesktop/login1"]
        stdout: SplitParser {
            onRead: line => {
                if (/PrepareForSleep \(true,?\)/.test(line)) { if (!Ui.locked) Ui.lock(); letSleep.restart() }
                else if (/PrepareForSleep \(false,?\)/.test(line)) root.holdSleep = true
            }
        }
    }

    // the compositor must confirm the lock; when it does not (no screen got a lock surface...) say so, and do not
    // leave the shell believing it is locked
    Timer {
        id: confirm
        interval: 2500
        onTriggered: if (Ui.locked && lock.secure === false) {
            root.log("the compositor did not confirm the lock (it is NOT locked)")
            Ui.locked = false
            Quickshell.execDetached(["notify-send", "-a", "Arqen", "-u", "critical", "The screen could not be locked", "Hyprland did not accept the lock. Details: Settings > Lock screen."])
        } else if (Ui.locked) root.log("locked (confirmed by the compositor)")
    }
    WlSessionLock {
        id: lock
        property bool unlocking: false
        locked: Ui.locked
        onLockedChanged: {
            if (locked) { unlocking = false; root.status = ""; root.log("lock requested"); confirm.restart() }
            else { confirm.stop(); root.log("unlocked") }
        }

        WlSessionLockSurface {
            id: surf
            color: "black"
            // fades in when it locks
            LockFace {
                id: face
                anchors.fill: parent
                opacity: 0
                status: root.status
                shake: root.shake
                onSubmit: pw => root.tryPassword(pw)
                onTyping: root.status = ""
                Component.onCompleted: { fadeIn.start(); focusField() }
                NumberAnimation { id: fadeIn; target: face; property: "opacity"; to: 1; duration: 400; easing.type: Easing.OutCubic }
            }
        }
    }
}
