import Quickshell
import Quickshell.Bluetooth
import Quickshell.Services.UPower
import QtQuick
import QtQuick.Layouts
import qs.config
import qs.components
import qs.services

// The options popup of a control centre tile (right-click): Wi-Fi networks, Bluetooth devices,
// sound outputs, Caffeine timers, and so on.
// Each entry is a plain object: { icon, text, sub, check, lock, danger, keep, act }
// (keep = leave the menu open after the click), or { k: "head" | "sep" | "swatches" }.
Rectangle {
    id: m
    property string tileId: ""
    property string pendingSsid: ""        // a secured Wi-Fi network waiting for its password
    signal editRequested()

    function close() { tileId = ""; pendingSsid = ""; pwField.text = "" }
    onTileIdChanged: {
        pendingSsid = ""
        pwField.text = ""
        if (tileId === "wifi") Net.rescan()
    }
    onPendingSsidChanged: if (pendingSsid !== "") Qt.callLater(pwField.focusInput)

    function submitPassword() {
        if (pwField.text === "") return
        Net.connect(m.pendingSsid, pwField.text, false)
        m.pendingSsid = ""
        pwField.text = ""
    }

    radius: Math.max(0, Theme.radius - 2)
    color: Theme.cardSolid
    border.width: 1
    border.color: Theme.stroke
    height: Math.min(col.implicitHeight + 20, parent ? parent.height * 0.62 : 420)
    MouseArea { anchors.fill: parent; acceptedButtons: Qt.AllButtons }   // clicks inside the menu stay inside

    // ---------- the entries ----------
    function sep() { return { k: "sep" } }
    function head(t) { return { k: "head", text: t } }
    // Tiles are edited with the pencil button or by pressing and holding a tile, not from these menus.
    function editItem() { return [] }

    function wifiPick(n) {
        if (n.active) Net.disconnect(n.ssid)
        else if (n.saved || !n.secure) Net.connect(n.ssid, "", n.saved)
        else m.pendingSsid = n.ssid
    }
    function wifiItems() {
        const out = [{ icon: Net.wifiOn ? "wifi" : "wifi_off", text: "Wi-Fi", sub: Net.wifiOn ? (Net.ssid ? "Connected to " + Net.ssid : "On") : "Off",
                       check: Net.wifiOn, act: () => Net.toggleWifi(), keep: true }]
        if (Net.wifiOn) {
            out.push(Object.assign(head("Available networks"), { busy: Net.scanning }))
            for (const n of Net.networks) {
                out.push({
                    icon: n.signal >= 66 ? "wifi" : (n.signal >= 33 ? "wifi_2_bar" : "wifi_1_bar"),
                    text: n.ssid,
                    sub: n.active ? "Connected · tap to disconnect" : (n.saved ? "Saved" : (n.secure ? "Secured" : "Open")),
                    check: n.active,
                    lock: n.secure && !n.saved && !n.active,
                    act: () => m.wifiPick(n), keep: true
                })
            }
            if (Net.networks.length === 0) out.push(head("No networks found yet"))
            out.push({ icon: "refresh", text: "Scan again", act: () => Net.rescan(), keep: true })
        }
        out.push(sep())
        out.push({ icon: "settings_ethernet", text: "Network settings...", act: () => Quickshell.execDetached(["nm-connection-editor"]) })
        return out.concat(editItem())
    }

    function btPick(d) {
        if (!d.paired) QuickSettings.btPair(d)
        else QuickSettings.btToggleConnect(d)
    }
    function btItems() {
        const ad = Bluetooth.defaultAdapter
        const on = ad ? ad.enabled : false
        const out = [{ icon: "bluetooth", text: "Bluetooth", sub: ad ? (on ? "On" : "Off") : "No adapter", check: on,
                       act: () => QuickSettings.toggleBluetooth(), keep: true }]
        if (ad && on) {
            out.push({ icon: "bluetooth_searching", text: ad.discovering ? "Scanning... tap to stop" : "Scan for devices",
                       act: () => { ad.discovering = !ad.discovering }, keep: true })
            const devs = Bluetooth.devices.values.slice()
            devs.sort((a, b) => ((b.connected ? 2 : 0) + (b.paired ? 1 : 0)) - ((a.connected ? 2 : 0) + (a.paired ? 1 : 0)))
            out.push(Object.assign(head("Devices"), { busy: Bluetooth.defaultAdapter?.discovering ?? false }))
            for (const d of devs) {
                out.push({
                    icon: d.connected ? "bluetooth_connected" : "bluetooth",
                    text: d.name || d.address,
                    busy: QuickSettings.btBusy === d.address,
                    sub: QuickSettings.btBusy === d.address ? "Working"
                         : d.connected ? "Connected · tap to disconnect" : (d.paired ? "Paired · tap to connect" : "Available · tap to pair"),
                    check: d.connected,
                    act: () => m.btPick(d), keep: true
                })
            }
            if (devs.length === 0) out.push(head("No devices yet, start a scan"))
            if (QuickSettings.btStatus !== "") out.push(head(QuickSettings.btStatus))
        }
        out.push(sep())
        out.push({ icon: "devices", text: "Bluetooth settings...", act: () => Quickshell.execDetached(["sh", "-c", "if command -v gnome-control-center >/dev/null 2>&1; then gnome-control-center bluetooth; elif command -v systemsettings >/dev/null 2>&1; then systemsettings kcm_bluetooth; elif command -v foot >/dev/null 2>&1; then foot -e bluetoothctl; elif command -v kitty >/dev/null 2>&1; then kitty bluetoothctl; else x-terminal-emulator -e bluetoothctl; fi"]) })
        return out.concat(editItem())
    }

    function soundItems() {
        const out = [head("Output device")]
        for (const n of Audio.sinks) {
            out.push({ icon: "speaker", text: n.description || n.nickname || n.name,
                       check: Audio.sink ? n.name === Audio.sink.name : false,
                       act: () => Audio.setSink(n), keep: true })
        }
        out.push(sep())
        out.push({ icon: Audio.muted ? "volume_up" : "volume_off", text: Audio.muted ? "Unmute" : "Mute", act: () => Audio.toggleMute(), keep: true })
        out.push({ icon: "tune", text: "Sound settings...", act: () => Ui.openSettings("sounds") })
        return out.concat(editItem())
    }

    function micItems() {
        const out = [head("Input device")]
        for (const n of Audio.sources) {
            out.push({ icon: "mic", text: n.description || n.nickname || n.name,
                       check: Audio.source ? n.name === Audio.source.name : false,
                       act: () => Audio.setSource(n), keep: true })
        }
        out.push(sep())
        out.push({ icon: Audio.micMuted ? "mic" : "mic_off", text: Audio.micMuted ? "Unmute microphone" : "Mute microphone", act: () => Audio.toggleMicMute(), keep: true })
        out.push({ icon: "tune", text: "Sound settings...", act: () => Ui.openSettings("sounds") })
        return out.concat(editItem())
    }

    function dndItems() {
        const out = [{ icon: Config.c.dnd ? "notifications_off" : "notifications", text: "Do not disturb", sub: Config.c.dnd ? "On" : "Off",
                       check: Config.c.dnd, act: () => { Config.c.dnd = !Config.c.dnd }, keep: true },
                     head("Pop-up duration")]
        for (const s of [3, 5, 10, 15])
            out.push({ icon: "timer", text: s + " seconds", check: Config.c.toastSeconds === s, act: () => { Config.c.toastSeconds = s }, keep: true })
        out.push(sep())
        out.push({ icon: "settings", text: "Notification settings...", act: () => Ui.openSettings("notifications") })
        return out.concat(editItem())
    }

    function darkItems() {
        return [
            { icon: "dark_mode", text: "Dark", check: Config.c.darkMode, act: () => { Config.c.darkMode = true }, keep: true },
            { icon: "light_mode", text: "Light", check: !Config.c.darkMode, act: () => { Config.c.darkMode = false }, keep: true },
            head("Accent colour"),
            { k: "swatches", colors: ["#3E91FF", "#7A5AF5", "#F0507A", "#F2562A", "#F5A623", "#34C759", "#00BCD4", "#9AA0A6"],
              pick: c => { Config.c.accent = c } }
        ].concat(editItem())
    }

    function nightItems() {
        const out = [{ icon: "brightness_4", text: "Night light", sub: QuickSettings.night ? QuickSettings.nightTemp + " K" : "Off",
                       check: QuickSettings.night, act: () => QuickSettings.setNight(!QuickSettings.night), keep: true },
                     head("Warmth")]
        for (const k of [2000, 2700, 3500, 4500, 5500])
            out.push({ icon: "thermostat", text: k + " K", sub: k <= 2700 ? "Very warm" : (k <= 3500 ? "Warm" : (k <= 4500 ? "Mild" : "Slight")),
                       check: QuickSettings.night && QuickSettings.nightTemp === k, act: () => QuickSettings.setNight(true, k), keep: true })
        out.push(head("Colour filter"))
        out.push({ icon: "block", text: "None", check: QuickSettings.filter === "", act: () => QuickSettings.setFilter(""), keep: true })
        for (const f of QuickSettings.filters)
            out.push({ icon: f.icon, text: f.name, sub: f.sub, check: QuickSettings.filter === f.id, act: () => QuickSettings.setFilter(f.id), keep: true })
        return out.concat(editItem())
    }

    // the Screenshot tile: a picture or a recording, of the screen, a window or a region
    function captureItems() {
        const out = []
        if (QuickSettings.recording) {
            out.push({ icon: "stop_circle", text: "Stop recording", danger: true, act: () => QuickSettings.record("stop") })
            out.push(sep())
        }
        out.push(head("Take a screenshot"))
        out.push({ icon: "fit_screen", text: "Whole screen", act: () => QuickSettings.screenshot("screen") })
        out.push({ icon: "select_window", text: "A window", sub: "Click the window", act: () => QuickSettings.screenshot("window") })
        out.push({ icon: "screenshot_region", text: "A region", sub: "Draw a box", act: () => QuickSettings.screenshot("region") })
        if (!QuickSettings.recording) {
            out.push(head("Record the screen"))
            out.push({ icon: "screen_record", text: "Whole screen", act: () => QuickSettings.record("screen") })
            out.push({ icon: "select_window", text: "A window", sub: "Click the window", act: () => QuickSettings.record("window") })
            out.push({ icon: "crop_free", text: "A region", sub: "Draw a box", act: () => QuickSettings.record("region") })
        }
        out.push(sep())
        out.push({ icon: "folder_open", text: "Screenshots folder", act: () => { Ui.close(); QuickSettings.openFolder(Config.shotDir) } })
        out.push({ icon: "video_library", text: "Recordings folder", act: () => { Ui.close(); QuickSettings.openFolder(Config.recDir) } })
        return out.concat(editItem())
    }

    function deskItems() {
        return [
            { icon: "workspaces", text: "Open desktop view", act: () => Ui.toggle("overview") },
            { icon: "dock_to_bottom", text: "Panel settings...", act: () => Ui.openSettings("panels") }
        ].concat(editItem())
    }

    function powerItems() {
        return [
            { icon: "lock", text: "Lock", act: () => QuickSettings.power("lock") },
            { icon: "bedtime", text: "Sleep", act: () => QuickSettings.power("suspend") },
            { icon: "logout", text: "Log out", act: () => QuickSettings.power("logout") },
            { icon: "restart_alt", text: "Restart", danger: true, act: () => QuickSettings.power("reboot") },
            { icon: "power_settings_new", text: "Shut down", danger: true, act: () => QuickSettings.power("poweroff") }
        ]
    }

    // battery tile: power mode (needs power-profiles-daemon or tuned-ppd running)
    function batteryItems() {
        const cur = PowerProfiles.profile
        const d = UPower.displayDevice
        const charging = d.state === UPowerDeviceState.Charging
        const out = [
            head("Battery " + Math.round(d.percentage * 100) + "%" + (charging ? " · charging" : "")),
            head("Power mode"),
            { icon: "eco", text: "Power saver", sub: "Longer battery life, slower", check: cur === PowerProfile.PowerSaver,
              act: () => QuickSettings.setProfile(PowerProfile.PowerSaver), keep: true },
            { icon: "balance", text: "Balanced", sub: "The usual", check: cur === PowerProfile.Balanced,
              act: () => QuickSettings.setProfile(PowerProfile.Balanced), keep: true }
        ]
        if (PowerProfiles.hasPerformanceProfile)
            out.push({ icon: "speed", text: "Performance", sub: "Fastest, uses more power", check: cur === PowerProfile.Performance,
                       act: () => QuickSettings.setProfile(PowerProfile.Performance), keep: true })
        return out.concat(editItem())
    }

    function caffeineItems() {
        const out = [{ icon: "coffee", text: Caffeine.active ? "Caffeine is on" : "Caffeine is off",
                       sub: Caffeine.active ? Caffeine.label : "The screen will not lock or sleep while it is on",
                       check: Caffeine.active, act: () => Caffeine.toggle(), keep: true },
                     head("Keep awake for")]
        for (const d of [[0, "Until I turn it off"], [15, "15 minutes"], [30, "30 minutes"], [60, "1 hour"], [120, "2 hours"], [240, "4 hours"]])
            out.push({ icon: d[0] === 0 ? "all_inclusive" : "timer", text: d[1], check: Caffeine.active && Caffeine.minutes === d[0],
                       act: () => Caffeine.start(d[0]), keep: true })
        return out.concat(editItem())
    }


    function build(id) {
        switch (id) {
        case "": return []
        case "wifi": return wifiItems()
        case "bluetooth": return btItems()
        case "sound":
        case "volume":
        case "output": return soundItems()
        case "mic": return micItems()
        case "dnd": return dndItems()
        case "dark": return darkItems()
        case "night": return nightItems()
        case "capture": return captureItems()
        case "desktops": return deskItems()
        case "lock": return [{ icon: "power_settings_new", text: "Power menu...", act: () => Ui.toggle("power") }].concat(powerItems()).concat(editItem())
        case "power": return powerItems()          // the power button in the header
        case "caffeine": return caffeineItems()
        case "battery": return batteryItems()
        default: return [head(CcTiles.info(id) ? CcTiles.info(id).name : "")].concat(editItem())
        }
    }
    readonly property var items: build(tileId)

    // ---------- drawing ----------
    Flickable {
        anchors { fill: parent; margins: 10 }
        contentWidth: width
        contentHeight: col.implicitHeight
        clip: true
        boundsBehavior: Flickable.StopAtBounds

        ColumnLayout {
            id: col
            width: parent.width
            spacing: 2

            Repeater {
                model: m.items
                delegate: Item {
                    id: row
                    required property var modelData
                    readonly property string kind: modelData.k ?? "item"
                    Layout.fillWidth: true
                    implicitHeight: kind === "sep" ? 9 : (kind === "head" ? 30 : (kind === "swatches" ? 48 : 46))

                    Rectangle { visible: row.kind === "sep"; anchors.centerIn: parent; width: parent.width - 20; height: 1; color: Theme.divider }
                    DText {
                        visible: row.kind === "head"
                        anchors { left: parent.left; right: parent.right; leftMargin: 12; rightMargin: 12; verticalCenter: parent.verticalCenter }
                        text: row.modelData.text ?? ""; font.pixelSize: 12; color: Theme.subtext; elide: Text.ElideRight
                    }
                    LoadingPill {
                        visible: row.kind === "head" && row.modelData.busy === true
                        anchors { right: parent.right; rightMargin: 12; verticalCenter: parent.verticalCenter }
                        width: 30; height: 16; color: Theme.subtext
                    }

                    Rectangle { visible: row.kind === "item"; anchors.fill: parent; radius: 16; color: ima.containsMouse ? Theme.hover : "transparent" }
                    RowLayout {
                        visible: row.kind === "item"
                        anchors { fill: parent; leftMargin: 12; rightMargin: 12 }
                        spacing: 12
                        Icon { name: row.modelData.icon ?? ""; size: 22; color: row.modelData.danger === true ? "#FF5A5A" : Theme.text }
                        ColumnLayout {
                            Layout.fillWidth: true; spacing: 0
                            DText { text: row.modelData.text ?? ""; Layout.fillWidth: true; elide: Text.ElideRight; color: row.modelData.danger === true ? "#FF5A5A" : Theme.text }
                            DText { visible: (row.modelData.sub ?? "") !== ""; text: row.modelData.sub ?? ""; font.pixelSize: 11; color: Theme.subtext; Layout.fillWidth: true; elide: Text.ElideRight }
                        }
                        LoadingPill { visible: row.modelData.busy === true; Layout.preferredWidth: 30; Layout.preferredHeight: 16 }
                        Icon { visible: row.modelData.lock === true; name: "lock"; size: 16; color: Theme.subtext }
                        Icon { visible: row.modelData.check === true; name: "check"; size: 20; color: Theme.accent }
                    }
                    MouseArea {
                        id: ima
                        visible: row.kind === "item"
                        anchors.fill: parent
                        hoverEnabled: true
                        cursorShape: Qt.PointingHandCursor
                        // Read everything first and run the action after this handler: an action can
                        // rebuild the list (a Bluetooth device appears, Wi-Fi state changes), which destroys
                        // this row while its handler is still running ("m is not defined").
                        onClicked: {
                            const menu = m
                            const act = row.modelData.act
                            const keep = row.modelData.keep === true
                            if (!keep) menu.close()
                            if (act) Qt.callLater(act)
                        }
                    }

                    Row {
                        visible: row.kind === "swatches"
                        anchors { left: parent.left; leftMargin: 12; verticalCenter: parent.verticalCenter }
                        spacing: 10
                        Repeater {
                            model: row.modelData.colors ?? []
                            delegate: Rectangle {
                                id: sw
                                required property string modelData
                                width: 30; height: 30; radius: 15
                                color: modelData
                                border.width: Config.c.accent.toLowerCase() === modelData.toLowerCase() ? 3 : 0
                                border.color: Theme.text
                                MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor
                                    onClicked: { const pick = row.modelData.pick, c = sw.modelData; Qt.callLater(() => pick(c)) } }
                            }
                        }
                    }
                }
            }

            // password prompt for a secured network that has not been used before
            RowLayout {
                visible: m.pendingSsid !== ""
                Layout.fillWidth: true
                Layout.topMargin: 6
                spacing: 8
                ArqField {
                    id: pwField
                    Layout.fillWidth: true
                    password: true
                    iconName: "key"
                    placeholder: "Password for " + m.pendingSsid
                    onAccepted: m.submitPassword()
                }
                ArqButton { text: "Connect"; primary: true; onClicked: m.submitPassword() }
            }
            DText {
                visible: m.tileId === "wifi" && Net.status !== ""
                Layout.fillWidth: true
                Layout.leftMargin: 12
                text: Net.status; wrapMode: Text.WordWrap; font.pixelSize: 12; color: Theme.subtext
            }
        }
    }
}
