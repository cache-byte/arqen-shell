import Quickshell
import Quickshell.Wayland
import QtQuick
import QtQuick.Effects
import Quickshell.Widgets
import qs.config
import qs.services
import Quickshell.Hyprland

// The wallpaper: an image, or a video (mp4 / webm / mkv / mov, looping, no sound), on every screen.
// With "Accent colour from the wallpaper" on, the accent is picked from it (from a frame for videos).
Variants {
    model: Quickshell.screens
    PanelWindow {
        id: wp
        required property var modelData
        screen: modelData
        anchors { top: true; bottom: true; left: true; right: true }
        exclusionMode: ExclusionMode.Ignore
        WlrLayershell.layer: WlrLayer.Background
        WlrLayershell.namespace: "arqen-wallpaper"
        color: "#0b0b1a"

        // the wallpaper being shown. Changes are taken a moment after the last click, so clicking
        // through many wallpapers quickly loads only the one you stop on (no backlog of big pictures)
        property string file: Config.c.wallpaper
        Timer { id: settle; interval: 140; onTriggered: wp.file = Config.c.wallpaper }
        Connections { target: Config.c; function onWallpaperChanged() { settle.restart() } }
        readonly property bool isVideo: /\.(mp4|webm|mkv|mov|m4v|avi)$/i.test(file)
        // decoded at the screen's real pixel size, covering it in both directions (decoding by the width
        // alone left wide pictures short, then stretched up: blurry). A picture smaller than the screen
        // is not decoded bigger than it is
        readonly property size pix: Qt.size(Math.ceil(width * (screen?.devicePixelRatio ?? 1)), Math.ceil(height * (screen?.devicePixelRatio ?? 1)))
        // one screen is enough to pick the colour
        readonly property bool picks: Quickshell.screens[0] === modelData

        // Fallback: a soft gradient when no wallpaper is chosen (or it failed to load)
        Rectangle {
            anchors.fill: parent
            visible: wp.isVideo ? (vid.status !== Loader.Ready) : (img.status !== Image.Ready && wp.prevSrc === "")
            gradient: Gradient {
                GradientStop { position: 0.0; color: "#1a1830" }
                GradientStop { position: 0.55; color: "#5f5a72" }
                GradientStop { position: 1.0; color: "#14142e" }
            }
        }
        // ---- the picture, with a transition when it changes (Settings > Appearance > Wallpaper) ----
        // The old picture stays underneath (`back`) while the new one (`img`, inside `front`) comes in.
        readonly property string style: Config.c.wallTransition || "fade"
        property string prevSrc: ""                 // the picture being replaced
        property real t: 1                           // 0 -> 1 while the new one comes in
        NumberAnimation {
            id: trans
            target: wp; property: "t"; from: 0; to: 1
            duration: wp.style === "none" ? 1 : (Config.c.wallTransitionMs || 900)
            easing.type: Easing.InOutCubic
            onFinished: wp.prevSrc = ""
        }
        property string lastSrc: ""
        property bool wasDefault: file === ""        // the built-in gradient is what is showing
        onFileChanged: {
            trans.stop()
            if (wp.isVideo) wp.lastSrc = ""
            if (!wp.isVideo && wp.lastSrc !== "") wp.prevSrc = wp.lastSrc
            else if (!wp.isVideo && wp.wasDefault && wp.file !== "") wp.prevSrc = "@default"
            wp.wasDefault = wp.file === ""
            wp.t = wp.prevSrc !== "" ? 0 : 1
            // back to the built-in wallpaper: nothing to load, the change starts straight away
            if (wp.file === "") {
                wp.lastSrc = ""
                if (wp.prevSrc !== "") trans.restart()
            }
        }
        Rectangle {   // the built-in gradient going out
            anchors.fill: parent
            visible: wp.prevSrc === "@default" && wp.t < 1
            opacity: wp.style === "fade" || wp.style === "zoom" || wp.style === "blur" ? 1 - wp.t * 0.3 : 1
            gradient: Gradient {
                GradientStop { position: 0.0; color: "#1a1830" }
                GradientStop { position: 0.55; color: "#5f5a72" }
                GradientStop { position: 1.0; color: "#14142e" }
            }
        }
        Image {
            id: back
            width: parent.width; height: parent.height
            visible: wp.prevSrc !== "" && wp.prevSrc !== "@default" && wp.t < 1
            source: wp.prevSrc === "@default" ? "" : wp.prevSrc
            fillMode: Image.PreserveAspectCrop
            sourceSize: wp.pix
            smooth: true; mipmap: true
            x: wp.style === "push" ? -wp.t * wp.width : 0
            opacity: wp.style === "fade" || wp.style === "zoom" || wp.style === "blur" ? 1 - wp.t * 0.3 : 1
            layer.enabled: wp.style === "blur" && visible
            layer.effect: MultiEffect { blurEnabled: true; blurMax: 64; blur: wp.t }
        }
        // diagonal wipe: a band tilted 45 degrees sweeps from the top-left corner to the bottom-right,
        // showing the new picture inside it (the picture itself stays put)
        Item {
            id: wiper
            visible: front.wipe
            x: 0; y: 0
            rotation: 45
            transformOrigin: Item.TopLeft
            readonly property real r2: Math.SQRT2
            Item {
                x: 0; y: -wp.width / wiper.r2
                width: (wp.width + wp.height) / wiper.r2 * wp.t
                height: (wp.width + wp.height) / wiper.r2
                clip: true
                Image {
                    x: 0; y: wp.width / wiper.r2
                    rotation: -45
                    transformOrigin: Item.TopLeft
                    width: wp.width; height: wp.height
                    source: front.wipe ? img.source : ""
                    fillMode: Image.PreserveAspectCrop
                    sourceSize: wp.pix
                    smooth: true; mipmap: true
                }
            }
        }
        ClippingRectangle {
            id: front
            visible: !wp.isVideo && !wipe
            color: "transparent"
            readonly property real diag: Math.sqrt(wp.width * wp.width + wp.height * wp.height)
            readonly property bool circle: wp.style === "circle" && wp.t < 1
            readonly property bool wipe: wp.style === "wipe" && wp.t < 1 && wp.prevSrc !== "" && wp.file !== ""
            width: circle ? diag * wp.t : wp.width
            height: circle ? width : wp.height
            radius: circle ? width / 2 : 0
            x: circle ? (wp.width - width) / 2 : ((wp.style === "slide" || wp.style === "push") && wp.t < 1 ? (1 - wp.t) * wp.width : 0)
            y: circle ? (wp.height - height) / 2 : 0
            opacity: (wp.style === "fade" || wp.style === "blur" || wp.style === "zoom") && wp.prevSrc !== "" ? wp.t : 1
            scale: wp.style === "zoom" && wp.t < 1 ? 1.12 - 0.12 * wp.t : 1
            // the built-in wallpaper (no file chosen): the soft gradient, with the same transitions
            Rectangle {
                visible: wp.file === ""
                x: front.circle ? -front.x : 0
                y: front.circle ? -front.y : 0
                width: wp.width; height: wp.height
                gradient: Gradient {
                    GradientStop { position: 0.0; color: "#1a1830" }
                    GradientStop { position: 0.55; color: "#5f5a72" }
                    GradientStop { position: 1.0; color: "#14142e" }
                }
            }
            Image {
                id: img
                // stays where it is on the screen while its frame grows or moves
                x: front.circle ? -front.x : 0
                y: front.circle ? -front.y : 0
                width: wp.width; height: wp.height
                source: (!wp.isVideo && wp.file !== "") ? "file://" + wp.file : ""
                fillMode: Image.PreserveAspectCrop
                asynchronous: true
                sourceSize: wp.pix
                smooth: true; mipmap: true
                onStatusChanged: {
                    if (status !== Image.Ready) return
                    wp.lastSrc = String(source)
                    if (wp.prevSrc !== "" && wp.prevSrc !== wp.lastSrc) trans.restart()
                    else { wp.prevSrc = ""; wp.t = 1 }
                }
            }
        }
        Loader {
            id: vid
            anchors.fill: parent
            active: wp.isVideo && wp.file !== ""
            source: active ? "video/VideoWall.qml" : ""
            opacity: status === Loader.Ready ? 1 : 0
            Behavior on opacity { NumberAnimation { duration: Config.c.wallTransitionMs || 900; easing.type: Easing.InOutCubic } }
            onLoaded: { item.path = Qt.binding(() => wp.file); item.paused = Qt.binding(() => Power.saving || (Hyprland.focusedWorkspace?.hasFullscreen ?? false)) }
            Connections {
                target: vid.item
                ignoreUnknownSignals: true
                function onFrame(u) { if (wp.picks) picker.pick(u) }
            }
        }
        Connections {
            target: Config.c
            function onAccentFromWallpaperChanged() {
                if (!Config.c.accentFromWallpaper || !wp.picks) return
                if (thumb.status === Image.Ready) picker.pickThumb()
                else if (wp.isVideo && vid.item) vid.item.pathChanged()
            }
        }

        // a tiny copy of a new picture, decoded straight away, so the accent changes the moment the
        // wallpaper is picked (not after the full picture has loaded)
        Image {
            id: thumb
            visible: false
            asynchronous: true
            sourceSize: Qt.size(96, 54)
            // (from the setting itself, not from `file`, which waits 140 ms for more clicks: the accent starts changing at the click)
            readonly property string want: Config.c.wallpaper
            // (a video: a still from it, made by ffmpeg; without one the frame the player grabs is used instead)
            readonly property string pic: (wp.picks && want !== "" && Config.c.accentFromWallpaper) ? VideoThumbs.pictureOf(want) : ""
            source: pic !== "" ? "file://" + pic : ""
            onStatusChanged: if (status === Image.Ready) picker.pickThumb()
        }

        // ---- accent colour from the wallpaper ----
        // Draws a tiny copy, then picks the hue that is both common and colourful (grey, very dark
        // and washed-out pixels do not count), and makes it bright enough to read as an accent.
        Canvas {
            id: picker
            width: 96; height: 54
            z: -10                              // behind the wallpaper itself, never seen
            renderTarget: Canvas.Image
            renderStrategy: Canvas.Immediate
            property string src: ""
            property bool fromThumb: false
            function pickThumb() { if (!Config.c.accentFromWallpaper) return; fromThumb = true; requestPaint() }
            function pick(u) {
                fromThumb = false
                if (!Config.c.accentFromWallpaper) return
                const s = String(u)
                if (s === "") return
                if (src !== "" && src !== s) unloadImage(src)
                src = s
                if (isImageLoaded(s)) requestPaint(); else loadImage(s)
            }
            onImageLoaded: requestPaint()
            onPaint: {
                const ctx = getContext("2d")
                if (fromThumb) {
                    if (thumb.status !== Image.Ready) return
                    ctx.clearRect(0, 0, width, height)
                    ctx.drawImage(thumb, 0, 0, width, height)
                } else {
                    if (src === "" || !isImageLoaded(src)) return
                    ctx.clearRect(0, 0, width, height)
                    ctx.drawImage(src, 0, 0, width, height)
                }
                const d = ctx.getImageData(0, 0, width, height).data
                const c = picker.dominant(d)
                if (c !== "" && Config.c.accentFromWallpaper) Config.c.accent = c
            }
            function dominant(d) {
                const bins = []
                for (let i = 0; i < 36; i++) bins.push({ w: 0, r: 0, g: 0, b: 0 })
                for (let i = 0; i < d.length; i += 4) {
                    const r = d[i] / 255, g = d[i + 1] / 255, b = d[i + 2] / 255
                    const mx = Math.max(r, g, b), mn = Math.min(r, g, b)
                    const v = mx, s = mx === 0 ? 0 : (mx - mn) / mx
                    if (s < 0.25 || v < 0.2) continue
                    let h = 0
                    if (mx !== mn) {
                        if (mx === r) h = ((g - b) / (mx - mn)) % 6
                        else if (mx === g) h = (b - r) / (mx - mn) + 2
                        else h = (r - g) / (mx - mn) + 4
                        h *= 60; if (h < 0) h += 360
                    }
                    const bin = bins[Math.floor(h / 10) % 36]
                    const w = s * v * v
                    bin.w += w; bin.r += d[i] * w; bin.g += d[i + 1] * w; bin.b += d[i + 2] * w
                }
                // neighbouring hues count together
                let best = -1, bw = 0
                for (let i = 0; i < 36; i++) {
                    const w = bins[i].w + 0.5 * (bins[(i + 35) % 36].w + bins[(i + 1) % 36].w)
                    if (w > bw) { bw = w; best = i }
                }
                if (best < 0 || bins[best].w <= 0) return ""
                const B = bins[best]
                const col = Qt.rgba(B.r / B.w / 255, B.g / B.w / 255, B.b / B.w / 255, 1)
                // readable accent: enough colour, mid lightness
                const out = Qt.hsla(col.hslHue < 0 ? 0 : col.hslHue,
                                    Math.max(0.55, Math.min(0.9, col.hslSaturation)),
                                    Math.max(0.5, Math.min(0.62, col.hslLightness)), 1)
                const hx = v => ("0" + Math.round(v * 255).toString(16)).slice(-2)
                return "#" + hx(out.r) + hx(out.g) + hx(out.b)
            }
        }
    }
}
