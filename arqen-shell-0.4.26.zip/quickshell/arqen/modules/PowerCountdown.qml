import Quickshell
import Quickshell.Wayland
import Quickshell.Hyprland
import QtQuick
import QtQuick.Shapes
import qs.config
import qs.components
import qs.services

// The countdown before lock / sleep / log out / restart / shut down (QuickSettings.power), over every
// screen. Esc or Cancel stops it, Enter or the "now" button skips the wait.
// Its look (Config.c.powerTheme) and where it sits (Config.c.powerPlace) are set in Settings > Power.
Variants {
    model: Quickshell.screens
    PanelWindow {
        id: w
        required property var modelData
        screen: modelData
        readonly property bool on: QuickSettings.pendingPower !== ""
        readonly property bool main: (Hyprland.focusedMonitor?.name ?? "") === modelData.name || Quickshell.screens.length === 1

        // fades in / out
        property real t: 0
        // how it moves (Settings > Power > Countdown)
        readonly property real speed: Math.max(0.25, (Config.c.powerAnimSpeed || 100) / 100)
        readonly property string animIn: ["Zoom", "Fade", "Rise", "Drop"].indexOf(Config.c.powerAnimIn) >= 0 ? Config.c.powerAnimIn : "Zoom"
        readonly property string tick: ["Pop", "Slide", "Flip", "Fade", "Roll", "None"].indexOf(Config.c.powerAnimTick) >= 0 ? Config.c.powerAnimTick : "Pop"
        NumberAnimation { id: cdIn; target: w; property: "t"; to: 1; duration: Math.round((w.animIn === "Drop" ? 650 : 420) / w.speed)
                          easing.type: w.animIn === "Drop" ? Easing.OutBounce : w.animIn === "Rise" ? Easing.OutBack : Easing.OutCubic }
        NumberAnimation { id: cdOut; target: w; property: "t"; to: 0; duration: Math.round(220 / w.speed); easing.type: Easing.InCubic }
        onOnChanged: { if (on) { cdOut.stop(); cdIn.restart(); w.now = Date.now() } else { cdIn.stop(); cdOut.restart() } }
        visible: t > 0.001

        color: "transparent"
        anchors { top: true; bottom: true; left: true; right: true }
        exclusionMode: ExclusionMode.Ignore
        WlrLayershell.namespace: "arqen-countdown"
        WlrLayershell.layer: WlrLayer.Overlay
        WlrLayershell.keyboardFocus: on && main ? WlrKeyboardFocus.Exclusive : WlrKeyboardFocus.None

        // ---- the numbers ----
        property double now: Date.now()
        Timer { interval: 100; repeat: true; running: w.on; onTriggered: w.now = Date.now() }
        readonly property real remain: Math.max(0, (QuickSettings.powerAt - now) / 1000)
        readonly property int secs: Math.ceil(remain)
        // the ring / bar: running down smoothly, or a step each second
        readonly property real frac: QuickSettings.powerTotal <= 0 ? 0
            : Math.min(1, (Config.c.powerProgress === "Steps" ? secs : remain) / QuickSettings.powerTotal)
        // what is drawn: steps glide into place
        property real shownFrac: frac
        Behavior on shownFrac { enabled: Config.c.powerProgress === "Steps"; NumberAnimation { duration: Math.round(380 / w.speed); easing.type: Easing.OutCubic } }
        readonly property string action: QuickSettings.pendingPower !== "" ? QuickSettings.pendingPower : lastAction
        property string lastAction: "poweroff"
        onActionChanged: if (QuickSettings.pendingPower !== "") lastAction = QuickSettings.pendingPower
        readonly property var info: ({
            lock:     { icon: "lock",               verb: "Locking",        now: "Lock now" },
            suspend:  { icon: "bedtime",            verb: "Going to sleep", now: "Sleep now" },
            logout:   { icon: "logout",             verb: "Logging out",    now: "Log out now" },
            reboot:   { icon: "restart_alt",        verb: "Restarting",     now: "Restart now" },
            poweroff: { icon: "power_settings_new", verb: "Shutting down",  now: "Shut down now" },
            preview:  { icon: "timer",              verb: "Preview",        now: "Close" }
        })[action] ?? { icon: "timer", verb: "", now: "Now" }
        readonly property color tone: Config.c.powerColor === "Red" ? "#FF4D4D" : Config.c.powerColor === "Accent" ? Theme.primary
                                    : (action === "reboot" || action === "poweroff" ? "#FF4D4D" : Theme.primary)
        readonly property string theme: ["Ring", "Big number", "Bar", "Glass"].indexOf(Config.c.powerTheme) >= 0 ? Config.c.powerTheme : "Ring"
        readonly property string place: ["Centre", "Top", "Bottom", "Left", "Right"].indexOf(Config.c.powerPlace) >= 0 ? Config.c.powerPlace : "Centre"

        // a little beat every second
        onSecsChanged: if (on && w.tick !== "None") beat.restart()
        property real pop: 1
        SequentialAnimation {
            id: beat
            NumberAnimation { target: w; property: "pop"; to: 1.12; duration: Math.round(90 / w.speed); easing.type: Easing.OutCubic }
            NumberAnimation { target: w; property: "pop"; to: 1; duration: Math.round(380 / w.speed); easing.type: Easing.OutBack; easing.overshoot: Motion.os(2) }
        }

        Shortcut { sequence: "Escape"; enabled: w.on && w.main; onActivated: QuickSettings.cancelPower() }
        Shortcut { sequence: "Return"; enabled: w.on && w.main; onActivated: QuickSettings.powerNow() }
        Shortcut { sequence: "Enter"; enabled: w.on && w.main; onActivated: QuickSettings.powerNow() }

        // ---- the screen behind: darkened, and blurred by Hyprland (the "arqen-countdown" layer is in
        // the shell's blur rule) ----
        Rectangle {
            anchors.fill: parent
            color: "black"
            opacity: Math.max(0, Math.min(90, Config.c.powerCdDim ?? 50)) / 100 * w.t
        }
        MouseArea { anchors.fill: parent }        // nothing behind it can be clicked meanwhile

        // ---- what is shown, where Settings put it ----
        Item {
            id: box
            width: body.width; height: body.height
            readonly property int m: 90
            x: w.place === "Left" ? m : w.place === "Right" ? w.width - width - m : (w.width - width) / 2
            y: w.place === "Top" ? m : w.place === "Bottom" ? w.height - height - m : (w.height - height) / 2
            opacity: w.animIn === "Drop" ? Math.min(1, w.t * 3) : w.t
            // comes in the chosen way, then stays at exactly scale 1 (pin-sharp at rest)
            scale: w.animIn !== "Zoom" || w.t >= 0.999 ? 1 : 0.92 + 0.08 * w.t
            transform: Translate { y: w.animIn === "Rise" ? 70 * (1 - w.t) : w.animIn === "Drop" ? -120 * (1 - w.t) : 0 }

            Column {
                id: body
                spacing: 26
                readonly property bool sideways: w.place === "Left" || w.place === "Right"

                Loader {
                    anchors.horizontalCenter: body.sideways ? undefined : parent.horizontalCenter
                    x: body.sideways && w.place === "Right" ? body.width - width : 0
                    sourceComponent: w.theme === "Big number" ? bigC : w.theme === "Bar" ? barC : w.theme === "Glass" ? glassC : ringC
                }
                // cancel / now
                Row {
                    anchors.horizontalCenter: body.sideways ? undefined : parent.horizontalCenter
                    x: body.sideways && w.place === "Right" ? body.width - width : 0
                    spacing: 12
                    ArqButton { text: "Cancel"; onClicked: QuickSettings.cancelPower() }
                    ArqButton { text: w.info.now; primary: true; onClicked: QuickSettings.powerNow() }
                }
                DText {
                    renderType: Text.QtRendering
                    anchors.horizontalCenter: body.sideways ? undefined : parent.horizontalCenter
                    x: body.sideways && w.place === "Right" ? body.width - width : 0
                    text: "Esc: cancel  ·  Enter: now"
                    color: Qt.rgba(1, 1, 1, 0.55); font.pixelSize: 12
                }
            }
        }

        // ---------- the looks ----------
        // Ring: a ring that empties, the seconds in the middle
        Component {
            id: ringC
            Column {
                spacing: 18
                Item {
                    anchors.horizontalCenter: parent.horizontalCenter
                    width: 250; height: 250
                    Shape {
                        anchors.fill: parent
                        // drawn as real curves at the screen's own resolution (sharp at any scale)
                        preferredRendererType: Shape.CurveRenderer
                        antialiasing: true
                        ShapePath {
                            strokeColor: Qt.rgba(1, 1, 1, 0.14); strokeWidth: 14; fillColor: "transparent"; capStyle: ShapePath.RoundCap
                            PathAngleArc { centerX: 125; centerY: 125; radiusX: 110; radiusY: 110; startAngle: 0; sweepAngle: 360 }
                        }
                        ShapePath {
                            strokeColor: w.tone; strokeWidth: 14; fillColor: "transparent"; capStyle: ShapePath.RoundCap
                            PathAngleArc { centerX: 125; centerY: 125; radiusX: 110; radiusY: 110; startAngle: -90; sweepAngle: 360 * w.shownFrac }
                        }
                    }
                    Column {
                        anchors.centerIn: parent
                        Icon { renderType: Text.QtRendering; anchors.horizontalCenter: parent.horizontalCenter; name: w.info.icon; size: 30; color: w.tone; scale: w.pop }
                        TickNumber { anchors.horizontalCenter: parent.horizontalCenter; value: w.secs; style: w.tick; speed: w.speed; color: "white"; pixelSize: 78; weight: Font.DemiBold }
                    }
                }
                DText { renderType: Text.QtRendering; anchors.horizontalCenter: parent.horizontalCenter; text: w.info.verb; color: "white"; font.pixelSize: 26; font.weight: Font.Medium }
            }
        }
        // Big number: just the seconds, very big
        Component {
            id: bigC
            Column {
                spacing: 0
                Row {
                    anchors.horizontalCenter: parent.horizontalCenter
                    spacing: 10
                    Icon { renderType: Text.QtRendering; name: w.info.icon; size: 30; color: w.tone; anchors.verticalCenter: parent.verticalCenter }
                    DText { renderType: Text.QtRendering; text: w.info.verb + " in"; color: "white"; font.pixelSize: 28; font.weight: Font.Medium; anchors.verticalCenter: parent.verticalCenter }
                }
                TickNumber {
                    anchors.horizontalCenter: parent.horizontalCenter
                    value: w.secs; style: w.tick; speed: w.speed
                    color: w.tone; pixelSize: 240; weight: Font.Bold
                }
                DText { renderType: Text.QtRendering; anchors.horizontalCenter: parent.horizontalCenter; text: w.secs === 1 ? "second" : "seconds"; color: Qt.rgba(1, 1, 1, 0.7); font.pixelSize: 20 }
            }
        }
        // Bar: a card with a line that runs down
        Component {
            id: barC
            Rectangle {
                width: 520; height: 150; radius: Theme.radius + 6
                color: Theme.cardSolid
                border.width: 1; border.color: Theme.stroke
                Row {
                    x: 26; y: 26; spacing: 16
                    Rectangle {
                        width: 54; height: 54; radius: 27; color: Qt.rgba(w.tone.r, w.tone.g, w.tone.b, 0.18)
                        Icon { renderType: Text.QtRendering; anchors.centerIn: parent; name: w.info.icon; size: 28; color: w.tone; scale: w.pop }
                    }
                    Column {
                        anchors.verticalCenter: parent.verticalCenter
                        DText { renderType: Text.QtRendering; text: w.info.verb; font.pixelSize: 22; font.weight: Font.DemiBold }
                        Row {
                            spacing: 5
                            DText { renderType: Text.QtRendering; text: "in"; color: Theme.subtext; font.pixelSize: 15 }
                            TickNumber { value: w.secs; style: w.tick; speed: w.speed; color: Theme.text; pixelSize: 15; weight: Font.Bold }
                            DText { renderType: Text.QtRendering; text: w.secs === 1 ? "second" : "seconds"; color: Theme.subtext; font.pixelSize: 15 }
                        }
                    }
                }
                Rectangle {
                    x: 26; y: parent.height - 40; width: parent.width - 52; height: 12; radius: 6
                    color: Theme.tile
                    Rectangle { width: Math.max(height, parent.width * w.shownFrac); height: parent.height; radius: 6; color: w.tone }
                }
            }
        }
        // Glass: a frosted card, the icon breathing, a thin line running down
        Component {
            id: glassC
            Rectangle {
                width: 440; height: glassCol.implicitHeight + 56; radius: 34
                color: Qt.rgba(1, 1, 1, 0.10)
                border.width: 1; border.color: Qt.rgba(1, 1, 1, 0.22)
                Column {
                    id: glassCol
                    anchors.centerIn: parent
                    spacing: 16
                    Rectangle {
                        anchors.horizontalCenter: parent.horizontalCenter
                        width: 84; height: 84; radius: 42
                        color: Qt.rgba(w.tone.r, w.tone.g, w.tone.b, 0.25)
                        scale: w.pop
                        Icon { renderType: Text.QtRendering; anchors.centerIn: parent; name: w.info.icon; size: 40; color: "white" }
                    }
                    DText { renderType: Text.QtRendering; anchors.horizontalCenter: parent.horizontalCenter; text: w.info.verb; color: "white"; font.pixelSize: 26; font.weight: Font.Medium }
                    Row {
                        anchors.horizontalCenter: parent.horizontalCenter
                        spacing: 6
                        TickNumber { value: w.secs; style: w.tick; speed: w.speed; color: "white"; pixelSize: 52; weight: Font.Bold }
                        DText { renderType: Text.QtRendering; text: "s"; color: "white"; font.pixelSize: 52; font.weight: Font.Bold }
                    }
                    // a thin line that runs down (centred, the card's width)
                    Rectangle {
                        anchors.horizontalCenter: parent.horizontalCenter
                        width: 300; height: 6; radius: 3
                        color: Qt.rgba(1, 1, 1, 0.18)
                        Rectangle {
                            width: Math.max(parent.height, parent.width * w.shownFrac); height: parent.height; radius: 3
                            color: "white"
                            Behavior on width { NumberAnimation { duration: 120 } }
                        }
                    }
                }
            }
        }
    }
}
