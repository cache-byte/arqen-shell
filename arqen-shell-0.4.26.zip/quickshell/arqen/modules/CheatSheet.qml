import Quickshell
import Quickshell.Io
import Quickshell.Hyprland
import QtQuick
import QtQuick.Layouts
import qs.config
import qs.components
import qs.services

// A small window with the keyboard shortcuts that are set right now (from Hyprland, so it is always true).
// Shows once when you log in (turn it off here or in Settings > Keyboard shortcuts); also
// `qs -c arqen ipc call arqen cheatsheet`.
FloatingWindow {
    id: win
    visible: Ui.cheatOpen
    onVisibleChanged: { if (!visible) Ui.cheatOpen = false; else { query = ""; load() } }
    title: "Arqen shortcuts"
    implicitWidth: 660
    implicitHeight: 680
    minimumSize: Qt.size(380, 360)
    color: Theme.windowBg

    property var binds: []
    property string query: ""
    function load() { if (!proc.running) proc.running = true }
    Process {
        id: proc
        command: ["python3", "-I", Appearance.scripts + "list-binds.py"]
        stdout: StdioCollector { onStreamFinished: { try { win.binds = JSON.parse(text).filter(b => !b.mouse) } catch (e) {} } }
    }
    // ---- turn what Hyprland reports into words a person would use, and sort it into groups ----
    readonly property var groupOrder: [
        { name: "Windows", icon: "web_asset" },
        { name: "Desktops", icon: "workspaces" },
        { name: "Apps and panels", icon: "apps" },
        { name: "Screenshots and recording", icon: "screenshot_region" },
        { name: "System", icon: "settings" },
        { name: "Other", icon: "more_horiz" }
    ]
    function keyLabel(k) {
        const m = { SUPER: "Super", CTRL: "Ctrl", ALT: "Alt", SHIFT: "Shift", Print: "PrtSc", Left: "←", Right: "→", Up: "↑", Down: "↓",
                    Delete: "Del", Return: "Enter", Escape: "Esc", Caps_Lock: "Caps Lock", Num_Lock: "Num Lock", Scroll_Lock: "Scroll Lock",
                    space: "Space", Prior: "Page Up", Next: "Page Down", comma: ",", period: ".", slash: "/", minus: "-", equal: "=",
                    XF86AudioRaiseVolume: "Volume up", XF86AudioLowerVolume: "Volume down", XF86AudioMute: "Mute", XF86AudioPlay: "Play / pause",
                    XF86AudioNext: "Next track", XF86AudioPrev: "Previous track", XF86MonBrightnessUp: "Brightness up", XF86MonBrightnessDown: "Brightness down" }
        return m[k] ?? (k.length === 1 ? k.toUpperCase() : k.replace(/_/g, " "))
    }
    // desktop target: "e-1" previous, "e+1" next, a number, ...
    function desk(t) {
        t = String(t).trim()
        if (t === "e-1" || t === "r-1" || t === "-1") return "the previous desktop"
        if (t === "e+1" || t === "r+1" || t === "+1") return "the next desktop"
        if (/^\d+$/.test(t)) return "desktop " + t
        if (t === "special" || t.indexOf("special") === 0) return "the scratchpad"
        return t
    }
    // [title, group] for an action text
    function describe(a) {
        a = String(a || "").trim()
        let m
        if ((m = a.match(/^Ipc\s*·\s*(.+)$/))) {
            const w = m[1].split(",").map(x => x.trim().toLowerCase())
            const key = w.join(" ")
            const known = {
                "screenshot window": ["Screenshot a window", 3], "screenshot area": ["Screenshot a selected area", 3],
                "screenshot screen": ["Screenshot the whole screen", 3], "screenshot record": ["Record the screen", 3],
                "screenshot open": ["Open the screenshot tool", 3], "switcher next": ["Switch to the next window", 0],
                "switcher prev": ["Switch to the previous window", 0], "power open": ["Open the power menu", 4],
                "launcher toggle": ["App launcher", 2], "search toggle": ["Search", 2], "quick toggle": ["Control centre", 2],
                "notifs toggle": ["Notifications", 2], "clipboard toggle": ["Clipboard history", 2], "overview toggle": ["Desktop view", 2]
            }
            if (known[key]) return known[key]
            return ["Arqen: " + w.join(" "), 5]
        }
        if ((m = a.match(/^Focus\s*·\s*workspace\s+(.+)$/))) return ["Go to " + desk(m[1]), 1]
        if ((m = a.match(/^Move window\s*·\s*workspace\s+(.+)$/))) return ["Move the window to " + desk(m[1]), 1]
        if ((m = a.match(/^Focus\s*·\s*(?:direction\s+)?([lrud]|left|right|up|down)$/i))) {
            const d = { l: "left", r: "right", u: "up", d: "down" }
            return ["Focus the window to the " + (d[m[1].toLowerCase()] ?? m[1].toLowerCase()), 0]
        }
        if (/^Move window\s*\(drag\)/.test(a)) return ["Drag a window with the mouse", 0]
        if (/^Resize window/.test(a)) return ["Resize a window", 0]
        if (a === "Close window") return ["Close the window", 0]
        if (/^Float or tile/.test(a)) return ["Float or tile the window", 0]
        if (/^Fullscreen/.test(a)) return ["Fullscreen the window", 0]
        if (/^Show \/ hide scratchpad/.test(a)) return ["Show or hide the scratchpad", 1]
        if (/^Leave Hyprland/.test(a)) return ["Log out", 4]
        if (/scripts\/ipc call arqen key caps/.test(a)) return ["Show the Caps Lock indicator", 4]
        if (/scripts\/ipc call arqen key num/.test(a)) return ["Show the Num Lock indicator", 4]
        if (/^Arqen:\s*Minimi[sz]e/.test(a)) return ["Minimise to the side panel", 0]
        if ((m = a.match(/^Arqen:\s*(.+)$/))) {
            const t = m[1]
            return [t, /screenshot|record/i.test(t) ? 3 : /settings|power|lock/i.test(t) ? 4 : 2]
        }
        if ((m = a.match(/^Open (.+)$/))) return [a, 2]
        if ((m = a.match(/^Run:\s*(.+)$/))) {
            const c = m[1]
            if (/xdg-terminal-exec|kitty|foot|alacritty|gnome-terminal|konsole|xterm|wezterm/.test(c)) return ["Open a terminal", 2]
            const first = c.split(/\s+/)[0].replace(/^.*\//, "").replace(/\|\|.*/, "")
            if (/brightness/.test(c)) return ["Change the screen brightness", 4]
            if (/playerctl/.test(c)) return ["Control the music player", 2]
            if (/wpctl|pamixer|pactl/.test(c)) return ["Change the volume", 4]
            return ["Open " + first, 2]
        }
        return [a === "" ? "Set in the Hyprland config" : a, 5]
    }
    // the shortcuts, as a list of group headings and rows
    readonly property var shown: {
        const q = query.trim().toLowerCase()
        const groups = groupOrder.map(g => ({ name: g.name, icon: g.icon, rows: [], seen: ({}) }))
        for (const b of binds) {
            const d = describe(b.action)
            const keys = String(b.keys).split("+").map(x => x.trim()).filter(x => x !== "").map(keyLabel)
            const sub = d[0] + " " + keys.join(" ") + " " + groups[d[1]].name + " " + b.action
            if (q !== "" && sub.toLowerCase().indexOf(q) < 0) continue
            const id = d[0] + "|" + keys.join("+")
            if (groups[d[1]].seen[id]) continue
            groups[d[1]].seen[id] = true
            groups[d[1]].rows.push({ title: d[0], keys: keys })
        }
        const out = []
        for (const g of groups) {
            if (g.rows.length === 0) continue
            g.rows.sort((x, y) => x.title < y.title ? -1 : x.title > y.title ? 1 : 0)
            out.push({ head: true, name: g.name, icon: g.icon, count: g.rows.length })
            for (const r of g.rows) out.push({ head: false, title: r.title, keys: r.keys })
        }
        return out
    }

    // once per login: the first time the shell starts in this session
    Process {
        id: marker
        command: ["sh", "-c", "f=\"${XDG_RUNTIME_DIR:-/tmp}/arqen-cheatsheet-shown\"; if [ -e \"$f\" ]; then echo seen; else : > \"$f\"; echo first; fi"]
        stdout: StdioCollector { onStreamFinished: { if (text.trim() === "first" && Config.c.cheatOnLogin) { win.load(); Ui.cheatOpen = true } } }
    }
    Timer { interval: 4000; running: true; onTriggered: marker.running = true }

    ColumnLayout {
        anchors { fill: parent; margins: 18 }
        spacing: 12
        RowLayout {
            Layout.fillWidth: true
            Icon { name: "keyboard"; size: 26; color: Theme.primary }
            DText { Layout.fillWidth: true; text: "Keyboard shortcuts"; font.pixelSize: 20; font.weight: Font.Medium }
            TrayButton { round: true; icon: "close"; size: 18; tip: "Close"; onClicked: Ui.cheatOpen = false }
        }
        ArqField { id: find; Layout.fillWidth: true; implicitHeight: 40; placeholder: "Search shortcuts"; iconName: "search"; onEdited: win.query = text }
        Flickable {
            Layout.fillWidth: true; Layout.fillHeight: true
            contentWidth: width; contentHeight: col.implicitHeight
            clip: true; boundsBehavior: Flickable.StopAtBounds
            Column {
                id: col
                width: parent.width
                spacing: 2
                Repeater {
                    model: win.shown
                    delegate: Item {
                        id: row
                        required property var modelData
                        readonly property bool head: modelData.head === true
                        width: col.width
                        height: head ? 46 : Math.max(40, chips.implicitHeight + 14)
                        // a group heading
                        Row {
                            visible: row.head
                            anchors { left: parent.left; leftMargin: 4; bottom: parent.bottom; bottomMargin: 6 }
                            spacing: 8
                            Icon { name: row.modelData.icon ?? "keyboard"; size: 18; color: Theme.primary; anchors.verticalCenter: parent.verticalCenter }
                            DText { text: row.modelData.name ?? ""; font.pixelSize: 14; font.weight: Font.DemiBold; anchors.verticalCenter: parent.verticalCenter }
                            DText { text: row.modelData.count ?? ""; font.pixelSize: 12; color: Theme.subtext; anchors.verticalCenter: parent.verticalCenter }
                        }
                        // a shortcut: what it does on the left, the keys on the right
                        Rectangle {
                            visible: !row.head
                            anchors.fill: parent; anchors.topMargin: 1; anchors.bottomMargin: 1
                            radius: 12
                            color: rowMa.containsMouse ? Theme.hover : "transparent"
                            MouseArea { id: rowMa; anchors.fill: parent; hoverEnabled: true }
                            DText {
                                anchors { left: parent.left; leftMargin: 12; right: chips.left; rightMargin: 16; verticalCenter: parent.verticalCenter }
                                text: row.modelData.title ?? ""; elide: Text.ElideRight; font.pixelSize: 14
                            }
                            Flow {
                                id: chips
                                anchors { right: parent.right; rightMargin: 10; verticalCenter: parent.verticalCenter }
                                width: Math.min(implicitWidth, parent.width * 0.55)
                                spacing: 4
                                layoutDirection: Qt.RightToLeft
                                Repeater {
                                    model: row.head ? [] : (row.modelData.keys ?? []).slice().reverse()
                                    delegate: Rectangle {
                                        required property string modelData
                                        height: 26; width: Math.max(26, kt.implicitWidth + 16); radius: 8
                                        color: Theme.tile
                                        border.width: 1; border.color: Theme.stroke
                                        DText { id: kt; anchors.centerIn: parent; text: parent.modelData; font.pixelSize: 12; font.weight: Font.Medium }
                                    }
                                }
                            }
                        }
                    }
                }
                DText {
                    visible: win.shown.length === 0
                    width: parent.width; horizontalAlignment: Text.AlignHCenter
                    topPadding: 30
                    text: win.binds.length === 0 ? "Loading the shortcuts..." : "No shortcut matches that"
                    color: Theme.subtext; font.pixelSize: 14
                }
            }
        }
        RowLayout {
            Layout.fillWidth: true
            DText { Layout.fillWidth: true; text: "Show this when I log in"; color: Theme.subtext; font.pixelSize: 13 }
            ArqToggle { checked: Config.c.cheatOnLogin; onToggled: v => Config.c.cheatOnLogin = v }
        }
    }
}
