import QtQuick
import QtMultimedia

// A looping, silent video wallpaper. Loaded on its own (Wallpaper.qml uses a Loader) so that a
// missing Qt multimedia module only breaks video wallpapers, not the shell.
// Fedora package: qt6-qtmultimedia (install.sh / update.sh install it).
Item {
    id: v
    property string path: ""
    // paused (saver on, or a full-screen window hides it): no decoding, no drawing
    property bool paused: false
    onPausedChanged: { if (paused) mp.pause(); else if (mp.source != "") mp.play() }
    // a small still of the video, for picking the accent colour
    signal frame(url u)

    MediaPlayer {
        id: mp
        source: v.path !== "" ? "file://" + v.path : ""
        loops: MediaPlayer.Infinite
        videoOutput: vo
        onSourceChanged: if (source != "" && !v.paused) play()
        Component.onCompleted: if (source != "" && !v.paused) play()
    }
    VideoOutput {
        id: vo
        anchors.fill: parent
        fillMode: VideoOutput.PreserveAspectCrop
    }
    // grab a frame once the video is showing
    Timer {
        id: grab
        interval: 700
        onTriggered: vo.grabToImage(r => v.frame(r.url), Qt.size(96, 54))
    }
    onPathChanged: grab.restart()
    Component.onCompleted: grab.restart()
}
