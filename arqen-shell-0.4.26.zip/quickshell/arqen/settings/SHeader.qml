import QtQuick
import QtQuick.Layouts
import qs.config
import qs.components

// Section title above a group of settings. Every page uses this, so they all look the same.
// `key`: the settings in this section ("a,b,c"); a "back to the defaults" button shows at the right
// while any of them is changed.
Item {
    id: h
    property string text: ""
    property string key: ""
    readonly property bool changed: key !== "" && !Config.isDefault(key)
    Layout.fillWidth: true
    Layout.topMargin: 10
    implicitHeight: Math.max(label.implicitHeight, key !== "" ? 28 : 0)
    DText {
        id: label
        anchors { left: parent.left; right: rb.left; verticalCenter: parent.verticalCenter; rightMargin: 8 }
        leftPadding: 18
        text: h.text
        font.pixelSize: 13
        font.weight: Font.DemiBold
        color: Theme.subtext
        elide: Text.ElideRight
    }
    Rectangle {
        id: rb
        anchors { right: parent.right; rightMargin: 8; verticalCenter: parent.verticalCenter }
        visible: h.key !== ""
        opacity: h.changed ? 1 : 0
        width: rrow.implicitWidth + 24; height: Sizes.hS; radius: Sizes.hS / 2
        color: rma.containsMouse && h.changed ? Theme.hover : "transparent"
        Behavior on opacity { NumberAnimation { duration: 120 } }
        Row {
            id: rrow
            anchors.centerIn: parent; spacing: 4
            Icon { name: "restart_alt"; size: 16; color: Theme.subtext; anchors.verticalCenter: parent.verticalCenter }
            DText { text: "Reset"; font.pixelSize: Sizes.textS; color: Theme.subtext; anchors.verticalCenter: parent.verticalCenter }
        }
        MouseArea { id: rma; anchors.fill: parent; enabled: h.changed; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: Config.resetKeys(h.key) }
        HoverTip { hovered: rma.containsMouse && h.changed; text: "Put everything in this section back to the default" }
    }
}
