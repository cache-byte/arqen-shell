import Quickshell
import QtQuick
import QtQuick.Layouts
import qs.config
import qs.components
import qs.services

FloatingWindow {
    id: win
    visible: Ui.settingsOpen
    onVisibleChanged: { if (!visible) Ui.settingsOpen = false; else reveal.restart() }
    title: "Arqen Settings"
    implicitWidth: 1080
    implicitHeight: 740
    color: Theme.windowBg

    // Do not force a large minimum size: at 150–200% scaling the available logical
    // desktop can be small. All content is scrollable and must adapt to the window.
    minimumSize: Qt.size(320, 360)

    // Pages, in the order they are listed (titles and icons from SettingsIndex, so the search
    // results and the navigation always agree).
    readonly property var cats: SettingsIndex.order.map(k => ({ k: k, t: SettingsIndex.pages[k].t, i: SettingsIndex.pages[k].i }))
    readonly property var current: cats.find(c => c.k === SettingsIndex.pageOf(Ui.settingsPage)) ?? cats[0]
    readonly property bool compact: width < 760
    readonly property bool veryCompact: width < 520

    // ---- header: page title, you ----
    Item {
        id: header
        anchors { left: parent.left; right: parent.right; top: parent.top }
        height: win.veryCompact ? 112 : (win.compact ? 100 : 76)
        DText {
            id: pageTitle
            anchors { left: parent.left; leftMargin: win.compact ? 18 : 32; verticalCenter: parent.verticalCenter }
            width: win.compact ? Math.max(60, parent.width - x - 16) : Math.max(60, Math.min(implicitWidth, Math.max(60, find.x - x - 16)))
            anchors.verticalCenterOffset: win.compact ? -22 : 0
            text: win.current.t; font.pixelSize: 26; font.weight: Font.Medium; elide: Text.ElideRight
        }
        // search every setting: type, then pick a result (or Enter for the first)
        ArqField {
            id: find
            anchors { verticalCenter: parent.verticalCenter; right: me.visible ? me.left : parent.right; rightMargin: 16 }
            width: win.compact ? Math.max(100, parent.width - 32) : Math.min(360, Math.max(100, parent.width * 0.36))
            anchors.verticalCenterOffset: win.compact ? 24 : 0
            implicitHeight: Sizes.hM
            placeholder: "Search settings"
            iconName: "search"
            closesOnEscape: false
            onEscaped: text = ""
            onAccepted: if (win.hits.length > 0) win.goTo(win.hits[0])
            onNav: k => { if (k === Qt.Key_Down && win.hits.length > 0) win.goTo(win.hits[0]) }
        }
        Rectangle {
            id: me
            visible: !win.compact
            anchors { right: parent.right; rightMargin: 24; verticalCenter: parent.verticalCenter }
            height: 44; radius: 22; width: meRow.implicitWidth + 18
            color: meMa.containsMouse ? Theme.hover : Theme.card
            Row { id: meRow; anchors.verticalCenter: parent.verticalCenter; x: 6; spacing: 10
                Avatar { size: 32; anchors.verticalCenter: parent.verticalCenter }
                DText { text: User.name; font.pixelSize: 14; font.weight: Font.Medium; anchors.verticalCenter: parent.verticalCenter } }
            MouseArea { id: meMa; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: Ui.settingsPage = "about" }
        }
    }

    readonly property var hits: find.text.trim() === "" ? [] : SettingsIndex.search(find.text).slice(0, 8)
    // ---- jump to the option that was searched for: open its page (and tab), scroll to its row, flash it ----
    property string jumpTitle: ""
    property string jumpText: ""
    property int jumpTries: 0
    property int jumpTab: 0
    function goTo(e) {
        jumpTitle = (e.t || "").toLowerCase()
        jumpText = find.text.toLowerCase().trim()
        Config.c.showAdvanced = true      // the result may be a setting that is normally hidden
        Ui.settingsPage = e.p
        find.text = ""
        jumpTries = 0; jumpTab = 0
        jumper.restart()
    }
    // how well one row (anything with a title) matches what was searched for
    function rowScore(it) {
        if (typeof it.title !== "string" || it.title === "" || !it.visible || it.height < 8) return 0
        const t = it.title.toLowerCase()
        if (t === jumpTitle) return 5
        if (jumpTitle.length > 2 && (t.includes(jumpTitle) || jumpTitle.includes(t))) return 4
        if (jumpText.length > 1 && t.includes(jumpText)) return 3
        const sub = typeof it.subtitle === "string" ? it.subtitle.toLowerCase() : ""
        if (jumpText.length > 2 && sub.includes(jumpText)) return 2
        const words = jumpTitle.split(/\s+/).filter(w => w.length > 3)
        if (words.length > 0 && words.every(w => t.includes(w))) return 2
        return 0
    }
    function scan(it, best) {
        const sc = rowScore(it)
        if (sc > best.s) { best.s = sc; best.it = it }
        const ch = it.children
        for (let i = 0; ch && i < ch.length; i++) scan(ch[i], best)
    }
    Timer {
        id: jumper
        interval: 160; repeat: true
        onTriggered: {
            win.jumpTries++
            if (win.jumpTries < 2) return          // let the page finish sliding in
            if (!ld.item || ld.status !== Loader.Ready || ld.item.height < 10) { if (win.jumpTries > 20) stop(); return }
            const best = { s: 0, it: null }
            win.scan(ld.item, best)
            if (best.it && best.s >= 2) {
                stop()
                const p = best.it.mapToItem(flick.contentItem, 0, 0)
                const maxY = Math.max(0, flick.contentHeight - flick.height)
                flick.contentY = Math.max(0, Math.min(maxY, p.y - 90))
                flashBox.x = p.x; flashBox.y = p.y; flashBox.width = best.it.width; flashBox.height = best.it.height
                flash.restart()
                return
            }
            // not on the first tab of a tabbed page: try the next one (a few tries on each)
            if (win.jumpTries % 4 === 0 && ld.item.tab !== undefined && win.jumpTab < 3) { win.jumpTab++; ld.item.tab = win.jumpTab }
            if (win.jumpTries > 18) stop()
        }
    }

    // ---- page ----
    Flickable {
        id: flick
        anchors { left: parent.left; right: parent.right; top: header.bottom; bottom: parent.bottom }
        // room under the last row for the floating navigation pill, so nothing is hidden behind it
        contentHeight: ld.item ? Math.max(ld.item.implicitHeight, ld.item.height) + (win.veryCompact ? 24 : 36) + nav.height + (win.veryCompact ? 6 : 12) : 0
        clip: true
        boundsBehavior: Flickable.StopAtBounds
        // the row that was jumped to glows for a moment
        Rectangle {
            id: flashBox
            z: 20; radius: 12; opacity: 0
            color: Qt.rgba(Theme.primary.r, Theme.primary.g, Theme.primary.b, 0.22)
            border.width: 2; border.color: Theme.primary
            SequentialAnimation {
                id: flash
                NumberAnimation { target: flashBox; property: "opacity"; to: 1; duration: 140 }
                PauseAnimation { duration: 1100 }
                NumberAnimation { target: flashBox; property: "opacity"; to: 0; duration: 700 }
            }
        }
        Loader {
            id: ld
            width: Math.max(0, Math.min(flick.width - (win.compact ? 16 : 64), 860))
            x: (flick.width - width) / 2; y: 4
            active: Ui.settingsOpen      // closed: the page (and its pictures) is freed
            source: "pages/" + win.current.k + ".qml"
            onSourceChanged: flick.contentY = 0
            // a new page slides up a little and fades in
            onLoaded: pageIn.restart()
            ParallelAnimation {
                id: pageIn
                NumberAnimation { target: ld; property: "opacity"; from: 0; to: 1; duration: 180; easing.type: Easing.OutCubic }
                NumberAnimation { target: ld; property: "y"; from: 14; to: 4; duration: 260; easing.type: Easing.OutCubic }
            }
        }
    }
    ArqScrollBar { flick: flick; topInset: 8; bottomInset: nav.height + (win.veryCompact ? 14 : 24) }
    // ---- navigation: a dark pill at the bottom; the open page is a white pill with its name ----
    Rectangle {
        id: nav
        anchors { bottom: parent.bottom; bottomMargin: win.veryCompact ? 6 : 12; horizontalCenter: parent.horizontalCenter }
        height: win.veryCompact ? 52 : 60; radius: height / 2
        width: Math.max(0, Math.min(navRow.implicitWidth + 20, win.width - (win.veryCompact ? 12 : 24)))
        color: Theme.navBar

        Flickable {
            id: navFlick
            anchors { fill: parent; leftMargin: 10; rightMargin: 10 }
            contentWidth: navRow.implicitWidth; contentHeight: height
            interactive: contentWidth > width
            clip: true
            boundsBehavior: Flickable.StopAtBounds
            flickableDirection: Flickable.HorizontalFlick
            // the mouse wheel scrolls it sideways when it does not fit
            WheelHandler {
                onWheel: e => {
                    const d = e.angleDelta.y !== 0 ? e.angleDelta.y : e.angleDelta.x
                    navFlick.contentX = Math.max(0, Math.min(navFlick.contentWidth - navFlick.width, navFlick.contentX - d))
                }
            }
            Row {
                id: navRow
                height: parent.height; spacing: 4
                Repeater {
                    id: navRep
                    model: win.cats
                    delegate: Item {
                        id: navItem
                        required property var modelData
                        required property int index
                        readonly property bool sel: win.current.k === modelData.k
                        height: 46; anchors.verticalCenter: parent.verticalCenter
                        width: sel ? navLabel.implicitWidth + 22 + 10 + 34 : 48
                        Behavior on width { NumberAnimation { duration: 220; easing.type: Easing.OutCubic } }
                        clip: true
                        Rectangle {
                            anchors.fill: parent; radius: height / 2
                            color: navItem.sel ? Theme.navPill : (navMa.containsMouse ? (Theme.dark ? Qt.rgba(1, 1, 1, 0.08) : Qt.rgba(0, 0, 0, 0.08)) : "transparent")
                            Behavior on color { ColorAnimation { duration: 160 } }
                        }
                        Row {
                            x: navItem.sel ? 15 : (navItem.width - 22) / 2
                            anchors.verticalCenter: parent.verticalCenter; spacing: 10
                            Icon { name: navItem.modelData.i; size: 22; color: navItem.sel ? Theme.navPillText : Theme.navIcon
                                   anchors.verticalCenter: parent.verticalCenter }
                            DText { id: navLabel; text: navItem.modelData.t; visible: navItem.sel; color: Theme.navPillText
                                    font.pixelSize: 14; font.weight: Font.DemiBold; anchors.verticalCenter: parent.verticalCenter }
                        }
                        MouseArea { id: navMa; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor
                                    onClicked: Ui.settingsPage = navItem.modelData.k }
                        HoverTip { hovered: navMa.containsMouse && !navItem.sel; text: navItem.modelData.t; side: "top" }
                    }
                }
            }
        }
    }
    // keep the open page's pill in view when the bar is scrolled
    Timer {
        id: reveal
        interval: 240
        onTriggered: {
            const i = win.cats.findIndex(c => c.k === win.current.k)
            const it = navRep.itemAt(i)
            if (!it || !navFlick.interactive) return
            const max = navFlick.contentWidth - navFlick.width
            if (it.x < navFlick.contentX) navFlick.contentX = Math.max(0, it.x - 8)
            else if (it.x + it.width > navFlick.contentX + navFlick.width) navFlick.contentX = Math.min(max, it.x + it.width - navFlick.width + 8)
        }
    }
    Connections { target: Ui; function onSettingsPageChanged() { reveal.restart() } }

    // ---- search results, under the search field ----
    Rectangle {
        visible: win.hits.length > 0
        z: 50
        x: find.x; y: header.height - 10
        width: find.width
        height: resCol.implicitHeight + 12
        radius: 18
        color: Theme.cardSolid
        border.width: 1; border.color: Theme.stroke
        Column {
            id: resCol
            anchors { left: parent.left; right: parent.right; top: parent.top; margins: 6 }
            Repeater {
                model: win.hits
                delegate: Rectangle {
                    required property var modelData
                    width: resCol.width; height: 46; radius: 12
                    color: rma.containsMouse ? Theme.hover : "transparent"
                    Row {
                        anchors { left: parent.left; leftMargin: 10; verticalCenter: parent.verticalCenter }
                        spacing: 10
                        Rectangle { width: 30; height: 30; radius: 15; color: Theme.tile; anchors.verticalCenter: parent.verticalCenter
                            Icon { anchors.centerIn: parent; name: modelData.i || "tune"; size: 17 } }
                        Column {
                            anchors.verticalCenter: parent.verticalCenter
                            DText { text: modelData.t; font.pixelSize: 13; width: resCol.width - 70; elide: Text.ElideRight }
                            DText { text: SettingsIndex.pageTitle(modelData.p); font.pixelSize: 11; color: Theme.subtext }
                        }
                    }
                    MouseArea { id: rma; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: win.goTo(modelData) }
                }
            }
        }
    }
}
