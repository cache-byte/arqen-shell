import QtQuick
import Quickshell
import Quickshell.Hyprland
import qs.config
import qs.components

// A drop-down: shows the current choice with an arrow; click for the list (it floats above
// everything; a click outside closes it). model: labels; `picked(index, label)`.
Rectangle {
    id: dd
    property var model: []
    property int currentIndex: -1
    property string placeholder: ""
    property real maxWidth: 100000          // set by SRow
    readonly property real naturalWidth: Math.max(160, meas.implicitWidth + 52)
    property bool open: false
    signal picked(int index, string label)

    implicitWidth: Math.min(naturalWidth, maxWidth)
    width: implicitWidth
    implicitHeight: Sizes.hS
    radius: height / 2
    color: ma.containsMouse || open ? Theme.hover : Theme.tile
    border.width: open ? 2 : 0; border.color: Theme.primary

    DText { id: meas; visible: false; font.pixelSize: Sizes.textS; text: dd.model.reduce((a, s) => String(s).length > a.length ? String(s) : a, "") }
    DText {
        anchors { left: parent.left; leftMargin: Sizes.padS; right: arrow.left; rightMargin: Sizes.gapS; verticalCenter: parent.verticalCenter }
        elide: Text.ElideRight
        font.pixelSize: Sizes.textS
        text: dd.currentIndex >= 0 && dd.currentIndex < dd.model.length ? dd.model[dd.currentIndex] : dd.placeholder
        color: dd.currentIndex >= 0 ? Theme.text : Theme.subtext
    }
    Icon { id: arrow; anchors { right: parent.right; rightMargin: 12; verticalCenter: parent.verticalCenter }
           name: dd.open ? "expand_less" : "expand_more"; size: Sizes.iconS; color: Theme.subtext }
    MouseArea { id: ma; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: dd.open = !dd.open }

    // only one list open at a time; closing on a click elsewhere is a Hyprland focus grab (a popup's own
    // grab, with a second popup open, gave "Creating a popup with a parent which does not match...")
    onOpenChanged: if (open) Ui.dropdownOwner = dd
    Connections { target: Ui; function onDropdownOwnerChanged() { if (Ui.dropdownOwner !== dd) dd.open = false } }
    HyprlandFocusGrab { windows: [pop]; active: pop.visible; onCleared: dd.open = false }
    PopupWindow {
        id: pop
        visible: dd.open
        anchor.item: dd
        anchor.edges: Edges.Bottom | Edges.Left
        anchor.gravity: Edges.Bottom | Edges.Right
        anchor.margins.top: 4
        color: "transparent"
        implicitWidth: Math.max(dd.width, 200)
        implicitHeight: Math.min(360, list.contentHeight + 12)
        onVisibleChanged: if (!visible) dd.open = false
        Rectangle {
            anchors.fill: parent
            radius: 14
            color: Theme.cardSolid
            border.width: 1; border.color: Theme.stroke
            ListView {
                id: list
                anchors { fill: parent; margins: 6 }
                clip: true
                model: dd.model
                boundsBehavior: Flickable.StopAtBounds
                delegate: Rectangle {
                    required property var modelData
                    required property int index
                    width: list.width; height: 32; radius: 16
                    color: index === dd.currentIndex ? Theme.secondaryContainer : (om.containsMouse ? Theme.hover : "transparent")
                    DText { anchors { left: parent.left; leftMargin: 16; right: parent.right; rightMargin: 36; verticalCenter: parent.verticalCenter }
                            elide: Text.ElideRight; font.pixelSize: 14; text: String(parent.modelData)
                            color: parent.index === dd.currentIndex ? Theme.onSecondaryContainer : Theme.text }
                    Icon { visible: parent.index === dd.currentIndex; anchors { right: parent.right; rightMargin: 12; verticalCenter: parent.verticalCenter }
                           name: "check"; size: 16; color: Theme.onSecondaryContainer }
                    MouseArea { id: om; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor
                                onClicked: { dd.open = false; dd.picked(parent.index, String(parent.modelData)) } }
                }
                Component.onCompleted: positionViewAtIndex(Math.max(0, dd.currentIndex), ListView.Center)
            }
            ArqScrollBar { flick: list }
        }
    }
}
