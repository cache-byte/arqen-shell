import QtQuick
import QtQuick.Layouts
import qs.config
import qs.components

// Pick one name from a list (fonts, themes, cursors) without typing it.
// Shows the current choice; "Change" opens a searchable list. Fonts can preview themselves.
Rectangle {
    id: pk
    property string title: ""
    property string icon: ""
    property var model: []                 // names
    property var extra: []                 // options shown first: [{ value, label }]
    property string current: ""
    property bool previewFont: false
    property bool open: false
    property string query: ""
    signal picked(string v)
    property string key: ""                // the setting it shows: a reset arrow while it is not the default

    readonly property var items: {
        const q = query.trim().toLowerCase()
        const ex = q === "" ? extra : extra.filter(e => e.label.toLowerCase().indexOf(q) >= 0)
        const names = q === "" ? model : model.filter(n => n.toLowerCase().indexOf(q) >= 0)
        return ex.concat(names.map(n => ({ value: n, label: n })))
    }
    function labelOf(v) {
        const e = extra.find(x => x.value === v)
        return e ? e.label : (v === "" ? "Not set" : v)
    }

    Layout.fillWidth: true
    implicitHeight: col.implicitHeight + 28
    radius: Math.max(0, Theme.radius - 2)
    color: Theme.card

    ColumnLayout {
        id: col
        anchors { left: parent.left; right: parent.right; top: parent.top; margins: 14 }
        spacing: 10

        RowLayout {
            Layout.fillWidth: true
            spacing: 14
            Layout.leftMargin: 4
            Rectangle {
                visible: pk.icon !== ""
                Layout.preferredWidth: 36; Layout.preferredHeight: 36; radius: 18; color: Theme.tile
                Icon { anchors.centerIn: parent; name: pk.icon; size: 20; color: Theme.text }
            }
            ColumnLayout {
                Layout.fillWidth: true; spacing: 1
                DText { text: pk.title; font.pixelSize: 15; Layout.fillWidth: true; elide: Text.ElideRight }
                DText {
                    text: pk.labelOf(pk.current)
                    font.pixelSize: 12; color: Theme.subtext
                    font.family: (pk.previewFont && pk.current !== "") ? pk.current : Theme.font
                    Layout.fillWidth: true; elide: Text.ElideRight
                }
            }
            Rectangle {
                visible: pk.key !== ""
                Layout.preferredWidth: 30; Layout.preferredHeight: 30; radius: 15
                readonly property bool changed: pk.key !== "" && !Config.isDefault(pk.key)
                opacity: changed ? 1 : 0
                color: pkr.containsMouse ? Theme.hover : "transparent"
                Icon { anchors.centerIn: parent; name: "restart_alt"; size: 19; color: Theme.subtext }
                MouseArea { id: pkr; anchors.fill: parent; enabled: parent.changed; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: Config.resetKeys(pk.key) }
                HoverTip { hovered: pkr.containsMouse && parent.changed; text: "Back to the default" }
            }
            ArqButton { text: pk.open ? "Done" : "Change"; onClicked: { pk.open = !pk.open; pk.query = ""; search.text = "" } }
        }

        ArqField {
            id: search
            visible: pk.open
            Layout.fillWidth: true
            placeholder: "Search " + pk.model.length + " " + pk.title.toLowerCase()
            iconName: "search"
            closesOnEscape: false
            onEscaped: pk.open = false
            onEdited: pk.query = text
        }
        Item {
          visible: pk.open
          Layout.fillWidth: true
          Layout.preferredHeight: Math.min(280, lv.contentHeight)
          ListView {
            id: lv
            anchors.fill: parent
            clip: true
            boundsBehavior: Flickable.StopAtBounds
            model: pk.open ? pk.items : []
            delegate: Rectangle {
                id: row
                required property var modelData
                readonly property bool on: modelData.value === pk.current
                width: lv.width; height: 40; radius: 12
                color: on ? Theme.tileOn : (rma.containsMouse ? Theme.hover : "transparent")
                DText {
                    anchors { left: parent.left; leftMargin: 14; right: parent.right; rightMargin: 40; verticalCenter: parent.verticalCenter }
                    text: row.modelData.label
                    font.pixelSize: 14
                    font.family: (pk.previewFont && row.modelData.value !== "") ? row.modelData.value : Theme.font
                    elide: Text.ElideRight
                }
                Icon { visible: row.on; anchors { right: parent.right; rightMargin: 12; verticalCenter: parent.verticalCenter } name: "check"; size: 18; color: Theme.accent }
                MouseArea { id: rma; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: pk.picked(row.modelData.value) }
            }
            DText { visible: lv.count === 0; anchors.centerIn: parent; text: "Nothing found"; color: Theme.subtext }
          }
          ArqScrollBar { flick: lv }
        }
    }
}
