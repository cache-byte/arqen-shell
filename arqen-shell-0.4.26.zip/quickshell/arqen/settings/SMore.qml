import QtQuick
import QtQuick.Layouts
import qs.config
import qs.components

// "Show more settings": the switch at the bottom of a page. Off: only what a daily user needs; on: everything.
SGroup {
    SRow {
        title: "Show more settings"
        subtitle: Config.c.showAdvanced ? "Everything is shown" : "Fine-tuning and rarely needed options are hidden"
        icon: "tune"
        ArqToggle { checked: Config.c.showAdvanced; onToggled: v => Config.c.showAdvanced = v }
    }
}
