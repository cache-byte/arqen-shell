import QtQuick
import QtQuick.Layouts
import qs.config
import qs.components
import qs.services
import qs.settings

// The options of one or more catalogue pages (assets/hypr-schema.json) as settings rows: search, a page
// chooser when there are several, and rarely used options under "Show advanced".
ColumnLayout {
    id: v
    width: parent ? parent.width : 400
    spacing: 16
    property var pageIds: []
    property string intro: ""
    property string pick: pageIds.length > 0 ? pageIds[0] : ""
    property string query: ""
    property bool advanced: false
    readonly property var cur: HyprOpts.page(pick)
    readonly property string q: query.trim().toLowerCase()
    function matches(o) {
        if (q === "") return true
        return (o.label + " " + o.key + " " + (o.desc || "")).toLowerCase().indexOf(q) >= 0
    }
    function sectionOpts(s) { return s.options.filter(o => matches(o)) }
    readonly property var shown: {
        if (!cur) return []
        const out = []
        for (const s of cur.sections) {
            if (s.advanced && !advanced && q === "") continue
            const opts = sectionOpts(s)
            if (opts.length) out.push({ title: s.title, options: opts })
        }
        return out
    }

    DText {
        visible: v.intro !== ""
        Layout.fillWidth: true; Layout.leftMargin: 18; Layout.rightMargin: 18
        wrapMode: Text.WordWrap; color: Theme.subtext; font.pixelSize: 13
        text: v.intro
    }
    SGroup {
        visible: !HyprOpts.loaded
        DText { Layout.fillWidth: true; Layout.margins: 18; wrapMode: Text.WordWrap; color: Theme.subtext; text: "The list of options is loading (assets/hypr-schema.json)." }
    }

    ArqField {
        Layout.fillWidth: true
        placeholder: "Search these options"; iconName: "search"
        onEdited: v.query = text
    }
    RowLayout {
        Layout.fillWidth: true; spacing: 8
        visible: v.pageIds.length > 1
        Repeater {
            model: v.pageIds
            delegate: ArqButton {
                required property string modelData
                text: HyprOpts.page(modelData) ? HyprOpts.page(modelData).title : modelData
                primary: v.pick === modelData
                onClicked: v.pick = modelData
            }
        }
    }

    Repeater {
        model: v.shown
        delegate: ColumnLayout {
            id: sec
            required property var modelData
            Layout.fillWidth: true; spacing: 6
            SHeader { text: sec.modelData.title }
            SGroup {
                Repeater {
                    model: sec.modelData.options
                    delegate: Loader {
                        id: row
                        required property var modelData
                        Layout.fillWidth: true
                        readonly property var opt: modelData
                        readonly property var value: HyprOpts.get(opt)
                        readonly property bool numeric: opt.type === "int" || opt.type === "float"
                        sourceComponent: opt.type === "bool" ? boolRow
                            : (numeric && opt.min !== undefined && opt.max !== undefined) ? sliderRow
                            : (opt.type === "choice" || opt.type === "enum") ? choiceRow : textRow
                        Component {
                            id: boolRow
                            SRow {
                                title: row.opt.label; subtitle: row.opt.desc || ""
                                changed: HyprOpts.has(row.opt.key); resetHandled: true; onReset: HyprOpts.reset(row.opt.key)
                                ArqToggle { checked: !!row.value; onToggled: v2 => HyprOpts.set(row.opt.key, v2) }
                            }
                        }
                        Component {
                            id: sliderRow
                            SliderRow {
                                title: row.opt.label; subtitle: row.opt.desc || ""
                                changed: HyprOpts.has(row.opt.key); resetHandled: true; onReset: HyprOpts.reset(row.opt.key)
                                from: row.opt.min; to: row.opt.max
                                step: row.opt.type === "int" ? 1 : Math.max(0.01, (row.opt.max - row.opt.min) / 100)
                                value: Number(row.value)
                                onMoved: v2 => HyprOpts.set(row.opt.key, row.opt.type === "int" ? Math.round(v2) : Math.round(v2 * 1000) / 1000)
                            }
                        }
                        Component {
                            id: choiceRow
                            SRow {
                                title: row.opt.label; subtitle: row.opt.desc || ""
                                changed: HyprOpts.has(row.opt.key); resetHandled: true; onReset: HyprOpts.reset(row.opt.key)
                                SDropdown {
                                    model: row.opt.choices || []
                                    currentIndex: (row.opt.choices || []).indexOf(String(row.value))
                                    placeholder: "Default"
                                    onPicked: (i, l) => HyprOpts.set(row.opt.key, l)
                                }
                            }
                        }
                        Component {
                            id: textRow
                            SRow {
                                title: row.opt.label; subtitle: row.opt.desc || ""
                                changed: HyprOpts.has(row.opt.key); resetHandled: true; onReset: HyprOpts.reset(row.opt.key)
                                ArqField {
                                    implicitWidth: 200; implicitHeight: 38
                                    text: row.value === undefined || row.value === null ? "" : String(row.value)
                                    onAccepted: {
                                        const raw = text.trim()
                                        if (raw === "") { HyprOpts.reset(row.opt.key); return }
                                        HyprOpts.set(row.opt.key, row.numeric && !isNaN(Number(raw)) ? Number(raw) : raw)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    DText {
        visible: v.shown.length === 0 && HyprOpts.loaded
        Layout.fillWidth: true; Layout.leftMargin: 18; horizontalAlignment: Text.AlignLeft
        color: Theme.subtext; text: v.q !== "" ? "Nothing matches your search on this page." : "Nothing to set here."
    }
    RowLayout {
        Layout.fillWidth: true; spacing: 8
        ArqButton { text: v.advanced ? "Hide advanced" : "Show advanced"; onClicked: v.advanced = !v.advanced; visible: v.q === "" }
        Item { Layout.fillWidth: true }
        ArqButton { text: "Reset this page"; onClicked: HyprOpts.resetPage(v.pick) }
    }
    Item { Layout.preferredHeight: 4 }
}
