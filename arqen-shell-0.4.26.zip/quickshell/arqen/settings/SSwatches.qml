import QtQuick
import qs.config
import qs.components

// A row of ready-made colours and a box for any hex colour (#RRGGBB). `picked(hex)` fires on either.
Item {
    id: s
    property string value: "#FFFFFF"
    property var colors: ["#FFFFFF", "#F5E6D3", "#E9D8A6", "#FFB74D", "#FF7A7A", "#F48FB1", "#B39DDB", "#82B1FF", "#80DEEA", "#A5D6A7", "#111114"]
    signal picked(string hex)
    readonly property real naturalWidth: row.implicitWidth
    implicitWidth: row.implicitWidth; implicitHeight: 34
    width: implicitWidth; height: implicitHeight
    Row {
        id: row
        spacing: 8
        Repeater {
            model: s.colors
            delegate: Rectangle {
                required property string modelData
                width: 26; height: 26; radius: 13
                anchors.verticalCenter: parent.verticalCenter
                color: modelData
                border.width: s.value.toLowerCase() === modelData.toLowerCase() ? 3 : 1
                border.color: s.value.toLowerCase() === modelData.toLowerCase() ? Theme.primary : Theme.stroke
                MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor; onClicked: s.picked(parent.modelData) }
            }
        }
        ArqField {
            width: 104; implicitHeight: 34
            anchors.verticalCenter: parent.verticalCenter
            placeholder: "#RRGGBB"
            text: s.value
            onEdited: if (/^#[0-9a-fA-F]{6}$/.test(text)) s.picked(text)
        }
    }
}
