import QtQuick
import QtQuick.Layouts
import qs.config
import qs.components
import qs.services
import qs.settings

// Power and lock: battery, sleep and idle, the lock screen and the power menu.
ColumnLayout {
    id: pg
    width: parent.width
    spacing: 16
    readonly property var rawTabs: (({ power: 0, lockscreen: 1, powermenu: 2 }))
    property int tab: rawTabs[Ui.settingsPage] ?? 0
    Connections { target: Ui; function onSettingsPageChanged() { const t = pg.rawTabs[Ui.settingsPage]; if (t !== undefined) pg.tab = t } }
    SSegmented {
        Layout.alignment: Qt.AlignHCenter
        model: ["Power", "Lock screen", "Power menu"]
        currentIndex: pg.tab
        onPicked: i => pg.tab = i
        segW: 130
        maxWidth: pg.width - 36
    }
    Loader {
        // exactly the page's width, whatever the loaded page would like (else its sliders run off the right edge)
        Layout.fillWidth: true
        Layout.minimumWidth: 0
        Layout.preferredWidth: pg.width
        Layout.maximumWidth: pg.width
        source: ["PowerMain.qml", "LockMain.qml", "PowerMenuMain.qml"][pg.tab]
    }
}
