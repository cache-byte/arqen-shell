import QtQuick
import QtQuick.Layouts
import qs.config
import qs.components
import qs.services
import qs.settings

// Windows: how apps open, the window handle, windows pushed off the screen, and Hyprland's own options.
ColumnLayout {
    id: pg
    width: parent.width
    spacing: 16
    readonly property var rawTabs: (({ windows: 0, hyprland: 1 }))
    property int tab: rawTabs[Ui.settingsPage] ?? 0
    Connections { target: Ui; function onSettingsPageChanged() { const t = pg.rawTabs[Ui.settingsPage]; if (t !== undefined) pg.tab = t } }
    SSegmented {
        Layout.alignment: Qt.AlignHCenter
        visible: Config.c.showAdvanced
        model: ["Windows", "Advanced"]
        currentIndex: pg.tab
        onPicked: i => pg.tab = i
        segW: 130
        maxWidth: pg.width - 36
    }
    Loader {
        // exactly the page's width, whatever the loaded page would like (else its sliders run off the right edge)
        Layout.fillWidth: true
        Layout.minimumWidth: 0
        Layout.preferredWidth: pg.width
        Layout.maximumWidth: pg.width
        source: ["WindowsMain.qml", "HyprMain.qml"][Config.c.showAdvanced ? pg.tab : 0]
    }
}
