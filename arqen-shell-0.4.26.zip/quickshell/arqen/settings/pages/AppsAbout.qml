import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Io
import qs.config
import qs.components
import qs.services
import qs.settings

// Where each app came from (system package, Flatpak, Snap, AppImage, your own) and how to remove it.
ColumnLayout {
    id: pg
    width: parent ? parent.width : 400
    spacing: 16
    property var apps: []
    property string query: ""
    property string open: ""
    property var detail: null
    readonly property string py: Quickshell.shellDir + "/scripts/app-info.py"

    Process {
        id: listP
        running: true
        command: ["python3", "-I", pg.py, "list"]
        stdout: StdioCollector { onStreamFinished: { try { pg.apps = JSON.parse(text) } catch (e) {} } }
    }
    Process {
        id: infoP
        stdout: StdioCollector { onStreamFinished: { try { pg.detail = JSON.parse(text) } catch (e) {} } }
    }
    function show(id) {
        if (pg.open === id) { pg.open = ""; return }
        pg.open = id; pg.detail = null
        infoP.command = ["python3", "-I", pg.py, "info", id]; infoP.running = true
    }
    readonly property var shown: {
        const q = query.trim().toLowerCase()
        return (q === "" ? apps : apps.filter(a => a.name.toLowerCase().indexOf(q) >= 0 || a.id.toLowerCase().indexOf(q) >= 0)).slice(0, 80)
    }
    readonly property var sourceName: ({ flatpak: "Flatpak", rpm: "System package (rpm)", deb: "System package (deb)", pacman: "System package (pacman)",
        snap: "Snap", appimage: "AppImage", user: "Your own launcher", system: "System package", unknown: "Unknown" })

    SHeader { text: "About your apps" }
    ArqField { Layout.fillWidth: true; placeholder: "Search installed apps"; iconName: "search"; onEdited: pg.query = text }
    SGroup {
        Repeater {
            model: pg.shown
            delegate: ColumnLayout {
                id: ar
                required property var modelData
                Layout.fillWidth: true; spacing: 0
                SRow {
                    title: ar.modelData.name
                    subtitle: pg.sourceName[ar.modelData.source] || ar.modelData.source
                    onClicked: pg.show(ar.modelData.id)
                    AppIcon { entry: Apps.byId(ar.modelData.id); source: Apps.byId(ar.modelData.id) ? "" : "application-x-executable"; size: 30; anchors.verticalCenter: parent.verticalCenter }
                    Icon { name: pg.open === ar.modelData.id ? "expand_less" : "expand_more"; color: Theme.subtext; anchors.verticalCenter: parent.verticalCenter }
                }
                ColumnLayout {
                    visible: pg.open === ar.modelData.id
                    Layout.fillWidth: true; Layout.leftMargin: 68; Layout.rightMargin: 18; Layout.bottomMargin: 14
                    spacing: 6
                    DText { visible: pg.detail === null; text: "Looking…"; color: Theme.subtext; font.pixelSize: 12 }
                    DText { visible: pg.detail !== null && pg.detail.package !== ""; Layout.fillWidth: true; wrapMode: Text.WrapAnywhere; color: Theme.subtext; font.pixelSize: 12
                        text: pg.detail ? "Package: " + pg.detail.package + (pg.detail.version ? "  ·  version " + pg.detail.version : "") : "" }
                    DText { visible: pg.detail !== null; Layout.fillWidth: true; wrapMode: Text.WrapAnywhere; color: Theme.subtext; font.pixelSize: 12
                        text: pg.detail ? "Launcher: " + pg.detail.file : "" }
                    RowLayout {
                        spacing: 8
                        ArqButton { text: "Open"; onClicked: { const e = Apps.byId(ar.modelData.id); if (e) e.execute() } }
                        ArqButton {
                            visible: pg.detail !== null && pg.detail.uninstall !== ""
                            text: "Uninstall…"
                            onClicked: Quickshell.execDetached(["sh", Quickshell.shellDir + "/scripts/run-in-terminal.sh", "Uninstall " + pg.detail.name, pg.detail.uninstall])
                        }
                    }
                }
            }
        }
    }
    DText { visible: pg.apps.length > pg.shown.length && pg.query === ""; Layout.leftMargin: 18; color: Theme.subtext; font.pixelSize: 12; text: "The first 80 apps are shown. Search for the rest." }
    Item { Layout.preferredHeight: 4 }
}
