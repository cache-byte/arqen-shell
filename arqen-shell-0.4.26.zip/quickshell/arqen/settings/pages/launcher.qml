import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Io
import qs.config
import qs.components
import qs.services
import qs.settings

ColumnLayout {
    id: pg
    width: parent.width; spacing: 16
    // the quick folders shown in search (empty list in the settings = the two defaults)
    readonly property var folders: (Config.c.quickFolders && Config.c.quickFolders.length > 0) ? Config.c.quickFolders
        : [{ n: "Downloads", d: Config.home + "/Downloads" }, { n: "Screenshots", d: Config.shotDir }]
    function setFolders(l) { Config.c.quickFolders = l }

    // ---------------- launcher (app drawer) ----------------
    SHeader { text: "Launcher  ·  " + Keybinds.launcher; key: "launcherPos,launcherLayout,launcherWidth,launcherHeight,launcherIconSize" }
    SGroup {
        SRow { key: "launcherPos"; title: "Position"; subtitle: "Where on the screen it opens"; icon: "open_with"
            PlacePicker { value: Config.c.launcherPos; onPicked: v => Config.c.launcherPos = v } }
        SRow { key: "launcherLayout"; title: "Layout"; subtitle: "Grid: icons with names below. List: one app per row"; icon: "view_module"
            SChoices { model: ["grid", "list"]; current: Config.c.launcherLayout; onPicked: v => Config.c.launcherLayout = v } }
        SliderRow { key: "launcherWidth"; title: "Width"; subtitle: "% of the screen"; icon: "width"; suffix: " %"; from: 25; to: 95; step: 1
            value: Config.c.launcherWidth; onMoved: v => Config.c.launcherWidth = Math.round(v) }
        SliderRow { key: "launcherHeight"; title: "Height"; subtitle: "% of the screen"; icon: "height"; suffix: " %"; from: 30; to: 95; step: 1
            value: Config.c.launcherHeight; onMoved: v => Config.c.launcherHeight = Math.round(v) }
        SliderRow { key: "launcherIconSize"; title: "Icon size"; icon: "photo_size_select_large"; suffix: " px"; from: 32; to: 72; step: 1
            value: Config.c.launcherIconSize; onMoved: v => Config.c.launcherIconSize = Math.round(v) }
    }

    // ---------------- search ----------------
    SHeader { text: "Search  ·  " + Keybinds.search; key: "searchPos,searchLayout,searchWidth,searchHeight" }
    SGroup {
        SRow { key: "searchPos"; title: "Position"; subtitle: "Where on the screen it opens"; icon: "open_with"
            PlacePicker { value: Config.c.searchPos; onPicked: v => Config.c.searchPos = v } }
        SRow { key: "searchLayout"; title: "App results"; subtitle: "Show apps as a grid or a list"; icon: "view_module"
            SChoices { model: ["grid", "list"]; current: Config.c.searchLayout; onPicked: v => Config.c.searchLayout = v } }
        SliderRow { key: "searchWidth"; title: "Width"; subtitle: "% of the screen"; icon: "width"; suffix: " %"; from: 25; to: 95; step: 1
            value: Config.c.searchWidth; onMoved: v => Config.c.searchWidth = Math.round(v) }
        SliderRow { key: "searchHeight"; title: "Maximum height"; subtitle: "% of the screen; it is shorter when there is less to show"; icon: "height"; suffix: " %"; from: 30; to: 95; step: 1
            value: Config.c.searchHeight; onMoved: v => Config.c.searchHeight = Math.round(v) }
    }
    SHeader { text: "Search: shown before you type"; key: "searchSuggestions,searchTopics,searchFolders" }
    SGroup {
        SRow { key: "searchSuggestions"; title: "Suggested apps"; subtitle: "Learns from what you open most"; icon: "lightbulb"
            ArqToggle { checked: Config.c.searchSuggestions; onToggled: v => Config.c.searchSuggestions = v } }
        SRow { key: "searchTopics"; title: "Settings topics"; icon: "tune"
            ArqToggle { checked: Config.c.searchTopics; onToggled: v => Config.c.searchTopics = v } }
        SRow { key: "searchFolders"; title: "Quick folders"; subtitle: "The folders shown as buttons"; icon: "folder"
            ArqToggle { checked: Config.c.searchFolders; onToggled: v => Config.c.searchFolders = v } }
    }
    SHeader { visible: Config.c.searchFolders; text: "Quick folders"; key: "quickFolders" }
    SGroup {
        visible: Config.c.searchFolders
        Repeater {
            model: pg.folders
            delegate: SRow {
                id: fr
                required property var modelData
                required property int index
                title: modelData.n; subtitle: modelData.d; icon: "folder"
                TrayButton { round: true; icon: "delete"; size: 18; tip: "Remove"; anchors.verticalCenter: parent.verticalCenter
                    onClicked: pg.setFolders(pg.folders.filter((x, i) => i !== fr.index)) }
            }
        }
        SRow { title: "Add a folder"; icon: "create_new_folder"; subtitle: pg.folders.length >= 8 ? "Eight is the most" : ""
            ArqButton { text: "Choose…"; enabled: pg.folders.length < 8; onClicked: { folderPick.command = ["python3", "-I", Quickshell.shellDir + "/scripts/pick-folder.py", "Add a quick folder", Config.home]; folderPick.running = true } } }
        SRow { visible: (Config.c.quickFolders || []).length > 0; title: "Back to Downloads and Screenshots"; icon: "restart_alt"
            ArqButton { text: "Reset"; onClicked: Config.c.quickFolders = [] } }
    }
    Process {
        id: folderPick
        stdout: StdioCollector { onStreamFinished: {
            const d = text.trim()
            if (d === "") return
            const n = d.replace(/\/+$/, "").split("/").pop() || d
            pg.setFolders(pg.folders.concat([{ n: n, d: d }]))
        } }
    }
}
