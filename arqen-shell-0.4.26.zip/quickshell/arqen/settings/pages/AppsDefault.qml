import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Io
import qs.config
import qs.components
import qs.services
import qs.settings

// Which app opens links, folders, pictures, videos, music, PDFs... Click a kind of file, then
// the app. Saved where every app looks (~/.config/mimeapps.list; the terminal in xdg-terminals.list).
ColumnLayout {
    id: pg
    width: parent.width; spacing: 16

    property var cats: []
    property bool loading: true
    property string open: ""                // the kind being changed
    function refresh() { if (!listProc.running) { loading = true; listProc.running = true } }
    Process {
        id: listProc
        running: true
        command: ["python3", "-I", Appearance.scripts + "default-apps.py", "list"]
        stdout: StdioCollector { onStreamFinished: { try { pg.cats = JSON.parse(text) } catch (e) {} pg.loading = false } }
    }
    Process {
        id: setProc
        onExited: pg.refresh()
    }
    function pick(cat, id) {
        setProc.command = ["python3", "-I", Appearance.scripts + "default-apps.py", "set", cat, id]
        setProc.running = true
        // show it straight away
        pg.cats = pg.cats.map(c => c.id === cat ? Object.assign({}, c, { current: id }) : c)
        pg.open = ""
    }
    function entryOf(id) { const k = String(id || "").replace(/\.desktop$/, ""); return k === "" ? null : Apps.byId(k) }

    SHeader { text: "Open with" }
    LoadingPill { visible: pg.loading && pg.cats.length === 0; Layout.alignment: Qt.AlignHCenter; width: 56; height: 30 }
    SGroup {
        Repeater {
            model: pg.cats
            delegate: ColumnLayout {
                id: cat
                required property var modelData
                readonly property var cur: pg.entryOf(modelData.current)
                Layout.fillWidth: true
                spacing: 0
                SRow {
                    title: cat.modelData.label
                    subtitle: cat.modelData.options.length === 0 ? "No app for this is installed" : ""
                    icon: cat.modelData.icon
                    onClicked: pg.open = pg.open === cat.modelData.id ? "" : cat.modelData.id
                    Row {
                        anchors.verticalCenter: parent.verticalCenter
                        spacing: 8
                        AppIcon { visible: cat.cur !== null; entry: cat.cur; size: 26; anchors.verticalCenter: parent.verticalCenter }
                        DText { text: cat.cur?.name ?? (cat.modelData.current !== "" ? cat.modelData.current.replace(/\.desktop$/, "") : "Not set"); color: cat.cur ? Theme.text : Theme.subtext; font.pixelSize: 13; anchors.verticalCenter: parent.verticalCenter }
                    }
                    ArqButton { visible: cat.modelData.options.length > 0; text: pg.open === cat.modelData.id ? "Close" : "Change"; onClicked: pg.open = pg.open === cat.modelData.id ? "" : cat.modelData.id }
                }
                // the apps that can open it: click one
                Flow {
                    visible: pg.open === cat.modelData.id
                    Layout.fillWidth: true; Layout.margins: 12
                    spacing: 4
                    Repeater {
                        model: pg.open === cat.modelData.id ? cat.modelData.options : []
                        delegate: Rectangle {
                            id: opt
                            required property string modelData
                            readonly property var e: pg.entryOf(modelData)
                            readonly property bool on: modelData === cat.modelData.current
                            width: 92; height: 92; radius: 14
                            color: on ? Theme.pillOn : (oma.containsMouse ? Theme.hover : "transparent")
                            AppIcon { entry: opt.e; source: opt.e ? "" : "application-x-executable"; size: 40; anchors { horizontalCenter: parent.horizontalCenter; top: parent.top; topMargin: 10 } }
                            DText {
                                anchors { bottom: parent.bottom; bottomMargin: 8; left: parent.left; right: parent.right; leftMargin: 4; rightMargin: 4 }
                                text: opt.e?.name ?? opt.modelData.replace(/\.desktop$/, ""); font.pixelSize: 11
                                elide: Text.ElideRight; horizontalAlignment: Text.AlignHCenter; color: opt.on ? Theme.pillOnText : Theme.text
                            }
                            MouseArea { id: oma; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: pg.pick(cat.modelData.id, opt.modelData) }
                        }
                    }
                }
            }
        }
    }
}
