import QtQuick
import QtQuick.Layouts
import QtQuick.Shapes
import Quickshell
import Quickshell.Services.UPower
import qs.config
import qs.components
import qs.services
import qs.settings

// Power menu: its look and buttons, and the countdown before lock / sleep / log out / restart / shut down.
ColumnLayout {
    id: page
    width: parent.width; spacing: 16

    // ---- the power menu (control centre > power button) ----
    readonly property var pmIds: ["poweroff", "reboot", "logout", "suspend", "lock"]
    readonly property var pmNames: ({ poweroff: ["Power off", "power_settings_new"], reboot: ["Restart", "restart_alt"], logout: ["Log out", "logout"], suspend: ["Sleep", "bedtime"], lock: ["Lock", "lock"] })
    readonly property var pmOrder: {
        const o = (Config.c.powerOrder || []).filter(id => pmIds.indexOf(id) >= 0)
        for (const id of pmIds) if (o.indexOf(id) < 0) o.push(id)
        return o
    }
    function pmMove(id, d) {
        const o = pmOrder.slice(), i = o.indexOf(id), j = i + d
        if (j < 0 || j >= o.length) return
        o[i] = o[j]; o[j] = id
        Config.c.powerOrder = o
    }
    function pmShow(id, on) {
        const h = (Config.c.powerHidden || []).filter(x => x !== id)
        if (!on) h.push(id)
        Config.c.powerHidden = h
    }
    SHeader { text: "Power menu"; key: "powerStyle,powerShape,powerSize,powerCols,powerDim,powerLabels,powerSettingsBtn,powerOrder,powerHidden" }
    SGroup {
        SRow { title: "Try it"; subtitle: "Order and which buttons: further down"; icon: "visibility"
            ArqButton { text: "Open the power menu"; onClicked: Ui.toggle("power") } }
        SRow { key: "powerStyle"; title: "Colours"; subtitle: "Accent: your accent colour.  Soft: its lighter shade.  Mixed: the three theme colours.  Outline: rings"; icon: "palette"
            SChoices { model: ["Accent", "Soft", "Mixed", "Outline"]; current: Config.c.powerStyle; onPicked: v => Config.c.powerStyle = v } }
        SRow { key: "powerShape"; title: "Shape"; icon: "interests"
            SChoices { model: ["Circle", "Squircle"]; current: Config.c.powerShape; onPicked: v => Config.c.powerShape = v } }
        SliderRow { key: "powerSize"; title: "Button size"; icon: "photo_size_select_large"; suffix: " px"; from: 72; to: 150; step: 2
            value: Config.c.powerSize; onMoved: v => Config.c.powerSize = Math.round(v) }
        SliderRow { key: "powerCols"; title: "Buttons per row"; icon: "view_column"; suffix: ""; from: 1; to: 5; step: 1
            value: Config.c.powerCols; onMoved: v => Config.c.powerCols = Math.round(v) }
        SliderRow { key: "powerDim"; title: "Darken the screen behind"; icon: "contrast"; suffix: " %"; from: 0; to: 80; step: 5
            value: Config.c.powerDim; onMoved: v => Config.c.powerDim = Math.round(v) }
        SRow { key: "powerLabels"; title: "Names under the buttons"; icon: "label"
            ArqToggle { checked: Config.c.powerLabels; onToggled: v => Config.c.powerLabels = v } }
        SRow { key: "powerSettingsBtn"; title: "\"Power settings\" button"; icon: "settings"
            ArqToggle { checked: Config.c.powerSettingsBtn; onToggled: v => Config.c.powerSettingsBtn = v } }
        SRow { key: "powerOrder,powerHidden"; title: "Buttons and their order"; subtitle: "Arrows move a button, the switch shows or hides it"; icon: "reorder" }
        Repeater {
            model: page.pmOrder
            delegate: SRow {
                required property string modelData
                required property int index
                title: page.pmNames[modelData][0]
                icon: page.pmNames[modelData][1]
                TrayButton { round: true; icon: "arrow_upward"; size: 18; tip: "Earlier"; opacity: index > 0 ? 1 : 0.3; onClicked: page.pmMove(modelData, -1) }
                TrayButton { round: true; icon: "arrow_downward"; size: 18; tip: "Later"; opacity: index < page.pmOrder.length - 1 ? 1 : 0.3; onClicked: page.pmMove(modelData, 1) }
                ArqToggle { checked: (Config.c.powerHidden || []).indexOf(modelData) < 0; onToggled: v => page.pmShow(modelData, v) }
            }
        }
    }

    SHeader { text: "Lock, sleep, log out, restart, shut down"; key: "powerCountdown,powerTheme,powerPlace,powerAnimIn,powerAnimTick,powerProgress,powerAnimSpeed,powerColor,powerCdDim" }
    SGroup {
        SliderRow { key: "powerCountdown"; title: "Countdown first"; subtitle: Config.c.powerCountdown > 0 ? "A full-screen countdown you can cancel (Esc) or skip (Enter)" : "Off: it happens straight away"
            icon: "timer"; suffix: " s"; from: 0; to: 60; step: 5
            value: Config.c.powerCountdown; onMoved: v => Config.c.powerCountdown = Math.round(v) }
        SRow { key: "powerTheme"; title: "Look"; icon: "palette"; visible: Config.c.powerCountdown > 0
            SChoices { model: ["Ring", "Big number", "Bar", "Glass"]; current: Config.c.powerTheme; onPicked: v => Config.c.powerTheme = v } }
        SRow { key: "powerPlace"; title: "Where on the screen"; icon: "picture_in_picture_center"; visible: Config.c.powerCountdown > 0
            SChoices { model: ["Centre", "Top", "Bottom", "Left", "Right"]; current: Config.c.powerPlace; onPicked: v => Config.c.powerPlace = v } }
        SRow { key: "powerAnimIn"; title: "Comes in"; subtitle: "Zoom: grows in.  Fade.  Rise: from below.  Drop: falls in and bounces"; icon: "animation"; visible: Config.c.powerCountdown > 0
            SChoices { model: ["Zoom", "Fade", "Rise", "Drop"]; current: Config.c.powerAnimIn; onPicked: v => Config.c.powerAnimIn = v } }
        SRow { key: "powerAnimTick"; title: "Each second"; subtitle: "How the number changes: Pop, Slide (rolls up), Flip (like a flip clock), Fade, Roll (spins in), or None"; icon: "timer_10_alt_1"; visible: Config.c.powerCountdown > 0
            SChoices { model: ["Pop", "Slide", "Flip", "Fade", "Roll", "None"]; current: Config.c.powerAnimTick; onPicked: v => Config.c.powerAnimTick = v } }
        SRow { key: "powerProgress"; title: "Ring and bar"; subtitle: Config.c.powerProgress === "Steps" ? "A step each second" : "Run down smoothly"; icon: "progress_activity"; visible: Config.c.powerCountdown > 0
            SChoices { model: ["Smooth", "Steps"]; current: Config.c.powerProgress; onPicked: v => Config.c.powerProgress = v } }
        SliderRow { key: "powerAnimSpeed"; title: "Animation speed"; icon: "speed"; suffix: " %"; from: 50; to: 200; step: 10; visible: Config.c.powerCountdown > 0
            value: Config.c.powerAnimSpeed; onMoved: v => Config.c.powerAnimSpeed = Math.round(v) }
        SRow { key: "powerColor"; title: "Colour"; subtitle: "Auto: red for restart and shut down, your accent colour for the rest"; icon: "palette"; visible: Config.c.powerCountdown > 0
            SChoices { model: ["Auto", "Accent", "Red"]; current: Config.c.powerColor; onPicked: v => Config.c.powerColor = v } }
        SliderRow { key: "powerCdDim"; title: "Darken the screen behind"; icon: "contrast"; suffix: " %"; from: 0; to: 90; step: 5; visible: Config.c.powerCountdown > 0
            value: Config.c.powerCdDim; onMoved: v => Config.c.powerCdDim = Math.round(v) }
        SRow { title: "Try it"; subtitle: "Shows the countdown; nothing happens at the end"; icon: "visibility"; visible: Config.c.powerCountdown > 0
            ArqButton { text: "Show"; onClicked: QuickSettings.previewCountdown() } }
    }

}
