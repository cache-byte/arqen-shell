import QtQuick
import QtQuick.Layouts
import Quickshell
import qs.config
import qs.components
import qs.services
import qs.settings

// The screen and how windows sit on it (Hyprland). How things look (blur, colours) is in Appearance.
ColumnLayout {
    id: page
    width: parent.width; spacing: 16
    Component.onCompleted: Monitors.refresh()
    // changes that were not applied are not kept when the page is left
    Component.onDestruction: Monitors.discard()

    // ---------- screens (laid out like GNOME's display settings) ----------
    // the screen being changed below
    property string selName: ""
    readonly property var sel: Monitors.list.find(m => m.name === selName) ?? Monitors.list[0] ?? null
    readonly property var selSet: sel ? Monitors.setting(sel.name) : ({})
    function numberOf(name) { return Monitors.list.findIndex(m => m.name === name) + 1 }
    function prettyName(m) { return m ? ((m.make || m.model) ? (m.make + " " + m.model).trim() : m.name) : "" }
    // the screen's size on the desktop (after scale and rotation), and where it sits
    function geo(m) {
        const s = Monitors.setting(m.name)
        let w = m.width, h = m.height
        if (s.mode) { const p = s.mode.split("@")[0].split("x"); w = Number(p[0]) || w; h = Number(p[1]) || h }
        const sc = Number(s.scale) > 0 ? Number(s.scale) : (m.scale || 1)
        const tr = s.transform !== undefined ? Number(s.transform) : (m.transform || 0)
        if (tr % 2 === 1) { const t = w; w = h; h = t }
        let x = m.x, y = m.y
        if (/^-?\d+x-?\d+$/.test(s.position || "")) { const p = s.position.split("x"); x = Number(p[0]); y = Number(p[1]) }
        return { x: x, y: y, w: w / sc, h: h / sc }
    }
    // "2560 × 1440 · 144 Hz · 125 %" for a screen as it will be with the staged changes
    function modeText(m) {
        if (!m) return ""
        const s = Monitors.setting(m.name)
        const res = s.mode ? s.mode.split("@")[0].split("x") : [m.width, m.height]
        const hz = s.mode && s.mode.indexOf("@") > 0 ? Number(s.mode.split("@")[1]) : m.refresh
        const sc = Number(s.scale) > 0 ? Number(s.scale) : (m.scale || 1)
        return res[0] + " × " + res[1] + " · " + (Math.round(hz * 100) / 100) + " Hz · " + Math.round(sc * 100) + " %"
    }
    function aspect(w, h) {
        const r = w / h
        const known = [[16 / 9, "16:9"], [16 / 10, "16:10"], [3 / 2, "3:2"], [4 / 3, "4:3"], [5 / 4, "5:4"], [21 / 9, "21:9"], [64 / 27, "21:9"], [32 / 9, "32:9"]]
        for (const k of known) if (Math.abs(r - k[0]) < 0.02) return k[1]
        return ""
    }

    SHeader { text: Monitors.list.length > 1 ? "Screens" : "Screen"; key: "scale" }
    SCard {
        visible: Monitors.list.length > 0
        spacing: 12
        DText {
            Layout.fillWidth: true; wrapMode: Text.WordWrap; color: Theme.subtext; font.pixelSize: 12
            text: (Monitors.list.length > 1 ? "Drag the screens to match how they stand on your desk. Click one to change it below."
                                            : "Click the screen to change it below.") + " Change as many things as you like: nothing happens to your screens until you press Apply."
        }
        // ---- the arrangement ----
        Rectangle {
            id: arr
            Layout.fillWidth: true
            implicitHeight: 200
            radius: 14
            color: Theme.dark ? Qt.rgba(0, 0, 0, 0.25) : Qt.rgba(0, 0, 0, 0.05)
            border.width: 1; border.color: Theme.stroke
            // everything, scaled to fit
            readonly property var geos: Monitors.list.map(m => ({ name: m.name, g: page.geo(m) }))
            readonly property real minX: Math.min.apply(null, geos.map(o => o.g.x).concat([0]))
            readonly property real minY: Math.min.apply(null, geos.map(o => o.g.y).concat([0]))
            readonly property real spanW: Math.max(1, Math.max.apply(null, geos.map(o => o.g.x + o.g.w).concat([1])) - minX)
            readonly property real spanH: Math.max(1, Math.max.apply(null, geos.map(o => o.g.y + o.g.h).concat([1])) - minY)
            readonly property real k: Math.min((width - 60) / spanW, (height - 50) / spanH)
            readonly property real offX: (width - spanW * k) / 2
            readonly property real offY: (height - spanH * k) / 2
            // drop a screen: it sticks to the nearest edge of another one, then every screen gets
            // its place written down (the top-left one at 0,0)
            function dropAt(name, lx, ly) {
                const me = geos.find(o => o.name === name)
                if (!me) return
                let best = null, bestD = 1e12
                for (const o of geos) {
                    if (o.name === name) continue
                    const a = o.g, b = me.g
                    const cy = Math.max(a.y - b.h, Math.min(a.y + a.h, ly))
                    const cx = Math.max(a.x - b.w, Math.min(a.x + a.w, lx))
                    for (const c of [{ x: a.x + a.w, y: cy }, { x: a.x - b.w, y: cy }, { x: cx, y: a.y + a.h }, { x: cx, y: a.y - b.h }]) {
                        // line up with the other screen's edge when close
                        if (Math.abs(c.y - a.y) < a.h * 0.08) c.y = a.y
                        if (Math.abs(c.x - a.x) < a.w * 0.08) c.x = a.x
                        const d = (c.x - lx) * (c.x - lx) + (c.y - ly) * (c.y - ly)
                        if (d < bestD) { bestD = d; best = c }
                    }
                }
                if (!best) return
                const pos = {}
                for (const o of geos) pos[o.name] = o.name === name ? { x: best.x, y: best.y } : { x: o.g.x, y: o.g.y }
                const mx = Math.min.apply(null, Object.values(pos).map(p => p.x)), my = Math.min.apply(null, Object.values(pos).map(p => p.y))
                const all = Object.assign({}, Monitors.monitorsNow())
                for (const n of Object.keys(pos)) {
                    const m = Object.assign({}, all[n] || {})
                    m.position = Math.round(pos[n].x - mx) + "x" + Math.round(pos[n].y - my)
                    all[n] = m
                }
                Monitors.replaceAll(all)
            }
            Repeater {
                model: arr.geos
                delegate: Rectangle {
                    id: scr
                    required property var modelData
                    readonly property bool on: page.sel && page.sel.name === modelData.name
                    readonly property bool off: !!Monitors.setting(modelData.name).disabled
                    readonly property bool changed: Monitors.isChanged(modelData.name)
                    property bool dragging: false
                    property real dx: 0
                    property real dy: 0
                    width: Math.max(24, modelData.g.w * arr.k - 4)
                    height: Math.max(18, modelData.g.h * arr.k - 4)
                    x: dragging ? dx : arr.offX + (modelData.g.x - arr.minX) * arr.k + 2
                    y: dragging ? dy : arr.offY + (modelData.g.y - arr.minY) * arr.k + 2
                    z: dragging ? 5 : 1
                    radius: 6
                    color: off ? Theme.tile : (on ? Theme.primary : Theme.secondaryContainer)
                    border.width: changed ? 2 : (on ? 0 : 1); border.color: changed ? Theme.tertiary : Theme.stroke
                    Behavior on x { enabled: !scr.dragging; NumberAnimation { duration: 160; easing.type: Easing.OutCubic } }
                    Behavior on y { enabled: !scr.dragging; NumberAnimation { duration: 160; easing.type: Easing.OutCubic } }
                    Rectangle {   // the top bar, like a real screen
                        anchors { left: parent.left; right: parent.right; top: parent.top }
                        height: Math.max(3, parent.height * 0.06); radius: 6
                        color: Qt.rgba(0, 0, 0, 0.35)
                        visible: !scr.off
                    }
                    Rectangle {   // its number
                        x: 6; y: 8
                        width: 22; height: 22; radius: 6
                        color: scr.on ? Theme.onPrimary : Theme.onSecondaryContainer
                        DText { anchors.centerIn: parent; text: page.numberOf(scr.modelData.name); font.pixelSize: 12; font.weight: Font.Bold
                                color: scr.on ? Theme.primary : Theme.secondaryContainer }
                    }
                    // what it will be: size, rate, scale (with the staged changes)
                    DText {
                        anchors { left: parent.left; right: parent.right; bottom: parent.bottom; margins: 6 }
                        visible: parent.height > 50
                        elide: Text.ElideRight; font.pixelSize: 11
                        text: scr.off ? scr.modelData.name + " (off)" : scr.modelData.name + "  ·  " + page.modeText(Monitors.list.find(m => m.name === scr.modelData.name))
                        color: scr.on ? Theme.onPrimary : Theme.onSecondaryContainer
                        opacity: 0.85
                    }
                    MouseArea {
                        anchors.fill: parent
                        cursorShape: Monitors.list.length > 1 ? (scr.dragging ? Qt.ClosedHandCursor : Qt.OpenHandCursor) : Qt.PointingHandCursor
                        preventStealing: true
                        property real px: 0
                        property real py: 0
                        property bool moved: false
                        onPressed: mouse => {
                            page.selName = scr.modelData.name
                            px = mouse.x; py = mouse.y; moved = false
                            scr.dx = scr.x; scr.dy = scr.y
                        }
                        onPositionChanged: mouse => {
                            if (!pressed || Monitors.list.length < 2) return
                            if (!moved && Math.abs(mouse.x - px) + Math.abs(mouse.y - py) < 4) return
                            moved = true
                            scr.dragging = true
                            const p = mapToItem(arr, mouse.x, mouse.y)
                            scr.dx = p.x - px; scr.dy = p.y - py
                        }
                        onReleased: {
                            if (scr.dragging) {
                                const lx = (scr.dx - 2 - arr.offX) / arr.k + arr.minX
                                const ly = (scr.dy - 2 - arr.offY) / arr.k + arr.minY
                                arr.dropAt(scr.modelData.name, lx, ly)
                            }
                            scr.dragging = false
                        }
                    }
                }
            }
        }
        // ---- which screen, and on / off ----
        Item {
            Layout.fillWidth: true
            implicitHeight: 40
            SDropdown {
                id: pickScreen
                anchors.verticalCenter: parent.verticalCenter
                model: Monitors.list.map((m, i) => (i + 1) + "   " + page.prettyName(m))
                currentIndex: page.sel ? Monitors.list.indexOf(page.sel) : -1
                onPicked: (i, l) => page.selName = Monitors.list[i].name
            }
            Row {
                anchors { right: parent.right; verticalCenter: parent.verticalCenter }
                spacing: 10
                ArqButton {
                    visible: !!page.sel && Object.keys(page.selSet).length > 0 && !Monitors.trialOn
                    text: "Automatic"
                    onClicked: Monitors.reset(page.sel.name)
                }
                ArqToggle {
                    visible: Monitors.list.length > 1
                    anchors.verticalCenter: parent.verticalCenter
                    checked: !!page.sel && !page.selSet.disabled
                    onToggled: v => Monitors.set(page.sel.name, "disabled", v ? null : true)
                }
            }
        }
        DText {
            Layout.fillWidth: true; color: Theme.subtext; font.pixelSize: 12; elide: Text.ElideRight
            text: page.sel ? page.sel.name + "  ·  " + (page.sel.disabled ? "turned off" : "now " + page.sel.width + " × " + page.sel.height + " at " + (Math.round(page.sel.refresh * 100) / 100) + " Hz")
                          + (Monitors.isChanged(page.sel.name) ? "  ·  will be " + (page.selSet.disabled ? "off" : page.modeText(page.sel)) : "") : ""
        }
    }

    // ---- the chosen screen's settings ----
    SGroup {
        id: mset
        visible: !!page.sel
        readonly property var m: page.sel
        readonly property var s: page.selSet
        readonly property string curRes: m ? (s.mode ? s.mode.split("@")[0] : m.width + "x" + m.height) : ""
        readonly property string curRate: m ? (s.mode && s.mode.indexOf("@") > 0 ? String(Number(s.mode.split("@")[1])) : String(Math.round(m.refresh * 100) / 100)) : ""
        readonly property var extraKeys: m ? (m.extra || []).map(e => e.w + "x" + e.h + "@" + Math.round(e.r)) : []
        function isExtra(res, rate) { return extraKeys.indexOf(res + "@" + Math.round(Number(rate))) >= 0 }
        readonly property var resList: m ? Monitors.resolutions(m) : []
        readonly property var rateList: m ? Monitors.rates(m, curRes) : []
        readonly property var orientations: ["Landscape", "Portrait right", "Landscape (upside down)", "Portrait left"]
        readonly property var scaleOpts: m ? Monitors.scalesFor(m.name) : []
        readonly property var scaleCur: Number(s.scale) > 0 ? Monitors.nearestScale(scaleOpts, Number(s.scale)) : null

        SRow { title: "Orientation"; icon: "screen_rotation"
            SDropdown { model: mset.orientations; currentIndex: (Number(mset.s.transform || 0) % 4)
                onPicked: (i, l) => Monitors.set(mset.m.name, "transform", i || null) } }
        SRow { title: "Resolution"; icon: "aspect_ratio"
            SDropdown {
                model: mset.resList.map(r => {
                    const p = r.split("x"), a = page.aspect(Number(p[0]), Number(p[1]))
                    const extra = mset.extraKeys.some(k => k.startsWith(r + "@")) && !(mset.m.modes || []).some(x => x.w + "x" + x.h === r)
                    return p[0] + " × " + p[1] + (a ? " (" + a + ")" : "") + (extra ? "  +" : "")
                })
                currentIndex: mset.resList.indexOf(mset.curRes)
                onPicked: (i, l) => {
                    const res = mset.resList[i]
                    const rates = Monitors.rates(mset.m, res)
                    Monitors.tryMode(mset.m.name, res + "@" + (rates.length > 0 ? rates[0] : "60"))
                }
            } }
        SRow { title: "Refresh rate"; icon: "speed"
            subtitle: mset.isExtra(mset.curRes, mset.curRate) ? "Found by the check (+): the screen says it can, it was not offered" : ""
            SDropdown {
                model: mset.rateList.map(r => Number(r).toFixed(2) + " Hz" + (mset.isExtra(mset.curRes, r) ? "  +" : ""))
                currentIndex: mset.rateList.findIndex(r => Math.abs(Number(r) - Number(mset.curRate)) < 0.05)
                onPicked: (i, l) => Monitors.tryMode(mset.m.name, mset.curRes + "@" + mset.rateList[i])
            } }
        SRow { title: "Scale"; icon: "zoom_in"
            subtitle: "Only sizes that divide this resolution into whole pixels are listed, so the layout never breaks"
            SDropdown {
                model: ["Automatic"].concat(mset.scaleOpts.map(o => o.label))
                currentIndex: mset.scaleCur ? 1 + mset.scaleOpts.indexOf(mset.scaleCur) : 0
                onPicked: i => Monitors.set(mset.m.name, "scale", i > 0 ? String(mset.scaleOpts[i - 1].value) : null)
            } }
    }

    // ---- staged changes: apply them all together ----
    SCard {
        visible: Monitors.anyChanged
        Layout.fillWidth: true
        spacing: 10
        RowLayout {
            Layout.fillWidth: true
            spacing: 12
            Icon { name: "preview"; size: 22; color: Theme.tertiary }
            ColumnLayout {
                Layout.fillWidth: true
                spacing: 2
                DText { text: "Changes not applied yet"; font.weight: Font.DemiBold; font.pixelSize: 14 }
                DText {
                    Layout.fillWidth: true; wrapMode: Text.WordWrap; color: Theme.subtext; font.pixelSize: 12
                    text: "The screens above show how they will look. After Apply you have 10 seconds to keep them; otherwise everything goes back."
                }
            }
            ArqButton { text: "Discard"; onClicked: Monitors.discard() }
            ArqButton { text: "Apply"; primary: true; onClicked: Monitors.apply() }
        }
    }

    SHeader { text: "On-screen display"; key: "osdKeys,osdPos,osdVertical" }
    SGroup {
        SRow { key: "osdKeys"; title: "Media and lock keys"; subtitle: "Volume, brightness, keyboard light, play / pause, Caps Lock and Num Lock keys show what changed"; icon: "keyboard"
            ArqToggle { checked: Config.c.osdKeys; onToggled: v => Config.c.osdKeys = v } }
        SRow { key: "osdPos"; visible: Config.c.osdKeys; title: "Where"; subtitle: "Where on the screen it appears"; icon: "open_with"
            PlacePicker { value: Config.c.osdPos || "bottom"; onPicked: v => Config.c.osdPos = v } }
        SRow { key: "osdVertical"; visible: Config.c.osdKeys; title: "Direction"; icon: "swap_vert"
            SChoices { model: ["horizontal", "vertical"]; current: Config.c.osdVertical ? "vertical" : "horizontal"; onPicked: v => Config.c.osdVertical = v === "vertical" } }
        SRow { visible: Config.c.osdKeys; title: "Try it"; icon: "visibility"
            ArqButton { text: "Show"; onClicked: Osd.show("volume_up", "Volume", Audio.volume) } }
    }

    SHeader { text: "Motion"; key: "animations" }
    SGroup {
        SRow { key: "animations"; title: "Animations"; subtitle: "Windows, desktops and the shell slide and fade"; icon: "animation"
            ArqToggle { checked: Config.c.animations; onToggled: v => Config.c.animations = v } }
        SliderRow { key: "bounce"; visible: Config.c.animations && Config.c.showAdvanced; title: "Bounce"; subtitle: "How springy things are: buttons, pop-ups, the panel, new windows and desktops. 0 = no spring"; icon: "sports_basketball"
            suffix: " %"; from: 0; to: 200; step: 10
            value: Config.c.bounce ?? 120; onMoved: v => Config.c.bounce = Math.round(v) }
    }

    SMore {}
}
