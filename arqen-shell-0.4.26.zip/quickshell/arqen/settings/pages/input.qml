import QtQuick
import QtQuick.Layouts
import Quickshell
import qs.config
import qs.components
import qs.services
import qs.settings

// Mouse, touchpad and keyboard: layouts, the on-screen keyboard, what happens at login, and the options Hyprland has for them.
ColumnLayout {
    id: pg
    width: parent.width
    spacing: 16
    SHeader { text: "At login"; key: "loginCaps,loginNum" }
    SGroup {
        SRow { key: "loginCaps"; title: "Caps Lock"; subtitle: "Whether it is on when you log in"; icon: "keyboard_capslock"
            SSegmented { model: ["Keep", "On", "Off"]; currentIndex: ["keep", "on", "off"].indexOf(Config.c.loginCaps || "keep"); onPicked: i => Config.c.loginCaps = ["keep", "on", "off"][i] } }
        SRow { key: "loginNum"; title: "Num Lock"; subtitle: "Whether it is on when you log in"; icon: "123"
            SSegmented { model: ["Keep", "On", "Off"]; currentIndex: ["keep", "on", "off"].indexOf(Config.c.loginNum || "keep"); onPicked: i => Config.c.loginNum = ["keep", "on", "off"][i] } }
    }
    SHeader { text: "Keyboard layouts"; key: "realKbLayout,realKbVariant,oskLang,oskLangs,oskOnLock,oskHeight,giphyKey,oskPos" }
    SGroup {
        SRow { key: "realKbLayout"; title: "Physical keyboard layouts"; subtitle: "Choose one or more layouts. Selected layouts are applied immediately and saved for future Hyprland starts."; icon: "keyboard"
            ColumnLayout {
                Layout.fillWidth: true
                Flow {
                    id: physicalLayoutPicker
                    Layout.fillWidth: true
                    width: parent.width
                    spacing: 7
                    Repeater {
                        model: [
                            {id:"us",name:"English (US)"},{id:"gb",name:"English (UK)"},{id:"fr",name:"French"},
                            {id:"de",name:"German"},{id:"es",name:"Spanish"},{id:"pt",name:"Portuguese"},
                            {id:"it",name:"Italian"},{id:"ru",name:"Russian"},{id:"ua",name:"Ukrainian"},
                            {id:"pl",name:"Polish"},{id:"br",name:"Portuguese (Brazil)"},{id:"za",name:"South African"},
                            {id:"ara",name:"Arabic"},{id:"tr",name:"Turkish"},{id:"se",name:"Swedish"},{id:"no",name:"Norwegian"}
                        ]
                        delegate: Rectangle {
                            required property var modelData
                            readonly property bool selected: (Config.c.realKbLayout || "us").split(",").indexOf(modelData.id) >= 0
                            width: kbLabel.implicitWidth + 24; height: 34; radius: 17
                            color: selected ? Theme.pillOn : (kbMouse.containsMouse ? Theme.hover : Theme.tile)
                            border.width: selected ? 1 : 0; border.color: Theme.accent
                            DText { id: kbLabel; anchors.centerIn: parent; text: (parent.selected ? "✓  " : "") + parent.modelData.name; font.pixelSize: 12; color: parent.selected ? Theme.pillOnText : Theme.text }
                            MouseArea { id: kbMouse; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor
                                onClicked: {
                                    let layouts = (Config.c.realKbLayout || "us").split(",").map(x => x.trim()).filter(x => x.length > 0)
                                    const i = layouts.indexOf(parent.modelData.id)
                                    if (i >= 0) { if (layouts.length > 1) layouts.splice(i, 1) }
                                    else layouts.push(parent.modelData.id)
                                    Config.c.realKbLayout = layouts.join(",") || "us"
                                    Quickshell.execDetached(["hyprctl", "keyword", "input:kb_layout", Config.c.realKbLayout])
                                }
                            }
                        }
                    }
                }
                // A compact visual switcher for the layouts currently selected above.
                // Buttons explicitly choose an index; Next/Previous cycle through the same list.
                ColumnLayout {
                    id: physicalLayoutSwitcher
                    Layout.fillWidth: true
                    spacing: 7
                    property var selectedLayouts: (Config.c.realKbLayout || "us").split(",").map(x => x.trim()).filter(x => x.length > 0)
                    property int activeLayoutIndex: 0
                    Flow {
                        Layout.fillWidth: true
                        width: parent.width
                        spacing: 7
                        Repeater {
                            model: physicalLayoutSwitcher.selectedLayouts
                            delegate: Rectangle {
                                required property string modelData
                                required property int index
                                readonly property var labels: ({us:"English (US)",gb:"English (UK)",fr:"French",de:"German",es:"Spanish",pt:"Portuguese",it:"Italian",ru:"Russian",ua:"Ukrainian",pl:"Polish",br:"Portuguese (Brazil)",za:"South African",ara:"Arabic",tr:"Turkish",se:"Swedish",no:"Norwegian"})
                                readonly property bool active: index === physicalLayoutSwitcher.activeLayoutIndex
                                width: switchLabel.implicitWidth + 26; height: 34; radius: 17
                                color: active ? Theme.pillOn : (switchMouse.containsMouse ? Theme.hover : Theme.tile)
                                border.width: active ? 1 : 0; border.color: Theme.accent
                                DText { id: switchLabel; anchors.centerIn: parent; text: (parent.active ? "●  " : "") + (parent.labels[parent.modelData] || parent.modelData.toUpperCase()); font.pixelSize: 12; color: parent.active ? Theme.pillOnText : Theme.text }
                                MouseArea { id: switchMouse; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor
                                    onClicked: { physicalLayoutSwitcher.activeLayoutIndex = index; Quickshell.execDetached(["hyprctl", "switchxkblayout", "all", String(index)]) }
                                }
                            }
                        }
                    }
                    RowLayout {
                        Layout.fillWidth: true
                        ArqButton { text: "Apply layouts"; onClicked: { Quickshell.execDetached(["hyprctl", "keyword", "input:kb_layout", Config.c.realKbLayout || "us"]); Quickshell.execDetached(["hyprctl", "keyword", "input:kb_variant", Config.c.realKbVariant || ""]); physicalLayoutSwitcher.activeLayoutIndex = 0; Quickshell.execDetached(["hyprctl", "switchxkblayout", "all", "0"]) } }
                        ArqButton { text: "Previous"; onClicked: { const n = physicalLayoutSwitcher.selectedLayouts.length; if (n > 0) { physicalLayoutSwitcher.activeLayoutIndex = (physicalLayoutSwitcher.activeLayoutIndex + n - 1) % n; Quickshell.execDetached(["hyprctl", "switchxkblayout", "all", String(physicalLayoutSwitcher.activeLayoutIndex)]) } } }
                        ArqButton { text: "Next layout"; onClicked: { const n = physicalLayoutSwitcher.selectedLayouts.length; if (n > 0) { physicalLayoutSwitcher.activeLayoutIndex = (physicalLayoutSwitcher.activeLayoutIndex + 1) % n; Quickshell.execDetached(["hyprctl", "switchxkblayout", "all", String(physicalLayoutSwitcher.activeLayoutIndex)]) } } }
                    }
                }
            }
        }
        SRow { key: "realKbVariant"; title: "Physical keyboard variant"; subtitle: "Optional XKB variant(s), comma-separated; usually leave blank."; icon: "tune"
            ArqField { width: 170; implicitHeight: 38; text: Config.c.realKbVariant; placeholder: "(default)"; anchors.verticalCenter: parent.verticalCenter; onAccepted: { Config.c.realKbVariant = text.trim(); Quickshell.execDetached(["hyprctl", "keyword", "input:kb_variant", Config.c.realKbVariant]) } }
            ArqButton { text: "Apply variant"; anchors.verticalCenter: parent.verticalCenter; onClicked: Quickshell.execDetached(["hyprctl", "keyword", "input:kb_variant", Config.c.realKbVariant || ""]) }
        }
        SRow { key: "oskOnLock"; title: "On-screen keyboard on lock screen"; subtitle: "Show the keyboard above the password screen and route its keys directly into the password field."; icon: "lock_open"
            ArqToggle { checked: Config.c.oskOnLock; onToggled: v => { Config.c.oskOnLock = v; if (Ui.locked) Osk.shown = v } }
        }
    }
    SHeader { text: "On-screen keyboard"; key: "oskLangs,oskHeight,giphyKey,oskLang,oskPos" }
    SGroup {
        SRow { key: "oskLangs"; title: "Languages"; subtitle: "The globe button goes through the ones picked here (none picked: all of them)"; icon: "language"
            Flow {
                property real maxWidth: 420              // set by the row: the room it has
                readonly property real naturalWidth: 420
                width: Math.min(420, maxWidth)
                spacing: 6
                Repeater {
                    model: Osk.languages
                    delegate: Rectangle {
                        required property var modelData
                        readonly property bool on: (Config.c.oskLangs || []).indexOf(modelData.id) >= 0
                        height: 32; width: lt.implicitWidth + 24; radius: 16
                        color: on ? Theme.pillOn : (lm.containsMouse ? Theme.hover : Theme.tile)
                        DText { id: lt; anchors.centerIn: parent; text: parent.modelData.name; font.pixelSize: 12; color: parent.on ? Theme.pillOnText : Theme.text }
                        MouseArea {
                            id: lm; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor
                            onClicked: {
                                const l = (Config.c.oskLangs || []).slice()
                                const i = l.indexOf(parent.modelData.id)
                                if (i >= 0) l.splice(i, 1); else l.push(parent.modelData.id)
                                Config.c.oskLangs = l
                                if (l.length > 0 && l.indexOf(Config.c.oskLang) < 0) Config.c.oskLang = l[0]
                            }
                        }
                    }
                }
            } }
        SliderRow { key: "oskHeight"; title: "Height"; icon: "height"; suffix: " px"; from: 220; to: 520; step: 1
            value: Config.c.oskHeight || 320; onMoved: v => Config.c.oskHeight = Math.round(v) }
        SRow { key: "giphyKey"; title: "GIPHY API key"; subtitle: "For the GIF tab. Free: developers.giphy.com > Create an app > API. Press Enter to save"; icon: "gif_box"
            ArqButton { text: "Get a key"; anchors.verticalCenter: parent.verticalCenter; onClicked: Quickshell.execDetached(["xdg-open", "https://developers.giphy.com/dashboard/?create=true"]) }
            ArqField { width: 220; implicitHeight: 38; password: true; text: Config.c.giphyKey; placeholder: "Paste the key"; anchors.verticalCenter: parent.verticalCenter
                onAccepted: Config.c.giphyKey = text.trim() } }
        SRow { title: "Position"; subtitle: (Config.c.oskPos && Config.c.oskPos.x !== undefined) ? "Where you dragged it (drag the dots at its top left)" : "Along the bottom of the screen. Drag the dots at its top left to move it"; icon: "open_with"
            ArqButton { visible: Config.c.oskPos && Config.c.oskPos.x !== undefined; text: "Back to the bottom"; onClicked: Config.c.oskPos = ({}) } }
        SRow { title: "Show it now"; subtitle: "Also: its panel item, or qs -c arqen ipc call arqen toggle keyboard"; icon: "keyboard"
            ArqButton { text: Osk.shown ? "Hide" : "Show"; onClicked: Osk.toggle() } }
    }

    HyprOptionsView {
        Layout.fillWidth: true
        pageIds: ["mouse", "keyboard-options"]
        intro: "Pointer speed, tap to click, natural scrolling, key repeat. Changes reach Hyprland within a moment."
    }
}
