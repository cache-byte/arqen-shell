import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Io
import Quickshell.Bluetooth
import qs.config
import qs.components
import qs.services
import qs.settings

// Wi-Fi and Bluetooth: networks, Bluetooth devices, and what is connected (a tester for keyboards
// and for sound), also over cable or a receiver.
ColumnLayout {
    id: pg
    width: parent.width; spacing: 16
    readonly property var ad: Bluetooth.defaultAdapter
    readonly property bool btOn: ad?.enabled ?? false
    // connected first, then paired, then the rest
    readonly property var devices: {
        const d = Bluetooth.devices.values.slice()
        d.sort((a, b) => ((b.connected ? 2 : 0) + (b.paired ? 1 : 0)) - ((a.connected ? 2 : 0) + (a.paired ? 1 : 0)))
        return d
    }
    // the device being tried out on its card (its address)
    property string trying: ""

    // ================= Wi-Fi =================
    SHeader { text: "Wi-Fi" }
    SGroup {
        SRow { title: "Wi-Fi"; subtitle: Net.wifiOn ? (Net.ssid ? "Connected to " + Net.ssid : "On") : "Off"; icon: "wifi"
            ArqToggle { checked: Net.wifiOn; onToggled: Net.toggleWifi() } }
        SRow { title: "Networks"; subtitle: "Pick one from the Wi-Fi tile in the control centre (right-click it)"; icon: "wifi_find" }
        SRow { title: "Advanced network settings"; subtitle: "Wired, VPN and saved networks"; icon: "settings_ethernet"
            ArqButton { text: "Open"; onClicked: Quickshell.execDetached(["nm-connection-editor"]) } }
    }

    // ================= connected devices =================
    SHeader { text: "Connected"; visible: pg.btOn && Gadgets.connected.length > 0 }
    Repeater {
        model: pg.btOn ? Gadgets.connected : []
        delegate: SCard {
            id: dc
            required property var modelData
            readonly property string kind: Gadgets.kind(modelData)
            readonly property real bat: Gadgets.battery(modelData)
            readonly property bool canTry: kind === "keyboard"
            readonly property bool open: pg.trying === modelData.address
            spacing: 14
            RowLayout {
                Layout.fillWidth: true
                spacing: 16
                DeviceBadge { icon: Gadgets.icon(dc.modelData); battery: dc.bat; size: 64 }
                ColumnLayout {
                    Layout.fillWidth: true
                    spacing: 2
                    DText { Layout.fillWidth: true; elide: Text.ElideRight; text: dc.modelData.name || dc.modelData.address; font.pixelSize: 16; font.weight: Font.DemiBold }
                    DText {
                        Layout.fillWidth: true; elide: Text.ElideRight
                        text: (Gadgets.names[dc.kind] ?? "Device") + "  ·  " + (dc.bat >= 0 ? "Battery " + Gadgets.batteryText(dc.modelData) : "Battery not shared") + (Gadgets.approx(dc.modelData) ? "  (install KDE Connect for the exact figure)" : "")
                        color: dc.bat >= 0 && dc.bat < 0.2 ? "#FF5A5A" : Theme.subtext; font.pixelSize: 13
                    }
                }
                Row {
                    spacing: 8
                    ArqButton { visible: Gadgets.isAudio(dc.modelData); text: "Left"; onClicked: Gadgets.soundTest(dc.modelData, "left") }
                    ArqButton { visible: Gadgets.isAudio(dc.modelData); text: "Right"; onClicked: Gadgets.soundTest(dc.modelData, "right") }
                    ArqButton { visible: dc.canTry; text: dc.open ? "Done" : "Try it"; primary: !dc.open
                                onClicked: pg.trying = dc.open ? "" : dc.modelData.address }
                    ArqButton { text: "Disconnect"; onClicked: QuickSettings.btToggleConnect(dc.modelData) }
                }
            }
            DText {
                visible: Gadgets.isAudio(dc.modelData)
                Layout.fillWidth: true; wrapMode: Text.Wrap
                text: "Left and Right play a sound in that ear only" + (dc.bat < 0 && dc.kind === "earbuds" ? ". AirPods and many earbuds only tell phones their battery" : "")
                color: Theme.subtext; font.pixelSize: 12
            }
            // the tester, only while trying it out
            Loader {
                Layout.fillWidth: true
                Layout.preferredHeight: item ? item.implicitHeight : 0
                active: dc.open
                visible: active
                sourceComponent: keyT
            }
        }
    }
    Component { id: keyT; KeyTester { Component.onCompleted: forceActiveFocus() } }

    // ================= Bluetooth =================
    SHeader { text: "Bluetooth" }
    SGroup {
        SRow { title: "Bluetooth"; subtitle: pg.ad ? (pg.btOn ? "On" : "Off") : "No adapter found"; icon: "bluetooth"
            ArqToggle { checked: pg.btOn; onToggled: QuickSettings.toggleBluetooth() } }
        SRow {
            visible: pg.btOn
            title: pg.ad?.discovering ? "Looking for devices…" : "Find devices"
            subtitle: "Put the device in pairing mode first"
            icon: "bluetooth_searching"
            LoadingPill { anchors.verticalCenter: parent.verticalCenter; visible: pg.ad?.discovering ?? false }
            ArqButton { text: pg.ad?.discovering ? "Stop" : "Scan"; onClicked: { if (pg.ad) pg.ad.discovering = !pg.ad.discovering } }
        }
        SRow { visible: QuickSettings.btStatus !== ""; title: QuickSettings.btStatus; icon: "info" }
        Repeater {
            model: pg.btOn ? pg.devices : []
            delegate: SRow {
                id: dr
                required property var modelData
                readonly property bool busy: QuickSettings.btBusy === modelData.address
                title: modelData.name || modelData.address
                subtitle: busy ? "Working…" : (modelData.connected ? "Connected" : (modelData.paired ? "Paired" : "Available"))
                icon: Gadgets.icon(modelData)
                iconColor: modelData.connected ? Theme.secondaryContainer : Theme.tile
                LoadingPill { anchors.verticalCenter: parent.verticalCenter; visible: dr.busy }
                ArqButton { visible: !dr.modelData.paired; text: "Pair"; primary: true; onClicked: QuickSettings.btPair(dr.modelData) }
                ArqButton { visible: dr.modelData.paired; text: dr.modelData.connected ? "Disconnect" : "Connect"; onClicked: QuickSettings.btToggleConnect(dr.modelData) }
                ArqButton { visible: dr.modelData.paired; text: "Forget"; onClicked: QuickSettings.btForget(dr.modelData) }
            }
        }
        SRow { key: "btDevicesInBar"; title: "Devices on the panel"; subtitle: "Connected devices and their battery in the control centre button"; icon: "earbuds"
            ArqToggle { checked: Config.c.btDevicesInBar; onToggled: v => Config.c.btDevicesInBar = v } }
        SRow { title: "More Bluetooth settings"; subtitle: "Your system's own Bluetooth settings"; icon: "devices"
            ArqButton { text: "Open"; onClicked: Quickshell.execDetached(["sh", "-c", "if command -v gnome-control-center >/dev/null 2>&1; then gnome-control-center bluetooth; elif command -v systemsettings >/dev/null 2>&1; then systemsettings kcm_bluetooth; elif command -v foot >/dev/null 2>&1; then foot -e bluetoothctl; elif command -v kitty >/dev/null 2>&1; then kitty bluetoothctl; else x-terminal-emulator -e bluetoothctl; fi"]) } }
    }

    // ---- what is plugged in or paired in other ways: cable, 2.4 GHz receiver (dongle) ----
    SHeader { text: "Plugged in or wireless dongles"; visible: Gadgets.otherPeripherals.length > 0 }
    DText { visible: Gadgets.otherPeripherals.length > 0; Layout.fillWidth: true; Layout.leftMargin: 18; Layout.rightMargin: 18; wrapMode: Text.WordWrap; color: Theme.subtext; font.pixelSize: 13
            text: "Keyboards, mice and other gadgets the computer sees that are not paired over Bluetooth: connected by cable, or through a small USB receiver (a 2.4 GHz dongle). A receiver often shows up twice, once as a keyboard and once as a mouse. Nothing to set up here." }
    SGroup {
        visible: Gadgets.otherPeripherals.length > 0
        Repeater {
            model: Gadgets.otherPeripherals
            delegate: SRow {
                required property var modelData
                title: modelData.name
                subtitle: Gadgets.periKind(modelData) + "  ·  " + Gadgets.periWhere(modelData)
                         + (modelData.battery >= 0 ? "  ·  " + modelData.battery + " %" + (modelData.charging ? " (charging)" : "") : "")
                icon: Gadgets.periIcon(modelData)
                DText { visible: modelData.battery >= 0; text: modelData.battery + " %"; color: modelData.battery < 20 ? "#FF5A5A" : Theme.subtext; font.pixelSize: 13; anchors.verticalCenter: parent.verticalCenter }
            }
        }
    }
}
