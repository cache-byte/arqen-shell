import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Services.Pipewire
import qs.config
import qs.components
import qs.services
import qs.settings

// Sound and notifications: volume, where sound goes, pop-ups, and the system sounds.
ColumnLayout {
    id: page
    width: parent.width; spacing: 16
    readonly property bool soundsOn: (Config.c.soundTheme || "") !== ""

    // ---------- volume and output ----------
    SHeader { text: "Sound" }
    SGroup {
        SRow { title: "Volume"; subtitle: Audio.muted ? "Muted" : Math.round(Audio.volume * 100) + "%"; icon: Audio.muted ? "volume_off" : "volume_up"
            TrayButton { round: true; icon: Audio.muted ? "volume_off" : "volume_up"; size: 18; tip: Audio.muted ? "Unmute" : "Mute"; active: Audio.muted; anchors.verticalCenter: parent.verticalCenter; onClicked: Audio.toggleMute() }
            ArqSlider { width: Math.min(240, Math.max(100, parent.width * 0.38)); stepSize: 0.01; value: Audio.volume; onMoved: v => { if (Audio.muted && v > 0) Audio.toggleMute(); Audio.setVolume(v) }; anchors.verticalCenter: parent.verticalCenter } }
        Repeater {
            model: Audio.sinks
            delegate: SRow {
                id: sinkRow
                required property var modelData
                readonly property bool cur: Pipewire.defaultAudioSink === modelData
                title: modelData.description || modelData.name
                subtitle: cur ? "Sound plays here" : "Click to play sound here"
                icon: /head|ear/i.test(title) ? "headphones" : (/hdmi|display/i.test(title) ? "tv" : "speaker")
                onClicked: Pipewire.preferredDefaultAudioSink = modelData
                Icon { visible: sinkRow.cur; name: "check_circle"; color: Theme.primary; anchors.verticalCenter: parent.verticalCenter }
            }
        }
    }

    // ---------- notifications ----------
    // ---------- microphone ----------
    SHeader { text: "Microphone" }
    SGroup {
        SRow { title: "Input volume"; visible: Audio.hasMic
            subtitle: Audio.micMuted ? "Microphone off" : Math.round(Audio.micVolume * 100) + "%"; icon: Audio.micMuted ? "mic_off" : "mic"
            TrayButton { round: true; icon: Audio.micMuted ? "mic_off" : "mic"; size: 18; tip: Audio.micMuted ? "Turn on" : "Turn off"; active: Audio.micMuted; anchors.verticalCenter: parent.verticalCenter; onClicked: Audio.toggleMicMute() }
            ArqSlider { width: Math.min(240, Math.max(100, parent.width * 0.38)); stepSize: 0.01; value: Audio.micVolume; onMoved: v => { if (Audio.micMuted && v > 0) Audio.toggleMicMute(); Audio.setMicVolume(v) }; anchors.verticalCenter: parent.verticalCenter } }
        SRow { visible: !Audio.hasMic; title: "No microphone found"; subtitle: "Plug one in or connect a headset"; icon: "mic_off" }
        Repeater {
            model: Audio.sources
            delegate: SRow {
                id: srcRow
                required property var modelData
                readonly property bool cur: Audio.source === modelData
                title: modelData.description || modelData.name
                subtitle: cur ? "The microphone in use" : "Click to use this microphone"
                icon: /head|ear|bluez/i.test(title) ? "headset_mic" : "mic"
                onClicked: Audio.setSource(modelData)
                Icon { visible: srcRow.cur; name: "check_circle"; color: Theme.primary; anchors.verticalCenter: parent.verticalCenter }
            }
        }
    }

    SHeader { text: "Notifications"; key: "dnd,toastOverFullscreen,toastSeconds,toastPlace,notifGroup" }
    SGroup {
        SRow { key: "dnd"; title: "Do not disturb"; subtitle: "No pop-ups and no sound; notifications still collect in the control centre"; icon: "do_not_disturb_on"
            ArqToggle { checked: Config.c.dnd; onToggled: v => Config.c.dnd = v } }
        SRow { key: "toastOverFullscreen"; title: "Pop-ups over full-screen windows"; subtitle: "Off: while a game or video is full screen, notifications wait quietly in the control centre"; icon: "fullscreen"
            ArqToggle { checked: Config.c.toastOverFullscreen; onToggled: v => Config.c.toastOverFullscreen = v } }
        SRow { key: "toastPlace"; title: "Where pop-ups appear"; subtitle: "New notifications, and alarms and reminders that ring. Click where on the screen"; icon: "notifications_active"
            PlacePicker { value: Ui.toastPlace; onPicked: v => Config.c.toastPlace = v } }
        SRow { key: "notifGroup"; title: "Group by app"; subtitle: "Stack notifications from the same app in the notification list. Off: each one is its own card"; icon: "stacks"
            ArqToggle { checked: Config.c.notifGroup; onToggled: v => Config.c.notifGroup = v } }
        SliderRow { key: "toastSeconds"; title: "Pop-up duration"; icon: "timer"; suffix: " s"
            value: Config.c.toastSeconds; from: 2; to: 15; onMoved: v => Config.c.toastSeconds = Math.round(v) }
    }

    // ---------- system sounds: themes like KDE's chooser, then each event's sound ----------
    SHeader { text: "System sounds"; key: "soundTheme,soundNotify,soundVolume,soundCapture,soundPower,soundDevices,soundError,soundPicks" }
    SCard {
        spacing: 14
        DText {
            Layout.fillWidth: true; wrapMode: Text.WordWrap; font.pixelSize: 12; color: Theme.subtext
            text: Sounds.themes.length === 0 ? "No sound themes are installed. ./update.sh installs the standard one (sound-theme-freedesktop)"
                                             : "Click a theme to use it. ▶ plays its notification sound; the small buttons play its other sounds. Apps that make their own sounds use it too"
        }
        GridLayout {
            Layout.fillWidth: true
            columns: Math.max(1, Math.floor(width / 250))
            columnSpacing: 12; rowSpacing: 12
            Repeater {
                model: Sounds.themes.concat([{ id: "", name: "No sounds", desc: "Quiet: no system sounds at all" }])
                delegate: Rectangle {
                    id: th
                    required property var modelData
                    readonly property bool sel: (Config.c.soundTheme || "") === modelData.id
                    readonly property bool none: modelData.id === ""
                    Layout.fillWidth: true
                    implicitHeight: thCol.implicitHeight + 28
                    radius: Math.max(8, Theme.radius - 8)
                    color: sel ? Theme.secondaryContainer : (thm.containsMouse ? Theme.hover : Theme.tile)
                    border.width: sel ? 2 : 0
                    border.color: Theme.primary
                    Behavior on color { ColorAnimation { duration: 120 } }
                    MouseArea { id: thm; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: Config.c.soundTheme = th.modelData.id }
                    Column {
                        id: thCol
                        x: 14; y: 14
                        width: parent.width - 28
                        spacing: 10
                        Item {
                            width: parent.width; height: Math.max(nameCol.implicitHeight, 34)
                            Column {
                                id: nameCol
                                width: parent.width - (th.none ? 0 : 44)
                                anchors.verticalCenter: parent.verticalCenter
                                spacing: 2
                                DText { width: parent.width; elide: Text.ElideRight; text: th.modelData.name; font.pixelSize: 15; font.weight: Font.DemiBold; color: th.sel ? Theme.onSecondaryContainer : Theme.text }
                                DText { width: parent.width; wrapMode: Text.WordWrap; maximumLineCount: 2; elide: Text.ElideRight; text: th.modelData.desc || th.modelData.id; font.pixelSize: 11; color: th.sel ? Theme.onSecondaryContainer : Theme.subtext; opacity: 0.85 }
                            }
                            TrayButton {
                                visible: !th.none
                                anchors { right: parent.right; verticalCenter: parent.verticalCenter }
                                round: true; icon: "play_arrow"; size: 20; tip: "Listen"
                                onClicked: Sounds.preview("notify", th.modelData.id)
                            }
                        }
                        // preview each of its sounds
                        Row {
                            visible: !th.none
                            spacing: 4
                            DText { text: "Preview:"; font.pixelSize: 11; color: th.sel ? Theme.onSecondaryContainer : Theme.subtext; anchors.verticalCenter: parent.verticalCenter; rightPadding: 4 }
                            Repeater {
                                model: Sounds.events
                                delegate: TrayButton {
                                    required property var modelData
                                    round: true; icon: modelData.icon; size: 15; tip: modelData.name
                                    onClicked: Sounds.preview(modelData.id, th.modelData.id)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // a check: is there a player, a theme, does PipeWire answer
    SGroup {
        SRow {
            title: "No sound? Check"; icon: "troubleshoot"
            subtitle: page.checkText
            ArqButton { text: Sounds.checking ? "Checking…" : "Check"; onClicked: { Sounds.check(); Sounds.preview("notify") } }
        }
    }
    readonly property string checkText: Sounds.checkLines.length === 0 ? "Plays the notification sound and checks the player, the sound themes and PipeWire"
        : Sounds.checkLines.map(l => (l.ok === "ok" ? "✓ " : l.ok === "warn" ? "! " : "✗ ") + l.text).join("\n")

    // each event: on / off, and its own sound if you like
    readonly property var soundChoices: {
        // the sounds of every installed theme, by name, once each (the chosen theme's first)
        const cur = Config.c.soundTheme || ""
        const list = Sounds.files.slice().sort((a, b) => (a.theme === cur ? 0 : 1) - (b.theme === cur ? 0 : 1) || (a.name < b.name ? -1 : a.name > b.name ? 1 : 0))
        const seen = {}, out = []
        for (const f of list) {
            const k = f.theme + "/" + f.name
            if (seen[k]) continue
            seen[k] = true
            out.push(f)
        }
        return out
    }
    function soundLabel(f) { return f.name.replace(/-/g, " ") + "  ·  " + f.theme }
    Component.onCompleted: { Sounds.refresh(); Sounds.refreshFiles() }
    SGroup {
        opacity: page.soundsOn ? 1 : 0.45
        Repeater {
            model: Sounds.events
            delegate: SRow {
                id: er
                required property var modelData
                readonly property string pick: Sounds.pickOf(modelData.id)
                key: modelData.key
                title: modelData.name
                subtitle: !page.soundsOn ? "Pick a sound theme above to hear this"
                        : er.pick !== "" ? "Its own sound: " + er.pick.split("/").pop().replace(/\.[a-z0-9]+$/i, "").replace(/-/g, " ")
                        : modelData.id === "notify" ? "The theme's sound. Not while Do not disturb is on"
                        : modelData.id === "power" ? "The theme's sound. Charger in or out, and the battery notifications"
                        : modelData.id === "error" ? "Instead of the usual sound, for notifications marked urgent"
                        : "The theme's sound"
                icon: modelData.icon
                SDropdown {
                    visible: page.soundsOn
                    model: ["The theme's sound"].concat(page.soundChoices.map(f => page.soundLabel(f)))
                    currentIndex: er.pick === "" ? 0 : Math.max(0, page.soundChoices.findIndex(f => f.file === er.pick) + 1)
                    onPicked: (i, label) => { Sounds.setPick(er.modelData.id, i === 0 ? "" : page.soundChoices[i - 1].file); Sounds.preview(er.modelData.id) }
                }
                TrayButton { round: true; icon: "play_arrow"; size: 18; tip: "Listen"; visible: page.soundsOn; anchors.verticalCenter: parent.verticalCenter; onClicked: Sounds.preview(er.modelData.id) }
                ArqToggle { checked: Config.c[er.modelData.key]; onToggled: v => Config.c[er.modelData.key] = v; anchors.verticalCenter: parent.verticalCenter }
            }
        }
    }
}
