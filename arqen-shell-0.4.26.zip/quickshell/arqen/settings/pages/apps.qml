import QtQuick
import QtQuick.Layouts
import qs.config
import qs.components
import qs.services
import qs.settings

// Apps: what opens things, what starts at login, and where each app came from.
ColumnLayout {
    id: pg
    width: parent.width
    spacing: 16
    property int tab: 0
    SSegmented {
        Layout.alignment: Qt.AlignHCenter
        model: ["Default apps", "Start at login", "About apps"]
        currentIndex: pg.tab
        onPicked: i => pg.tab = i
        segW: 120          // these names are long
        maxWidth: pg.width - 36
    }
    Loader {
        // exactly the page's width, whatever the loaded page would like (else its sliders run off the right edge)
        Layout.fillWidth: true
        Layout.minimumWidth: 0
        Layout.preferredWidth: pg.width
        Layout.maximumWidth: pg.width
        source: pg.tab === 0 ? "AppsDefault.qml" : pg.tab === 1 ? "AppsAutostart.qml" : "AppsAbout.qml"
    }
}
