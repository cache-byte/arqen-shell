import QtQuick
import QtQuick.Layouts
import qs.config
import qs.components
import qs.services
import qs.settings

// Everything else Hyprland can do: window look, layouts, cursor, gestures and the rest.
HyprOptionsView {
    pageIds: ["hypr-windows", "hypr-decoration", "hypr-layouts", "hypr-cursor", "hypr-gestures", "hypr-advanced"]
    intro: "Hyprland's own options, in the order of its manual. Gaps, borders, corners and animations on/off are in the Windows tab and Display. Options you change here are written after those, so they win."
}
