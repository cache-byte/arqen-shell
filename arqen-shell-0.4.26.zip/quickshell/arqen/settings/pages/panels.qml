import QtQuick
import QtQuick.Layouts
import Quickshell
import qs.config
import qs.components
import qs.services
import qs.settings

// Panels: how many, where, what is on them and how big, and what the items on them do (dock,
// clock, desktop indicator ...).
ColumnLayout {
    id: page
    width: parent.width; spacing: 16

    // the panel being edited on this page (Ui.settingsPanel, or the first one)
    readonly property var pnl: Config.panel(Ui.settingsPanel) ?? (Config.panelsNow[0] ?? null)
    readonly property string pid: pnl ? pnl.id : ""
    readonly property string name: pid !== "" ? "Panel " + (Config.panelIndex(pid) + 1) : ""
    function set(key, v) { if (pid !== "") Config.setPanel(pid, key, v) }

    // ---------- your panels: pick one, where it sits, add / remove ----------
    SHeader { text: "Your panels" }
    SCard {
        id: whereCard
        spacing: 16
        GridLayout {
            Layout.fillWidth: true
            columns: whereCard.width >= 620 ? 2 : 1
            columnSpacing: 28; rowSpacing: 16
            Item {   // live preview of every panel; the selected one is in the accent colour (click one to pick it)
                id: scr
                Layout.preferredWidth: Math.min(288, whereCard.width - 40); Layout.preferredHeight: Math.min(288, whereCard.width - 40) * 9 / 16
                Layout.alignment: Qt.AlignHCenter | Qt.AlignTop
                readonly property real sc: width / 1920
                readonly property real mm: Ui.barGap * sc
                Rectangle {
                    anchors.fill: parent; radius: 14; border.width: 2; border.color: Theme.stroke
                    gradient: Gradient {
                        GradientStop { position: 0.0; color: "#2b2845" }
                        GradientStop { position: 1.0; color: "#11111d" }
                    }
                }
                Repeater {
                    model: Config.panelsNow
                    delegate: Rectangle {
                        required property var modelData
                        readonly property var pp: modelData
                        readonly property bool vert: pp.edge === "left" || pp.edge === "right"
                        readonly property real t: Math.max(6, pp.thickness * scr.sc)
                        readonly property bool full: pp.length >= 100
                        function along(total, size) {
                            return pp.align === "start" ? scr.mm : (pp.align === "end" ? total - size - scr.mm : (total - size) / 2)
                        }
                        radius: scr.mm > 0 || pp.islands ? 5 : 0
                        color: pp.id === page.pid ? Theme.primary : "#8A8A96"
                        opacity: pp.id === page.pid ? 0.95 : 0.5
                        width: vert ? t : (full ? scr.width - 2 * scr.mm : scr.width * pp.length / 100)
                        height: vert ? (full ? scr.height - 2 * scr.mm : scr.height * pp.length / 100) : t
                        x: vert ? (pp.edge === "left" ? scr.mm : scr.width - width - scr.mm) : along(scr.width, width)
                        y: vert ? along(scr.height, height) : (pp.edge === "top" ? scr.mm : scr.height - height - scr.mm)
                        Behavior on x { NumberAnimation { duration: 140 } }
                        Behavior on y { NumberAnimation { duration: 140 } }
                        Behavior on width { NumberAnimation { duration: 140 } }
                        Behavior on height { NumberAnimation { duration: 140 } }
                        MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor; onClicked: Ui.settingsPanel = parent.pp.id }
                    }
                }
            }
            ColumnLayout {
                id: whereCol
                Layout.fillWidth: true; spacing: 8
                DText { text: "Panel"; color: Theme.subtext; font.pixelSize: 12 }
                Flow {
                    Layout.fillWidth: true
                    spacing: 8
                    Repeater {
                        model: Config.panelIds
                        delegate: Rectangle {
                            id: pc
                            required property string modelData
                            readonly property bool cur: modelData === page.pid
                            height: 36; width: pcRow.implicitWidth + 28; radius: 18
                            color: cur ? Theme.pillOn : (pcMa.containsMouse ? Theme.hover : Theme.tile)
                            Row {
                                id: pcRow; anchors.centerIn: parent; spacing: 6
                                DText { text: "Panel " + (Config.panelIndex(pc.modelData) + 1); font.pixelSize: 13; color: pc.cur ? Theme.pillOnText : Theme.text; anchors.verticalCenter: parent.verticalCenter }
                                DText { text: Config.panel(pc.modelData)?.edge ?? ""; font.pixelSize: 11; color: pc.cur ? Theme.pillOnText : Theme.subtext; opacity: 0.8; anchors.verticalCenter: parent.verticalCenter }
                            }
                            MouseArea { id: pcMa; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: Ui.settingsPanel = pc.modelData }
                        }
                    }
                }
                DText { text: "Screen edge"; color: Theme.subtext; font.pixelSize: 12; Layout.topMargin: 6 }
                SChoices { maxWidth: whereCol.width; model: ["top", "bottom", "left", "right"]; current: page.pnl?.edge ?? ""; onPicked: v => page.set("edge", v) }
                DText { text: "Along the edge (when it is shorter than the edge)"; color: Theme.subtext; font.pixelSize: 12; Layout.topMargin: 6; Layout.fillWidth: true; wrapMode: Text.WordWrap }
                SChoices { maxWidth: whereCol.width; model: ["start", "center", "end"]; current: page.pnl?.align ?? ""; onPicked: v => page.set("align", v) }
            }
        }
        // everything you do to whole panels, together
        Flow {
            Layout.fillWidth: true
            spacing: 8
            ArqButton { text: "Add a panel"; onClicked: { const id = Config.addPanel(); if (id) Ui.settingsPanel = id } }
            ArqButton { text: "Edit " + page.name + " on screen"; primary: true; onClicked: { Ui.settingsOpen = false; Ui.editPanels(page.pid) } }
            ArqButton { visible: Config.panelsNow.length > 1; text: "Remove " + page.name; onClicked: { const id = page.pid; Ui.settingsPanel = ""; Config.removePanel(id) } }
        }
        DText { Layout.fillWidth: true; wrapMode: Text.WordWrap; color: Theme.subtext; font.pixelSize: 12
            text: "Quicker: right-click a panel on the screen to move, remove and resize its items right there." }
    }

    // ---------- items ----------
    SHeader { text: "Items on " + page.name }
    BarLayoutEditor { panelId: page.pid }

    // ---------- this panel's size ----------
    SHeader { text: page.name }
    SGroup {
        SRow { resetHandled: true; changed: page.pnl?.islands === true; onReset: page.set("islands", false); title: "Islands"; subtitle: "The left, centre and right groups each get their own floating pill, with the screen showing between them"; icon: "view_column"
            ArqToggle { checked: page.pnl?.islands ?? false; onToggled: v => page.set("islands", v) } }
        SRow { resetHandled: true; changed: page.pnl?.autohide === true; onReset: page.set("autohide", false); title: "Hide automatically"; subtitle: "Slides away and gives windows the room; push the pointer to that screen edge to bring it back"; icon: "unfold_less"
            ArqToggle { checked: page.pnl?.autohide ?? false; onToggled: v => page.set("autohide", v) } }
        SliderRow { resetHandled: true; changed: (page.pnl?.thickness ?? 56) !== 56; onReset: page.set("thickness", 56); title: "Thickness"; icon: "height"; suffix: " px"; from: 32; to: 120; step: 1
            value: page.pnl?.thickness ?? 56; onMoved: v => page.set("thickness", Math.round(v)) }
        SliderRow { resetHandled: true; changed: (page.pnl?.length ?? 100) !== 100; onReset: page.set("length", 100); title: "Length"; subtitle: "It grows by itself when its items need more room"; icon: "straighten"; suffix: " %"; from: 15; to: 100; step: 1
            value: page.pnl?.length ?? 100; onMoved: v => page.set("length", Math.round(v)) }
    }

    // ---------- every panel ----------
    SHeader { visible: Config.c.showAdvanced; text: "All panels"; key: "panelScaleMode,panelFloat,panelGap,itemPadding,iconSize,itemSize" }
    SGroup { visible: Config.c.showAdvanced;
        SRow { key: "panelScaleMode"; title: "With the screen scale"; subtitle: (Config.c.panelScaleMode || "auto") === "auto" ? "Panels keep their size on the screen when you change the screen scale" : "Panels get bigger and smaller with the screen scale, like apps"; icon: "aspect_ratio"
            SChoices { model: ["Keep their size", "Follow the scale"]; current: (Config.c.panelScaleMode || "auto") === "auto" ? "Keep their size" : "Follow the scale"
                       onPicked: v => Config.c.panelScaleMode = v === "Keep their size" ? "auto" : "scale" } }
        SRow { key: "panelFloat"; title: "Floating panels"; subtitle: "Off: panels sit on the screen edge"; icon: "picture_in_picture"
            ArqToggle { checked: Config.c.panelFloat; onToggled: v => Config.c.panelFloat = v } }
        SliderRow { key: "panelGap"; title: "Gap"; subtitle: Config.c.panelFloat ? "Around floating panels, pop-ups and the control centre" : "Around pop-ups and the control centre"; icon: "open_in_full"; suffix: " px"; from: 0; to: 32
            value: Config.c.panelGap; onMoved: v => Config.c.panelGap = Math.round(v) }
        SliderRow { key: "itemPadding"; title: "Space around items"; subtitle: "Not the dock"; icon: "padding"; suffix: " px"; from: 0; to: 16
            value: Config.c.itemPadding; onMoved: v => Config.c.itemPadding = Math.round(v) }
        SliderRow { key: "iconSize"; title: "App icon size"; subtitle: "Pinned and running apps in the dock"; icon: "photo_size_select_large"; suffix: " px"; from: 24; to: 64; step: 1
            value: Config.c.iconSize; onMoved: v => Config.c.iconSize = Math.round(v) }
        SliderRow { key: "itemSize"; title: "Other item size"; subtitle: "Buttons, status icons, desktop indicator. One item only: right-click its panel and pull its corner"; icon: "zoom_in"; suffix: " px"; from: 16; to: 40; step: 1
            value: Config.c.itemSize; onMoved: v => Config.c.itemSize = Math.round(v) }
    }

    SHeader { text: "Dock  ·  pinned apps in dock order"; key: "showRunning" }
    SGroup {
        SRow { key: "showRunning"; title: "Show running apps"; subtitle: "Apps that are open but not pinned"; icon: "apps"
            ArqToggle { checked: Config.c.showRunning; onToggled: v => Config.c.showRunning = v } }
        AppListEditor { key: "pinned" }
    }

    SHeader { text: "Clock"; key: "clockFontSize,clockShowTime,clockShowDate,clockLayout,clockDateFormat" }
    SGroup {
        SliderRow { key: "clockFontSize"; title: "Font size"; subtitle: "The time; the date follows it"; icon: "format_size"; suffix: " px"; from: 10; to: 32; step: 1
            value: Config.c.clockFontSize; onMoved: v => Config.c.clockFontSize = Math.round(v) }
        SRow { key: "clockShowTime"; title: "Show time"; icon: "schedule"; ArqToggle { checked: Config.c.clockShowTime; onToggled: v => Config.c.clockShowTime = v } }
        SRow { key: "clockShowDate"; title: "Show date"; icon: "calendar_today"; ArqToggle { checked: Config.c.clockShowDate; onToggled: v => Config.c.clockShowDate = v } }
        SRow { key: "clockLayout"; visible: Config.c.clockShowTime && Config.c.clockShowDate; title: "Layout"; subtitle: "Stacked: one above the other. Inline: side by side. Flip: date first"; icon: "view_agenda"
            SChoices { model: ["stacked", "stacked flip", "inline", "inline flip"]; current: Config.c.clockLayout; onPicked: v => Config.c.clockLayout = v } }
        SRow { key: "clockDateFormat"; visible: Config.c.clockShowDate; title: "Date format"; icon: "event"
            SChoices { model: ["ddd dd/MM", "dd/MM/yy", "d MMM", "dddd d MMM"]; current: Config.c.clockDateFormat; onPicked: v => Config.c.clockDateFormat = v } }
    }

    SHeader { text: "Music item on the panel"; key: "mediaPillStyle,mediaPillWidth,mediaPillArtist,mediaScroll,mediaPillControls" }
    SGroup {
        SRow { key: "mediaPillStyle"; title: "What it shows"; subtitle: "Full: cover, beat and title. Cover: just the round cover. Title: no cover"; icon: "view_compact"
            SChoices { model: ["Full", "Cover", "Title"]; current: Config.c.mediaPillStyle; onPicked: v => Config.c.mediaPillStyle = v } }
        SRow { key: "mediaPillWidth"; visible: (Config.c.mediaPillStyle || "Full") !== "Cover"; title: "Title width"; icon: "width"
            ArqSlider { from: 60; to: 320; stepSize: 10; value: Config.c.mediaPillWidth; onMoved: v => Config.c.mediaPillWidth = Math.round(v); width: 180 } }
        SRow { key: "mediaPillArtist"; visible: (Config.c.mediaPillStyle || "Full") !== "Cover"; title: "Artist after the title"; icon: "person"
            ArqToggle { checked: Config.c.mediaPillArtist; onToggled: v => Config.c.mediaPillArtist = v } }
        SRow { key: "mediaScroll"; visible: (Config.c.mediaPillStyle || "Full") !== "Cover"; title: "Long titles run along"; subtitle: "Off: they are cut with ..."; icon: "text_rotation_none"
            ArqToggle { checked: Config.c.mediaScroll; onToggled: v => Config.c.mediaScroll = v } }
        SRow { key: "mediaPillControls"; title: "Previous / play / next in the pill"; subtitle: "Middle-click the pill also plays and pauses"; icon: "play_circle"
            ArqToggle { checked: Config.c.mediaPillControls; onToggled: v => Config.c.mediaPillControls = v } }
    }
    SHeader { visible: Config.c.showAdvanced; text: "Cover and beat"; key: "mediaCoverShape,mediaSpin,mediaPulse,mediaViz,mediaVizSide,mediaVizColor" }
    SGroup { visible: Config.c.showAdvanced;
        SRow { key: "mediaCoverShape"; title: "Cover shape"; icon: "category"
            SChoices { model: ["Circle", "Rounded", "Square"]; current: Config.c.mediaCoverShape; onPicked: v => Config.c.mediaCoverShape = v } }
        SRow { key: "mediaSpin"; title: "Round cover turns while it plays"; icon: "autorenew"
            ArqToggle { checked: Config.c.mediaSpin; onToggled: v => Config.c.mediaSpin = v } }
        SRow { key: "mediaPulse"; title: "Cover beats with the bass"; icon: "album"
            ArqToggle { checked: Config.c.mediaPulse; onToggled: v => Config.c.mediaPulse = v } }
        SRow { key: "mediaViz"; title: "Moves to the beat"; subtitle: "Needs cava for the real beat; without it a made-up one moves instead"; icon: "equalizer"
            SChoices { model: ["Off", "Bars", "Mirror", "Dots", "Wave"]; current: Config.c.mediaViz; onPicked: v => Config.c.mediaViz = v } }
        SRow { key: "mediaVizSide"; title: "Beat sits"; icon: "align_horizontal_left"
            SChoices { model: ["Before", "After"]; current: Config.c.mediaVizSide; onPicked: v => Config.c.mediaVizSide = v } }
        SRow { key: "mediaVizColor"; title: "Colour"; icon: "palette"
            SChoices { model: ["Accent", "Text", "Rainbow"]; current: Config.c.mediaVizColor; onPicked: v => Config.c.mediaVizColor = v } }
    }
    SHeader { visible: Config.c.showAdvanced; text: "Music card (click the item)"; key: "mediaPopKind,mediaPopViz,mediaPopBlur" }
    SGroup { visible: Config.c.showAdvanced;
        SRow { key: "mediaPopKind"; title: "Beat drawn as"; subtitle: "Bars, Mirror, Dots (a dot-matrix), Wave (a smooth ribbon) or Blob (a round shape behind the cover that swells, like ferrofluid)"; icon: "bubble_chart"
            SChoices { model: ["Same", "Bars", "Mirror", "Dots", "Wave", "Blob"]; current: Config.c.mediaPopKind; onPicked: v => Config.c.mediaPopKind = v } }
        SRow { key: "mediaPopViz"; title: "Beat in the card"; subtitle: "Behind: faint, behind everything. Bottom: a strip of its own"; icon: "graphic_eq"
            SChoices { model: ["Behind", "Bottom", "Off"]; current: Config.c.mediaPopViz; onPicked: v => Config.c.mediaPopViz = v } }
        SRow { key: "mediaPopBlur"; title: "Cover blurred behind"; icon: "blur_on"
            ArqToggle { checked: Config.c.mediaPopBlur; onToggled: v => Config.c.mediaPopBlur = v } }
    }

    SHeader { text: "In use"; key: "privacyIndicators" }
    SGroup {
        SRow { key: "privacyIndicators"; title: "Microphone, camera and screen sharing"; subtitle: "A dot beside the notifications shows when an app is using one (orange: microphone, green: camera, blue: screen). Hover it for which apps"; icon: "privacy_tip"
            ArqToggle { checked: Config.c.privacyIndicators; onToggled: v => Config.c.privacyIndicators = v } }
    }

    SHeader { text: "Control centre and clipboard" }
    SGroup {
        SRow { title: "Control centre tiles"; subtitle: "In the control centre: pencil = move, resize, hide or add tiles. Right-click a tile for its options"; icon: "tune"
            ArqButton { text: "Reset tiles"; onClicked: CcTiles.commit(CcTiles.placed(CcTiles.defaults)) } }
        SRow { title: "Clipboard history"; subtitle: Clipboard.entries.length + " saved. Everything you copy is kept, passwords included"; icon: "content_paste"
            ArqButton { text: "Clear"; onClicked: Clipboard.wipe() } }
    }

    SMore {}
}
