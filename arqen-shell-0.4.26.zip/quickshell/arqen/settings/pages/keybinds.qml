import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Io
import Quickshell.Hyprland
import qs.config
import qs.components
import qs.services
import qs.settings

// Keyboard shortcuts: make your own (open an app or run a command), and see, change or turn off
// every shortcut Hyprland has. Your shortcuts and changes are written to the Hyprland file Arqen
// manages (arqen.lua / arqen-overrides.conf); your own hyprland config is left as it is.
ColumnLayout {
    id: pg
    readonly property var modNames: ["Super + Shift", "Super + Alt", "Super + Ctrl", "Alt + Shift", "Off"]
    readonly property var modVals: ["SUPER + SHIFT", "SUPER + ALT", "SUPER + CTRL", "ALT + SHIFT", ""]
    width: parent.width; spacing: 16

    SHeader { text: "Cheat sheet"; key: "cheatOnLogin" }
    SGroup {
        SRow { key: "cheatOnLogin"; title: "Show the shortcuts when I log in"; subtitle: "A small window with the shortcuts that are set now. It has the same switch."; icon: "keyboard"
            ArqToggle { checked: Config.c.cheatOnLogin; onToggled: v => Config.c.cheatOnLogin = v } }
        SRow { title: "Show it now"; icon: "visibility"
            ArqButton { text: "Open"; onClicked: Ui.cheatOpen = true } }
    }

    // ---- what Hyprland has now ----
    property var all: []
    property bool loading: true
    function refresh() { if (!listProc.running) { loading = true; listProc.running = true } }
    Process {
        id: listProc
        running: true
        command: ["python3", "-I", Appearance.scripts + "list-binds.py"]
        stdout: StdioCollector { onStreamFinished: { try { pg.all = JSON.parse(text) } catch (e) {} pg.loading = false } }
    }
    Connections {
        target: Hyprland
        function onRawEvent(event) { if (event.name === "configreloaded") refreshLater.restart() }
    }
    Timer { id: refreshLater; interval: 400; onTriggered: pg.refresh() }

    readonly property var mine: Config.c.keybinds || []
    readonly property var off: Config.c.unbinds || []
    function keysNorm(k) { return String(k).split("+").map(x => x.trim().toUpperCase()).filter(x => x !== "").join(" + ") }
    function isMine(keys) { return mine.some(b => keysNorm(b.keys) === keysNorm(keys)) }

    // ---- the editor (new shortcut, or changing one) ----
    property bool editing: false
    property int editIndex: -1              // index in Config.c.keybinds, -1 = new
    property string replaces: ""            // an existing shortcut this one takes the place of
    property var mods: []                   // ["SUPER", "SHIFT"]
    property string key: ""
    property string kind: "app"
    property string value: ""
    property string label: ""
    function startNew() { editIndex = -1; replaces = ""; mods = ["SUPER"]; key = ""; kind = "app"; value = ""; label = ""; editing = true }
    function startEdit(i) {
        const b = mine[i]
        const parts = String(b.keys).split("+").map(x => x.trim())
        editIndex = i; replaces = ""; key = parts.pop(); mods = parts.map(x => x.toUpperCase())
        kind = b.kind; value = b.value; label = b.label || ""; editing = true
    }
    function startReplace(row) {
        const parts = String(row.keys).split("+").map(x => x.trim())
        editIndex = -1; replaces = row.keys; key = parts.pop(); mods = parts
        const run = /^Run: (.*)$/.exec(row.action || "")
        kind = "command"; value = run ? run[1] : ""; label = ""; editing = true
    }
    function toggleMod(m) { mods = mods.includes(m) ? mods.filter(x => x !== m) : mods.concat([m]) }
    readonly property string combo: ["SUPER", "CTRL", "ALT", "SHIFT"].filter(m => mods.includes(m)).concat(key !== "" ? [key] : []).join(" + ")
    readonly property bool canSave: key !== "" && value.trim() !== ""
    function save() {
        if (!canSave) return
        const entry = { keys: combo, kind: kind, value: value.trim(),
                        label: kind === "app" ? (Apps.byId(value)?.name ?? value) : (label.trim() || value.trim()) }
        const list = mine.slice()
        if (editIndex >= 0) list[editIndex] = entry; else list.push(entry)
        Config.c.keybinds = list
        // a changed shortcut from your config: its old keys stop doing the old thing
        if (replaces !== "" && keysNorm(replaces) !== keysNorm(combo) && !off.some(k => keysNorm(k) === keysNorm(replaces)))
            Config.c.unbinds = off.concat([replaces])
        editing = false
        refreshLater.restart()
    }
    function removeMine(i) { const l = mine.slice(); l.splice(i, 1); Config.c.keybinds = l; refreshLater.restart() }
    function turnOff(keys) { if (!off.some(k => keysNorm(k) === keysNorm(keys))) Config.c.unbinds = off.concat([keys]); refreshLater.restart() }
    function turnOn(keys) { Config.c.unbinds = off.filter(k => keysNorm(k) !== keysNorm(keys)); refreshLater.restart() }

    // Qt key -> the name Hyprland uses
    function keyName(e) {
        const k = e.key
        if (k >= Qt.Key_A && k <= Qt.Key_Z) return String.fromCharCode(k)
        if (k >= Qt.Key_0 && k <= Qt.Key_9) return String.fromCharCode(k)
        if (k >= Qt.Key_F1 && k <= Qt.Key_F24) return "F" + (k - Qt.Key_F1 + 1)
        const map = {}
        map[Qt.Key_Return] = "Return"; map[Qt.Key_Enter] = "KP_Enter"; map[Qt.Key_Escape] = "Escape"; map[Qt.Key_Tab] = "Tab"
        map[Qt.Key_Backspace] = "BackSpace"; map[Qt.Key_Delete] = "Delete"; map[Qt.Key_Insert] = "Insert"
        map[Qt.Key_Home] = "Home"; map[Qt.Key_End] = "End"; map[Qt.Key_PageUp] = "Page_Up"; map[Qt.Key_PageDown] = "Page_Down"
        map[Qt.Key_Left] = "left"; map[Qt.Key_Right] = "right"; map[Qt.Key_Up] = "up"; map[Qt.Key_Down] = "down"
        map[Qt.Key_Space] = "space"; map[Qt.Key_Print] = "Print"; map[Qt.Key_Comma] = "comma"; map[Qt.Key_Period] = "period"
        map[Qt.Key_Slash] = "slash"; map[Qt.Key_Minus] = "minus"; map[Qt.Key_Equal] = "equal"; map[Qt.Key_Semicolon] = "semicolon"
        map[Qt.Key_Apostrophe] = "apostrophe"; map[Qt.Key_BracketLeft] = "bracketleft"; map[Qt.Key_BracketRight] = "bracketright"
        map[Qt.Key_Backslash] = "backslash"; map[Qt.Key_QuoteLeft] = "grave"
        map[Qt.Key_VolumeUp] = "XF86AudioRaiseVolume"; map[Qt.Key_VolumeDown] = "XF86AudioLowerVolume"; map[Qt.Key_VolumeMute] = "XF86AudioMute"
        map[Qt.Key_MediaPlay] = "XF86AudioPlay"; map[Qt.Key_MediaTogglePlayPause] = "XF86AudioPlay"; map[Qt.Key_MediaNext] = "XF86AudioNext"; map[Qt.Key_MediaPrevious] = "XF86AudioPrev"
        map[Qt.Key_MonBrightnessUp] = "XF86MonBrightnessUp"; map[Qt.Key_MonBrightnessDown] = "XF86MonBrightnessDown"
        if (map[k] !== undefined) return map[k]
        if ([Qt.Key_Shift, Qt.Key_Control, Qt.Key_Alt, Qt.Key_Meta, Qt.Key_Super_L, Qt.Key_Super_R, Qt.Key_AltGr, Qt.Key_CapsLock].includes(k)) return ""
        return (e.text || "").trim()
    }

    // a key combination drawn as little keys
    component Combo: Row {
        property string keys: ""
        spacing: 4
        Repeater {
            model: String(parent.keys).split("+").map(x => x.trim()).filter(x => x !== "")
            delegate: Rectangle {
                required property string modelData
                height: 26; width: Math.max(26, kt.implicitWidth + 14); radius: 8
                color: Theme.tile; border.width: 1; border.color: Theme.stroke
                DText { id: kt; anchors.centerIn: parent; text: modelData === "SUPER" ? "Super" : modelData === "CTRL" ? "Ctrl" : modelData === "ALT" ? "Alt" : modelData === "SHIFT" ? "Shift" : modelData; font.pixelSize: 12; font.weight: Font.Medium }
            }
        }
    }

    // ---- the shell's own shortcuts (Arqen writes them to its Hyprland file, so they always work) ----
    function setShellKey(id, keys) { const o = Object.assign({}, Config.c.shellKeys || {}); o[id] = keys; Config.c.shellKeys = o; refreshLater.restart() }
    function resetShellKey(id) { setShellKey(id, String(Config.defaults.shellKeys[id] || "")) }
    readonly property var shellIcons: ({ settings: "settings", search: "search", overview: "grid_view", quick: "tune", clipboard: "content_paste",
                                         capture: "screenshot_region", lock: "lock", power: "power_settings_new", keyboard: "keyboard", minimize: "remove" })
    SHeader { text: "Arqen" }
    SGroup {
        Repeater {
            model: Config.shellKeyList
            delegate: SRow {
                required property var modelData
                title: modelData[1]
                icon: pg.shellIcons[modelData[0]] || "keyboard"
                resetHandled: true
                changed: Config.shellKeyOf(modelData[0]) !== String(Config.defaults.shellKeys[modelData[0]] || "")
                onReset: pg.resetShellKey(modelData[0])
                KeyRecorder { keys: Config.shellKeyOf(modelData[0]); onPicked: k => pg.setShellKey(modelData[0], k); anchors.verticalCenter: parent.verticalCenter }
            }
        }
        SRow { key: "keyFloat"; title: "Toggle floating"; subtitle: "Switch the focused window between floating and tiled"; icon: "open_in_new"
            KeyRecorder { keys: Config.c.keyFloat; onPicked: k => Config.c.keyFloat = k; anchors.verticalCenter: parent.verticalCenter } }
        SRow { key: "keyFullscreen"; title: "Full screen"; subtitle: "Hide panels for the focused window; press again to restore"; icon: "fullscreen"
            KeyRecorder { keys: Config.c.keyFullscreen; onPicked: k => Config.c.keyFullscreen = k; anchors.verticalCenter: parent.verticalCenter } }
        SRow { key: "keyMaximize"; title: "Maximise"; subtitle: "Fills the screen but keeps the panels"; icon: "open_in_full"
            KeyRecorder { keys: Config.c.keyMaximize; onPicked: k => Config.c.keyMaximize = k; anchors.verticalCenter: parent.verticalCenter } }
        SRow { key: "keyResize"; title: "Resize with the arrow keys"; subtitle: "Hold these and press an arrow key to resize the focused window"; icon: "aspect_ratio"
            SDropdown { model: pg.modNames; currentIndex: Math.max(0, pg.modVals.indexOf(Config.c.keyResize || "")); onPicked: (i, label) => Config.c.keyResize = pg.modVals[i] } }
        SRow { key: "keyMove"; title: "Move with the arrow keys"; subtitle: "Hold these and press an arrow key to move the focused window (a tiled one swaps places with its neighbour)"; icon: "open_with"
            SDropdown { model: pg.modNames; currentIndex: Math.max(0, pg.modVals.indexOf(Config.c.keyMove || "")); onPicked: (i, label) => Config.c.keyMove = pg.modVals[i] } }
        SRow { title: "Launcher"; subtitle: "Press and let go of Super on its own"; icon: "apps" }
    }

    // ---- your shortcuts ----
    SHeader { text: "Your shortcuts" }
    SGroup {
        Repeater {
            model: pg.mine
            delegate: SRow {
                required property var modelData
                required property int index
                title: modelData.label || modelData.value
                subtitle: modelData.kind === "app" ? "Opens the app" : "Runs " + modelData.value
                icon: modelData.kind === "app" ? "apps" : "terminal"
                Combo { keys: modelData.keys; anchors.verticalCenter: parent.verticalCenter }
                ArqButton { text: "Change"; onClicked: pg.startEdit(index) }
                ArqButton { text: "Remove"; onClicked: pg.removeMine(index) }
            }
        }
        SRow {
            visible: !pg.editing
            title: pg.mine.length === 0 ? "No shortcuts of your own yet" : "Add another"
            subtitle: "A key combination that opens an app or runs a command"
            icon: "add"
            ArqButton { text: "Add shortcut"; primary: true; onClicked: pg.startNew() }
        }
    }

    // ---- editor ----
    SCard {
        visible: pg.editing
        DText { text: pg.editIndex >= 0 ? "Change shortcut" : (pg.replaces !== "" ? "Change " + pg.replaces : "New shortcut"); font.pixelSize: 16; font.weight: Font.Medium }
        DText { text: "Keys"; color: Theme.subtext; font.pixelSize: 12 }
        Flow {
            Layout.fillWidth: true; spacing: 8
            Repeater {
                model: ["SUPER", "CTRL", "ALT", "SHIFT"]
                delegate: Rectangle {
                    required property string modelData
                    readonly property bool on: pg.mods.includes(modelData)
                    height: 32; width: mt.implicitWidth + 32; radius: 16
                    color: on ? Theme.pillOn : (mma.containsMouse ? Theme.hover : Theme.tile)
                    DText { id: mt; anchors.centerIn: parent; text: modelData.charAt(0) + modelData.slice(1).toLowerCase(); color: parent.on ? Theme.pillOnText : Theme.text; font.pixelSize: 14 }
                    MouseArea { id: mma; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: pg.toggleMod(modelData) }
                }
            }
            DText { text: "+"; color: Theme.subtext; font.pixelSize: 16; height: 32; verticalAlignment: Text.AlignVCenter }
            // press the key here
            Rectangle {
                id: keyBox
                height: 32; width: Math.max(150, keyLabel.implicitWidth + 32); radius: 16
                color: Theme.dark ? Qt.rgba(1, 1, 1, 0.10) : Qt.rgba(0, 0, 0, 0.07)
                border.width: keyFocus.activeFocus ? 2 : 0; border.color: Theme.primary
                DText { id: keyLabel; anchors.centerIn: parent; text: keyFocus.activeFocus ? (pg.key !== "" ? pg.key + "  (press another to change)" : "Press a key…") : (pg.key !== "" ? pg.key : "Click, then press a key"); color: pg.key !== "" ? Theme.text : Theme.subtext; font.pixelSize: 14 }
                Item {
                    id: keyFocus
                    anchors.fill: parent
                    focus: false
                    Keys.onPressed: e => { const n = pg.keyName(e); if (n !== "") pg.key = n; e.accepted = true }
                }
                MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor; onClicked: keyFocus.forceActiveFocus() }
            }
        }
        RowLayout {
            Layout.fillWidth: true
            DText { text: "Shortcut:"; color: Theme.subtext; font.pixelSize: 12 }
            Combo { keys: pg.combo }
            DText {
                visible: pg.key !== "" && pg.all.some(r => pg.keysNorm(r.keys) === pg.keysNorm(pg.combo)) && pg.keysNorm(pg.combo) !== pg.keysNorm(pg.replaces)
                text: "Already used; this one will take its place"; color: "#F5A623"; font.pixelSize: 12
            }
        }
        DText { text: "What it does"; color: Theme.subtext; font.pixelSize: 12 }
        SChoices { model: ["open an app", "run a command"]; current: pg.kind === "app" ? "open an app" : "run a command"; onPicked: v => { pg.kind = v === "open an app" ? "app" : "command"; pg.value = "" } }
        // an app: pick from the icons
        ArqField { visible: pg.kind === "app"; id: appFind; Layout.fillWidth: true; implicitHeight: 40; placeholder: "Find an app…"; iconName: "search"; closesOnEscape: false }
        Item {
            visible: pg.kind === "app"
            Layout.fillWidth: true; Layout.preferredHeight: Math.min(appFlow.implicitHeight, 230)
            Flickable {
                id: appPickFlick
                anchors.fill: parent
                contentHeight: appFlow.implicitHeight; clip: true; boundsBehavior: Flickable.StopAtBounds
                Flow {
                    id: appFlow; width: parent.width; spacing: 4
                    Repeater {
                        model: pg.kind === "app" ? Apps.search(appFind.text) : []
                        delegate: Rectangle {
                            required property var modelData
                            readonly property bool on: pg.value === modelData.id
                            width: 84; height: 88; radius: 14
                            color: on ? Theme.pillOn : (ama.containsMouse ? Theme.hover : "transparent")
                            AppIcon { entry: modelData; size: 40; anchors { horizontalCenter: parent.horizontalCenter; top: parent.top; topMargin: 8 } }
                            DText { anchors { bottom: parent.bottom; bottomMargin: 8; left: parent.left; right: parent.right; leftMargin: 4; rightMargin: 4 }
                                    text: modelData.name; font.pixelSize: 11; elide: Text.ElideRight; horizontalAlignment: Text.AlignHCenter; color: parent.on ? Theme.pillOnText : Theme.text }
                            MouseArea { id: ama; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: pg.value = modelData.id }
                        }
                    }
                }
            }
            ArqScrollBar { flick: appPickFlick }
        }
        // a command
        ArqField { visible: pg.kind === "command"; id: cmdField; Layout.fillWidth: true; implicitHeight: 40; placeholder: "Command, e.g.  kitty -e btop"; iconName: "terminal"; closesOnEscape: false
                   text: pg.value; onEdited: pg.value = text }
        ArqField { visible: pg.kind === "command"; Layout.fillWidth: true; implicitHeight: 40; placeholder: "Name (optional)"; iconName: "label"; closesOnEscape: false
                   text: pg.label; onEdited: pg.label = text }
        RowLayout {
            Layout.alignment: Qt.AlignRight
            spacing: 8
            ArqButton { text: "Cancel"; onClicked: pg.editing = false }
            ArqButton { text: "Save"; primary: true; opacity: pg.canSave ? 1 : 0.5; onClicked: pg.save() }
        }
    }

    // ---- shortcuts you turned off ----
    SHeader { visible: pg.off.length > 0; text: "Turned off" }
    SGroup {
        visible: pg.off.length > 0
        Repeater {
            model: pg.off
            delegate: SRow {
                required property string modelData
                title: modelData; icon: "keyboard_off"
                ArqButton { text: "Turn back on"; onClicked: pg.turnOn(modelData) }
            }
        }
    }

    // ---- the same keys doing two things at once ----
    readonly property var clashes: {
        const by = {}
        for (const r of all) {
            if (r.mouse) continue
            const k = keysNorm(r.keys)
            if (!by[k]) by[k] = []
            if (by[k].indexOf(r.action) < 0) by[k].push(r.action)
        }
        return Object.keys(by).filter(k => by[k].length > 1).map(k => ({ keys: k, actions: by[k] }))
    }
    SHeader { visible: !pg.loading; text: pg.clashes.length > 0 ? "Keys that do two things (" + pg.clashes.length + ")" : "No keys do two things" }
    SGroup {
        visible: pg.clashes.length > 0
        Repeater {
            model: pg.clashes
            delegate: SRow {
                required property var modelData
                title: modelData.actions.join("  ·  ")
                subtitle: "Pressing these keys does all of these. Change or turn off one of them below"
                icon: "warning"; iconColor: "#FF8A3D"
                Combo { keys: modelData.keys; anchors.verticalCenter: parent.verticalCenter }
            }
        }
    }

    // ---- everything Hyprland has ----
    SHeader { text: "All shortcuts" }
    SGroup {
        Item {
            Layout.fillWidth: true; implicitHeight: 64
            ArqField { id: find; anchors { fill: parent; margins: 9; leftMargin: 18; rightMargin: 18 } placeholder: "Search shortcuts…"; iconName: "search"; closesOnEscape: false }
        }
        LoadingPill { visible: pg.loading; Layout.alignment: Qt.AlignHCenter; Layout.bottomMargin: 12; width: 48; height: 26 }
        Repeater {
            model: pg.all.filter(r => !r.mouse && (find.text === "" || (r.keys + " " + r.action).toLowerCase().includes(find.text.toLowerCase())))
            delegate: SRow {
                required property var modelData
                title: modelData.action
                Combo { keys: modelData.keys; anchors.verticalCenter: parent.verticalCenter }
                ArqButton { visible: !pg.isMine(modelData.keys); text: "Change"; onClicked: pg.startReplace(modelData) }
                ArqButton { visible: !pg.isMine(modelData.keys); text: "Turn off"; onClicked: pg.turnOff(modelData.keys) }
            }
        }
    }
}
