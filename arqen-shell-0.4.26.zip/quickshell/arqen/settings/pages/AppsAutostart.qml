import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Io
import qs.config
import qs.components
import qs.services
import qs.settings

// Apps that start when you log in (the autostart folder every desktop reads).
ColumnLayout {
    id: pg
    width: parent ? parent.width : 400
    spacing: 16
    property var items: []
    property bool adding: false
    property string query: ""
    readonly property string py: Quickshell.shellDir + "/scripts/autostart.py"

    function refresh() { if (!listP.running) listP.running = true }
    Process {
        id: listP
        running: true
        command: ["python3", "-I", pg.py, "list"]
        stdout: StdioCollector { onStreamFinished: { try { pg.items = JSON.parse(text) } catch (e) {} } }
    }
    Process { id: act; onExited: pg.refresh() }
    function run(args) { act.command = ["python3", "-I", pg.py].concat(args); act.running = true }

    SHeader { text: "Start at login" }
    SGroup {
        visible: pg.items.length === 0
        DText { Layout.fillWidth: true; Layout.margins: 18; wrapMode: Text.WordWrap; color: Theme.subtext; text: "Nothing starts by itself yet. Add an app below." }
    }
    SGroup {
        visible: pg.items.length > 0
        Repeater {
            model: pg.items
            delegate: SRow {
                id: row
                required property var modelData
                readonly property var e: Apps.byId(String(modelData.file).replace(/\.desktop$/, ""))
                title: modelData.name
                subtitle: modelData.mine ? modelData.exec : "Started by the system" + (modelData.exec ? ": " + modelData.exec : "")
                icon: ""
                AppIcon { entry: row.e; source: row.e ? "" : (modelData.icon !== "" ? modelData.icon : "application-x-executable"); size: 30; anchors.verticalCenter: parent.verticalCenter }
                ArqToggle { checked: row.modelData.enabled; onToggled: v => { pg.run(["set", row.modelData.file, v ? "on" : "off"]) } }
                TrayButton { visible: row.modelData.mine; round: true; icon: "delete"; size: 18; tip: "Remove from the list"; anchors.verticalCenter: parent.verticalCenter
                    onClicked: pg.run(["remove", row.modelData.file]) }
            }
        }
    }

    RowLayout {
        Layout.fillWidth: true
        spacing: 8
        ArqButton { text: pg.adding ? "Close the list" : "Add an app"; primary: !pg.adding; onClicked: pg.adding = !pg.adding }
        ArqField { Layout.fillWidth: true; visible: pg.adding; placeholder: "Search apps"; iconName: "search"; implicitHeight: 38; onEdited: pg.query = text }
    }
    SGroup {
        visible: pg.adding
        Repeater {
            model: pg.adding ? Apps.search(pg.query).slice(0, 12) : []
            delegate: SRow {
                id: ar
                required property var modelData
                title: modelData.name
                subtitle: modelData.comment || ""
                onClicked: { pg.run(["add", modelData.id]); pg.adding = false }
                AppIcon { entry: ar.modelData; size: 30; anchors.verticalCenter: parent.verticalCenter }
                ArqButton { text: "Start at login"; onClicked: { pg.run(["add", ar.modelData.id]); pg.adding = false } }
            }
        }
    }
    Item { Layout.preferredHeight: 4 }
}
