import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Io
import qs.config
import qs.components
import qs.services
import qs.settings

// Date and time: the clock format, the time zone and automatic time (timedatectl).
ColumnLayout {
    id: page
    width: parent.width; spacing: 16
    property string zone: ""
    property bool ntp: true
    property bool ntpSynced: false
    property var zones: []
    property string message: ""
    property string timeSvc: ""         // the time service that is running (chronyd / systemd-timesyncd), "" for none
    property string timeHave: ""        // one that is installed

    function reload() { if (!info.running) info.running = true }
    Component.onCompleted: { reload(); if (!zoneList.running) zoneList.running = true }

    Process {
        id: info
        // (the zone also from /etc/localtime when timedatectl cannot say, so the page never shows "Not set" for a
        // computer that has one)
        command: ["sh", "-c", "timedatectl show --property=Timezone,NTP,NTPSynchronized 2>/dev/null; "
                  + "z=$(timedatectl show --property=Timezone --value 2>/dev/null); "
                  + "case \"$z\" in ''|n/a) z=$(readlink -f /etc/localtime 2>/dev/null | sed 's#.*/zoneinfo/##'); [ \"$z\" = /etc/localtime ] && z=''; echo \"ZoneFile=$z\";; esac; "
                  + "for s in chronyd systemd-timesyncd; do systemctl is-active --quiet $s 2>/dev/null && { echo \"Svc=$s\"; break; }; done; "
                  + "for s in chronyd systemd-timesyncd; do systemctl cat $s >/dev/null 2>&1 && { echo \"Have=$s\"; break; }; done"]
        stdout: StdioCollector {
            onStreamFinished: {
                page.timeSvc = ""; page.timeHave = ""
                for (const l of text.split("\n")) {
                    const i = l.indexOf("=")
                    if (i < 0) continue
                    const k = l.slice(0, i), val = l.slice(i + 1).trim()
                    if (k === "Timezone" && val !== "" && val !== "n/a") page.zone = val
                    else if (k === "ZoneFile" && val !== "" && page.zone === "") page.zone = val
                    else if (k === "NTP") page.ntp = val === "yes"
                    else if (k === "NTPSynchronized") page.ntpSynced = val === "yes"
                    else if (k === "Svc") page.timeSvc = val
                    else if (k === "Have") page.timeHave = val
                }
            }
        }
    }
    Process {
        id: zoneList
        command: ["timedatectl", "list-timezones"]
        stdout: StdioCollector { onStreamFinished: page.zones = text.split("\n").filter(z => z !== "") }
    }
    // Changing these needs the administrator's permission. First through the desktop's own prompt (polkit); when
    // there is no prompt to show it (no authentication agent running), the same command in a terminal with sudo.
    property var lastArgs: []
    Process {
        id: setter
        stderr: StdioCollector { id: err }
        onExited: code => {
            if (code === 0) {
                page.reload()
                page.message = page.lastArgs[0] === "set-timezone" ? "Time zone set to " + page.lastArgs[1] : (page.lastArgs[1] === "true" ? "Automatic time is on" : "Automatic time is off")
                page.good = true
                // programs keep the time zone they started with: the shell reloads once so every clock (panel, lock
                // screen, calendar, notifications) uses the new one
                if (page.lastArgs[0] === "set-timezone") { page.message += ". The shell reloads in a moment to use it."; reloadLater.restart() }
                else msgClear.restart()
                return
            }
            page.good = false
            const e = err.text.trim()
            if (code === 124 || /authori|authentic|polkit|denied|privilege|not allowed/i.test(e) || e === "") {
                page.message = "No permission prompt appeared: a terminal opens to ask for your password."
                viaTerminal.command = ["sh", Appearance.scripts + "term-run.sh", "sudo timedatectl " + page.lastArgs.map(a => "'" + a + "'").join(" ")]
                viaTerminal.running = true
            } else {
                page.message = "Could not change it: " + e + "."
                page.reload()
            }
        }
    }
    Process {
        id: viaTerminal
        onExited: { page.message = ""; page.reload() }
    }
    property bool good: false
    Timer { id: msgClear; interval: 4000; onTriggered: page.message = "" }
    Timer { id: reloadLater; interval: 2200; onTriggered: Quickshell.reload(true) }
    // (a permission prompt nobody answers must not leave the page stuck: 30 seconds, then the terminal way)
    function run(args) {
        if (setter.running) { page.good = false; page.message = "Still waiting for the permission prompt..."; return }
        page.good = false
        page.message = "Changing it (you may be asked for your password)..."
        page.lastArgs = args
        setter.command = ["timeout", "30", "timedatectl"].concat(args)
        setter.running = true
    }
    // the time zone from where the computer is (its internet address): one request, only when you press the button
    Process {
        id: geo
        // several free services in turn (any one can be busy or refuse), and what went wrong is shown if none answers
        command: ["sh", "-c", 'err=""; command -v curl >/dev/null 2>&1 || { echo "ERR=curl is not installed"; exit 0; }; '
            + 'for u in https://ipinfo.io/timezone https://ipapi.co/timezone "http://ip-api.com/line/?fields=timezone" https://worldtimeapi.org/api/ip https://ipwho.is/; do '
            + 'o=$(curl -sS -L --max-time 7 -A "Mozilla/5.0" "$u" 2>/tmp/arqen-geo-err); '
            + 'z=$(printf "%s" "$o" | sed -n \'s/.*"timezone": *"\\([^"]*\\)".*/\\1/p; s/.*"id": *"\\([A-Za-z_]*\\/[^"]*\\)".*/\\1/p\' | head -n1); '
            + '[ -z "$z" ] && z=$(printf "%s" "$o" | head -n1); '
            + 'case "$z" in [A-Za-z]*/[A-Za-z_]*) case "$z" in *" "*|*"<"*) ;; *) echo "$z"; exit 0;; esac;; esac; '
            + 'err="$err $(echo "$u" | cut -d/ -f3): $(head -c 80 /tmp/arqen-geo-err | tr "\\n" " ")"; done; echo "ERR=$err"']
        stdout: StdioCollector {
            onStreamFinished: {
                const z = text.trim().split("\n")[0]
                if (z !== "" && page.zones.indexOf(z) >= 0) page.run(["set-timezone", z])
                else {
                    page.good = false
                    const why = z.indexOf("ERR=") === 0 ? z.slice(4).trim() : (z !== "" ? "got \"" + z.slice(0, 40) + "\"" : "")
                    page.message = "Could not find out where this computer is" + (why !== "" ? " (" + why + ")" : "") + ". Pick the time zone from the list below."
                }
            }
        }
    }

    SHeader { text: "Clock"; key: "clock24" }
    SGroup {
        SRow { key: "clock24"; title: "24-hour time"; subtitle: "Shown in the bar, the lock screen and the calendar"; icon: "schedule"
            ArqToggle { checked: Config.c.clock24; onToggled: v => Config.c.clock24 = v } }
        SRow { title: "Now"; icon: "today"
            DText { text: Qt.formatDateTime(clock.date, Config.c.clock24 ? "dddd d MMMM, HH:mm" : "dddd d MMMM, h:mm AP"); color: Theme.subtext; anchors.verticalCenter: parent.verticalCenter }
            SystemClock { id: clock; precision: SystemClock.Minutes } }
    }

    SHeader { text: "Time zone and network time" }
    SGroup {
        SRow { title: "Set automatically"; subtitle: page.ntp ? (page.ntpSynced ? "The clock is synchronised with internet time"
                : (page.timeSvc === "" ? "Waiting for internet time: no time service is running, so it cannot sync (see below)" : "Waiting for internet time (" + page.timeSvc + " is running)")) : "The clock is set by hand"; icon: "sync"
            ArqToggle { checked: page.ntp; onToggled: v => { page.ntp = v; page.run(["set-ntp", v ? "true" : "false"]) } } }
        SRow { visible: page.ntp && !page.ntpSynced && page.timeSvc === ""; icon: "build"
            title: page.timeHave !== "" ? "Start the time service" : "Install a time service"
            subtitle: page.timeHave !== "" ? "Starts " + page.timeHave + " (asks for your password in a terminal) and syncs the clock" : "Installs chrony (sudo dnf install chrony), starts it and syncs the clock"
            ArqButton { text: page.timeHave !== "" ? "Start" : "Install"; onClicked: {
                const svc = page.timeHave !== "" ? page.timeHave : "chronyd"
                const pre = page.timeHave !== "" ? "" : "dnf install -y chrony && "
                page.message = "A terminal opens to ask for your password."; page.good = true
                viaTerminal.command = ["sh", Appearance.scripts + "term-run.sh", "sudo sh -c '" + pre + "systemctl enable --now " + svc + " && timedatectl set-ntp true; chronyc makestep 2>/dev/null; true'"]
                viaTerminal.running = true } } }
    }
    DText {
        visible: page.message !== ""
        Layout.fillWidth: true; Layout.leftMargin: 18; Layout.rightMargin: 18; wrapMode: Text.WordWrap
        color: page.good ? Theme.accent : "#E5484D"; font.pixelSize: 13; text: page.message
    }
    SGroup {
        SRow { title: "Time zone from my location"; icon: "my_location"
            subtitle: "Automatic time keeps the clock exact, but does not know the time zone. This looks it up from the computer's internet address (one request, only now)"
            ArqButton { text: geo.running ? "Looking..." : "Detect"; onClicked: { if (!geo.running) { page.good = false; page.message = "Looking up where this computer is..."; geo.running = true } } } }
    }
    SPicker {
        title: "Time zone"; icon: "public"
        model: page.zones
        current: page.zone
        onPicked: v => page.run(["set-timezone", v])
    }
    Item { Layout.preferredHeight: 4 }
}
