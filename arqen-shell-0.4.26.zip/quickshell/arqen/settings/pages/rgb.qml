import QtQuick
import QtQuick.Layouts
import Quickshell
import qs.config
import qs.components
import qs.services
import qs.settings

// Lighting: the RGB on connected devices (keyboard, mouse, fans, RAM ...) through OpenRGB.
ColumnLayout {
    id: pg
    width: parent.width; spacing: 16
    readonly property var labels: ["Leave alone", "Follow wallpaper", "Custom colour", "Lights off"]
    readonly property var values: ["off", "wallpaper", "custom", "dark"]

    SHeader { text: "Lighting"; key: "rgbMode,rgbColor,rgbBrightness" }
    SGroup {
        SRow {
            title: "OpenRGB"
            subtitle: Rgb.found ? "Found. Devices must be supported by OpenRGB (openrgb.org)"
                : "Not installed. Install openrgb (and openrgb-udev-rules), then log out and in"
            icon: Rgb.found ? "check_circle" : "error"
            iconColor: Rgb.found ? Theme.tile : "#E5484D"
        }
        SRow {
            key: "rgbMode"; title: "Lights"
            subtitle: Config.c.rgbMode === "wallpaper" ? "They take the shell's accent colour, so they follow the wallpaper"
                : Config.c.rgbMode === "custom" ? "One colour of your own"
                : Config.c.rgbMode === "dark" ? "All lights off"
                : "The shell does not touch your lights"
            icon: "lightbulb"
            SChoices {
                maxWidth: 420
                model: pg.labels
                current: pg.labels[Math.max(0, pg.values.indexOf(Config.c.rgbMode || "off"))]
                onPicked: v => Config.c.rgbMode = pg.values[pg.labels.indexOf(v)]
            }
        }
        SRow {
            visible: Config.c.rgbMode === "wallpaper"
            title: "Colour now"; subtitle: "#" + Rgb.wanted; icon: "colorize"
            Rectangle { width: 32; height: 32; radius: 16; color: Theme.accent; border.width: 1; border.color: Theme.stroke }
        }
        SRow {
            visible: Config.c.rgbMode === "custom"
            key: "rgbColor"; title: "Colour"; icon: "palette"
            SSwatches {
                colors: ["#FFFFFF", "#FF3B30", "#FF9F0A", "#FFD60A", "#30D158", "#00C7BE", "#0A84FF", "#BF5AF2", "#FF2D95"]
                value: Config.c.rgbColor || "#FFFFFF"
                onPicked: hex => Config.c.rgbColor = hex
            }
        }
        SliderRow {
            visible: Config.c.rgbMode !== "off" && Config.c.rgbMode !== "dark"
            key: "rgbBrightness"; title: "Brightness"; subtitle: "Devices without a brightness setting ignore it"; icon: "brightness_6"
            suffix: " %"; from: 0; to: 100; step: 5
            value: Config.c.rgbBrightness; onMoved: v => Config.c.rgbBrightness = Math.round(v)
        }
        SRow {
            visible: Config.c.rgbMode !== "off"
            title: "Apply now"
            subtitle: Rgb.busy ? "Sending ..." : (Rgb.status !== "" ? Rgb.status : "Sent when the colour changes; press this if a device missed it")
            icon: "sync"
            ArqButton { text: "Apply"; onClicked: Rgb.apply() }
        }
    }

    SHeader { visible: Config.c.showAdvanced; text: "OpenRGB itself" }
    SGroup {
        visible: Config.c.showAdvanced
        SRow {
            key: "rgbServer"; title: "Keep OpenRGB running in the background"
            subtitle: "Faster changes. Off: OpenRGB starts and stops for each change"
            icon: "dns"
            ArqToggle { checked: Config.c.rgbServer !== false; onToggled: v => Config.c.rgbServer = v }
        }
        SRow {
            title: "Open OpenRGB"; subtitle: "Its own window: per-device effects, zones and profiles"; icon: "open_in_new"
            ArqButton { text: "Open"; onClicked: Quickshell.execDetached(["sh", "-c", "openrgb >/dev/null 2>&1 &"]) }
        }
    }

    SMore {}
}
