import QtQuick
import qs.config

// 3x3 grid: click where on the screen something should appear
Item {
    id: pp
    property string value: "center"
    signal picked(string v)
    width: 132; height: 84

    readonly property var names: ["top-left", "top", "top-right", "left", "center", "right", "bottom-left", "bottom", "bottom-right"]

    Grid {
        anchors.fill: parent
        columns: 3; spacing: 4
        Repeater {
            model: pp.names
            delegate: Rectangle {
                id: cell
                required property string modelData
                width: (pp.width - 8) / 3; height: (pp.height - 8) / 3
                radius: 8
                color: modelData === pp.value ? Theme.pillOn : (cma.containsMouse ? Theme.hover : Theme.tile)
                MouseArea { id: cma; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: pp.picked(cell.modelData) }
            }
        }
    }
}
