import QtQuick
import qs.config
import qs.components

// Row with a value label + slider. The slider is 260 px when there is room, and stretches
// across the row when the row stacks (narrow window).
SRow {
    id: s
    property real value: 0
    property real from: 0
    property real to: 10
    property real step: 1
    property string suffix: ""
    property real factor: 1                  // shown value = value x factor (0.82 -> 82 %)
    property string display: ""              // shown instead of the number when set ("Never", "1 h")
    signal moved(real v)
    // as many decimals as one step needs: 1 px, 0.1 s, 1 %
    readonly property int decimals: Math.max(0, Math.ceil(-Math.log10(Math.max(1e-6, step * factor)) - 1e-9))
    DText { text: s.display !== "" ? s.display : (s.value * s.factor).toFixed(s.decimals) + s.suffix; color: Theme.subtext; font.pixelSize: s.compact ? 12 : 14; width: s.compact ? 44 : 54; horizontalAlignment: Text.AlignRight; anchors.verticalCenter: parent.verticalCenter }
    ArqSlider {
        readonly property real naturalWidth: s.compact ? 170 : 260
        width: s.stacked ? Math.max(100, s.trailingMax - (s.compact ? 54 : 64)) : Math.min(s.compact ? 170 : 260, Math.max(100, s.trailingMax - (s.compact ? 54 : 64)))
        value: s.value; from: s.from; to: s.to; stepSize: s.step
        onMoved: v => s.moved(v)
        anchors.verticalCenter: parent.verticalCenter
    }
}
