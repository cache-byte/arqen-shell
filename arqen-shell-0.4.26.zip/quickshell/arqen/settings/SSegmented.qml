import QtQuick
import qs.config
import qs.components

// Joined buttons, one of them chosen (like the scale buttons in GNOME's display settings).
Rectangle {
    id: sg
    property var model: []                  // labels
    property int currentIndex: -1
    property real maxWidth: 100000
    signal picked(int index)
    property real segW: 64
    readonly property real naturalWidth: model.length * segW + 4
    implicitWidth: Math.min(naturalWidth, maxWidth)
    width: implicitWidth
    implicitHeight: 36
    radius: 18
    color: Theme.tile
    Row {
        anchors { fill: parent; margins: 2 }
        Repeater {
            model: sg.model
            delegate: Rectangle {
                required property var modelData
                required property int index
                readonly property bool on: index === sg.currentIndex
                width: (sg.width - 4) / Math.max(1, sg.model.length); height: parent.height
                radius: 16
                color: on ? Theme.primary : (sm.containsMouse ? Theme.hover : "transparent")
                Behavior on color { ColorAnimation { duration: 100 } }
                DText { anchors.centerIn: parent; text: String(parent.modelData); font.pixelSize: 14; color: parent.on ? Theme.onPrimary : Theme.text }
                MouseArea { id: sm; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: sg.picked(parent.index) }
                // a thin line between buttons that are not chosen
                Rectangle { visible: parent.index > 0 && !parent.on && parent.index - 1 !== sg.currentIndex
                            x: 0; anchors.verticalCenter: parent.verticalCenter; width: 1; height: parent.height * 0.5; color: Theme.divider }
            }
        }
    }
}
