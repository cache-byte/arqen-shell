import QtQuick
import QtQuick.Layouts
import qs.config
import qs.components
import qs.services

// Every option of one desktop widget, as rows: its own, then the ones all widgets have (background, corners,
// text...). Changes are saved as they are made (the widget on the desktop follows). Used in Settings > Desktop
// and in the editor on the desktop itself. `wid` is the widget's id (Config.c.desktopWidgets).
ColumnLayout {
    id: wo
    property string wid: ""
    readonly property var wd: (Config.c.desktopWidgets || []).find(x => x.id === wid) ?? null
    readonly property var cfg: Widgets.cfg(wd)
    readonly property var opts: wd ? Widgets.optionsFor(wd) : []
    spacing: 0

    Repeater {
        model: wo.opts
        delegate: Loader {
            id: ld
            required property var modelData
            Layout.fillWidth: true
            Layout.preferredHeight: item ? item.implicitHeight : 0
            sourceComponent: modelData.section ? secC : modelData.slider ? sliC : rowC
            onLoaded: { item.od = modelData; item.width = Qt.binding(() => ld.width) }
        }
    }

    // a heading
    Component {
        id: secC
        Item {
            property var od: ({})
            implicitHeight: 28
            DText { x: 12; anchors.bottom: parent.bottom; anchors.bottomMargin: 4; text: parent.od.section ?? ""; font.pixelSize: 12; font.weight: Font.DemiBold; color: Theme.subtext }
        }
    }
    // a slider
    Component {
        id: sliC
        SliderRow {
            id: sr
            property var od: ({ slider: [0, 1, 1, ""] })
            compact: true
            title: od.name ?? ""; icon: od.icon ?? ""
            // back to the widget's default for this option
            resetHandled: true
            changed: (wo.cfg[od.key] ?? od.def) !== od.def
            onReset: Widgets.set(wo.wid, od.key, od.def)
            display: od.autoZero && value === 0 ? "Auto" : ""
            from: od.slider[0]; to: od.slider[1]; step: od.slider[2]; suffix: od.slider[3]
            // the corner radius: -1 means the theme's own
            value: !isNaN(pending) ? pending : (od.key === "radius" && (wo.cfg.radius ?? -1) < 0 ? Theme.radius : (wo.cfg[od.key] ?? od.def))
            // saved a moment after the slider stops moving for a beat, so the desktop is not rebuilt at every pixel
            property real pending: NaN
            onMoved: v => { pending = Math.round(v); commit.restart() }
            Timer { id: commit; interval: 70; onTriggered: if (!isNaN(sr.pending)) { Widgets.set(wo.wid, sr.od.key, sr.pending); sr.pending = NaN } }
        }
    }
    // choices, a switch, a colour or a line of text
    Component {
        id: rowC
        SRow {
            id: rr
            property var od: ({})
            compact: true
            title: od.name ?? ""; icon: od.icon ?? ""
            resetHandled: true
            changed: String(wo.cfg[od.key] ?? od.def) !== String(od.def)
            onReset: Widgets.set(wo.wid, od.key, od.def)
            SChoices {
                compact: true
                visible: !!rr.od.choices
                model: rr.od.choices || []
                current: String(wo.cfg[rr.od.key] ?? "")
                onPicked: v => Widgets.set(wo.wid, rr.od.key, v)
            }
            ArqToggle {
                visible: !!rr.od.toggle
                checked: !!wo.cfg[rr.od.key]
                onToggled: v => Widgets.set(wo.wid, rr.od.key, v)
            }
            SSwatches {
                visible: !!rr.od.color
                value: String(wo.cfg[rr.od.key] ?? rr.od.def ?? "#FFFFFF")
                onPicked: hex => Widgets.set(wo.wid, rr.od.key, hex)
            }
            ArqField {
                visible: !!rr.od.text
                readonly property real naturalWidth: 170
                width: 170; implicitHeight: 32
                placeholder: "None"
                text: String(wo.cfg[rr.od.key] ?? "")
                onEdited: Widgets.set(wo.wid, rr.od.key, text)
            }
        }
    }
}
