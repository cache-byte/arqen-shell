import QtQuick
import qs.config
import qs.components

// A shortcut you set by pressing it: shows the keys; click, then press the new combination (Esc
// cancels, Backspace clears it). `keys` is "SUPER + SHIFT + S" ("" = none).
Rectangle {
    id: kr
    property string keys: ""
    signal picked(string keys)
    readonly property bool recording: cap.activeFocus
    readonly property real naturalWidth: Math.max(150, row.implicitWidth + 24)
    implicitWidth: naturalWidth
    implicitHeight: 36
    radius: 18
    color: recording ? Qt.rgba(Theme.primary.r, Theme.primary.g, Theme.primary.b, 0.14) : (ma.containsMouse ? Theme.hover : Theme.tile)
    border.width: recording ? 2 : 0
    border.color: Theme.primary

    readonly property var parts: String(keys).split("+").map(x => x.trim()).filter(x => x !== "")
    function nice(k) { return k === "SUPER" ? "Super" : k === "CTRL" ? "Ctrl" : k === "ALT" ? "Alt" : k === "SHIFT" ? "Shift" : k.length === 1 ? k.toUpperCase() : k }
    Row {
        id: row
        anchors.centerIn: parent
        spacing: 4
        visible: !kr.recording && kr.parts.length > 0
        Repeater {
            model: kr.parts
            delegate: Rectangle {
                required property string modelData
                height: 24; width: Math.max(24, kt.implicitWidth + 12); radius: 7
                color: Theme.dark ? Qt.rgba(1, 1, 1, 0.08) : Qt.rgba(0, 0, 0, 0.06)
                border.width: 1; border.color: Theme.stroke
                DText { id: kt; anchors.centerIn: parent; text: kr.nice(parent.modelData); font.pixelSize: 12; font.weight: Font.Medium }
            }
        }
    }
    DText {
        anchors.centerIn: parent
        visible: kr.recording || kr.parts.length === 0
        text: kr.recording ? "Press the keys…" : "None"
        color: kr.recording ? Theme.primary : Theme.subtext; font.pixelSize: 13
    }
    // Qt key -> Hyprland's name for it
    function keyName(e) {
        const k = e.key
        if (k >= Qt.Key_A && k <= Qt.Key_Z) return String.fromCharCode(k)
        if (k >= Qt.Key_0 && k <= Qt.Key_9) return String.fromCharCode(k)
        if (k >= Qt.Key_F1 && k <= Qt.Key_F24) return "F" + (k - Qt.Key_F1 + 1)
        const m = {}
        m[Qt.Key_Return] = "Return"; m[Qt.Key_Enter] = "KP_Enter"; m[Qt.Key_Tab] = "Tab"; m[Qt.Key_Backtab] = "Tab"
        m[Qt.Key_Delete] = "Delete"; m[Qt.Key_Insert] = "Insert"; m[Qt.Key_Home] = "Home"; m[Qt.Key_End] = "End"
        m[Qt.Key_PageUp] = "Page_Up"; m[Qt.Key_PageDown] = "Page_Down"; m[Qt.Key_Left] = "left"; m[Qt.Key_Right] = "right"
        m[Qt.Key_Up] = "up"; m[Qt.Key_Down] = "down"; m[Qt.Key_Space] = "Space"; m[Qt.Key_Print] = "Print"
        m[Qt.Key_Comma] = "comma"; m[Qt.Key_Period] = "period"; m[Qt.Key_Slash] = "slash"; m[Qt.Key_Minus] = "minus"
        m[Qt.Key_Equal] = "equal"; m[Qt.Key_Semicolon] = "semicolon"; m[Qt.Key_Apostrophe] = "apostrophe"
        m[Qt.Key_BracketLeft] = "bracketleft"; m[Qt.Key_BracketRight] = "bracketright"; m[Qt.Key_Backslash] = "backslash"; m[Qt.Key_QuoteLeft] = "grave"
        if (m[k] !== undefined) return m[k]
        return ""
    }
    Item {
        id: cap
        anchors.fill: parent
        Keys.onPressed: e => {
            e.accepted = true
            if (e.key === Qt.Key_Escape) { cap.focus = false; return }
            if (e.key === Qt.Key_Backspace && e.modifiers === Qt.NoModifier) { kr.picked(""); cap.focus = false; return }
            const n = kr.keyName(e)
            if (n === "") return                       // a modifier on its own: wait for the key
            const mods = []
            if (e.modifiers & Qt.MetaModifier) mods.push("SUPER")
            if (e.modifiers & Qt.ControlModifier) mods.push("CTRL")
            if (e.modifiers & Qt.AltModifier) mods.push("ALT")
            if (e.modifiers & Qt.ShiftModifier) mods.push("SHIFT")
            kr.picked(mods.concat([n]).join(" + "))
            cap.focus = false
        }
    }
    MouseArea { id: ma; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: cap.forceActiveFocus() }
    HoverTip { hovered: ma.containsMouse && !kr.recording; text: "Click, then press the new keys. Backspace: none" }
}
