import QtQuick
import QtQuick.Layouts
import qs.config
import qs.components

// Drag a panel's items between its left / centre / right sections, or up and down inside a
// section to change their order. A blue line shows where it will land. The x removes an item
// from this panel; the chips underneath add items that are not on it.
Rectangle {
    id: ed
    property string panelId: ""
    readonly property var pnl: Config.panel(panelId)
    readonly property var lay: Config.panelLayout(panelId)
    readonly property bool vert: pnl ? (pnl.edge === "left" || pnl.edge === "right") : false
    readonly property var names: vert ? ["Top", "Middle", "Bottom"] : ["Left", "Centre", "Right"]
    readonly property var addable: Config.unplaced(panelId)

    // drag state (coordinates are in this card's space)
    property string dragId: ""
    property real dragX: 0
    property real dragY: 0
    property int hoverSec: -1
    property int hoverIdx: 0
    property real indX: 0
    property real indY: 0
    property real indW: 0

    Layout.fillWidth: true
    implicitHeight: content.implicitHeight + 40
    radius: Math.max(0, Theme.radius - 2)
    color: Theme.card

    // the section under the pointer (sections sit side by side, or stacked in a narrow window)
    function secAt(x, y) {
        for (let i = 0; i < secRep.count; i++) {
            const s = secRep.itemAt(i)
            if (!s) continue
            const p = s.mapToItem(ed, 0, 0)
            if (x >= p.x - 6 && x <= p.x + s.width + 6 && y >= p.y - 6 && y <= p.y + s.height + 6) return i
        }
        return -1
    }
    function chipY(sec, id) {   // centre y (in ed space) of a chip, or -1
        const c = sec.chipRepeater.itemAt(sec.items.indexOf(id))
        return c ? c.mapToItem(ed, 0, 0).y : -1
    }
    function chipH(sec, id) {
        const c = sec.chipRepeater.itemAt(sec.items.indexOf(id))
        return c ? c.height : 0
    }
    function updateHover() {
        const i = secAt(dragX, dragY)
        hoverSec = i
        if (i < 0) return
        const s = secRep.itemAt(i)
        if (!s) return
        const items = s.items.filter(x => x !== dragId)
        let idx = 0
        for (const id of items) {
            const y = chipY(s, id)
            if (y >= 0 && y + chipH(s, id) / 2 < dragY) idx++
        }
        hoverIdx = idx
        const sp = s.mapToItem(ed, 0, 0)
        indX = sp.x + 10
        indW = s.width - 20
        if (items.length === 0) indY = sp.y + 40
        else if (idx < items.length) indY = chipY(s, items[idx]) - 4
        else indY = chipY(s, items[items.length - 1]) + chipH(s, items[items.length - 1]) + 2
    }
    function finishDrag() {
        const id = dragId, i = hoverSec, idx = hoverIdx
        dragId = ""; hoverSec = -1
        const pid = panelId
        if (id !== "" && i >= 0) Qt.callLater(() => Config.placeElement(pid, id, Config.barSections[i], idx))
    }
    function cancelDrag() { dragId = ""; hoverSec = -1 }

    ColumnLayout {
        id: content
        anchors { fill: parent; margins: 20 }
        spacing: 14

        RowLayout {
            Layout.fillWidth: true
            DText { Layout.fillWidth: true; wrapMode: Text.WordWrap; color: Theme.subtext; font.pixelSize: 12
                text: "Drag an item into another section, or up and down to change its order. The x takes it off this panel." }
            ArqButton { text: "Reset"; onClicked: { ed.cancelDrag(); Config.resetLayout(ed.panelId) } }
        }

        GridLayout {
            Layout.fillWidth: true
            columns: ed.width >= 560 ? 3 : 1
            columnSpacing: 12; rowSpacing: 12
            Repeater {
                id: secRep
                model: Config.barSections
                delegate: Rectangle {
                    id: sec
                    required property string modelData
                    required property int index
                    readonly property var items: ed.lay[modelData] ?? []
                    readonly property var chipRepeater: chipRep
                    Layout.fillWidth: true
                    Layout.preferredWidth: 1
                    Layout.alignment: Qt.AlignTop
                    implicitHeight: Math.max(secCol.implicitHeight + 24, 90)
                    radius: 18
                    color: ed.hoverSec === sec.index ? Theme.tileOn : Theme.tile
                    Behavior on color { ColorAnimation { duration: 100 } }

                    ColumnLayout {
                        id: secCol
                        anchors { left: parent.left; right: parent.right; top: parent.top; margins: 12 }
                        spacing: 6
                        DText { text: ed.names[sec.index]; color: Theme.subtext; font.pixelSize: 12; font.weight: Font.Medium; leftPadding: 2 }
                        Repeater {
                            id: chipRep
                            model: sec.items
                            delegate: Rectangle {
                                id: chip
                                required property string modelData
                                readonly property var info: Config.elementInfo(modelData)
                                Layout.fillWidth: true
                                implicitHeight: 44; radius: 14
                                opacity: ed.dragId === modelData ? 0.3 : 1
                                color: cma.containsMouse ? Theme.hover : Theme.card
                                Row {
                                    anchors { verticalCenter: parent.verticalCenter; left: parent.left; leftMargin: 10 }
                                    spacing: 8
                                    Icon { name: "drag_indicator"; size: 18; color: Theme.subtext; anchors.verticalCenter: parent.verticalCenter }
                                    Icon { name: chip.info.icon; size: 18; anchors.verticalCenter: parent.verticalCenter }
                                    DText { text: chip.info.name; font.pixelSize: 13; width: chip.width - 110; elide: Text.ElideRight; anchors.verticalCenter: parent.verticalCenter }
                                }
                                MouseArea {
                                    id: cma
                                    anchors.fill: parent; hoverEnabled: true
                                    preventStealing: true
                                    cursorShape: pressed ? Qt.ClosedHandCursor : Qt.OpenHandCursor
                                    property bool dragging: false
                                    property real sx: 0
                                    property real sy: 0
                                    onPressed: mouse => { sx = mouse.x; sy = mouse.y; dragging = false }
                                    onPositionChanged: mouse => {
                                        if (!pressed) return
                                        if (!dragging && Math.abs(mouse.x - sx) + Math.abs(mouse.y - sy) > 8) {
                                            dragging = true
                                            ed.dragId = chip.modelData
                                        }
                                        if (dragging) {
                                            const p = cma.mapToItem(ed, mouse.x, mouse.y)
                                            ed.dragX = p.x; ed.dragY = p.y
                                            ed.updateHover()
                                        }
                                    }
                                    onReleased: { if (dragging) { dragging = false; ed.finishDrag() } }
                                    onCanceled: { dragging = false; ed.cancelDrag() }
                                }
                                Rectangle {   // remove from this panel
                                    anchors { right: parent.right; rightMargin: 8; verticalCenter: parent.verticalCenter }
                                    width: 26; height: 26; radius: 13
                                    color: rmMa.containsMouse ? "#E5484D" : "transparent"
                                    Icon { anchors.centerIn: parent; name: "close"; size: 16; color: rmMa.containsMouse ? "white" : Theme.subtext }
                                    MouseArea {
                                        id: rmMa; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor
                                        onClicked: { const pid = ed.panelId, id = chip.modelData; Qt.callLater(() => Config.removeElement(pid, id)) }
                                    }
                                }
                            }
                        }
                        DText { visible: sec.items.length === 0; text: "Drop items here"; color: Theme.subtext; font.pixelSize: 12; leftPadding: 2; bottomPadding: 4 }
                    }
                }
            }
        }

        // items that are not on this panel
        DText { visible: ed.addable.length > 0; text: "Add to this panel"; color: Theme.subtext; font.pixelSize: 12 }
        Flow {
            visible: ed.addable.length > 0
            Layout.fillWidth: true
            spacing: 8
            Repeater {
                model: ed.addable
                delegate: Rectangle {
                    id: ach
                    required property var modelData
                    height: 38; width: achRow.implicitWidth + 26; radius: 19
                    color: achMa.containsMouse ? Theme.hover : Theme.tile
                    Row {
                        id: achRow; anchors.centerIn: parent; spacing: 8
                        Icon { name: "add"; size: 18; color: Theme.accent; anchors.verticalCenter: parent.verticalCenter }
                        Icon { name: ach.modelData.icon; size: 18; anchors.verticalCenter: parent.verticalCenter }
                        DText { text: ach.modelData.name; font.pixelSize: 13; anchors.verticalCenter: parent.verticalCenter }
                    }
                    MouseArea { id: achMa; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor
                        onClicked: Config.addElement(ed.panelId, ach.modelData.id) }
                }
            }
        }
    }

    // where the dragged item will land
    Rectangle {
        visible: ed.dragId !== "" && ed.hoverSec >= 0
        x: ed.indX; y: ed.indY; width: ed.indW; height: 3; radius: 2
        color: Theme.accent
        z: 20
    }

    // the item following the pointer
    Rectangle {
        visible: ed.dragId !== ""
        readonly property var info: Config.elementInfo(ed.dragId)
        width: 190; height: 44; radius: 14
        x: ed.dragX - width / 2; y: ed.dragY - height / 2
        color: Theme.cardSolid
        border.width: 2; border.color: Theme.accent
        z: 30
        Row {
            anchors { verticalCenter: parent.verticalCenter; left: parent.left; leftMargin: 12 }
            spacing: 8
            Icon { name: parent.parent.info.icon; size: 18; anchors.verticalCenter: parent.verticalCenter }
            DText { text: parent.parent.info.name; font.pixelSize: 13; anchors.verticalCenter: parent.verticalCenter }
        }
    }
}
