import QtQuick
import qs.config
import qs.components

// Chips to pick one value from. They wrap onto more lines when the row is too narrow
// (SRow sets maxWidth). Sizes follow the button guide: 32 high, 14 px text, 16 padding (compact: 26, 12 px, 10).
Item {
    id: c
    property var model: []
    property string current: ""
    property real maxWidth: 100000
    property bool compact: false
    signal picked(string v)
    readonly property real naturalWidth: meas.implicitWidth
    implicitWidth: Math.min(naturalWidth, maxWidth)
    implicitHeight: flow.implicitHeight
    width: implicitWidth
    height: implicitHeight

    // measures the chips on one line
    Row {
        id: meas
        visible: false
        spacing: c.compact ? 4 : 8
        Repeater {
            model: c.model
            delegate: Item {
                required property string modelData
                width: mtx.implicitWidth + (c.compact ? 16 : Sizes.padS * 2); height: c.compact ? 24 : Sizes.hS
                DText { id: mtx; text: parent.modelData; font.pixelSize: c.compact ? 12 : Sizes.textS }
            }
        }
    }
    Flow {
        id: flow
        width: c.width
        spacing: c.compact ? 4 : 8
        Repeater {
            model: c.model
            delegate: Rectangle {
                required property string modelData
                height: c.compact ? 24 : Sizes.hS; width: tx.implicitWidth + (c.compact ? 16 : Sizes.padS * 2); radius: height / 2
                color: modelData === c.current ? Theme.pillOn : (chMa.containsMouse ? Theme.hover : Theme.tile)
                Behavior on color { ColorAnimation { duration: 140 } }
                scale: chMa.pressed ? 0.93 : (chMa.containsMouse ? 1.04 : 1)
                Behavior on scale { NumberAnimation { duration: 260; easing.type: Easing.OutBack; easing.overshoot: Motion.os(2.5) } }
                DText { id: tx; anchors.centerIn: parent; text: parent.modelData; font.pixelSize: c.compact ? 12 : Sizes.textS; color: parent.modelData === c.current ? Theme.pillOnText : Theme.text }
                MouseArea { id: chMa; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: c.picked(parent.modelData) }
            }
        }
    }
}
