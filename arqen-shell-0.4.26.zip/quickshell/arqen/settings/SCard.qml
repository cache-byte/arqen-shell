import QtQuick
import QtQuick.Layouts
import qs.config

// A card for content that is not a list of rows (pickers, previews, editors).
// Same corners and colour as SGroup; children go in a padded column.
Rectangle {
    default property alias content: col.data
    property alias spacing: col.spacing
    Layout.fillWidth: true
    implicitHeight: col.implicitHeight + 40
    radius: Math.max(0, Theme.radius - 2)
    color: Theme.card
    ColumnLayout {
        id: col
        anchors { left: parent.left; right: parent.right; top: parent.top; margins: 20 }
        spacing: 12
    }
}
