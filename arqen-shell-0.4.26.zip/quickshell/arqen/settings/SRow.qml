import QtQuick
import QtQuick.Layouts
import qs.config
import Quickshell.Widgets
import qs.components

// One settings row: icon, title and subtitle, and its controls (toggle, slider, buttons...).
// Wide window: controls on the right. Narrow window (or wide controls): they move under the text
// and get the full width, so nothing is squeezed or overlaps.
// Controls that can wrap (SChoices) or stretch (sliders) read `maxWidth` / the row's `trailingMax`.
Item {
    id: r
    property string title: ""
    property string subtitle: ""
    property string icon: ""
    property url iconImage2: ""            // tried when iconImage does not load
    property url iconImage: ""             // a real logo loaded from the web; the icon shows until it is there (or when offline)
    property color iconColor: Theme.tile            // neutral; set a colour only to flag something (an error)
    // the icon on it: readable on whatever colour the circle is
    readonly property color iconFg: Qt.colorEqual(iconColor, Theme.secondaryContainer) ? Theme.onSecondaryContainer
                                  : Qt.colorEqual(iconColor, Theme.primary) ? Theme.onPrimary
                                  : iconColor.a < 0.5 ? Theme.text : "white"
    default property alias trailing: tr.data
    signal clicked()
    // Reset arrow: give `key` (one setting name, or several "a,b") and it shows while the setting
    // differs from its default; or set `changed` yourself and handle `reset()`.
    property string key: ""
    property bool compact: false           // tighter: smaller icon, text and spacing (the widget editor)
    property bool changed: key !== "" && !Config.isDefault(key)
    readonly property bool resettable: key !== "" || resetHandled
    property bool resetHandled: false       // set by rows that handle reset() themselves
    signal reset()
    onReset: if (key !== "") Config.resetKeys(key)
    Layout.fillWidth: true

    readonly property real pad: compact ? 8 : 16
    readonly property real iconD: compact ? 24 : 40
    readonly property real lm: compact ? 8 : 16
    readonly property real rm: compact ? 8 : 16
    readonly property real minText: compact ? 110 : 170
    readonly property real textX: icon !== "" ? lm + iconD + (compact ? 8 : 16) : lm
    // width the controls want when they are not squeezed
    readonly property real naturalTrailing: {
        let w = 0, n = 0
        for (let i = 0; i < tr.children.length; i++) {
            const c = tr.children[i]
            if (!c.visible) continue
            w += (c.naturalWidth !== undefined ? c.naturalWidth : c.implicitWidth > 0 ? c.implicitWidth : c.width)
            n++
        }
        return w + Math.max(0, n - 1) * tr.spacing + (resettable ? Sizes.hS + trOuter.spacing : 0)
    }
    // under the text when the title would get less than ~170 px next to the controls
    readonly property bool stacked: naturalTrailing > 0 && width > 0 && (width - textX - rm - naturalTrailing - 14) < minText
    // room the controls can use
    readonly property real resetW: resettable ? Sizes.hS + trOuter.spacing : 0   // the reset button keeps its place while hidden
    readonly property real trailingMax: stacked ? Math.max(0, width - textX - rm - resetW) : Math.max(0, width - textX - rm - minText - 14 - resetW)

    implicitHeight: stacked
        ? pad + Math.max(iconD, textCol.implicitHeight) + (compact ? 5 : 10) + trOuter.height + (compact ? 9 : 16)
        : (compact ? Math.max(subtitle !== "" ? 46 : 40, textCol.implicitHeight + 14, trOuter.height + 12)
                   : Math.max(subtitle !== "" ? 72 : 60, textCol.implicitHeight + 24, trOuter.height + 20))

    // tell controls that can shrink how much room they have
    function applyMax() {
        for (let i = 0; i < tr.children.length; i++) {
            const c = tr.children[i]
            if (c.maxWidth !== undefined) c.maxWidth = trailingMax
        }
    }
    onTrailingMaxChanged: applyMax()
    Component.onCompleted: applyMax()
    Connections { target: tr; function onChildrenChanged() { r.applyMax() } }

    MouseArea { anchors.fill: parent; onClicked: r.clicked() }

    Rectangle {
        visible: r.icon !== ""
        x: r.lm
        y: r.stacked ? r.pad : (r.height - height) / 2
        width: r.iconD; height: r.iconD; radius: r.iconD / 2; color: r.iconColor
        Icon { visible: !logo.ready; anchors.centerIn: parent; name: r.icon; size: r.compact ? 15 : 20; color: r.iconFg }
        // a logo fills the whole round badge and is cut to it (square avatars no longer poke out with hard corners)
        ClippingRectangle {
            visible: logo.ready; anchors.fill: parent; radius: width / 2; color: "white"
            border.width: 1; border.color: Qt.rgba(0, 0, 0, 0.08)
            Image {
                id: logo
                readonly property bool ready: status === Image.Ready && r.iconImage.toString() !== ""
                property bool alt: false
                anchors.fill: parent; anchors.margins: 1
                source: alt ? r.iconImage2 : r.iconImage; asynchronous: true; cache: true; fillMode: Image.PreserveAspectCrop; smooth: true; mipmap: true
                onStatusChanged: if (status === Image.Error && !alt && r.iconImage2.toString() !== "") alt = true
                sourceSize: Qt.size(160, 160)
            }
        }
    }
    Column {
        id: textCol
        x: r.textX
        width: r.stacked ? r.width - r.textX - r.rm : Math.max(60, r.width - r.textX - r.rm - trOuter.width - 14)
        y: r.stacked ? r.pad + Math.max(0, (r.iconD - implicitHeight) / 2) : (r.height - implicitHeight) / 2
        spacing: 1
        DText { width: parent.width; text: r.title; font.pixelSize: r.compact ? 13 : 15; elide: Text.ElideRight }
        DText {
            visible: r.subtitle !== ""
            width: parent.width
            text: r.subtitle; font.pixelSize: r.compact ? 11 : 12; color: Theme.subtext
            wrapMode: Text.WordWrap; maximumLineCount: 3; elide: Text.ElideRight
        }
    }
    Row {
        id: trOuter
        spacing: 8
        x: r.stacked ? r.textX : r.width - r.rm - width
        y: r.stacked ? r.pad + Math.max(r.iconD, textCol.implicitHeight) + (r.compact ? 5 : 10) : (r.height - height) / 2
        // back to the default (its place is kept while hidden, so the controls do not jump)
        Rectangle {
            visible: r.resettable
            width: Sizes.hS; height: Sizes.hS; radius: Sizes.hS / 2
            anchors.verticalCenter: parent.verticalCenter
            color: rma.containsMouse && r.changed ? Theme.hover : "transparent"
            opacity: r.changed ? 1 : 0
            Behavior on opacity { NumberAnimation { duration: 120 } }
            Icon { anchors.centerIn: parent; name: "restart_alt"; size: Sizes.iconM; color: Theme.subtext }
            MouseArea { id: rma; anchors.fill: parent; enabled: r.changed; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: r.reset() }
            HoverTip { hovered: rma.containsMouse && r.changed; text: "Back to the default" }
        }
        Row {
            id: tr
            spacing: 10
            anchors.verticalCenter: parent.verticalCenter
        }
    }
    Rectangle { anchors { bottom: parent.bottom; left: parent.left; right: parent.right; leftMargin: r.lm; rightMargin: r.rm } height: 1; color: Theme.divider }
}
