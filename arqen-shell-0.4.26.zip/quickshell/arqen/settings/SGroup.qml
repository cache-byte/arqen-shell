import QtQuick
import QtQuick.Layouts
import qs.config

Rectangle {
    default property alias rows: col.data
    Layout.fillWidth: true
    implicitHeight: col.implicitHeight
    radius: Math.max(0, Theme.radius - 2)
    color: Theme.card
    ColumnLayout { id: col; width: parent.width; spacing: 0 }
}
