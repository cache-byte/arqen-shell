pragma Singleton
import Quickshell
import QtQuick

// How springy the shell's animations are (Settings > Display > Motion > Bounce). Every "overshoot" in the shell goes
// through here: Motion.os(1.5) is an overshoot of 1.5 at the default setting, scaled by the slider (0 % = no overshoot,
// 200 % = twice as much). With animations off nothing overshoots.
Singleton {
    id: root
    readonly property real k: Config.c.animations ? Math.max(0, Math.min(2.5, (Config.c.bounce ?? 120) / 100)) : 0
    function os(base) { return base * k }
}
