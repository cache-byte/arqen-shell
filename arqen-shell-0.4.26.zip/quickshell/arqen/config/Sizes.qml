pragma Singleton
import Quickshell
import QtQuick

// The shell's size grid (4 px base; named Sizes because Grid is a QtQuick type). Buttons, fields, chips, rows and icons snap to these three sizes:
//   S: 32 high, 14 px text, 16 side padding   (icon + text: 12 | icon 16 | 4 | text | 16)
//   M: 44 high, 16 px text, 24 side padding   (icon + text: 20 | icon 20 | 8 | text | 24)
//   L: 52 high, 16 px text, 32 side padding   (icon + text: 24 | icon 24 | 8 | text | 32)
Singleton {
    readonly property int unit: 4
    readonly property int hS: 32
    readonly property int hM: 44
    readonly property int hL: 52
    readonly property int textS: 14
    readonly property int textM: 16
    readonly property int textL: 16
    readonly property int padS: 16
    readonly property int padM: 24
    readonly property int padL: 32
    readonly property int iconS: 16
    readonly property int iconM: 20
    readonly property int iconL: 24
    readonly property int gapS: 4
    readonly property int gapM: 8
    readonly property int gapL: 8
    function snap(v) { return Math.round(v / unit) * unit }
}
