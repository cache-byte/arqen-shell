pragma Singleton
import Quickshell
import QtQuick

Singleton {
    id: root
    readonly property bool dark: Config.c.darkMode
    // ---- colour roles from the accent colour (the "seed") ----
    // primary: the accent itself, toned for dark / light (switches, sliders, main buttons, checks)
    // secondary: the same hue, much calmer (selected chips, the workspace pill, highlighted rows)
    // tertiary: a neighbouring hue for contrast (avatars, today in calendars, app badges)
    // *Container: a soft background in that colour; on*: text / icons drawn on top of it
    // the accent colour (changes at once: everything drawn in it follows in the same frame)
    readonly property color seed: Config.c.accent
    readonly property real hue: seed.hslHue < 0 ? 0.6 : seed.hslHue
    // vivid: even a dull accent gets enough colour to read as one
    readonly property real sat: Math.min(1, Math.max(0.62, seed.hslSaturation * 1.1))
    function role(h, s, toneDark, toneLight) { return Qt.hsla(((h % 1) + 1) % 1, Math.min(1, s), dark ? toneDark : toneLight, 1) }
    readonly property color primary: role(hue, sat, 0.70, 0.44)
    readonly property color onPrimary: role(hue, sat, 0.14, 0.99)
    readonly property color primaryContainer: role(hue, sat * 0.75, 0.30, 0.86)
    readonly property color onPrimaryContainer: role(hue, sat, 0.90, 0.14)
    // secondary and tertiary: your own colours when picked (Settings > Appearance > Accent colour),
    // otherwise made from the accent
    readonly property bool own2: !Config.c.accentFromWallpaper && /^#[0-9a-fA-F]{6}$/.test(Config.c.accent2 || "")
    readonly property bool own3: !Config.c.accentFromWallpaper && /^#[0-9a-fA-F]{6}$/.test(Config.c.accent3 || "")
    readonly property color seed2: own2 ? Config.c.accent2 : seed
    readonly property color seed3: own3 ? Config.c.accent3 : seed
    readonly property real hue2: own2 ? (seed2.hslHue < 0 ? hue : seed2.hslHue) : hue + 0.04
    readonly property real sat2: own2 ? Math.min(1, Math.max(0.45, seed2.hslSaturation)) : sat * 0.55
    readonly property real hue3: own3 ? (seed3.hslHue < 0 ? hue : seed3.hslHue) : hue + 0.17
    readonly property real sat3: own3 ? Math.min(1, Math.max(0.5, seed3.hslSaturation * 1.05)) : sat * 0.85
    readonly property color secondary: role(hue2, sat2, 0.74, 0.40)
    readonly property color onSecondary: role(hue2, sat2, 0.15, 0.99)
    readonly property color secondaryContainer: role(hue2, sat2 * 0.82, 0.26, 0.86)
    readonly property color onSecondaryContainer: role(hue2, sat2, 0.90, 0.13)
    readonly property color tertiary: role(hue3, sat3, 0.74, 0.42)
    readonly property color onTertiary: role(hue3, sat3, 0.14, 0.99)
    readonly property color tertiaryContainer: role(hue3, sat3 * 0.76, 0.30, 0.86)
    readonly property color onTertiaryContainer: role(hue3, sat3, 0.90, 0.14)
    // control centre tiles that are on.
    // Dark mode: the tile in primary, its icon badge and text in a deep secondary.
    // Light mode the other way round: a soft secondary tile, the badge and text in primary.
    readonly property color ccOn: dark ? primary : role(hue2, sat2 * 0.9, 0.82, 0.82)
    readonly property color ccBadge: dark ? role(hue2, Math.min(1, sat2 * 1.1), 0.17, 0.17) : primary
    readonly property color ccBadgeIcon: dark ? primary : onPrimary
    readonly property color ccOnText: dark ? role(hue2, Math.min(1, sat2 * 1.27), 0.15, 0.15) : Qt.hsla(hue, sat, 0.26, 1)
    // older name, used all over: the primary role
    readonly property color accent: primary
    readonly property string font: Config.c.fontFamily
    readonly property int radius: Config.c.radius

    readonly property color text: dark ? "#FFFFFF" : "#111114"
    readonly property color subtext: dark ? "#A7A7B0" : "#5F5F68"
    // ONE see-through surface for the whole shell: panels, the control centre, the launcher, search,
    // menus, popups, toasts and the Settings window all use exactly this colour, so Transparency
    // (Settings > Appearance > Effects) looks the same everywhere, and Blur shows the same behind it.
    readonly property color glassBase: dark ? "#111115" : "#F2F2F6"
    readonly property color glass: Qt.rgba(glassBase.r, glassBase.g, glassBase.b, Config.c.opacity)
    readonly property color bar: glass
    readonly property color panel: glass
    // cards and tiles on the glass: a light veil, so they stay see-through with it
    readonly property color card: dark ? Qt.rgba(1, 1, 1, 0.065) : Qt.rgba(1, 1, 1, 0.62)
    // something that floats over other content (a menu over the tiles) must hide what is under it
    readonly property color cardSolid: dark ? "#1E1E24" : "#FFFFFF"
    readonly property color window: dark ? "#0B0B0D" : "#F1F1F5"
    readonly property color windowBg: glass
    readonly property color tile: dark ? Qt.rgba(1, 1, 1, 0.08) : Qt.rgba(0, 0, 0, 0.06)
    readonly property color tileOn: secondaryContainer
    readonly property color stroke: dark ? Qt.rgba(1, 1, 1, 0.08) : Qt.rgba(0, 0, 0, 0.08)
    readonly property color divider: dark ? Qt.rgba(1, 1, 1, 0.07) : Qt.rgba(0, 0, 0, 0.07)
    // a selected chip or choice
    // in the primary colour with its own text colour, so the choice stands out and stays readable
    readonly property color pillOn: primary
    readonly property color pillOnText: onPrimary
    // the Settings navigation bar: always a dark pill, a touch lighter than the dark window
    readonly property color navBar: dark ? "#1E1E26" : "#E6E6EE"
    readonly property color navIcon: dark ? "#8C8C98" : "#5A5A68"
    readonly property color navPill: dark ? "#FFFFFF" : "#1E1E26"          // the open page in the settings navigation
    readonly property color navPillText: dark ? "#111114" : "#FFFFFF"
    readonly property color hover: dark ? Qt.rgba(1, 1, 1, 0.10) : Qt.rgba(0, 0, 0, 0.07)
}
