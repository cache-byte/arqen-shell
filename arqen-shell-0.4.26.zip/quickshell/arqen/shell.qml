import QtQuick
import Quickshell
import Quickshell.Io
import qs.config
import qs.modules
import qs.settings
import qs.services

ShellRoot {
    // the clipboard watchers must run even before the clipboard popup is opened
    Component.onCompleted: { Clipboard.init(); Appearance.init(); Sounds.init(); Power.init(); Errors.init(); Monitors.refresh(); Idle.init(); Rgb.init(); Updater.init(); Gadgets.init(); Clocks.init() }

    Wallpaper {}
    Desktop {}
    Panels {}
    PanelEditor {}
    Launcher {}
    SearchPopup {}
    Sidebar {}
    ClipboardPopup {}
    ClockPopup {}
    RingAlert {}
    TrayMenu {}
    OverviewScreen {}
    Toast {}
    OsdPopup {}
    CaptureOverlay {}
    RecordFrame {}
    ScreenCorners {}
    Keyboard {}
    EdgeDock {}
    PowerCountdown {}
    DisplayConfirm {}
    UpdatePrompt {}
    CaptureAfter {}
    WindowHandle {}
    PowerMenu {}
    // password prompt for admin actions (polkit). Loaded separately: a Quickshell built without
    // polkit support then only loses this, not the whole shell.
    Loader { source: Qt.resolvedUrl("modules/PolkitPrompt.qml") }
    // the lock screen: also through a Loader (a Quickshell without its lock / PAM parts only loses this)
    Loader { source: Qt.resolvedUrl("modules/LockScreen.qml") }
    SettingsWindow {}
    CheatSheet {}
    DrawOverlay {}

    // qs -c arqen ipc call arqen toggle|open launcher|search|quick|notifs|clipboard|overview
    IpcHandler {
        id: ipc
        target: "arqen"
        function toggle(name: string): void { if (name === "capture") Ui.startCapture(); else if (name === "keyboard") Osk.toggle(); else if (name === "draw") Ui.toggleDraw(); else Ui.toggle(name) }
        function open(name: string): void { if (Ui.open !== name) { if (name === "capture") Ui.startCapture(); else Ui.toggle(name) } }
        function close(): void { Ui.close() }
        function minimize(): void { if (!EdgeTuck.tuckActive()) Windows.minimizeActive() }
        function lock(): void { Ui.lock() }
        function restoreAll(): void { Windows.restoreAll() }
        function settings(page: string): void { Ui.openSettings(page) }
        function settingsApp(): void { Ui.openSettings("") }
        function cheatsheet(): void { Ui.cheatOpen = !Ui.cheatOpen }
        // start an app by its desktop-file id (keyboard shortcuts made in Settings use this)
        // volume / brightness / keyboard light / media / lock keys (bound by Arqen in Hyprland)
        function key(name: string): void { Osd.key(name) }
        function launch(id: string): void { const e = Apps.byId(id); if (e) Ui.launch(e) }
    }

    // The fast way in (scripts/ipc writes "toggle launcher" etc. to a pipe; this reads it)
    Process {
        id: listen
        running: true
        command: ["sh", Quickshell.shellDir + "/scripts/ipc-listen.sh"]
        stdout: SplitParser {
            onRead: line => {
                const w = String(line).trim().split(/\s+/)
                const f = w[0], arg = w.slice(1).join(" ")
                if (["toggle", "open", "key", "launch", "settings"].indexOf(f) >= 0) ipc[f](arg)
                else if (["close", "minimize", "restoreAll", "settingsApp", "lock"].indexOf(f) >= 0) ipc[f]()
            }
        }
        onExited: relisten.restart()
    }
    Timer { id: relisten; interval: 1000; onTriggered: listen.running = true }
}
