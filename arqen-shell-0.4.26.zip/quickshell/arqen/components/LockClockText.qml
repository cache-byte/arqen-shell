import QtQuick
import QtQuick.Effects

// The big time on the lock / login screen, in the style set in Settings > Lock screen: plain, tall and narrow (a
// phone's), stacked or small; in one colour, or fading from one colour to another from top to bottom.
Item {
    id: ct
    property var cfg: ({})
    property color accent: "#7AA2FF"
    property string family: ""
    property date date: new Date()
    property real u: 1                      // a thousandth of the screen's height
    property bool h24: true

    readonly property string style: ["big", "tall", "stacked", "small"].indexOf(cfg.lockClockStyle) >= 0 ? cfg.lockClockStyle : "big"
    readonly property real k: Math.max(0.5, Math.min(1.6, (cfg.lockClockSize || 100) / 100))
    readonly property string mode: cfg.lockClockColor === "white" || cfg.lockClockColor === "custom" || cfg.lockClockColor === "gradient" ? cfg.lockClockColor : "accent"
    property bool light: false
    readonly property color colTop: mode === "white" ? (light ? "#1B1B20" : "white") : mode === "custom" || mode === "gradient"
        ? (/^#[0-9a-fA-F]{6}$/.test(cfg.lockClockCustom || "") ? cfg.lockClockCustom : "#F5E6D3") : accent
    readonly property color colBottom: mode === "gradient"
        ? (/^#[0-9a-fA-F]{6}$/.test(cfg.lockClockCustom2 || "") ? cfg.lockClockCustom2 : accent) : colTop

    // the text's own scaling: tall = narrow digits
    readonly property real xs: style === "tall" ? 0.52 : 1
    readonly property real px: Math.max(10, Math.round((style === "small" ? 120 : style === "stacked" ? 210 : style === "tall" ? 440 : 250) * u * k))
    // the hour is worked out by hand: 24-hour "15", 12-hour "3" ("03" when stacked)
    function two(n) { return n < 10 ? "0" + n : String(n) }
    function hourOf(pad) { const h = date.getHours(); const v = h24 ? h : (h % 12 === 0 ? 12 : h % 12); return pad || h24 ? two(v) : String(v) }
    readonly property string txt: style === "stacked"
        ? hourOf(true) + "\n" + two(date.getMinutes())
        : hourOf(false) + ":" + two(date.getMinutes())

    implicitWidth: label.implicitWidth * xs
    implicitHeight: label.implicitHeight * (style === "stacked" ? 0.82 : 1) * (style === "tall" ? 0.86 : 1)
    width: implicitWidth; height: implicitHeight

    // the shape of the digits (a mask when the colour fades, else just the text)
    Item {
        id: holder
        anchors.fill: parent
        visible: ct.mode !== "gradient"
        Text {
            id: label
            x: 0; y: ct.style === "tall" ? -label.implicitHeight * 0.07 : 0
            width: implicitWidth
            renderType: Text.QtRendering
            horizontalAlignment: Text.AlignHCenter
            text: ct.txt
            color: ct.colTop
            lineHeight: 0.82
            font.family: ct.family
            font.pixelSize: ct.px
            font.weight: ct.style === "small" ? Font.Medium : ct.style === "tall" ? Font.Bold : Font.DemiBold
            font.letterSpacing: ct.style === "tall" ? 0 : -4 * ct.u
            transform: Scale { xScale: ct.xs; yScale: 1 }
        }
    }
    // the fading colour: the digits drawn on a canvas with a gradient fill (a mask effect left the
    // digits plain on some setups)
    Canvas {
        id: grad
        anchors.fill: parent
        visible: ct.mode === "gradient"
        antialiasing: true
        renderTarget: Canvas.Image
        renderStrategy: Canvas.Immediate
        function css(c) { return "rgba(" + Math.round(c.r * 255) + "," + Math.round(c.g * 255) + "," + Math.round(c.b * 255) + "," + c.a + ")" }
        Connections {
            target: ct
            function onTxtChanged() { grad.requestPaint() }
            function onColTopChanged() { grad.requestPaint() }
            function onColBottomChanged() { grad.requestPaint() }
            function onPxChanged() { grad.requestPaint() }
            function onStyleChanged() { grad.requestPaint() }
            function onFamilyChanged() { grad.requestPaint() }
            function onModeChanged() { grad.requestPaint() }
            function onWidthChanged() { grad.requestPaint() }
            function onHeightChanged() { grad.requestPaint() }
        }
        Component.onCompleted: requestPaint()
        onAvailableChanged: if (available) requestPaint()
        onVisibleChanged: if (visible) requestPaint()
        onPaint: {
            const ctx = getContext("2d")
            ctx.reset()
            if (ct.mode !== "gradient" || width <= 0 || height <= 0) return
            const g = ctx.createLinearGradient(0, height * 0.15, 0, height * 0.95)
            g.addColorStop(0, css(ct.colTop))
            g.addColorStop(1, css(ct.colBottom))
            ctx.fillStyle = g
            const w = ct.style === "tall" ? 700 : ct.style === "small" ? 500 : 600
            ctx.font = w + " " + ct.px + "px \"" + ct.family + "\""
            ctx.textAlign = "center"
            ctx.textBaseline = "middle"
            ctx.save()
            ctx.scale(ct.xs, 1)
            const lines = ct.txt.split("\n")
            const pitch = label.implicitHeight / lines.length
            const cx = label.implicitWidth / 2
            const top = ct.style === "tall" ? -label.implicitHeight * 0.07 : 0
            for (let i = 0; i < lines.length; i++) ctx.fillText(lines[i], cx, top + pitch * (i + 0.5))
            ctx.restore()
        }
    }
}
