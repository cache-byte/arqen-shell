import QtQuick

// A soft shadow around a card (a widget on the desktop): rings that fade out, a little more below than above.
// Drawn outside the card only, so a see-through card does not get a dark patch behind it. Put it as a child of the
// card (z: -1); `strength` 0 = no shadow.
Item {
    id: sh
    property real strength: 0
    property real cardRadius: 20
    anchors.fill: parent
    visible: strength > 0
    Repeater {
        model: sh.visible ? 12 : 0
        delegate: Rectangle {
            required property int index
            readonly property real d: index + 1
            anchors {
                fill: parent
                leftMargin: -d; rightMargin: -d
                topMargin: -d * 0.55; bottomMargin: -d * 1.7
            }
            radius: sh.cardRadius + d
            color: "transparent"
            border.width: 1.5
            border.color: Qt.rgba(0, 0, 0, sh.strength * 0.5 * Math.pow(1 - index / 12, 2.2))
        }
    }
}
