import QtQuick
import qs.config

// A button, sized by the standard button guide:
//   size "S": 32 high, 14 px text, 16 padding each side   (icon + text: 12 | icon 16 | 4 | text | 16)
//   size "M": 44 high, 16 px text, 24 padding             (icon + text: 20 | icon 20 | 8 | text | 24)
//   size "L": 52 high, 16 px text, 32 padding             (icon + text: 24 | icon 24 | 8 | text | 32)
// An icon on its own (no text) is a square of the same height with the icon 16 / 20 / 24 px.
Rectangle {
    id: b
    property string text: ""
    property string icon: ""
    property string size: "S"
    property bool primary: false
    signal clicked()
    readonly property int idx: size === "L" ? 2 : size === "M" ? 1 : 0
    readonly property int hgt: [32, 44, 52][idx]
    readonly property int fontPx: [14, 16, 16][idx]
    readonly property int padX: [16, 24, 32][idx]
    readonly property int padIcon: [12, 20, 24][idx]          // left padding when there is an icon before the text
    readonly property int icPx: [16, 20, 24][idx]
    readonly property int gap: [4, 8, 8][idx]
    readonly property bool hasIcon: icon !== ""
    readonly property bool hasText: text !== ""
    implicitHeight: hgt
    implicitWidth: !hasText ? hgt : (hasIcon ? padIcon + icPx + gap + label.implicitWidth + padX : label.implicitWidth + 2 * padX)
    radius: height / 2
    color: primary ? Theme.accent : (ma.containsMouse ? Theme.hover : Theme.tile)
    Behavior on color { ColorAnimation { duration: 120 } }
    // squashes when pressed, grows a little under the pointer, and springs back
    scale: ma.pressed ? 0.93 : (ma.containsMouse ? 1.03 : 1)
    Behavior on scale { NumberAnimation { duration: 260; easing.type: Easing.OutBack; easing.overshoot: Motion.os(2.5) } }
    opacity: enabled ? 1 : 0.5
    Icon {
        visible: b.hasIcon
        name: b.icon; size: b.icPx; color: b.primary ? Theme.onPrimary : Theme.text
        x: b.hasText ? b.padIcon : (b.width - width) / 2
        anchors.verticalCenter: parent.verticalCenter
    }
    DText {
        id: label
        visible: b.hasText
        x: b.hasIcon ? b.padIcon + b.icPx + b.gap : (b.width - width) / 2
        anchors.verticalCenter: parent.verticalCenter
        text: b.text; color: b.primary ? Theme.onPrimary : Theme.text; font.pixelSize: b.fontPx; font.weight: Font.Medium
    }
    MouseArea { id: ma; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: b.clicked() }
}
