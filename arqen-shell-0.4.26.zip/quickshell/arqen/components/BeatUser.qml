import QtQuick
import qs.services

// Put one of these in anything that shows the beat: while `on` it asks Beat (cava) to listen, and lets go when not.
Item {
    id: bu
    property bool on: true
    property bool held: false
    function sync() {
        if (bu.on && !bu.held) { Beat.users++; bu.held = true }
        else if (!bu.on && bu.held) { Beat.users--; bu.held = false }
    }
    onOnChanged: sync()
    Component.onCompleted: sync()
    Component.onDestruction: if (bu.held) Beat.users--
    width: 0; height: 0; visible: false
}
