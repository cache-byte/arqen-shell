import QtQuick
import qs.config

// Icon by name from the rounded symbol icon font (installed by install.sh)
Text {
    property string name: ""
    property int size: 22
    text: name
    color: Theme.text
    font.family: "Material Symbols Rounded"
    font.pixelSize: size
    renderType: Text.NativeRendering
    horizontalAlignment: Text.AlignHCenter
    verticalAlignment: Text.AlignVCenter
}
