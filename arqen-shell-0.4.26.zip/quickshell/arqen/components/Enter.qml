import QtQuick
import qs.config

// Makes its parent pop in (fade and a small springy grow) every time `trigger` changes, after
// `delay` ms, so things inside a panel come in one after another each time it opens.
// Put it inside the item: Enter { trigger: win.openSerial; delay: 30 }
Item {
    id: e
    property int trigger: 0
    property int delay: 0
    property real from: 0.88
    property Item target: parent           // or another item (a list: its contents are not its children)
    visible: false
    width: 0; height: 0
    onTriggerChanged: if (target && trigger > 0) run.restart()
    SequentialAnimation {
        id: run
        ScriptAction { script: { e.target.opacity = 0; e.target.scale = e.from } }
        PauseAnimation { duration: e.delay }
        ParallelAnimation {
            NumberAnimation { target: e.target; property: "opacity"; to: 1; duration: 200; easing.type: Easing.OutCubic }
            NumberAnimation { target: e.target; property: "scale"; to: 1; duration: 420; easing.type: Easing.OutBack; easing.overshoot: Motion.os(1.6) }
        }
    }
}
