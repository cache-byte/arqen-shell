import QtQuick
import qs.config

// The one slider of the shell: a rounded track that fills in the accent colour, like the volume
// slider in the control centre. pill: the big kind (control centre, OSD) with an icon at the start
// of the fill, filling from the bottom when `vertical`. Otherwise a slimmer one (settings rows)
// with a small grip at the end of the fill. It swells a little while you hold it.
Item {
    id: s
    property real value: 0
    property real from: 0
    property real to: 1
    property real stepSize: 0
    property bool pill: false
    property bool vertical: false
    property string icon: ""
    property color fillColor: Theme.primary
    property color iconColor: Theme.onPrimary
    // muted / at zero: the fill disappears and this icon shows in grey at the start (volume: a
    // crossed-out note)
    property bool off: false
    property string offIcon: ""
    readonly property bool showOff: pill && offIcon !== "" && (off || frac <= 0.005)
    signal moved(real v)
    // whole steps counted from `from`, inside the range, without float noise (0.30000000004)
    function snap(v) {
        v = Math.max(from, Math.min(to, v))
        if (stepSize > 0) v = from + Math.round((v - from) / stepSize) * stepSize
        return Math.round(Math.max(from, Math.min(to, v)) * 1e6) / 1e6
    }

    implicitWidth: vertical ? 38 : 200
    implicitHeight: vertical ? 160 : (pill ? 38 : 32)
    readonly property real frac: Math.max(0, Math.min(1, (value - from) / (to - from)))
    readonly property bool held: ma.pressed
    property real thick: pill ? (vertical ? width : 38) : (held ? 28 : 24)
    Behavior on thick { NumberAnimation { duration: 260; easing.type: Easing.OutBack; easing.overshoot: Motion.os(2) } }

    Rectangle {
        id: track
        anchors.centerIn: parent
        width: s.vertical ? s.thick : parent.width
        height: s.vertical ? parent.height : s.thick
        radius: (s.vertical ? width : height) / 2
        color: Theme.tile
        Rectangle {
            visible: !s.showOff
            anchors { left: parent.left; bottom: parent.bottom }
            width: s.vertical ? parent.width : Math.max(height, parent.width * s.frac)
            height: s.vertical ? Math.max(width, parent.height * s.frac) : parent.height
            radius: (s.vertical ? width : height) / 2
            color: s.fillColor
            // follows clicks and the wheel smoothly; drags stay glued to the pointer
            Behavior on width { enabled: !s.held && !s.vertical; NumberAnimation { duration: 180; easing.type: Easing.OutCubic } }
            Behavior on height { enabled: !s.held && s.vertical; NumberAnimation { duration: 180; easing.type: Easing.OutCubic } }
            // the grip at the end of the fill (the slim kind)
            Rectangle {
                visible: !s.pill
                width: 4; height: parent.height * 0.5; radius: 2
                anchors.verticalCenter: parent.verticalCenter
                x: parent.width - width - (parent.height - width) / 2
                color: s.iconColor
                opacity: 0.9
            }
        }
        Icon {
            visible: s.pill && (s.showOff || s.icon !== "")
            name: s.showOff ? s.offIcon : s.icon
            size: Math.min(19, s.thick * 0.5)
            color: s.showOff ? Theme.subtext : s.iconColor
            x: s.vertical ? (parent.width - width) / 2 : 12
            y: s.vertical ? parent.height - height - 12 : (parent.height - height) / 2
        }
    }
    MouseArea {
        id: ma
        anchors.fill: parent
        cursorShape: Qt.PointingHandCursor
        preventStealing: true
        function setFrom(mx, my) {
            let f = s.vertical ? 1 - my / height : mx / width
            f = Math.max(0, Math.min(1, f))
            let v = s.from + f * (s.to - s.from)
            s.moved(s.snap(v))
        }
        onPressed: mouse => setFrom(mouse.x, mouse.y)
        onPositionChanged: mouse => { if (pressed) setFrom(mouse.x, mouse.y) }
        // one step per wheel notch (5 % of the range when there are no steps)
        onWheel: wheel => s.moved(s.snap(s.value + (wheel.angleDelta.y > 0 ? 1 : -1) * (s.stepSize > 0 ? s.stepSize : (s.to - s.from) * 0.05)))
    }
}
