import Quickshell
import Quickshell.Wayland
import Quickshell.Hyprland
import QtQuick
import qs.config

// Floating popup: sits next to the panel it was opened from, closes when you
// click outside it or press Escape. Ui.popAlong is a screen coordinate; this window starts
// after the panels' reserved space (Ui.rLeft / Ui.rTop), hence the subtraction below.
PanelWindow {
    id: win

    property bool open: false
    property real cardWidth: 400
    property real cardHeight: 300
    property string position: "center"      // center | bottom-right | bottom-left
    property bool wantsKeyboard: false
    readonly property string pos: position === "tray" ? Ui.trayCorner : position
    // tray-style popups line up with the icon that opened them (when known)
    readonly property bool alignToIcon: position === "tray" && Ui.popAlong >= 0
    // opening springs in (a small overshoot), closing is quick and plain; started explicitly each
    // time (a Behavior with changing settings only animated the first time)
    property real t: 0                  // everything starts closed
    NumberAnimation { id: popIn; target: win; property: "t"; to: 1; duration: 340; easing.type: Easing.OutBack; easing.overshoot: Motion.os(1.1) }
    NumberAnimation { id: popOut; target: win; property: "t"; to: 0; duration: 160; easing.type: Easing.InCubic }
    readonly property bool popWant: open
    onPopWantChanged: { if (popWant) { popOut.stop(); popIn.restart() } else { popIn.stop(); popOut.restart() } }
    default property alias content: card.data
    // things drawn above the card, in window coordinates (e.g. an app being dragged out)
    property alias above: aboveLayer.data
    property real cardOpacity: 1
    // true when things inside move while it opens (then it is not drawn into a texture)
    property bool liveContent: false
    // when it last opened or its contents last changed: lists use it to animate in only then
    property double freshAt: 0
    function fresh() { return Date.now() - freshAt < 450 }
    property int openSerial: 0
    readonly property bool moving: popIn.running || popOut.running
    onOpenChanged: if (open) { freshAt = Date.now(); openSerial++ }

    screen: Quickshell.screens.find(s => s.name === Hyprland.focusedMonitor?.name) ?? Quickshell.screens[0]
    visible: t > 0.001
    color: "transparent"
    anchors { top: true; left: true; right: true; bottom: true }
    margins { top: Ui.rTop; bottom: Ui.rBottom; left: Ui.rLeft; right: Ui.rRight }
    exclusionMode: ExclusionMode.Ignore
    WlrLayershell.namespace: "arqen-popup"
    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.keyboardFocus: (open && wantsKeyboard) ? WlrKeyboardFocus.Exclusive : WlrKeyboardFocus.None

    Shortcut { sequence: "Escape"; enabled: win.open; onActivated: Ui.close() }
    MouseArea { anchors.fill: parent; onClicked: Ui.close() }

    Rectangle {
        id: card
        // Clamp every popup to the usable screen area. Several menus have a comfortable
        // desktop size, but must still fit on small displays and scaled HiDPI screens.
        width: Math.max(1, Math.min(win.cardWidth, win.width - 2 * Ui.gap))
        height: Math.max(1, Math.min(win.cardHeight, win.height - 2 * Ui.gap))
        clip: true
        radius: Theme.radius
        color: Theme.panel
        border.color: Theme.stroke
        border.width: 1
        // (the fade for cardOpacity is its own property: a Behavior on opacity itself ran behind the
        // opening animation, restarted at every frame)
        property real fade: win.cardOpacity
        Behavior on fade { NumberAnimation { duration: 140 } }
        opacity: Math.min(1, win.t) * fade
        scale: 0.92 + 0.08 * win.t
        // while it grows or shrinks it is drawn once into a texture and that is scaled (much
        // cheaper than redrawing every icon and line of text at every frame)
        layer.enabled: (popIn.running || popOut.running) && !win.liveContent
        layer.smooth: true
        x: (win.alignToIcon && !Ui.vertical) ? Math.max(Ui.gap, Math.min(win.width - width - Ui.gap, Ui.popAlong - Ui.rLeft - width / 2))
         : win.pos.indexOf("right") >= 0 ? win.width - width - Ui.gap
         : win.pos.indexOf("left") >= 0 ? Ui.gap : (win.width - width) / 2
        y: (win.alignToIcon && Ui.vertical) ? Math.max(Ui.gap, Math.min(win.height - height - Ui.gap, Ui.popAlong - Ui.rTop - height / 2))
         : win.pos.indexOf("bottom") >= 0 ? win.height - height - Ui.gap + (1 - win.t) * 14
         : win.pos.indexOf("top") >= 0 ? Ui.gap - (1 - win.t) * 14
         : (win.height - height) / 2 - 20
        MouseArea { anchors.fill: parent }   // swallow clicks inside the card
    }
    Item { id: aboveLayer; anchors.fill: parent; z: 50 }
}
