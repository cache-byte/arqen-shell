import QtQuick
import qs.config

// A pill whose outline is a progress ring: `level` (0..1) of the way round is drawn in `color`, the rest in a
// neutral `track`, going clockwise from where `startAt` says: "top" (top-left of the straight edge), "left" (the bottom
// of the left end) or "mid" (9 o'clock, the middle of the left end, then up over the top).
// Whatever is put inside (text, an icon) sits in the middle. Used for the battery on the panel and the
// screen-recording timer.
// Drawn on a Canvas (plain 2D drawing, in the item's own units): it
// does not depend on the GPU shape renderer, which left the coloured arc invisible on some setups.
Item {
    id: rp
    property real level: 0                       // how far round (0..1)
    property color color: Theme.primary
    property color track: Qt.rgba(Theme.text.r, Theme.text.g, Theme.text.b, 0.18)
    property color fill: "transparent"           // inside the ring
    property real stroke: Math.max(2, height * 0.14)
    property string startAt: "top"
    default property alias content: inner.data
    implicitWidth: 64
    implicitHeight: 28

    readonly property real p: isNaN(level) ? 0 : Math.max(0, Math.min(1, level))

    Rectangle {
        anchors { fill: parent; margins: rp.stroke }
        radius: height / 2
        color: rp.fill
    }

    Canvas {
        id: cv
        anchors.fill: parent
        antialiasing: true
        renderTarget: Canvas.Image
        renderStrategy: Canvas.Immediate
        Connections {
            target: rp
            function onPChanged() { cv.requestPaint() }
            function onColorChanged() { cv.requestPaint() }
            function onTrackChanged() { cv.requestPaint() }
            function onStrokeChanged() { cv.requestPaint() }
            function onStartAtChanged() { cv.requestPaint() }
            function onWidthChanged() { cv.requestPaint() }
            function onHeightChanged() { cv.requestPaint() }
        }
        Component.onCompleted: requestPaint()
        onAvailableChanged: if (available) requestPaint()
        onVisibleChanged: if (visible) requestPaint()
        // once more shortly after it appears, in case the first paints came before the size and values were final
        Timer { interval: 400; running: cv.visible; repeat: false; onTriggered: cv.requestPaint() }
        // and every second while it shows: a value that arrives late (the battery reports after the shell starts) can never be left unpainted
        Timer { interval: 10000; running: cv.visible; repeat: true; onTriggered: cv.requestPaint() }
        onPaint: {
            const ctx = getContext("2d")
            ctx.reset()
            // colours as CSS strings (a QML color handed straight to the canvas was not always taken)
            function css(c) { return "rgba(" + Math.round(c.r * 255) + "," + Math.round(c.g * 255) + "," + Math.round(c.b * 255) + "," + c.a + ")" }
            const w = rp.width, h = rp.height, sw = rp.stroke
            if (w <= 0 || h <= 0) return
            const r = Math.max(0.5, (h - sw) / 2)
            const x0 = sw / 2 + r, x1 = w - sw / 2 - r
            const y0 = sw / 2, y1 = h - sw / 2, cy = h / 2
            const PI = Math.PI
            const straight = Math.max(0, x1 - x0), arc = PI * r
            // the way round, clockwise from the top-left corner of the straight edge, as pieces: a line or an arc
            const top = { len: straight, line: [x0, y0, x1, y0] }
            const right = { len: arc, arc: [x1, cy, 1.5 * PI, 2.5 * PI] }
            const bottom = { len: straight, line: [x1, y1, x0, y1] }
            const leftTop = { len: arc / 2, arc: [x0, cy, PI, 1.5 * PI] }          // from 9 o'clock up to the top
            const leftBottom = { len: arc / 2, arc: [x0, cy, 0.5 * PI, PI] }       // from the bottom up to 9 o'clock
            const leftAll = { len: arc, arc: [x0, cy, 0.5 * PI, 1.5 * PI] }        // the whole left end, bottom to top
            const full = { len: arc, arc: [x0, cy, 0.5 * PI, 1.5 * PI] }
            let segs
            if (rp.startAt === "mid") segs = [leftTop, top, right, bottom, leftBottom]
            else if (rp.startAt === "left") segs = [leftAll, top, right, bottom]
            else segs = [top, right, bottom, full]
            ctx.lineCap = "round"; ctx.lineJoin = "round"; ctx.lineWidth = sw
            // draws `amount` (px) of the way round
            function draw(amount) {
                let left = amount, first = true
                ctx.beginPath()
                for (const s of segs) {
                    if (left <= 0.0001 && !first) break
                    const f = s.len <= 0.0001 ? 1 : Math.min(1, left / s.len)
                    if (s.line) {
                        const a = s.line
                        if (first) ctx.moveTo(a[0], a[1])
                        ctx.lineTo(a[0] + (a[2] - a[0]) * f, a[1] + (a[3] - a[1]) * f)
                    } else {
                        const a = s.arc
                        if (first) ctx.moveTo(a[0] + r * Math.cos(a[2]), a[1] + r * Math.sin(a[2]))
                        ctx.arc(a[0], a[1], r, a[2], a[2] + (a[3] - a[2]) * f, false)
                    }
                    first = false
                    left -= s.len
                }
                ctx.stroke()
            }
            const perim = 2 * straight + 2 * arc
            ctx.strokeStyle = css(rp.track)
            draw(perim)
            if (rp.p > 0.003) { ctx.strokeStyle = rp.color.a < 0.05 ? "rgba(52,199,89,1)" : css(rp.color); draw(perim * rp.p) }
        }
    }
    Item { id: inner; anchors.fill: parent }
}
