import Quickshell
import Quickshell.Widgets
import QtQuick
import qs.config
import qs.services

// Your picture in a circle, or your initial when there is none.
ClippingRectangle {
    id: av
    property int size: 44
    width: size; height: size
    implicitWidth: size; implicitHeight: size
    radius: size / 2
    color: Theme.tertiaryContainer
    DText {
        visible: User.faceAnimated ? anim.status !== AnimatedImage.Ready : img.status !== Image.Ready
        anchors.centerIn: parent
        text: (User.name || "?").charAt(0).toUpperCase()
        color: Theme.onTertiaryContainer
        font.pixelSize: Math.round(av.size * 0.45)
        font.weight: Font.Bold
    }
    // a GIF moves
    AnimatedImage {
        id: anim
        anchors.fill: parent
        visible: User.faceAnimated
        source: (User.faceAnimated && User.face !== "") ? "file://" + User.face + "?v=" + User.faceVersion : ""
        fillMode: Image.PreserveAspectCrop
        cache: false
        playing: visible
        asynchronous: true
    }
    Image {
        id: img
        anchors.fill: parent
        visible: !User.faceAnimated
        // the ?v= part makes it load again after the picture is changed
        source: (!User.faceAnimated && User.face !== "") ? "file://" + User.face + "?v=" + User.faceVersion : ""
        sourceSize: Qt.size(av.size * 2, av.size * 2)
        fillMode: Image.PreserveAspectCrop
        cache: false
        asynchronous: true
    }
}
