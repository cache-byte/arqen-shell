import Quickshell
import QtQuick
import qs.config
import qs.services

// The calendar widget: a month, today marked. Click the heading to go back to this month; the arrows
// (when the pointer is on it) and the mouse wheel go through the months. Options: Widgets.baseTypes.calendar.
Rectangle {
    id: w
    property var cfg: Widgets.cfg({ type: "calendar" })
    radius: Widgets.radiusOf(cfg)
    color: Widgets.bgOf(cfg)
    border.width: Widgets.borderW(cfg)
    border.color: Widgets.borderCol(cfg)
    // shadow behind the card (Shadow option)
    WidgetShadow { z: -1; strength: Widgets.shadowA(cfg); cardRadius: w.radius }
    readonly property color fg: Widgets.fgOf(cfg)
    readonly property color subc: Widgets.subOf(cfg)
    readonly property real ts: Widgets.ts(cfg)

    SystemClock { id: clock; precision: SystemClock.Minutes }
    readonly property date now: clock.date
    property int offset: 0                       // months away from this one
    readonly property date shownMonth: new Date(now.getFullYear(), now.getMonth() + offset, 1)
    readonly property int first: cfg.weekStart === "Sunday" ? 0 : cfg.weekStart === "Saturday" ? 6 : 1     // JS: 0 = Sunday
    readonly property bool wn: cfg.weekNumbers === true
    readonly property int cols: wn ? 8 : 7
    // 6 weeks of days, starting on the first weekday on or before the 1st
    readonly property var days: {
        const m = shownMonth
        const lead = (m.getDay() - first + 7) % 7
        const start = new Date(m.getFullYear(), m.getMonth(), 1 - lead)
        const out = []
        for (let i = 0; i < 42; i++) out.push(new Date(start.getFullYear(), start.getMonth(), start.getDate() + i))
        return out
    }
    function weekNo(d) {                          // ISO week number
        const t = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()))
        const n = t.getUTCDay() || 7
        t.setUTCDate(t.getUTCDate() + 4 - n)
        return Math.ceil(((t - new Date(Date.UTC(t.getUTCFullYear(), 0, 1))) / 86400000 + 1) / 7)
    }
    function same(a, b) { return a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate() }

    // small: just today, as numbers (or words), and the month and year — the grid needs room
    readonly property bool compact: cfg.compact === "Always" || (cfg.compact !== "Never" && (Math.min(width, height) < 250 || width * height < 62000))
    readonly property bool words: cfg.compactText === "Words"
    readonly property bool showYear: cfg.compactYear !== false
    readonly property real pad: 12
    readonly property real headH: cfg.header === "None" ? 0 : Math.max(22, Math.min(34, height * 0.13))
    readonly property real cellW: (width - 2 * pad) / cols
    readonly property real cellH: (height - 2 * pad - headH - (headH > 0 ? 4 : 0)) / 7
    readonly property real fs: Math.max(8, Math.min(cellH * 0.5, cellW * 0.5, 17)) * ts

    // heading
    Item {
        visible: w.headH > 0 && !w.compact
        x: w.pad; y: w.pad; width: parent.width - 2 * w.pad; height: w.headH
        DText {
            anchors.verticalCenter: parent.verticalCenter
            text: Qt.formatDate(w.shownMonth, w.cfg.header === "Month" ? "MMMM" : "MMMM yyyy")
            color: w.offset === 0 ? w.fg : Theme.primary
            font.pixelSize: Math.round(Math.max(12, w.headH * 0.6) * w.ts); font.weight: Font.DemiBold
            MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor; onClicked: w.offset = 0 }
        }
        Row {
            anchors.right: parent.right; anchors.verticalCenter: parent.verticalCenter
            opacity: hov.hovered || w.offset !== 0 ? 1 : 0
            Behavior on opacity { NumberAnimation { duration: 150 } }
            Repeater {
                model: [["chevron_left", -1], ["chevron_right", 1]]
                delegate: Item {
                    required property var modelData
                    width: w.headH; height: w.headH
                    Icon { anchors.centerIn: parent; name: parent.modelData[0]; size: Math.round(w.headH * 0.7); color: w.fg }
                    MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor; onClicked: w.offset += parent.modelData[1] }
                }
            }
        }
    }
    HoverHandler { id: hov }
    WheelHandler { enabled: !w.compact; onWheel: ev => w.offset += ev.angleDelta.y > 0 ? -1 : 1 }

    // ---- compact: the date big, month and year under it ----
    Column {
        visible: w.compact
        anchors.centerIn: parent
        width: parent.width - 2 * w.pad
        spacing: Math.round(Math.min(w.height, w.width) * 0.02)
        DText {
            visible: w.words
            width: parent.width; horizontalAlignment: Text.AlignHCenter; elide: Text.ElideRight
            text: Qt.formatDate(w.now, "dddd")
            color: w.subc
            font.pixelSize: Math.round(Math.max(10, Math.min(w.height * 0.11, w.width * 0.11)) * w.ts); font.weight: Font.Medium
        }
        DText {
            width: parent.width; horizontalAlignment: Text.AlignHCenter
            text: w.now.getDate()
            color: w.cfg.weekend === false ? w.fg : Theme.primary
            font.pixelSize: Math.round(Math.max(18, Math.min(w.height * 0.5, w.width * 0.5)) * w.ts); font.weight: Font.DemiBold
        }
        DText {
            width: parent.width; horizontalAlignment: Text.AlignHCenter; elide: Text.ElideRight
            text: w.words ? Qt.formatDate(w.now, w.showYear ? "MMMM yyyy" : "MMMM")
                          : (w.now.getMonth() + 1 < 10 ? "0" : "") + (w.now.getMonth() + 1) + (w.showYear ? " · " + w.now.getFullYear() : "")
            color: w.fg
            font.pixelSize: Math.round(Math.max(10, Math.min(w.height * 0.12, w.width * 0.12)) * w.ts); font.weight: Font.Medium
        }
    }

    // weekday names, then the days
    Item {
        visible: !w.compact
        x: w.pad; y: w.pad + w.headH + (w.headH > 0 ? 4 : 0)
        width: parent.width - 2 * w.pad; height: w.cellH * 7
        Repeater {
            model: 7
            delegate: DText {
                required property int index
                x: (w.wn ? w.cellW : 0) + index * w.cellW; y: 0; width: w.cellW; height: w.cellH
                horizontalAlignment: Text.AlignHCenter; verticalAlignment: Text.AlignVCenter
                text: Qt.locale().dayName((w.first + index) % 7, Locale.NarrowFormat).substring(0, 1).toUpperCase()
                color: w.subc; font.pixelSize: Math.round(w.fs * 0.85); font.weight: Font.Medium
            }
        }
        Repeater {
            model: w.days
            delegate: Item {
                id: dc
                required property var modelData
                required property int index
                readonly property int row: Math.floor(index / 7)
                readonly property int col: index % 7
                readonly property bool inMonth: modelData.getMonth() === w.shownMonth.getMonth()
                readonly property bool isToday: w.same(modelData, w.now)
                readonly property bool weekend: modelData.getDay() === 0 || modelData.getDay() === 6
                x: (w.wn ? w.cellW : 0) + col * w.cellW; y: (row + 1) * w.cellH; width: w.cellW; height: w.cellH
                Rectangle {
                    visible: dc.isToday && w.cfg.today !== "Underline"
                    anchors.centerIn: parent
                    width: Math.min(parent.width, parent.height) - 2; height: width
                    radius: w.cfg.today === "Fill" ? 5 : width / 2
                    color: w.cfg.today === "Fill" ? Theme.primary : "transparent"
                    border.width: w.cfg.today === "Fill" ? 0 : 2; border.color: Theme.primary
                }
                Rectangle {
                    visible: dc.isToday && w.cfg.today === "Underline"
                    anchors.horizontalCenter: parent.horizontalCenter; anchors.bottom: parent.bottom; anchors.bottomMargin: 1
                    width: parent.width * 0.5; height: 3; radius: 1.5; color: Theme.primary
                }
                DText {
                    anchors.centerIn: parent
                    text: dc.modelData.getDate()
                    font.pixelSize: Math.round(w.fs); font.weight: dc.isToday ? Font.Bold : Font.Normal
                    color: dc.isToday && w.cfg.today === "Fill" ? Theme.onPrimary
                         : w.cfg.weekend && dc.weekend ? Theme.primary : w.fg
                    opacity: dc.inMonth ? 1 : (w.cfg.dim === false ? 0.85 : 0.3)
                }
            }
        }
        // week numbers down the left
        Repeater {
            model: w.wn ? 6 : 0
            delegate: DText {
                required property int index
                x: 0; y: (index + 1) * w.cellH; width: w.cellW; height: w.cellH
                horizontalAlignment: Text.AlignHCenter; verticalAlignment: Text.AlignVCenter
                text: w.weekNo(new Date(w.days[index * 7].getFullYear(), w.days[index * 7].getMonth(), w.days[index * 7].getDate() + 3))
                color: w.subc; opacity: 0.8; font.pixelSize: Math.round(w.fs * 0.75)
            }
        }
    }
}
