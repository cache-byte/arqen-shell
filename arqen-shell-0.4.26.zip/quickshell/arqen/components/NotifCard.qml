import Quickshell
import QtQuick
import QtQuick.Layouts
import qs.config
import qs.services

// One notification, like a phone's: a rounded card with the app's icon (or the sender's picture
// with the app as a badge); a small line with where it came from and when; the title; one line of
// text; the picture that came with it on the right; an arrow (or, on a stack, how many there are).
//  - click: what the app says a click does (open the chat, show the screenshot), else open it out
//  - the arrow: open it out: all the text, the picture big, the app's buttons (Reply, Mark as read...)
//    and a reply box for apps that take replies. Several can be open at once; a click on empty space
//    (or closing the control centre) closes them all
//  - swipe it sideways: gone
Item {
    id: c
    property var notif: null
    property bool expanded: false
    property bool remember: false           // open / closed is kept by Notifs (the list's cards)
    property bool popup: false              // the pop-up: a solid card
    property int count: 0                   // > 1: the top of a closed stack: the number instead of the arrow
    property real ring: -1                  // 0..1: time left, shown as two bars along the bottom that close in on the middle (the pop-up)
    signal done()                           // an action was taken (the pop-up hides itself)
    signal countClicked()
    signal swiped()                         // swiped away (a stack uses it to clear all of them)
    property bool swipeClears: true         // swiping dismisses this notification

    readonly property bool open: remember ? Notifs.cardOpen(notif) : expanded
    function toggle() { if (remember) Notifs.toggleCard(notif); else expanded = !expanded }
    readonly property var btns: Notifs.buttons(notif)
    readonly property string pic: Notifs.imageOf(notif)
    // what the picture turns out to be once loaded: a small square is an icon, not a photo
    readonly property bool picReady: probe.status === Image.Ready
    readonly property bool picIsIcon: picReady && probe.implicitWidth <= 160 && Math.abs(probe.implicitWidth - probe.implicitHeight) <= 8
    readonly property bool chat: Notifs.isChat(notif) && pic !== "" && !picIsIcon
    readonly property bool showPic: picReady && !picIsIcon && !chat
    readonly property string source: Notifs.appName(notif)
    readonly property string title: Notifs.plain(notif?.summary) || source
    readonly property string bodyText: Notifs.plain(notif?.body)
    property bool replying: false
    Image { id: probe; visible: false; source: c.pic; asynchronous: true; sourceSize.width: 1024 }
    // a picture that was still being written when the card appeared (a fresh screenshot): try again shortly, a few times
    property int picTries: 0
    onPicChanged: picTries = 0
    Timer {
        interval: 600
        running: probe.status === Image.Error && c.pic !== "" && c.picTries < 4
        onTriggered: { c.picTries++; const s = c.pic; probe.source = ""; probe.source = s }
    }

    implicitHeight: card.height
    implicitWidth: 400

    // the colour of the cards (dark, a little see-through, like the phone's)
    readonly property color base: Theme.dark ? Qt.rgba(0.08, 0.08, 0.10, popup ? 0.94 : 0.78) : Qt.rgba(1, 1, 1, popup ? 0.97 : 0.86)

    // ---- arrives: grows in a little and fades in (only when new) ----
    property real enter: 1
    Component.onCompleted: {
        const t = notif ? Notifs.timeOf(notif) : 0
        if (!t || Date.now() - t < 1500) { enter = 0; enterAnim.start() }
    }
    NumberAnimation { id: enterAnim; target: c; property: "enter"; to: 1; duration: 340; easing.type: Easing.OutBack; easing.overshoot: Motion.os(1.2) }

    // ---- swipe ----
    property real dx: 0
    property bool swiping: false
    NumberAnimation { id: back; target: c; property: "dx"; to: 0; duration: 260; easing.type: Easing.OutBack }
    NumberAnimation {
        id: away; target: c; property: "dx"; duration: 180; easing.type: Easing.InCubic
        onFinished: { c.swiped(); if (c.swipeClears) { const n = c.notif; c.done(); Notifs.dismiss(n) } }
    }

    readonly property int pad: 14
    Rectangle {
        id: card
        width: parent.width
        height: Math.max(72, body.implicitHeight + 2 * c.pad - (c.open ? 0 : 4)) + (c.ring >= 0 ? 8 : 0)
        Behavior on height { enabled: !c.swiping; NumberAnimation { duration: 220; easing.type: Easing.OutCubic } }
        radius: c.open ? 28 : Math.min(height / 2, 36)
        Behavior on radius { NumberAnimation { duration: 200 } }
        color: c.base
        border.width: Theme.dark ? 0 : 1
        border.color: Theme.stroke
        opacity: Math.min(c.enter, 1 - Math.min(0.8, Math.abs(c.dx) / Math.max(1, c.width)))
        scale: 0.96 + 0.04 * c.enter
        transform: Translate { x: c.dx }
        clip: true

        // hover tint
        Rectangle { anchors.fill: parent; radius: parent.radius; color: Theme.hover; visible: cma.containsMouse && !c.open }

        // how long the pop-up stays: two bars along the bottom edge, one from each side, that shrink towards the
        // middle as the time runs out (full while the pointer is on it)
        Item {
            visible: c.ring >= 0
            anchors { left: parent.left; right: parent.right; bottom: parent.bottom; leftMargin: 26; rightMargin: 26; bottomMargin: 7 }
            height: 4
            z: 5
            readonly property real half: Math.max(0, width / 2 - 3)
            Rectangle {
                anchors.left: parent.left; anchors.verticalCenter: parent.verticalCenter
                width: parent.half * Math.max(0, Math.min(1, c.ring)); height: 4; radius: 2
                color: Qt.rgba(Theme.primary.r, Theme.primary.g, Theme.primary.b, 0.9)
            }
            Rectangle {
                anchors.right: parent.right; anchors.verticalCenter: parent.verticalCenter
                width: parent.half * Math.max(0, Math.min(1, c.ring)); height: 4; radius: 2
                color: Qt.rgba(Theme.primary.r, Theme.primary.g, Theme.primary.b, 0.9)
            }
        }

        // click / swipe
        MouseArea {
            id: cma
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            property real px: 0
            onPressed: mouse => { px = mouse.x; c.swiping = false; back.stop() }
            onPositionChanged: mouse => {
                if (!pressed) return
                const d = mouse.x - px
                if (!c.swiping && Math.abs(d) > 10) c.swiping = true
                if (c.swiping) c.dx = d
            }
            onReleased: {
                if (!c.swiping) return
                if (Math.abs(c.dx) > c.width * 0.3) { away.to = c.dx > 0 ? c.width + 40 : -c.width - 40; away.start() }
                else back.start()
            }
            onClicked: {
                if (c.swiping) { c.swiping = false; return }
                if (!c.open && Notifs.hasDefault(c.notif)) { const n = c.notif; c.done(); Notifs.open(n) }
                else c.toggle()
            }
        }

        ColumnLayout {
            id: body
            x: c.pad; y: c.pad - (c.open ? 0 : 2)
            width: card.width - c.pad - 10
            spacing: 10

            RowLayout {
                Layout.fillWidth: true
                spacing: 12
                // the icon
                Item {
                    Layout.preferredWidth: 46; Layout.preferredHeight: 46
                    Layout.alignment: Qt.AlignTop
                    NotifIcon { anchors.centerIn: parent; notif: c.notif; size: 44; iconPic: c.picIsIcon ? c.pic : "" }
                }
                ColumnLayout {
                    Layout.fillWidth: true
                    Layout.alignment: Qt.AlignVCenter
                    spacing: 1
                    // where it came from, and when
                    DText {
                        Layout.fillWidth: true
                        text: c.source + "  ·  " + Notifs.clock(c.notif)
                        font.pixelSize: 11; color: Theme.subtext
                        elide: Text.ElideRight
                    }
                    DText {
                        Layout.fillWidth: true
                        text: c.title
                        font.pixelSize: 14; font.weight: Font.DemiBold
                        elide: Text.ElideRight
                        maximumLineCount: c.open ? 3 : 1
                        wrapMode: c.open ? Text.Wrap : Text.NoWrap
                    }
                    DText {
                        visible: text !== ""
                        Layout.fillWidth: true
                        text: c.bodyText
                        font.pixelSize: 13
                        color: c.open ? Theme.text : Theme.subtext
                        wrapMode: c.open ? Text.Wrap : Text.NoWrap
                        maximumLineCount: c.open ? 14 : 1
                        elide: Text.ElideRight
                        textFormat: Text.PlainText
                    }
                }
                // the picture that came with it, small
                Rectangle {
                    visible: c.showPic && !c.open
                    Layout.preferredWidth: 52; Layout.preferredHeight: 40
                    Layout.alignment: Qt.AlignVCenter
                    radius: 10; color: Theme.tile; clip: true
                    Image { anchors.fill: parent; source: c.showPic ? c.pic : ""; fillMode: Image.PreserveAspectCrop; asynchronous: true; sourceSize.width: 160 }
                }
                // the arrow (open / close), or how many there are in the stack
                Item {
                    Layout.preferredWidth: 34; Layout.preferredHeight: 34
                    Layout.alignment: Qt.AlignVCenter
                    Rectangle {
                        anchors.fill: parent; radius: 17
                        color: c.count > 1 ? Qt.rgba(Theme.text.r, Theme.text.g, Theme.text.b, am.containsMouse ? 0.16 : 0.09)
                                           : (am.containsMouse ? Theme.hover : "transparent")
                    }
                    Icon {
                        visible: c.count <= 1
                        anchors.centerIn: parent
                        name: "expand_more"; size: 22; color: Theme.subtext
                        rotation: c.open ? 180 : 0
                        Behavior on rotation { NumberAnimation { duration: 220; easing.type: Easing.OutCubic } }
                    }
                    DText {
                        visible: c.count > 1
                        anchors.centerIn: parent
                        text: c.count > 99 ? "99+" : c.count
                        font.pixelSize: 13; font.weight: Font.DemiBold; color: Theme.text
                    }
                    MouseArea {
                        id: am
                        anchors.fill: parent; anchors.margins: -6
                        hoverEnabled: true; cursorShape: Qt.PointingHandCursor
                        onClicked: { if (c.count > 1) c.countClicked(); else c.toggle() }
                    }
                }
            }

            // ---- opened out ----
            // the picture, big
            Rectangle {
                visible: c.open && c.showPic
                Layout.fillWidth: true
                Layout.rightMargin: 4
                Layout.preferredHeight: Math.min(220, width * 9 / 16)
                radius: 18; color: Theme.tile; clip: true
                Image { anchors.fill: parent; source: c.open && c.showPic ? c.pic : ""; fillMode: Image.PreserveAspectCrop; asynchronous: true; sourceSize.width: 800 }
                MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor; onClicked: { const n = c.notif; c.done(); Notifs.open(n) } }
            }
            // a reply, for apps that take one
            RowLayout {
                visible: c.open && c.replying
                Layout.fillWidth: true
                Layout.rightMargin: 4
                spacing: 8
                ArqField {
                    id: replyField
                    Layout.fillWidth: true
                    iconName: "reply"
                    placeholder: c.notif?.inlineReplyPlaceholder || "Reply"
                    closesOnEscape: false
                    onEscaped: c.replying = false
                    onAccepted: c.sendReply()
                }
                Rectangle {
                    width: 44; height: 44; radius: 22
                    color: Theme.primary
                    Icon { anchors.centerIn: parent; name: "send"; size: 20; color: Theme.onPrimary }
                    MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor; onClicked: c.sendReply() }
                }
            }
            // the app's buttons, across the bottom like the phone's (Reply · Mark as read · Mute)
            RowLayout {
                visible: c.open
                Layout.fillWidth: true
                Layout.rightMargin: 4
                spacing: 4
                Repeater {
                    model: c.open ? (c.notif?.hasInlineReply ? [{ text: "Reply", reply: true }] : []).concat(c.btns.length ? c.btns : (Notifs.hasDefault(c.notif) ? [{ text: "Open", openIt: true }] : [])).concat([{ text: "Clear", clear: true }]) : []
                    delegate: Rectangle {
                        id: ab
                        required property var modelData
                        Layout.fillWidth: true
                        Layout.preferredHeight: 38
                        radius: 19
                        color: abm.containsMouse ? Theme.hover : Qt.rgba(Theme.text.r, Theme.text.g, Theme.text.b, 0.05)
                        DText {
                            anchors.centerIn: parent
                            width: Math.min(implicitWidth, parent.width - 12); elide: Text.ElideRight
                            text: ab.modelData.text
                            font.pixelSize: 13; font.weight: Font.DemiBold
                            color: ab.modelData.clear ? Theme.subtext : Theme.text
                        }
                        MouseArea {
                            id: abm
                            anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor
                            onClicked: {
                                const m = ab.modelData, n = c.notif
                                if (m.reply) { c.replying = !c.replying; if (c.replying) Qt.callLater(() => replyField.focusInput()); return }
                                if (m.clear) { c.done(); Notifs.dismiss(n); return }
                                if (m.openIt) { c.done(); Notifs.open(n); return }
                                c.done(); Notifs.invoke(n, m)
                            }
                        }
                    }
                }
            }
        }
    }
    function sendReply() {
        const t = replyField.text.trim()
        if (t === "" || !notif) return
        const n = notif
        replyField.text = ""
        replying = false
        done()
        n.sendInlineReply(t)
    }
}
