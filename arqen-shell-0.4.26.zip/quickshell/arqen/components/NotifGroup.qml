import QtQuick
import QtQuick.Layouts
import qs.config
import qs.services

// All the notifications from one app, like a phone:
//  - one: just its card
//  - several, closed: the newest on top of a stack (the edges of the others peek out under it),
//    with how many there are where the arrow would be. Click the number to open the stack;
//    swipe the stack away to clear all of them
//  - open: the app's name with an arrow to close it again, then every card (each opens on its own)
Item {
    id: g
    property var group: ({ key: "", items: [] })
    readonly property var items: group.items || []
    readonly property int n: items.length
    readonly property bool open: n > 1 && Notifs.groupOpen(group.key)
    implicitHeight: open ? openCol.implicitHeight : topCard.implicitHeight + (n > 1 ? Math.min(2, n - 1) * 7 : 0)
    Behavior on implicitHeight { NumberAnimation { duration: 260; easing.type: Easing.OutCubic } }
    clip: false

    // ---- closed ----
    Item {
        anchors.fill: parent
        visible: !g.open
        // the stack's edges under the top card
        Repeater {
            model: g.n > 1 ? Math.min(2, g.n - 1) : 0
            delegate: Rectangle {
                required property int index
                z: -1 - index
                width: g.width - 24 * (index + 1)
                x: 12 * (index + 1)
                height: topCard.height
                y: 7 * (index + 1)
                radius: Math.min(height / 2, 38)
                color: topCard.base
                opacity: 0.75 - index * 0.25
            }
        }
        NotifCard {
            id: topCard
            width: g.width
            notif: g.items[0] ?? null
            remember: true
            count: g.n
            swipeClears: g.n <= 1
            onCountClicked: Notifs.toggleGroup(g.group.key)
            onSwiped: if (g.n > 1) Notifs.dismissAll(g.items)
        }
    }

    // ---- open ----
    ColumnLayout {
        id: openCol
        visible: g.open
        width: g.width
        spacing: 8
        // the app, and the arrow to close the stack
        RowLayout {
            Layout.fillWidth: true
            Layout.leftMargin: 16; Layout.rightMargin: 8
            spacing: 8
            DText { text: Notifs.appName(g.items[0]); font.pixelSize: 13; font.weight: Font.DemiBold; color: Theme.text }
            Item { Layout.fillWidth: true }
            Rectangle {
                width: Sizes.hS; height: Sizes.hS; radius: Sizes.hS / 2
                color: clearMa.containsMouse ? Theme.hover : "transparent"
                Icon { anchors.centerIn: parent; name: "clear_all"; size: Sizes.iconM; color: Theme.subtext }
                MouseArea { id: clearMa; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: Notifs.dismissAll(g.items) }
                HoverTip { hovered: clearMa.containsMouse; text: "Clear all from " + Notifs.appName(g.items[0]) }
            }
            Rectangle {
                width: Sizes.hS; height: Sizes.hS; radius: Sizes.hS / 2
                color: closeMa.containsMouse ? Theme.hover : "transparent"
                Icon { anchors.centerIn: parent; name: "expand_less"; size: Sizes.iconM; color: Theme.subtext }
                MouseArea { id: closeMa; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: Notifs.toggleGroup(g.group.key) }
            }
        }
        Repeater {
            model: g.open ? g.items : []
            delegate: NotifCard {
                id: oc
                required property var modelData
                required property int index
                Layout.fillWidth: true
                notif: modelData
                remember: true
                // they fan out from the stack
                opacity: 0
                Component.onCompleted: fan.start()
                SequentialAnimation {
                    id: fan
                    PauseAnimation { duration: index * 35 }
                    NumberAnimation { target: oc; property: "opacity"; to: 1; duration: 220; easing.type: Easing.OutCubic }
                }
            }
        }
    }
}
