import Quickshell
import QtQuick
import qs.config
import qs.services

// The clock widget (desktop, and its preview in Settings). `cfg` is its settings (Widgets.cfg): see
// Widgets.baseTypes.clock for the options; the background, corners, outline and text colour / size are
// the common ones every widget has.
Item {
    id: w
    property var cfg: Widgets.cfg({ type: "clock" })
    readonly property string look: cfg.look || "Solid"

    // The card (background, outline, corners, shadow) hugs what is drawn: the time and date, or the dial, however
    // big or small the widget is made. The widget's own size (its cells on the desktop) only gives the room.
    readonly property string faceKind: cfg.face === "Stacked" ? "stacked" : cfg.face === "Analog" ? "analog" : "digital"
    readonly property real cl: faceKind === "stacked" ? stk.x : faceKind === "analog" ? face.x : dig.x
    readonly property real ct: faceKind === "stacked" ? stk.y : faceKind === "analog" ? face.y : dig.y
    readonly property real cr: faceKind === "stacked" ? stk.x + stk.width : faceKind === "analog" ? (anaCol.visible ? anaCol.x + anaCol.width : face.x + face.width) : dig.x + dig.width
    readonly property real cb: faceKind === "stacked" ? stk.y + stk.height : faceKind === "analog" ? face.y + face.height : dig.y + dig.height
    readonly property real pad: Math.max(10, Math.min(26, Math.round((cb - ct) * 0.14)))
    // where the card is (the desktop draws its edit frame and resize corner there)
    readonly property real hugX: card.x
    readonly property real hugY: card.y
    readonly property real hugW: card.width
    readonly property real hugH: card.height
    Rectangle {
        id: card
        z: -2
        x: Math.max(0, w.cl - w.pad); y: Math.max(0, w.ct - w.pad)
        width: Math.min(w.width - x, w.cr - w.cl + 2 * w.pad)
        height: Math.min(w.height - y, w.cb - w.ct + 2 * w.pad)
        radius: Math.min(Widgets.radiusOf(cfg), Math.round(Math.min(width, height) / 3))
        color: Widgets.bgOf(cfg)
        border.width: Math.min(Widgets.borderW(cfg), Math.max(1, Math.round(Math.min(width, height) / 90)))
        border.color: Widgets.borderCol(cfg)
        WidgetShadow { z: -1; strength: Widgets.shadowA(cfg); cardRadius: card.radius }
    }
    readonly property color fg: Widgets.fgOf(cfg)
    readonly property color subc: Widgets.subOf(cfg)
    // the time's colour: your accent colour, the widget's text colour, or one you pick
    readonly property string timeMode: cfg.timeColor === "Custom" || cfg.timeColor === "Text" ? cfg.timeColor : (cfg.accent === false ? "Text" : "Accent")
    readonly property color timeCol: timeMode === "Custom" ? Qt.color(Widgets.validHex(cfg.timeCustom, "#8FB4FF")) : timeMode === "Text" ? fg : Theme.primary
    // stacked: the minutes in the other colour, unless one colour was picked
    readonly property color minCol: timeMode === "Custom" ? timeCol : timeMode === "Accent" ? fg : Theme.primary
    readonly property real ts: Widgets.ts(cfg)
    // see-through: a soft shadow keeps the text readable on any wallpaper
    readonly property bool clear: look === "Clear"
    readonly property bool h24: cfg.hours === "24-hour" || (cfg.hours !== "12-hour" && Config.c.clock24)
    readonly property int wt: cfg.weight === "Light" ? Font.Light : cfg.weight === "Bold" ? Font.Bold : Font.Medium

    SystemClock { id: clock; precision: w.cfg.seconds ? SystemClock.Seconds : SystemClock.Minutes }
    readonly property date now: clock.date
    // the hour is worked out by hand: 24-hour "15", 12-hour "3" (or "03" when padded), AM / PM from the hour
    function two(n) { return n < 10 ? "0" + n : String(n) }
    function hourOf(pad) { const h = now.getHours(); const v = h24 ? h : (h % 12 === 0 ? 12 : h % 12); return pad || h24 ? two(v) : String(v) }
    readonly property string hm: hourOf(false) + ":" + two(now.getMinutes())
    readonly property string hh: hourOf(true)
    readonly property string ap: !h24 && cfg.ampm !== false ? (now.getHours() < 12 ? "AM" : "PM") : ""
    readonly property real k: Math.min(width / 300, height / 180)
    readonly property string dateText: {
        const f = cfg.dateFormat
        if (f === "Short") return Qt.formatDate(now, "ddd d MMM")
        if (f === "Day only") return Qt.formatDate(now, "dddd")
        if (f === "Numeric") return Qt.formatDate(now, "dd/MM/yyyy")
        return Qt.formatDate(now, width < 220 ? "ddd d MMM" : "dddd, d MMMM")
    }

    readonly property string stackedDay: cfg.dateFormat === "Short" ? Qt.formatDate(now, "ddd") : cfg.dateFormat === "Numeric" ? Qt.formatDate(now, "dd/MM/yyyy") : Qt.formatDate(now, "dddd")
    readonly property string stackedDate: cfg.dateFormat === "Short" ? Qt.formatDate(now, "d MMM") : (cfg.dateFormat === "Day only" || cfg.dateFormat === "Numeric") ? "" : Qt.formatDate(now, "d MMMM")

    // ---- Digital ----
    Column {
        id: dig
        visible: w.cfg.face !== "Stacked" && w.cfg.face !== "Analog"
        readonly property string side: w.cfg.align === "Left" ? "l" : w.cfg.align === "Right" ? "r" : "c"
        anchors.verticalCenter: parent.verticalCenter
        x: side === "l" ? 18 : side === "r" ? w.width - width - 18 : (w.width - width) / 2
        spacing: 2
        Row {
            id: timeRow
            spacing: 4
            DText {
                id: timeTxt
                text: w.hm
                color: w.timeCol
                font.pixelSize: Math.round(Math.min(w.height * (w.cfg.date ? 0.42 : 0.55), w.width * (w.cfg.seconds ? 0.22 : 0.31)) * w.ts)
                font.weight: w.wt
                style: w.clear ? Text.Raised : Text.Normal; styleColor: "#55000000"
            }
            // seconds and AM / PM sit beside the time, their bottom on its baseline (a plain Item: no anchors inside the Row)
            Item {
                visible: w.cfg.seconds || w.ap !== ""
                width: Math.max(secTxt.implicitWidth, apTxt.implicitWidth) + 2
                height: timeTxt.height
                Column {
                    y: Math.max(0, timeTxt.baselineOffset - height)
                    DText {
                        id: secTxt
                        visible: w.cfg.seconds
                        text: Qt.formatTime(w.now, "ss")
                        color: w.subc
                        font.pixelSize: Math.round(Math.min(w.height * 0.18, w.width * 0.09) * w.ts)
                    }
                    DText { id: apTxt; visible: w.ap !== ""; text: w.ap; color: w.subc; font.pixelSize: Math.round(Math.min(w.height * 0.13, w.width * 0.07) * w.ts) }
                }
            }
        }
        DText {
            visible: w.cfg.date
            text: w.dateText
            font.pixelSize: Math.round(Math.max(11, Math.min(w.height * 0.1, w.width * 0.06, 34)) * w.ts)
            width: timeRow.width
            horizontalAlignment: w.cfg.align === "Left" ? Text.AlignLeft : w.cfg.align === "Right" ? Text.AlignRight : Text.AlignHCenter
            color: w.subc
            style: w.clear ? Text.Raised : Text.Normal; styleColor: "#55000000"
        }
    }

    // ---- Stacked: hours over minutes ----
    Row {
        id: stk
        visible: w.cfg.face === "Stacked"
        anchors.centerIn: parent
        spacing: Math.round(14 * w.k)
        Column {
            anchors.verticalCenter: parent.verticalCenter
            spacing: Math.round(-w.height * 0.06)
            DText {
                text: w.hh
                color: w.timeCol; font.weight: w.cfg.weight === "Light" ? Font.Normal : Font.Bold
                font.pixelSize: Math.round(w.height * (w.height > 120 ? 0.36 : 0.42) * w.ts)
                style: w.clear ? Text.Raised : Text.Normal; styleColor: "#55000000"
            }
            DText {
                text: Qt.formatTime(w.now, "mm")
                color: w.minCol; font.weight: w.cfg.weight === "Light" ? Font.Normal : Font.Bold
                font.pixelSize: Math.round(w.height * (w.height > 120 ? 0.36 : 0.42) * w.ts)
                style: w.clear ? Text.Raised : Text.Normal; styleColor: "#55000000"
            }
        }
        Column {
            visible: w.cfg.date && w.width > 200
            anchors.verticalCenter: parent.verticalCenter
            spacing: 2
            // the date in the format picked (Long: Saturday / 17 October, Short: Sat / 17 Oct, Day only: Saturday, Numeric: 17/10/2026)
            DText { text: w.stackedDay; color: w.fg; font.pixelSize: Math.round(Math.max(13, 20 * w.k) * w.ts); font.weight: Font.DemiBold }
            DText { visible: w.stackedDate !== ""; text: w.stackedDate; color: w.subc; font.pixelSize: Math.round(Math.max(12, 16 * w.k) * w.ts) }
            DText { visible: w.cfg.seconds; text: Qt.formatTime(w.now, "ss") + " s"; color: w.subc; font.pixelSize: Math.round(Math.max(11, 14 * w.k) * w.ts) }
        }
    }

    // ---- Analog ----
    Item {
        id: face
        visible: w.cfg.face === "Analog"
        readonly property real d: Math.min(w.height - 20, (w.cfg.date && w.width > w.height * 1.6) ? w.width * 0.5 : w.width - 20)
        width: d; height: d
        x: (w.cfg.date && w.width > w.height * 1.6) ? w.width * 0.08 : (w.width - d) / 2
        anchors.verticalCenter: parent.verticalCenter
        Rectangle { anchors.fill: parent; radius: width / 2; color: Qt.rgba(w.fg.r, w.fg.g, w.fg.b, 0.06); border.width: 2; border.color: Qt.rgba(w.fg.r, w.fg.g, w.fg.b, 0.18) }
        // the hour marks
        Repeater {
            model: w.cfg.marks === "Ticks" || w.cfg.marks === undefined ? 12 : 0
            delegate: Rectangle {
                required property int index
                width: index % 3 === 0 ? 3 : 2; height: index % 3 === 0 ? face.d * 0.09 : face.d * 0.05
                radius: 1
                color: Qt.rgba(w.fg.r, w.fg.g, w.fg.b, index % 3 === 0 ? 0.7 : 0.35)
                x: face.d / 2 - width / 2; y: face.d * 0.05
                transform: Rotation { origin.x: width / 2; origin.y: face.d / 2 - face.d * 0.05; angle: index * 30 }
            }
        }
        // the hour numbers
        Repeater {
            model: w.cfg.marks === "Numbers" ? 12 : 0
            delegate: DText {
                required property int index
                readonly property real a: (index + 1) * 30 * Math.PI / 180
                text: index + 1
                color: w.fg; opacity: 0.85
                font.pixelSize: Math.round(face.d * 0.11 * w.ts); font.weight: Font.Medium
                x: face.d / 2 + Math.sin(a) * face.d * 0.38 - width / 2
                y: face.d / 2 - Math.cos(a) * face.d * 0.38 - height / 2
            }
        }
        // hands: [length, thickness, angle, colour]
        Repeater {
            model: [
                [0.27, 5, ((w.now.getHours() % 12) + w.now.getMinutes() / 60) * 30, w.fg],
                [0.40, 3.5, (w.now.getMinutes() + w.now.getSeconds() / 60) * 6, w.timeCol === w.fg ? w.fg : Theme.primary],
                [0.43, 1.5, w.now.getSeconds() * 6, Theme.primary]
            ]
            delegate: Rectangle {
                required property var modelData
                required property int index
                visible: index < 2 || w.cfg.seconds
                width: modelData[1]; height: face.d * modelData[0]
                radius: width / 2
                color: modelData[3]
                antialiasing: true
                x: face.d / 2 - width / 2; y: face.d / 2 - height
                transform: Rotation { origin.x: width / 2; origin.y: height; angle: modelData[2] }
            }
        }
        Rectangle { anchors.centerIn: parent; width: 9; height: 9; radius: 4.5; color: Theme.primary }
    }
    Column {
        id: anaCol
        visible: w.cfg.face === "Analog" && w.cfg.date && w.width > w.height * 1.6
        anchors.left: face.right; anchors.leftMargin: w.width * 0.07
        anchors.verticalCenter: parent.verticalCenter
        spacing: 2
        DText { text: w.hm + (w.ap !== "" ? " " + w.ap : ""); color: w.timeCol; font.pixelSize: Math.round(Math.max(18, 34 * w.k) * w.ts); font.weight: w.wt }
        DText { text: Qt.formatDate(w.now, "dddd"); color: w.fg; font.pixelSize: Math.round(Math.max(12, 16 * w.k) * w.ts) }
        DText { text: Qt.formatDate(w.now, "d MMMM"); color: w.subc; font.pixelSize: Math.round(Math.max(11, 14 * w.k) * w.ts) }
    }
}
