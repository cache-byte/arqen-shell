import QtQuick
import qs.config

// A number wheel like a phone's time picker: the chosen number big in the middle, the ones before and after it
// faded above and below. Drag it, use the mouse wheel, or click a neighbour. It wraps round (23 -> 00).
Item {
    id: tw
    property int value: 0
    property int count: 60                 // 24 for hours, 60 for minutes
    property bool twelve: false            // 12-hour: 0 shows as 12
    property color accentColor: Theme.primary
    property real rowH: 54
    signal moved(int v)
    implicitWidth: 120
    implicitHeight: rowH * 3
    clip: true

    property real acc: 0                   // how far it is dragged from the middle (px)
    function pad(n) { return (n < 10 ? "0" : "") + n }
    function wrap(n) { return ((n % count) + count) % count }
    function step(d) { tw.moved(wrap(tw.value + d)) }      // the owner sets `value` (kept as a binding)
    Behavior on acc { enabled: !ma.pressed; NumberAnimation { duration: 260; easing.type: Easing.OutBack; easing.overshoot: Motion.os(1.4) } }

    Repeater {
        model: [-2, -1, 0, 1, 2]
        delegate: DText {
            required property int modelData
            readonly property real dist: Math.abs(modelData + tw.acc / tw.rowH)
            width: tw.width; height: tw.rowH
            horizontalAlignment: Text.AlignHCenter; verticalAlignment: Text.AlignVCenter
            y: tw.height / 2 - tw.rowH / 2 + (modelData * tw.rowH) + tw.acc
            text: tw.pad(tw.twelve && tw.wrap(tw.value + modelData) === 0 ? 12 : tw.wrap(tw.value + modelData))
            font.pixelSize: Math.round(tw.rowH * (dist < 0.5 ? 0.84 : 0.74))
            font.weight: dist < 0.5 ? Font.DemiBold : Font.Medium
            color: dist < 0.5 ? tw.accentColor : Theme.subtext
            opacity: Math.max(0.08, 1 - dist * 0.62)
        }
    }
    MouseArea {
        id: ma
        anchors.fill: parent
        property real py: 0
        property real moved: 0
        onPressed: mouse => { py = mouse.y; moved = 0 }
        onPositionChanged: mouse => {
            if (!pressed) return
            const dy = mouse.y - py
            py = mouse.y
            moved += Math.abs(dy)
            tw.acc += dy
            while (tw.acc > tw.rowH / 2) { tw.acc -= tw.rowH; tw.step(-1) }
            while (tw.acc < -tw.rowH / 2) { tw.acc += tw.rowH; tw.step(1) }
        }
        onReleased: { tw.acc = 0 }
        onClicked: mouse => {
            if (moved > 6) return
            const d = Math.round((mouse.y - tw.height / 2) / tw.rowH)
            if (d !== 0) tw.step(d)
        }
        onWheel: wheel => tw.step(wheel.angleDelta.y > 0 ? -1 : 1)
    }
}
