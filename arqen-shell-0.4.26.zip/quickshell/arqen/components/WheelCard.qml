import QtQuick
import qs.config

// A card with one to three number wheels side by side (hours and minutes, or hours, minutes and seconds), the
// chosen row lit by a band across them. The owner keeps the numbers in `values` and changes them on moved().
Rectangle {
    id: wc
    property var counts: [24, 60]
    property var values: [0, 0]
    property var units: ["hr", "min"]
    property bool twelveFirst: false        // the first wheel is a 12-hour clock (0 shows as 12)
    property real rowH: 48
    default property alias extra: extraLayer.data
    signal moved(int index, int value)
    implicitHeight: rowH * 3 + 16
    radius: 26
    color: Theme.tile
    // the band that lights the chosen row
    Rectangle {
        x: 10; width: parent.width - 20; height: wc.rowH - 4; radius: 16
        anchors.verticalCenter: parent.verticalCenter
        color: Theme.tileOn
    }
    Row {
        x: 8; y: 8; width: parent.width - 16; height: parent.height - 16
        Repeater {
            model: wc.counts.length
            delegate: Item {
                id: cell
                required property int index
                width: (wc.width - 16) / wc.counts.length; height: wc.rowH * 3
                TimeWheel {
                    anchors.fill: parent
                    rowH: wc.rowH
                    accentColor: Theme.onSecondaryContainer
                    count: wc.counts[cell.index]
                    value: wc.values[cell.index] ?? 0
                    twelve: wc.twelveFirst && cell.index === 0
                    onMoved: v => wc.moved(cell.index, v)
                }
                DText {
                    x: parent.width / 2 + 32; y: (parent.height - height) / 2
                    text: wc.units[cell.index] ?? ""
                    color: Theme.onSecondaryContainer; opacity: 0.7; font.pixelSize: 11
                }
            }
        }
    }
    Item { id: extraLayer; anchors.fill: parent }
}
