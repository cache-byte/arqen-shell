import QtQuick
import qs.config

// An icon that reacts: a small springy pop whenever it changes (e.g. Wi-Fi bars, the speaker's
// waves) or appears. `pulse()` pops it on demand (a volume step).
Icon {
    id: li
    function pulse() { pop.restart() }
    onNameChanged: pop.restart()
    onVisibleChanged: if (visible) pop.restart()
    SequentialAnimation {
        id: pop
        NumberAnimation { target: li; property: "scale"; to: 1.22; duration: 90; easing.type: Easing.OutCubic }
        NumberAnimation { target: li; property: "scale"; to: 1; duration: 340; easing.type: Easing.OutBack; easing.overshoot: Motion.os(2.2) }
    }
}
