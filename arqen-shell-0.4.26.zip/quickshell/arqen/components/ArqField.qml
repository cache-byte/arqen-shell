import QtQuick
import qs.config

Rectangle {
    id: f
    property alias text: input.text
    property string placeholder: ""
    property string iconName: ""
    property bool password: false
    signal accepted()
    signal edited()
    signal nav(int key)
    signal escaped()
    property bool navSideways: false       // Left/Right always go to the result list (a grid), not the text cursor
    property bool closesOnEscape: true     // Escape closes the popup it is in
    readonly property bool hasFocus: input.activeFocus
    function focusInput() { input.forceActiveFocus() }

    readonly property bool tight: width < 220   // narrow field: smaller padding and text so the placeholder fits
    implicitHeight: Sizes.hM
    implicitWidth: 240
    radius: height / 2
    color: Theme.dark ? Qt.rgba(1, 1, 1, 0.10) : Qt.rgba(0, 0, 0, 0.07)
    border.width: input.activeFocus ? 2 : 0
    border.color: Theme.accent

    Row {
        anchors.fill: parent
        anchors.leftMargin: f.tight ? 12 : (f.iconName !== "" ? Sizes.padM - 4 : Sizes.padM); anchors.rightMargin: f.tight ? 12 : Sizes.padM
        spacing: f.tight ? Sizes.gapS * 2 : Sizes.gapM
        Icon { visible: f.iconName !== ""; name: f.iconName; size: f.tight ? Sizes.iconS : Sizes.iconM; color: Theme.subtext; anchors.verticalCenter: parent.verticalCenter }
        Item {
            width: parent.width - (f.iconName !== "" ? (f.tight ? Sizes.iconS + 8 : Sizes.iconM + Sizes.gapM) : 0); height: parent.height
            DText { visible: input.text === ""; text: f.placeholder; color: Theme.subtext; anchors.verticalCenter: parent.verticalCenter; font.pixelSize: f.tight ? Sizes.textS : Sizes.textM }
            TextInput {
                id: input
                anchors.fill: parent
                verticalAlignment: TextInput.AlignVCenter
                color: Theme.text
                font.family: Theme.font
                font.pixelSize: f.tight ? Sizes.textS : Sizes.textM
                clip: true
                selectByMouse: true
                echoMode: f.password ? TextInput.Password : TextInput.Normal
                onAccepted: f.accepted()
                onTextEdited: f.edited()
                Keys.onEscapePressed: { f.escaped(); if (f.closesOnEscape) Ui.close() }
                Keys.onPressed: event => {
                    const k = event.key
                    if (k === Qt.Key_Up || k === Qt.Key_Down || ((k === Qt.Key_Left || k === Qt.Key_Right) && (f.navSideways || input.text === ""))) {
                        f.nav(k); event.accepted = true
                    }
                }
            }
        }
    }
}
