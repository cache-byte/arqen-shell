import QtQuick
import QtQuick.Shapes
import qs.config

// Loading animation: a pill-shaped track with a bright stroke running around it, like a light
// chasing its own tail. Size it with width / height (wider than tall); it runs while visible.
Item {
    id: lp
    implicitWidth: 40
    implicitHeight: 22
    property color color: Theme.text
    property color track: Qt.rgba(color.r, color.g, color.b, 0.22)
    property real stroke: Math.max(2.5, height * 0.24)
    property int duration: 1300
    property bool running: visible

    readonly property real r: Math.max(0.5, (height - stroke) / 2)
    readonly property real straight: Math.max(0, width - height)
    readonly property real perim: 2 * straight + 2 * Math.PI * r
    // the bright part: a bit over a third of the way round, breathing a little as it goes
    property real phase: 0
    NumberAnimation on phase { from: 0; to: 1; duration: lp.duration; loops: Animation.Infinite; running: lp.running }
    readonly property real seg: perim * (0.38 + 0.12 * Math.sin(phase * Math.PI * 2))

    // corners of the straight parts (the path is the middle of the stroke)
    readonly property real x0: stroke / 2 + r
    readonly property real x1: width - stroke / 2 - r
    readonly property real y0: stroke / 2
    readonly property real y1: height - stroke / 2

    Shape {
        anchors.fill: parent
        // drawn at 4x size and scaled down, multisampled: smooth curves even when small
        layer.enabled: true
        layer.samples: 8
        layer.smooth: true
        layer.mipmap: true
        layer.textureSize: Qt.size(Math.max(1, width * 4), Math.max(1, height * 4))            // smooth edges

        ShapePath {
            strokeColor: lp.track; strokeWidth: lp.stroke; fillColor: "transparent"
            capStyle: ShapePath.RoundCap; joinStyle: ShapePath.RoundJoin
            startX: lp.x0; startY: lp.y0
            PathLine { x: lp.x1; y: lp.y0 }
            PathArc { x: lp.x1; y: lp.y1; radiusX: lp.r; radiusY: lp.r }
            PathLine { x: lp.x0; y: lp.y1 }
            PathArc { x: lp.x0; y: lp.y0; radiusX: lp.r; radiusY: lp.r }
        }
        ShapePath {
            strokeColor: lp.color; strokeWidth: lp.stroke; fillColor: "transparent"
            capStyle: ShapePath.RoundCap; joinStyle: ShapePath.RoundJoin
            strokeStyle: ShapePath.DashLine
            // one dash and one gap that add up to the whole way round, so it loops seamlessly
            dashPattern: [lp.seg / lp.stroke, (lp.perim - lp.seg) / lp.stroke]
            dashOffset: -lp.phase * lp.perim / lp.stroke
            startX: lp.x0; startY: lp.y0
            PathLine { x: lp.x1; y: lp.y0 }
            PathArc { x: lp.x1; y: lp.y1; radiusX: lp.r; radiusY: lp.r }
            PathLine { x: lp.x0; y: lp.y1 }
            PathArc { x: lp.x0; y: lp.y0; radiusX: lp.r; radiusY: lp.r }
        }
    }
}
