import QtQuick
import qs.config

// Click it, then type: each key you press lights up while it is down. Still until you type.
// (Other programs can't read a keyboard directly, so this shows what reaches this window.)
FocusScope {
    id: kt
    implicitWidth: 520
    implicitHeight: board.height + 34
    property var down: ({})
    property string last: ""

    readonly property color body: Theme.dark ? "#2A2A31" : "#E4E4EA"
    readonly property color edge: Theme.dark ? "#3E3E48" : "#C4C4CE"
    readonly property color key: Theme.dark ? "#1C1C22" : "#F7F7FA"
    readonly property color lit: Theme.primary

    readonly property var rows: [
        [["Esc", 1], ["1", 1], ["2", 1], ["3", 1], ["4", 1], ["5", 1], ["6", 1], ["7", 1], ["8", 1], ["9", 1], ["0", 1], ["-", 1], ["=", 1], ["⌫", 2]],
        [["Tab", 1.5], ["Q", 1], ["W", 1], ["E", 1], ["R", 1], ["T", 1], ["Y", 1], ["U", 1], ["I", 1], ["O", 1], ["P", 1], ["[", 1], ["]", 1], ["\\", 1.5]],
        [["Caps", 1.75], ["A", 1], ["S", 1], ["D", 1], ["F", 1], ["G", 1], ["H", 1], ["J", 1], ["K", 1], ["L", 1], [";", 1], ["'", 1], ["Enter", 2.25]],
        [["Shift", 2.25], ["Z", 1], ["X", 1], ["C", 1], ["V", 1], ["B", 1], ["N", 1], ["M", 1], [",", 1], [".", 1], ["/", 1], ["Shift ", 2.75]],
        [["Ctrl", 1.5], ["Super", 1.25], ["Alt", 1.25], ["Space", 6.25], ["AltGr", 1.25], ["Menu", 1.25], ["Ctrl ", 2.25]]
    ]
    // a key press -> the key's label above (by its position on a US keyboard, so any layout works)
    readonly property var scan: ({
        9: "Esc", 10: "1", 11: "2", 12: "3", 13: "4", 14: "5", 15: "6", 16: "7", 17: "8", 18: "9", 19: "0", 20: "-", 21: "=", 22: "⌫",
        23: "Tab", 24: "Q", 25: "W", 26: "E", 27: "R", 28: "T", 29: "Y", 30: "U", 31: "I", 32: "O", 33: "P", 34: "[", 35: "]", 51: "\\",
        66: "Caps", 38: "A", 39: "S", 40: "D", 41: "F", 42: "G", 43: "H", 44: "J", 45: "K", 46: "L", 47: ";", 48: "'", 36: "Enter",
        50: "Shift", 52: "Z", 53: "X", 54: "C", 55: "V", 56: "B", 57: "N", 58: "M", 59: ",", 60: ".", 61: "/", 62: "Shift ",
        37: "Ctrl", 133: "Super", 64: "Alt", 65: "Space", 108: "AltGr", 135: "Menu", 105: "Ctrl "
    })
    function nameOf(e) {
        const s = scan[e.nativeScanCode]
        if (s) return s
        if (e.key === Qt.Key_Escape) return "Esc"
        if (e.key === Qt.Key_Return || e.key === Qt.Key_Enter) return "Enter"
        if (e.key === Qt.Key_Space) return "Space"
        if (e.key === Qt.Key_Backspace) return "⌫"
        if (e.key === Qt.Key_Tab || e.key === Qt.Key_Backtab) return "Tab"
        if (e.key === Qt.Key_Shift) return "Shift"
        if (e.key === Qt.Key_Control) return "Ctrl"
        if (e.key === Qt.Key_Alt) return "Alt"
        if (e.key >= Qt.Key_A && e.key <= Qt.Key_Z) return String.fromCharCode(e.key)
        if (e.key >= Qt.Key_0 && e.key <= Qt.Key_9) return String.fromCharCode(e.key)
        return ""
    }
    Keys.onPressed: e => {
        const n = nameOf(e)
        if (n !== "") { const d = Object.assign({}, down); d[n] = true; down = d }
        last = e.text && e.text.trim() !== "" ? "“" + e.text + "”" : (n || "a key")
        e.accepted = true
    }
    Keys.onReleased: e => {
        if (e.isAutoRepeat) { e.accepted = true; return }
        const n = nameOf(e)
        const d = Object.assign({}, down); delete d[n]; down = d
        e.accepted = true
    }
    onActiveFocusChanged: if (!activeFocus) down = ({})

    MouseArea { anchors.fill: parent; cursorShape: Qt.IBeamCursor; onClicked: kt.forceActiveFocus() }

    Rectangle {
        id: board
        anchors.horizontalCenter: parent.horizontalCenter
        width: Math.min(parent.width, 560); height: width * 0.34
        radius: 12
        color: kt.body; border.width: 1.5; border.color: kt.activeFocus ? kt.lit : kt.edge
        readonly property real u: (width - 16) / 15
        Column {
            x: 8; y: 8; spacing: board.u * 0.12
            Repeater {
                model: kt.rows
                delegate: Row {
                    id: kr
                    required property var modelData
                    spacing: board.u * 0.12
                    Repeater {
                        model: kr.modelData
                        delegate: Rectangle {
                            required property var modelData
                            readonly property bool on: kt.down[modelData[0]] === true
                            width: board.u * modelData[1] - board.u * 0.12; height: board.u * 0.88
                            radius: 4
                            color: on ? kt.lit : kt.key
                            border.width: 1; border.color: on ? kt.lit : kt.edge
                            Text {
                                anchors.centerIn: parent
                                text: parent.modelData[0].trim()
                                color: parent.on ? Theme.onPrimary : Theme.subtext
                                font.pixelSize: Math.max(7, Math.round(board.u * (parent.modelData[0].length > 1 ? 0.24 : 0.34)))
                                font.family: Theme.font
                            }
                        }
                    }
                }
            }
        }
    }
    Text {
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.top: board.bottom; anchors.topMargin: 10
        text: kt.activeFocus ? (kt.last !== "" ? "You pressed " + kt.last : "Type something") : "Click the keyboard, then type"
        color: Theme.subtext; font.pixelSize: 12; font.family: Theme.font
    }
}
