import Quickshell
import Quickshell.Widgets
import QtQuick
import qs.services

// An app's icon, drawn the same way everywhere (launcher, search, dock, desktop):
//  - always exactly `size` x `size`, whatever size the icon theme has (small 16/22 px theme icons
//    used to show up tiny, others edge to edge)
//  - loaded at twice the size so it stays sharp, scaled smoothly
//  - inside a rounded square, so square "photo" icons (players, cameras) get soft corners
//    like the rest instead of hard edges
ClippingRectangle {
    id: ai
    property var entry: null
    property string source: ""              // instead of entry: any icon name or path
    property int size: 48
    width: size; height: size
    implicitWidth: size; implicitHeight: size
    radius: Math.round(size * 0.22)
    color: "transparent"

    // the file found for it; if that cannot be drawn, Qt's own icon lookup
    readonly property string primarySrc: ai.source !== "" ? Apps.iconFor(ai.source) : Apps.icon(ai.entry)
    readonly property string fallbackSrc: Apps.themed(ai.source !== "" ? ai.source : (ai.entry?.icon ?? ""))
    property bool failed: false
    onPrimarySrcChanged: failed = false
    Image {
        anchors.fill: parent
        source: ai.failed ? ai.fallbackSrc : ai.primarySrc
        onStatusChanged: if (status === Image.Error && !ai.failed) ai.failed = true
        sourceSize: Qt.size(ai.size * 2, ai.size * 2)
        fillMode: Image.PreserveAspectFit
        smooth: true
        mipmap: true
        asynchronous: true
    }
}
