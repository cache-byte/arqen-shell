import QtQuick

// A drawing layer: freehand pen, highlighter, arrow, rectangle, ellipse. Used over the frozen screen in the
// capture screen (drawn into the picture) and by the draw overlay (shown over the desktop, so it is in
// screen recordings). `interactive` lets it take the pointer itself; otherwise call press / move / release.
Item {
    id: ac
    property string tool: "pen"            // pen | marker | arrow | rect | ellipse
    property color color: "#FF3B30"
    property real lineW: 5
    property bool interactive: false
    property var strokes: []
    property var cur: null
    readonly property bool hasAny: strokes.length > 0 || cur !== null

    function press(x, y) { cur = { tool: tool, color: String(color), w: lineW, pts: [{ x: x, y: y }] }; cv.requestPaint() }
    function move(x, y) {
        if (!cur) return
        const p = cur.pts
        if (cur.tool === "pen" || cur.tool === "marker") p.push({ x: x, y: y }); else p[1] = { x: x, y: y }
        cv.requestPaint()
    }
    function release() {
        if (!cur) return
        const s = cur; cur = null
        // a click without moving makes no mark (except a dot with the pen)
        if (s.pts.length > 1 || s.tool === "pen" || s.tool === "marker") strokes = strokes.concat([s])
        cv.requestPaint()
    }
    function undo() { if (strokes.length > 0) { strokes = strokes.slice(0, -1); cv.requestPaint() } }
    function clear() { strokes = []; cur = null; cv.requestPaint() }

    Canvas {
        id: cv
        anchors.fill: parent
        antialiasing: true
        onPaint: {
            const ctx = getContext("2d")
            ctx.reset()
            const all = ac.cur ? ac.strokes.concat([ac.cur]) : ac.strokes
            for (const s of all) {
                const p = s.pts
                ctx.save()
                ctx.lineCap = "round"; ctx.lineJoin = "round"
                ctx.strokeStyle = s.color; ctx.fillStyle = s.color
                ctx.lineWidth = s.tool === "marker" ? s.w * 3.5 : s.w
                if (s.tool === "marker") { ctx.globalAlpha = 0.35; ctx.lineCap = "butt" }
                if (s.tool === "pen" || s.tool === "marker") {
                    ctx.beginPath()
                    ctx.moveTo(p[0].x, p[0].y)
                    if (p.length === 1) ctx.lineTo(p[0].x + 0.01, p[0].y)
                    for (let i = 1; i < p.length; i++) ctx.lineTo(p[i].x, p[i].y)
                    ctx.stroke()
                } else if (p.length > 1) {
                    const a = p[0], b = p[1]
                    if (s.tool === "rect") {
                        ctx.strokeRect(Math.min(a.x, b.x), Math.min(a.y, b.y), Math.abs(b.x - a.x), Math.abs(b.y - a.y))
                    } else if (s.tool === "ellipse") {
                        ctx.beginPath()
                        ctx.ellipse(Math.min(a.x, b.x), Math.min(a.y, b.y), Math.abs(b.x - a.x), Math.abs(b.y - a.y))
                        ctx.stroke()
                    } else if (s.tool === "arrow") {
                        const ang = Math.atan2(b.y - a.y, b.x - a.x)
                        const head = Math.max(14, s.w * 3.6)
                        // the line stops short of the tip so the head is not blunted by its width
                        ctx.beginPath()
                        ctx.moveTo(a.x, a.y)
                        ctx.lineTo(b.x - Math.cos(ang) * head * 0.6, b.y - Math.sin(ang) * head * 0.6)
                        ctx.stroke()
                        ctx.beginPath()
                        ctx.moveTo(b.x, b.y)
                        ctx.lineTo(b.x - head * Math.cos(ang - 0.45), b.y - head * Math.sin(ang - 0.45))
                        ctx.lineTo(b.x - head * Math.cos(ang + 0.45), b.y - head * Math.sin(ang + 0.45))
                        ctx.closePath()
                        ctx.fill()
                    }
                }
                ctx.restore()
            }
        }
    }
    MouseArea {
        anchors.fill: parent
        enabled: ac.interactive
        cursorShape: Qt.CrossCursor
        preventStealing: true
        onPressed: mouse => ac.press(mouse.x, mouse.y)
        onPositionChanged: mouse => ac.move(mouse.x, mouse.y)
        onReleased: ac.release()
        onCanceled: ac.release()
    }
}
