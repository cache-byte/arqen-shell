import QtQuick
import qs.config
import qs.components

// The drawing tools: what to draw with, colour, thickness, undo and clear. Controls an AnnotCanvas.
Rectangle {
    id: bar
    property var canvas: null
    property alias extra: extraRow.data           // more buttons at the end
    implicitWidth: row.implicitWidth + 20
    implicitHeight: 40
    radius: height / 2
    color: Qt.rgba(0.08, 0.08, 0.1, 0.86)
    border.width: 1; border.color: Qt.rgba(1, 1, 1, 0.14)
    // keep clicks on the bar from drawing underneath it
    MouseArea { anchors.fill: parent }

    readonly property var tools: [["pen", "edit", "Pen"], ["marker", "ink_highlighter", "Highlighter"], ["arrow", "north_east", "Arrow"],
                                  ["rect", "crop_square", "Rectangle"], ["ellipse", "circle", "Circle"]]
    readonly property var colors: ["#FF3B30", "#FFCC00", "#34C759", "#0A84FF", "#FFFFFF", "#111111"]
    readonly property var widths: [3, 5, 9]

    Row {
        id: row
        anchors.centerIn: parent
        spacing: 4
        Repeater {
            model: bar.tools
            delegate: Rectangle {
                id: tb
                required property var modelData
                width: 32; height: 32; radius: 16
                color: bar.canvas && bar.canvas.tool === modelData[0] ? Qt.rgba(1, 1, 1, 0.26) : (tma.containsMouse ? Qt.rgba(1, 1, 1, 0.12) : "transparent")
                Icon { anchors.centerIn: parent; name: tb.modelData[1]; size: 16; color: "white" }
                MouseArea { id: tma; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: bar.canvas.tool = tb.modelData[0] }
                HoverTip { hovered: tma.containsMouse; text: tb.modelData[2]; side: "top" }
            }
        }
        Rectangle { width: 1; height: 22; anchors.verticalCenter: parent.verticalCenter; color: Qt.rgba(1, 1, 1, 0.2) }
        Repeater {
            model: bar.colors
            delegate: Item {
                id: cb
                required property string modelData
                width: 26; height: 34
                Rectangle {
                    anchors.centerIn: parent
                    width: bar.canvas && String(bar.canvas.color).toLowerCase() === cb.modelData.toLowerCase() ? 22 : 17; height: width; radius: width / 2
                    color: cb.modelData
                    border.width: 2; border.color: bar.canvas && String(bar.canvas.color).toLowerCase() === cb.modelData.toLowerCase() ? "white" : Qt.rgba(1, 1, 1, 0.35)
                    Behavior on width { NumberAnimation { duration: 90 } }
                }
                MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor; onClicked: bar.canvas.color = cb.modelData }
            }
        }
        Rectangle { width: 1; height: 22; anchors.verticalCenter: parent.verticalCenter; color: Qt.rgba(1, 1, 1, 0.2) }
        Repeater {
            model: bar.widths
            delegate: Item {
                id: wb
                required property real modelData
                width: 28; height: 34
                Rectangle {
                    anchors.centerIn: parent
                    width: 8 + wb.modelData * 1.4; height: width; radius: width / 2
                    color: bar.canvas && bar.canvas.lineW === wb.modelData ? "white" : Qt.rgba(1, 1, 1, 0.4)
                }
                MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor; onClicked: bar.canvas.lineW = wb.modelData }
            }
        }
        Rectangle { width: 1; height: 22; anchors.verticalCenter: parent.verticalCenter; color: Qt.rgba(1, 1, 1, 0.2) }
        Rectangle {
            width: 32; height: 32; radius: 16
            color: uma.containsMouse ? Qt.rgba(1, 1, 1, 0.12) : "transparent"
            opacity: bar.canvas && bar.canvas.hasAny ? 1 : 0.4
            Icon { anchors.centerIn: parent; name: "undo"; size: 16; color: "white" }
            MouseArea { id: uma; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: bar.canvas.undo() }
            HoverTip { hovered: uma.containsMouse; text: "Undo"; side: "top" }
        }
        Rectangle {
            width: 32; height: 32; radius: 16
            color: dma.containsMouse ? Qt.rgba(1, 1, 1, 0.12) : "transparent"
            opacity: bar.canvas && bar.canvas.hasAny ? 1 : 0.4
            Icon { anchors.centerIn: parent; name: "delete"; size: 16; color: "white" }
            MouseArea { id: dma; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: bar.canvas.clear() }
            HoverTip { hovered: dma.containsMouse; text: "Clear all"; side: "top" }
        }
        Row { id: extraRow; spacing: 4 }
    }
}
