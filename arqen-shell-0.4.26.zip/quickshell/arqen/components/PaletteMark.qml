import QtQuick
import Quickshell.Widgets
import qs.config

// A small squircle showing the three colour roles: primary on the left half, secondary top right,
// tertiary bottom right.
ClippingRectangle {
    id: pm
    property real size: 44
    property color c1: Theme.primary
    property color c2: Theme.secondary
    property color c3: Theme.tertiary
    width: size; height: size
    radius: size * 0.32
    color: c1
    antialiasing: true
    Rectangle { x: pm.size / 2; y: 0; width: pm.size / 2; height: pm.size / 2; color: pm.c2 }
    Rectangle { x: pm.size / 2; y: pm.size / 2; width: pm.size / 2; height: pm.size / 2; color: pm.c3 }
}
