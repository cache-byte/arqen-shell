import QtQuick
import qs.config

Rectangle {
    id: b
    property string icon: ""
    property bool active: false
    property int size: 22
    property string tip: ""             // name shown after hovering (HoverTip)
    property string tipSide: "top"
    property color restColor: "transparent"   // background when not pointed at
    property bool round: false
    signal clicked()
    // button size follows the icon plus the panel "item padding" setting
    implicitWidth: size + Config.c.itemPadding * 2 + 4
    implicitHeight: implicitWidth
    radius: round ? width / 2 : Math.min(12, width / 2)
    color: active ? Theme.hover : (ma.containsMouse ? Theme.hover : restColor)
    Behavior on color { ColorAnimation { duration: 120 } }
    Icon {
        anchors.centerIn: parent; name: b.icon; size: b.size
        // a little pop when pointed at, a squeeze when pressed
        scale: ma.pressed ? 0.82 : (ma.containsMouse ? 1.08 : 1)
        Behavior on scale { NumberAnimation { duration: 260; easing.type: Easing.OutBack; easing.overshoot: Motion.os(2.5) } }
    }
    MouseArea { id: ma; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: b.clicked() }
    HoverTip { hovered: ma.containsMouse; text: b.tip; side: b.tipSide }
}
