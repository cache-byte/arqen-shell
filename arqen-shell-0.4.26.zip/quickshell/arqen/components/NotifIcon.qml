import Quickshell
import Quickshell.Widgets
import QtQuick
import qs.config
import qs.services

// A notification's picture, like a phone's: the app's icon in a rounded square; for a message from
// someone, their picture with the app's icon as a small badge in the corner.
// The icon is found, in order: what the app sent (a theme name or a file, unless the file is gone),
// the app's own icon (its desktop entry), a small square picture that came with it (some browsers
// send their icon that way), and last the app's first letter on an accent-coloured square.
Item {
    id: ni
    property var notif: null
    property int size: 44
    property string iconPic: ""             // a small square picture that is really an icon (NotifCard finds it)
    implicitWidth: size; implicitHeight: size

    readonly property string pic: Notifs.imageOf(notif)
    readonly property bool chat: Notifs.isChat(notif) && pic !== "" && iconPic === ""
    readonly property string iconName: Notifs.iconOf(notif)
    readonly property var entry: Notifs.entryOf(notif)
    readonly property string letter: (Notifs.appName(notif) || "?").charAt(0).toUpperCase()

    // (inline components do not see this file's ids: what they need is passed in)
    component AppPic: Item {
        id: ap
        property string name: ""
        property var entry: null
        property string extra: ""            // a picture to use when nothing else is found
        property string letter: "?"
        property int size: 44
        width: size; height: size
        readonly property bool isFile: name.startsWith("/") || name.startsWith("file:") || name.startsWith("image:")
        // which one shows: 0 = the file, 1 = a theme icon / the app's icon, 2 = the extra picture, 3 = the letter
        readonly property int pick: isFile && fileImg.status !== Image.Error ? 0
                                  : (!isFile && name !== "") || entry !== null ? 1
                                  : extra !== "" ? 2 : 3
        ClippingRectangle {
            anchors.fill: parent
            radius: Math.round(ap.size * 0.28)
            color: "transparent"
            visible: ap.pick === 0 || ap.pick === 2
            Image {
                id: fileImg
                anchors.fill: parent
                source: ap.isFile ? (ap.name.startsWith("/") ? "file://" + ap.name : ap.name) : ""
                visible: ap.pick === 0
                sourceSize: Qt.size(ap.size * 2, ap.size * 2)
                fillMode: Image.PreserveAspectCrop
                asynchronous: true
            }
            Image {
                anchors.fill: parent
                visible: ap.pick === 2
                source: ap.pick === 2 ? ap.extra : ""
                sourceSize: Qt.size(ap.size * 2, ap.size * 2)
                fillMode: Image.PreserveAspectFit
                asynchronous: true
            }
        }
        AppIcon {
            anchors.fill: parent
            size: ap.size
            visible: ap.pick === 1
            // the app's own icon when it is installed (the surest), else the theme name it sent
            entry: ap.entry !== null ? ap.entry : null
            source: ap.entry !== null ? "" : (ap.isFile ? "" : ap.name)
            radius: Math.round(ap.size * 0.28)
        }
        Rectangle {
            anchors.fill: parent
            visible: ap.pick === 3
            radius: Math.round(ap.size * 0.28)
            color: Theme.primaryContainer
            Text {
                anchors.centerIn: parent
                text: ap.letter
                color: Theme.onPrimaryContainer
                font.pixelSize: Math.round(ap.size * 0.46); font.bold: true
                renderType: Text.QtRendering
            }
        }
    }

    // the person's picture
    ClippingRectangle {
        visible: ni.chat
        anchors.fill: parent
        radius: Math.round(ni.size * 0.28)
        color: Theme.tile
        Image {
            anchors.fill: parent
            source: ni.chat ? ni.pic : ""
            sourceSize: Qt.size(ni.size * 2, ni.size * 2)
            fillMode: Image.PreserveAspectCrop
            asynchronous: true
        }
    }
    AppPic {
        visible: !ni.chat
        size: ni.size
        name: ni.iconName
        entry: ni.entry
        extra: ni.iconPic
        letter: ni.letter
    }
    // the app as a badge on the person's picture
    Rectangle {
        visible: ni.chat
        width: Math.round(ni.size * 0.46); height: width
        radius: width / 2
        x: ni.size - width + Math.round(ni.size * 0.08)
        y: ni.size - height + Math.round(ni.size * 0.08)
        color: Theme.cardSolid
        AppPic {
            anchors.centerIn: parent
            size: parent.width - 4
            name: ni.iconName
            entry: ni.entry
            letter: ni.letter
        }
    }
}
