import QtQuick
import qs.config

// "Nothing here yet": a faint icon and a line of text, centred in the room it is given.
Item {
    id: es
    property string icon: "inbox"
    property string text: ""
    implicitHeight: 96
    Column {
        anchors.centerIn: parent
        spacing: 6
        Rectangle {
            anchors.horizontalCenter: parent.horizontalCenter
            width: 48; height: 48; radius: 24; color: Theme.tile
            Icon { anchors.centerIn: parent; name: es.icon; size: 24; color: Theme.subtext }
        }
        DText { anchors.horizontalCenter: parent.horizontalCenter; text: es.text; color: Theme.subtext; font.pixelSize: 13 }
    }
}
