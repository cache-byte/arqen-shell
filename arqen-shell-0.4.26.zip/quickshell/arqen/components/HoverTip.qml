import Quickshell
import QtQuick
import qs.config

// The name of something, shown next to it after the pointer has rested on it for a while
// (Settings > System > Name tips; half a second by default). A tip is a name and, under it, a very short
// description of what the thing does: written as "Name\nWhat it does", or given as `desc`, or taken from the
// list below when the name is a known one. Moving on to the next thing right after a tip shows its tip at once.
// Put one inside the item and bind `hovered` to its MouseArea / HoverHandler.
//   side: where the tip appears: "top" | "bottom" | "left" | "right"
Item {
    id: t
    property bool hovered: false
    property string text: ""
    property string side: "top"
    property Item target: parent
    property string desc: ""
    property bool ready: false

    // what common things do, in a few words (looked up by name)
    readonly property var known: ({
        "Wi-Fi": "Wireless networks", "Bluetooth": "Pair and connect devices", "Sound": "Volume and output device",
        "Do not disturb": "Silence pop-ups", "Dark mode": "Switch light and dark", "Screen filters": "Night light and colour filters",
        "Caffeine": "Keep the screen awake", "Capture": "Screenshot or screen recording",
        "Desktops": "Switch between desktops", "Lock": "Lock the screen", "Battery": "Power mode and charge", "Output": "Choose where sound plays",
        "Brightness": "Screen brightness", "Volume": "Output volume",
        "Maximise": "Fill the screen, panels stay", "Full screen": "Cover the whole screen", "Close the window": "Close this window",
        "Back": "Go back", "Undo": "Take back the last mark", "Clear all": "Remove every mark",
        "Pen": "Draw freehand", "Highlighter": "See-through marker", "Arrow": "Point at something", "Rectangle": "Draw a box", "Circle": "Draw a circle"
    })
    readonly property string nameLine: text.indexOf("\n") >= 0 ? text.slice(0, text.indexOf("\n")) : text
    readonly property string descLine: desc !== "" ? desc : (text.indexOf("\n") >= 0 ? text.slice(text.indexOf("\n") + 1) : (known[text] || ""))

    // right after another tip: no wait (moving along a row of buttons)
    Timer { id: wait; interval: 500; onTriggered: t.ready = true }
    onHoveredChanged: {
        ready = false
        if (hovered && Config.c.tipsOn) {
            wait.interval = Date.now() - Ui.tipLast < 1500 ? 120 : Math.round(Config.c.tipSeconds * 1000)
            wait.restart()
        } else wait.stop()
    }
    onReadyChanged: if (ready) Ui.tipLast = Date.now()
    Component.onDestruction: if (ready) Ui.tipLast = Date.now()
    onTextChanged: if (text === "") ready = false

    readonly property int edge: side === "bottom" ? Edges.Bottom : side === "left" ? Edges.Left : side === "right" ? Edges.Right : Edges.Top

    PopupWindow {
        visible: t.ready && t.hovered && t.text !== "" && t.target !== null && t.target.visible
        anchor.item: t.target
        anchor.edges: t.edge
        anchor.gravity: t.edge
        anchor.margins.top: t.side === "top" ? -6 : 0
        anchor.margins.bottom: t.side === "bottom" ? -6 : 0
        anchor.margins.left: t.side === "left" ? -6 : 0
        anchor.margins.right: t.side === "right" ? -6 : 0
        implicitWidth: bubble.width
        implicitHeight: bubble.height
        color: "transparent"
        mask: Region {}              // never takes the pointer, so it can't steal the hover
        Rectangle {
            id: bubble
            width: Math.min(360, Math.max(label.implicitWidth, dlabel.visible ? dlabel.implicitWidth : 0) + 22)
            height: tipCol.implicitHeight + 14
            radius: 10
            color: Theme.panel
            border.width: 1
            border.color: Theme.stroke
            Column {
                id: tipCol
                anchors.centerIn: parent
                spacing: 1
                DText {
                    id: label
                    width: Math.min(implicitWidth, 340)
                    text: t.nameLine
                    font.pixelSize: 12
                    font.weight: t.descLine !== "" ? Font.Medium : Font.Normal
                    wrapMode: Text.Wrap
                }
                DText {
                    id: dlabel
                    visible: t.descLine !== ""
                    width: Math.min(implicitWidth, 340)
                    text: t.descLine
                    font.pixelSize: 11
                    color: Theme.subtext
                    wrapMode: Text.Wrap
                }
            }
        }
    }
}
