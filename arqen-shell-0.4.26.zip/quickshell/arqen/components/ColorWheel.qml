import QtQuick
import QtQuick.Shapes
import qs.config

// A colour wheel: hue around the circle, saturation from the middle out, and a brightness bar
// underneath. `color` is shown; `picked(hex)` fires while you drag (at most every 60 ms, so the
// whole shell is not recoloured on every pixel of movement) and once more when you let go.
Item {
    id: w
    property color color: "#3E91FF"
    property real size: 172
    signal picked(string hex)

    implicitWidth: size
    implicitHeight: size + 34

    // what is shown: follows `color`, except while you are dragging
    property real hh: 0
    property real ss: 0
    property real vv: 1
    property bool dragging: false
    function syncFromColor() {
        if (dragging) return
        const h = w.color.hsvHue
        if (h >= 0) hh = h
        ss = w.color.hsvSaturation
        vv = w.color.hsvValue
    }
    onColorChanged: syncFromColor()
    Component.onCompleted: syncFromColor()

    function hex(c) {
        const f = x => ("0" + Math.round(Math.max(0, Math.min(1, x)) * 255).toString(16)).slice(-2)
        return "#" + f(c.r) + f(c.g) + f(c.b)
    }
    property string pending: ""
    function emit() { pending = hex(Qt.hsva(hh, ss, vv, 1)); if (!throttle.running) { w.picked(pending); pending = ""; throttle.start() } }
    Timer { id: throttle; interval: 60; onTriggered: if (w.pending !== "") { w.picked(w.pending); w.pending = "" } }

    readonly property real r: size / 2

    // ---- the wheel ----
    Item {
        id: wheel
        width: w.size; height: w.size
        // hue around the circle (a conical gradient), fading to white in the middle (a radial one):
        // white at the centre over the hue at the edge is exactly saturation = distance / radius
        Shape {
            id: disc
            anchors.fill: parent
            layer.enabled: true
            layer.samples: 8
            preferredRendererType: Shape.CurveRenderer
            ShapePath {
                strokeWidth: -1
                fillGradient: ConicalGradient {
                    centerX: w.r; centerY: w.r; angle: 0
                    GradientStop { position: 0.000; color: "#FF0000" }
                    GradientStop { position: 0.167; color: "#FFFF00" }
                    GradientStop { position: 0.333; color: "#00FF00" }
                    GradientStop { position: 0.500; color: "#00FFFF" }
                    GradientStop { position: 0.667; color: "#0000FF" }
                    GradientStop { position: 0.833; color: "#FF00FF" }
                    GradientStop { position: 1.000; color: "#FF0000" }
                }
                PathAngleArc { centerX: w.r; centerY: w.r; radiusX: w.r; radiusY: w.r; startAngle: 0; sweepAngle: 360 }
            }
            ShapePath {
                strokeWidth: -1
                fillGradient: RadialGradient {
                    centerX: w.r; centerY: w.r; centerRadius: w.r
                    focalX: w.r; focalY: w.r; focalRadius: 0
                    GradientStop { position: 0; color: "#FFFFFFFF" }
                    GradientStop { position: 1; color: "#00FFFFFF" }
                }
                PathAngleArc { centerX: w.r; centerY: w.r; radiusX: w.r; radiusY: w.r; startAngle: 0; sweepAngle: 360 }
            }
        }
        // brightness: a darkening veil over the wheel
        Rectangle { anchors.fill: parent; radius: width / 2; color: "black"; opacity: 1 - w.vv; antialiasing: true }
        // the picked spot
        Rectangle {
            width: 22; height: 22; radius: 11
            x: w.r + Math.cos(w.hh * 2 * Math.PI) * w.ss * (w.r - 1) - width / 2
            y: w.r - Math.sin(w.hh * 2 * Math.PI) * w.ss * (w.r - 1) - height / 2
            color: Qt.hsva(w.hh, w.ss, w.vv, 1)
            border.width: 3; border.color: "white"
            antialiasing: true
            Rectangle { anchors.fill: parent; anchors.margins: -1; radius: width / 2; color: "transparent"; border.width: 1; border.color: Qt.rgba(0, 0, 0, 0.35) }
        }
        MouseArea {
            anchors.fill: parent
            preventStealing: true
            cursorShape: Qt.CrossCursor
            function at(mx, my) {
                const dx = mx - w.r, dy = my - w.r
                let h = Math.atan2(-dy, dx) / (2 * Math.PI)
                if (h < 0) h += 1
                w.hh = h
                w.ss = Math.min(1, Math.sqrt(dx * dx + dy * dy) / w.r)
                if (w.vv < 0.15) w.vv = 1          // picking a colour on a black wheel: show it
                w.emit()
            }
            onPressed: mouse => { w.dragging = true; at(mouse.x, mouse.y) }
            onPositionChanged: mouse => { if (pressed) at(mouse.x, mouse.y) }
            onReleased: { w.dragging = false; throttle.stop(); w.picked(w.hex(Qt.hsva(w.hh, w.ss, w.vv, 1))) }
            onCanceled: w.dragging = false
        }
    }

    // ---- brightness ----
    Rectangle {
        id: vbar
        y: w.size + 14
        width: w.size; height: 14; radius: 7
        gradient: Gradient {
            orientation: Gradient.Horizontal
            GradientStop { position: 0; color: "black" }
            GradientStop { position: 1; color: Qt.hsva(w.hh, w.ss, 1, 1) }
        }
        border.width: 1; border.color: Theme.stroke
        Rectangle {
            width: 20; height: 20; radius: 10
            anchors.verticalCenter: parent.verticalCenter
            x: w.vv * (parent.width - width)
            color: Qt.hsva(w.hh, w.ss, w.vv, 1)
            border.width: 3; border.color: "white"
        }
        MouseArea {
            anchors { fill: parent; margins: -8 }
            preventStealing: true
            function at(mx) { w.vv = Math.max(0, Math.min(1, (mx - 8) / vbar.width)); w.emit() }
            onPressed: mouse => { w.dragging = true; at(mouse.x) }
            onPositionChanged: mouse => { if (pressed) at(mouse.x) }
            onReleased: { w.dragging = false; throttle.stop(); w.picked(w.hex(Qt.hsva(w.hh, w.ss, w.vv, 1))) }
            onCanceled: w.dragging = false
        }
    }
}
