import QtQuick
import qs.config

// A number that animates each time it changes (the countdown's seconds).
// style: "Pop" (grows and settles) | "Slide" (the old one rises away, the new one comes up) |
//        "Flip" (turns over like a flip clock) | "Fade" (cross-fade) | "Roll" (spins in) | "None"
// speed: 1 = normal; 2 = twice as fast
Item {
    id: tn
    property int value: 0
    property string style: "Pop"
    property real speed: 1
    property color color: "white"
    property int pixelSize: 64
    property int weight: Font.DemiBold
    implicitWidth: Math.max(cur.implicitWidth, old.implicitWidth)
    implicitHeight: cur.implicitHeight

    // set by hand (a binding to value could update before the change is seen, losing the old number)
    property int shown: 0
    property int was: 0
    Component.onCompleted: { shown = value; was = value }
    function dur(ms) { return Math.max(30, Math.round(ms / Math.max(0.25, speed))) }
    onValueChanged: {
        was = shown; shown = value
        pop.stop(); slide.stop(); flip.stop(); fade.stop(); roll.stop()
        reset()
        if (style === "Pop") pop.restart()
        else if (style === "Slide") slide.restart()
        else if (style === "Flip") flip.restart()
        else if (style === "Fade") fade.restart()
        else if (style === "Roll") roll.restart()
    }
    function reset() {
        cur.opacity = 1; cur.y = 0; cur.scale = 1; cur.rotation = 0; curRot.angle = 0
        old.opacity = 0; old.y = 0; oldRot.angle = 0
    }
    DText {
        id: old
        anchors.horizontalCenter: parent.horizontalCenter
        renderType: Text.QtRendering
        text: tn.was
        color: tn.color; font.pixelSize: tn.pixelSize; font.weight: tn.weight
        opacity: 0
        transform: Rotation { id: oldRot; axis.x: 1; axis.y: 0; axis.z: 0; origin.x: old.width / 2; origin.y: old.height / 2 }
    }
    DText {
        id: cur
        anchors.horizontalCenter: parent.horizontalCenter
        renderType: Text.QtRendering
        text: tn.shown
        color: tn.color; font.pixelSize: tn.pixelSize; font.weight: tn.weight
        transform: Rotation { id: curRot; axis.x: 1; axis.y: 0; axis.z: 0; origin.x: cur.width / 2; origin.y: cur.height / 2 }
    }

    SequentialAnimation {
        id: pop
        NumberAnimation { target: cur; property: "scale"; to: 1.14; duration: tn.dur(90); easing.type: Easing.OutCubic }
        NumberAnimation { target: cur; property: "scale"; to: 1; duration: tn.dur(380); easing.type: Easing.OutBack; easing.overshoot: Motion.os(2) }
    }
    ParallelAnimation {
        id: slide
        NumberAnimation { target: old; property: "y"; from: 0; to: -tn.height * 0.55; duration: tn.dur(300); easing.type: Easing.InCubic }
        NumberAnimation { target: old; property: "opacity"; from: 1; to: 0; duration: tn.dur(260) }
        NumberAnimation { target: cur; property: "y"; from: tn.height * 0.55; to: 0; duration: tn.dur(380); easing.type: Easing.OutBack }
        NumberAnimation { target: cur; property: "opacity"; from: 0; to: 1; duration: tn.dur(300) }
    }
    SequentialAnimation {
        id: flip
        ScriptAction { script: { old.opacity = 1; cur.opacity = 0 } }
        NumberAnimation { target: oldRot; property: "angle"; from: 0; to: 90; duration: tn.dur(150); easing.type: Easing.InQuad }
        ScriptAction { script: { old.opacity = 0; cur.opacity = 1 } }
        NumberAnimation { target: curRot; property: "angle"; from: -90; to: 0; duration: tn.dur(260); easing.type: Easing.OutBack; easing.overshoot: Motion.os(1.6) }
    }
    ParallelAnimation {
        id: fade
        NumberAnimation { target: old; property: "opacity"; from: 1; to: 0; duration: tn.dur(320) }
        NumberAnimation { target: cur; property: "opacity"; from: 0; to: 1; duration: tn.dur(320) }
    }
    ParallelAnimation {
        id: roll
        NumberAnimation { target: cur; property: "rotation"; from: -120; to: 0; duration: tn.dur(420); easing.type: Easing.OutBack }
        NumberAnimation { target: cur; property: "scale"; from: 0.4; to: 1; duration: tn.dur(420); easing.type: Easing.OutBack }
        NumberAnimation { target: cur; property: "opacity"; from: 0; to: 1; duration: tn.dur(200) }
    }
}
