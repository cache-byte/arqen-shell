import QtQuick
import qs.config

// A scroll bar for a Flickable / ListView: `ArqScrollBar { flick: theFlickable }` as its sibling. It only shows when the
// content is longer than the view, is faint until you scroll or point at it, and can be dragged.
Item {
    id: sb
    property Item flick: null
    property real topInset: 4
    property real bottomInset: 4
    readonly property real total: flick ? flick.contentHeight : 0
    readonly property real view: flick ? flick.height : 0
    readonly property bool needed: flick !== null && total > view + 1
    visible: needed
    z: 60
    width: 12
    anchors { right: flick ? flick.right : undefined; top: flick ? flick.top : undefined; bottom: flick ? flick.bottom : undefined
              rightMargin: 3; topMargin: sb.topInset; bottomMargin: sb.bottomInset }
    readonly property real track: Math.max(1, height)
    readonly property real thumbH: Math.max(36, Math.min(track, track * view / Math.max(1, total)))
    readonly property real range: Math.max(1, total - view)
    readonly property bool active: (flick && (flick.moving || flick.flicking)) || ma.containsMouse || ma.pressed

    Rectangle {
        id: thumb
        width: ma.containsMouse || ma.pressed ? 8 : 5
        radius: width / 2
        anchors.right: parent.right
        height: sb.thumbH
        y: (sb.track - sb.thumbH) * Math.max(0, Math.min(1, (sb.flick ? sb.flick.contentY - sb.flick.originY : 0) / sb.range))
        color: Theme.subtext
        opacity: sb.active ? 0.75 : 0.28
        Behavior on opacity { NumberAnimation { duration: 160 } }
        Behavior on width { NumberAnimation { duration: 100 } }
    }
    MouseArea {
        id: ma
        anchors { top: parent.top; bottom: parent.bottom; right: parent.right }
        width: 14
        hoverEnabled: true
        preventStealing: true
        property real grab: 0
        onPressed: mouse => {
            // on the thumb: keep the spot; on the track: jump so the thumb is centred on the click
            if (mouse.y >= thumb.y && mouse.y <= thumb.y + thumb.height) grab = mouse.y - thumb.y
            else { grab = thumb.height / 2; move(mouse.y) }
        }
        onPositionChanged: mouse => { if (pressed) move(mouse.y) }
        function move(py) {
            const f = Math.max(0, Math.min(1, (py - grab) / Math.max(1, sb.track - sb.thumbH)))
            sb.flick.contentY = sb.flick.originY + f * sb.range
        }
    }
}
