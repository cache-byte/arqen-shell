import QtQuick
import QtQuick.Shapes
import qs.config
import qs.services

// One drawing of the beat for everywhere (the panel's music item, the music card, the desktop media widget).
// Nothing in it ever MOVES sideways or jumps: every bar, dot and point has a fixed place and only its height, size
// or brightness follows the beat (the values are already smoothed by Beat). Fill the space it is given.
//   kind: Bars (grow up from the baseline) | Mirror (grow both ways from the middle) | Dots (a dot-matrix
//         equaliser) | Wave (one smooth line that swings with the beat) | Blob (a soft round shape that swells, like ferrofluid)
//   tint: Accent | Text | Rainbow
Item {
    id: v
    property string kind: "Bars"
    property int n: 12
    property string tint: "Accent"
    property color accent: Theme.primary
    property color text: Theme.text
    property real sens: 1
    property bool live: Media.playing            // paused: everything rests low and still
    property real rest: 0.06                     // the height (0..1) of a resting bar
    readonly property string k: kind === "Blob" ? "Blob" : kind
    // one value (0..1) per bar, read again for every frame of the beat
    readonly property var vals: {
        const a = new Array(n)
        for (let i = 0; i < n; i++) a[i] = live ? Math.max(rest, Math.min(1, Beat.bar(i, n, 0) * sens)) : rest
        return a
    }
    function col(i, cnt) { return Beat.tint(tint, i, cnt, accent, text) }

    // ---- Bars / Mirror ----
    readonly property bool barsKind: k === "Bars" || k === "Mirror"
    readonly property real gap: Math.max(2, Math.min(4, width / (n * 4)))
    readonly property real bw: Math.max(2, (width - gap * (n - 1)) / n)
    Repeater {
        model: v.barsKind ? v.n : 0
        delegate: Rectangle {
            required property int index
            readonly property real val: v.vals[index] ?? 0
            x: Math.round(index * (v.bw + v.gap)); width: Math.round(v.bw); radius: width / 2
            height: Math.max(width, val * v.height)
            y: v.k === "Mirror" ? (v.height - height) / 2 : v.height - height
            color: v.col(index, v.n)
        }
    }

    // ---- Dots: a dot-matrix equaliser, mirrored about the middle row; the dots stay put, only their brightness changes ----
    readonly property int rows: Math.max(3, Math.min(9, Math.floor(height / 5) % 2 === 0 ? Math.floor(height / 5) - 1 : Math.floor(height / 5)))
    readonly property real dd: Math.max(2, Math.min(width / v.n * 0.7, height / rows * 0.78))
    Repeater {
        model: v.k === "Dots" ? v.n * v.rows : 0
        delegate: Rectangle {
            required property int index
            readonly property int c: Math.floor(index / v.rows)
            readonly property int r: index % v.rows
            readonly property real mid: (v.rows - 1) / 2
            readonly property real val: v.vals[c] ?? 0
            // lit while it is within the bar's reach, fading at its edge
            readonly property real lit: Math.max(0, Math.min(1, val * (mid + 1) + 0.15 - Math.abs(r - mid)))
            width: v.dd; height: v.dd; radius: width / 2
            x: (c + 0.5) * (v.width / v.n) - width / 2
            y: (r + 0.5) * (v.height / v.rows) - height / 2
            color: v.col(c, v.n)
            opacity: 0.14 + 0.86 * lit
        }
    }

    // ---- Wave: one smooth line that swings up and down through every bar's place; how far it swings follows the beat ----
    readonly property int steps: 6
    readonly property var waveLine: {
        if (k !== "Wave") return []
        const pts = []
        const m = Math.max(2, n), cnt = (m - 1) * steps
        const amp = Math.max(1, (height - lineW) / 2)
        for (let j = 0; j <= cnt; j++) {
            const f = j / steps, i = Math.min(m - 2, Math.floor(f)), t = f - i
            const s = (1 - Math.cos(t * Math.PI)) / 2                      // eased between two neighbours: no corners
            const a = vals[i] ?? 0, b = vals[i + 1] ?? 0
            const level = a + (b - a) * s
            // the line crosses the middle between the bars and peaks (up, then down, ...) on each one
            const swing = Math.cos(f * Math.PI)
            pts.push(Qt.point(j / cnt * width, height / 2 - swing * level * amp))
        }
        return pts
    }
    readonly property real lineW: Math.max(2, Math.min(4, height * 0.16))
    Shape {
        anchors.fill: parent
        visible: v.k === "Wave"
        layer.enabled: visible; layer.samples: 4
        ShapePath {
            strokeColor: v.col(Math.floor(v.n / 2), v.n)
            strokeWidth: v.lineW
            fillColor: "transparent"
            capStyle: ShapePath.RoundCap; joinStyle: ShapePath.RoundJoin
            PathPolyline { path: v.waveLine }
        }
    }

    // ---- Blob: a round shape whose edge swells with the bars, turning slowly (like a drop of ferrofluid) ----
    property real spin: 0
    NumberAnimation on spin { from: 0; to: 2 * Math.PI; duration: 24000; loops: Animation.Infinite; running: v.k === "Blob" && v.live && v.visible }
    readonly property int blobPts: 72
    readonly property var blobPath: {
        if (k !== "Blob") return []
        const pts = [], R = Math.min(width, height) / 2, cx = width / 2, cy = height / 2
        const m = Math.max(4, n)
        for (let j = 0; j <= blobPts; j++) {
            const th = j / blobPts * 2 * Math.PI
            // the loudness at this angle: the bars wrap round the circle, mirrored so the shape is balanced
            const u = Math.abs(((th + spin) / (2 * Math.PI)) % 1 * 2 - 1) * (m - 1)
            const i = Math.min(m - 2, Math.floor(u)), t = u - i
            const s = (1 - Math.cos(t * Math.PI)) / 2
            const a = vals[i] ?? 0, b = vals[i + 1] ?? 0
            const r = R * (0.5 + 0.5 * (a + (b - a) * s))
            pts.push(Qt.point(cx + Math.cos(th) * r, cy + Math.sin(th) * r))
        }
        return pts
    }
    Shape {
        anchors.fill: parent
        visible: v.k === "Blob"
        layer.enabled: visible; layer.samples: 4
        ShapePath {
            strokeColor: "transparent"
            fillColor: Qt.rgba(v.accent.r, v.accent.g, v.accent.b, 0.55)
            PathPolyline { path: v.blobPath }
        }
    }
}
