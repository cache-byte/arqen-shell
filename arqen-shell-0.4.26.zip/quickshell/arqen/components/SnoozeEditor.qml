import QtQuick
import qs.config

// The two snooze choices of an alarm: how long to wait before it rings again, and how many times it may be
// snoozed (Off: it has no snooze button).
Column {
    id: se
    property int minutes: 5
    property int times: 3
    signal edited(int minutes, int times)
    spacing: 6
    DText { text: "When snoozed, ring again after"; color: Theme.subtext; font.pixelSize: 12 }
    Flow {
        width: parent.width; spacing: 6
        Repeater {
            model: [1, 5, 10, 15, 30]
            delegate: ArqButton {
                required property int modelData
                text: modelData + " min"
                primary: se.minutes === modelData
                onClicked: { se.minutes = modelData; se.edited(se.minutes, se.times) }
            }
        }
    }
    DText { text: "Snooze up to"; color: Theme.subtext; font.pixelSize: 12 }
    Flow {
        width: parent.width; spacing: 6
        Repeater {
            model: [0, 1, 3, 5, 10]
            delegate: ArqButton {
                required property int modelData
                text: modelData === 0 ? "Off" : modelData + (modelData === 1 ? " time" : " times")
                primary: se.times === modelData
                onClicked: { se.times = modelData; se.edited(se.minutes, se.times) }
            }
        }
    }
}
