import QtQuick
import QtQuick.Shapes
import QtQuick.Effects

// The lock screen's (and the login screen's) background. Either the picture over the whole screen, blurred and
// darkened as set, or the picture inside a frame shape (heart, circle...) on a plain colour, like a phone's.
// Knows nothing of the rest of the shell: it is given `cfg` (the lock* settings), the accent colour and the
// picture, so the login screen can use it too.
Item {
    id: bg
    property var cfg: ({})
    property color accent: "#7AA2FF"
    property string source: ""              // a file:// url, or "" for none
    property bool preview: false
    property bool light: false              // a light lock screen: it is lightened, not darkened

    readonly property string frame: ["heart", "rounded", "circle", "arch", "blob"].indexOf(cfg.lockFrame) >= 0 ? cfg.lockFrame : "none"
    readonly property bool framed: frame !== "none"
    readonly property real k: Math.max(0.5, Math.min(1.3, (cfg.lockFrameSize || 100) / 100))

    // the colour round a frame
    readonly property color ground: {
        const m = cfg.lockFrameColor
        if (m === "dark") return "#0B0B10"
        if (m === "custom" && /^#[0-9a-fA-F]{6}$/.test(cfg.lockFrameCustom || "")) return cfg.lockFrameCustom
        return Qt.darker(bg.accent, 2.4)
    }

    // the shapes, drawn in a 100 x 100 box
    readonly property var paths: ({
        heart:   "M 50 96 C 12 66 0 42 0 26 C 0 9 14 0 27 0 C 38 0 46 6 50 15 C 54 6 62 0 73 0 C 86 0 100 9 100 26 C 100 42 88 66 50 96 Z",
        rounded: "M 16 0 H 84 Q 100 0 100 16 V 84 Q 100 100 84 100 H 16 Q 0 100 0 84 V 16 Q 0 0 16 0 Z",
        circle:  "M 50 0 A 50 50 0 1 1 50 100 A 50 50 0 1 1 50 0 Z",
        arch:    "M 0 100 V 50 A 50 50 0 0 1 100 50 V 100 Z",
        blob:    "M 52 2 C 78 -2 98 18 98 46 C 102 76 82 100 50 98 C 20 100 -2 76 2 48 C 0 22 24 6 52 2 Z"
    })
    readonly property string roundedPath: {
        const w = boxW, h = boxH, r = Math.min(w, h) * 0.14
        return "M " + r + " 0 H " + (w - r) + " Q " + w + " 0 " + w + " " + r + " V " + (h - r) + " Q " + w + " " + h + " " + (w - r) + " " + h
            + " H " + r + " Q 0 " + h + " 0 " + (h - r) + " V " + r + " Q 0 0 " + r + " 0 Z"
    }
    // where the frame sits: a box under the clock (round ones are square)
    readonly property bool square: frame === "circle" || frame === "blob" || frame === "arch"
    // (the heart keeps its proportions too: stretched wide it looked deformed)
    readonly property real boxH: height * 0.52 * k
    readonly property real boxW: (square || frame === "heart") ? Math.min(boxH, width * 0.9) : Math.min(width * 0.92 * k, width * 0.96)
    readonly property real boxX: (width - boxW) / 2
    readonly property real boxY: height * 0.30

    Image {
        id: pic
        visible: false
        source: bg.source
        width: bg.framed ? bg.boxW : bg.width; height: bg.framed ? bg.boxH : bg.height
        sourceSize: bg.preview ? Qt.size(Math.ceil(bg.width * 1.5), Math.ceil(bg.height * 1.5)) : Qt.size(0, 0)
        fillMode: Image.PreserveAspectCrop
        asynchronous: true
    }

    // ---- picture over everything ----
    MultiEffect {
        anchors.fill: parent
        source: pic
        visible: !bg.framed && pic.status === Image.Ready
        blurEnabled: (bg.cfg.lockBlur ?? 60) > 0
        blur: Math.max(0, Math.min(1, (bg.cfg.lockBlur ?? 60) / 100))
        blurMax: bg.preview ? 24 : 48
    }
    // no picture, or a frame: a plain colour
    Rectangle {
        anchors.fill: parent
        visible: bg.framed || pic.status !== Image.Ready
        color: bg.framed ? bg.ground : "transparent"
        gradient: bg.framed ? null : fallback
    }
    Gradient {
        id: fallback
        GradientStop { position: 0; color: Qt.darker(bg.accent, 3.2) }
        GradientStop { position: 1; color: "#0B0B10" }
    }

    // ---- picture inside the frame ----
    Item {
        id: shape
        visible: false
        x: bg.boxX; y: bg.boxY; width: bg.boxW; height: bg.boxH
        layer.enabled: true
        Shape {
            width: 100; height: 100
            preferredRendererType: Shape.CurveRenderer
            // the other shapes are drawn in a 100 x 100 box and scaled evenly (their box is square); the
            // rounded one is drawn at its real size, so its corners stay round
            transform: Scale { xScale: bg.frame === "rounded" ? 1 : shape.width / 100; yScale: bg.frame === "rounded" ? 1 : shape.height / 100 }
            ShapePath {
                fillColor: "white"; strokeColor: "transparent"
                PathSvg { path: bg.frame === "rounded" ? bg.roundedPath : (bg.paths[bg.frame] || bg.roundedPath) }
            }
        }
    }
    MultiEffect {
        visible: bg.framed && pic.status === Image.Ready
        x: bg.boxX; y: bg.boxY; width: bg.boxW; height: bg.boxH
        source: pic
        maskEnabled: true
        maskSource: shape
        maskThresholdMin: 0.5
        maskSpreadAtMin: 1.0
        // the blur setting applies to the picture inside the frame too
        blurEnabled: (bg.cfg.lockBlur ?? 60) > 0
        blur: Math.max(0, Math.min(1, (bg.cfg.lockBlur ?? 60) / 100))
        blurMax: bg.preview ? 24 : 48
        autoPaddingEnabled: false
    }
    // ...and so does the darkening (inside the shape only, so the colour round it stays as chosen)
    Rectangle { id: dimTint; visible: false; layer.enabled: true; x: bg.boxX; y: bg.boxY; width: bg.boxW; height: bg.boxH; color: bg.light ? "white" : "black" }
    MultiEffect {
        visible: bg.framed && pic.status === Image.Ready
        x: bg.boxX; y: bg.boxY; width: bg.boxW; height: bg.boxH
        source: dimTint
        maskEnabled: true
        maskSource: shape
        opacity: Math.max(0, Math.min(0.9, (bg.cfg.lockDim ?? 25) / 100))
    }
    // no picture: the frame is filled with a lighter shade, so the shape still shows
    MultiEffect {
        visible: bg.framed && pic.status !== Image.Ready
        x: bg.boxX; y: bg.boxY; width: bg.boxW; height: bg.boxH
        source: tint
        maskEnabled: true
        maskSource: shape
    }
    Rectangle { id: tint; visible: false; layer.enabled: true; x: bg.boxX; y: bg.boxY; width: bg.boxW; height: bg.boxH; color: Qt.lighter(bg.ground, 1.5) }

    // darkening (only over a full-screen picture, so the frame colour stays as chosen)
    Rectangle {
        anchors.fill: parent
        color: bg.light ? "white" : "black"
        visible: !bg.framed
        opacity: Math.max(0, Math.min(0.9, (bg.cfg.lockDim ?? 25) / 100))
    }
}
