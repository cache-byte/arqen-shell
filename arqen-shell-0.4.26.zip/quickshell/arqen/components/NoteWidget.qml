import Quickshell
import QtQuick
import qs.config
import qs.services

// A note on the desktop. Click it and type; it is saved when you click elsewhere. Options: Widgets.baseTypes.note.
Rectangle {
    id: w
    property var cfg: Widgets.cfg({ type: "note" })
    property string wid: ""                       // set by the desktop: which widget this is (to save the text)
    radius: Widgets.radiusOf(cfg)
    color: Widgets.bgOf(cfg)
    border.width: Widgets.borderW(cfg)
    border.color: Widgets.borderCol(cfg)
    // shadow behind the card (Shadow option)
    WidgetShadow { z: -1; strength: Widgets.shadowA(cfg); cardRadius: w.radius }
    readonly property color fg: Widgets.fgOf(cfg)
    readonly property color subc: Widgets.subOf(cfg)
    readonly property real ts: Widgets.ts(cfg)

    // The desktop takes the keyboard only while the pointer is on a note (so the click lands), and a note the pointer
    // has left stops taking keys: typing never goes into a note you are not pointing at.
    HoverHandler {
        id: hh
        onHoveredChanged: {
            Widgets.noteHover = hovered
            if (!hovered && edit.activeFocus) edit.focus = false
        }
    }
    Column {
        anchors { fill: parent; margins: 14 }
        spacing: 6
        DText { visible: (w.cfg.title || "") !== ""; width: parent.width; elide: Text.ElideRight; text: w.cfg.title; color: w.fg; font.pixelSize: Math.round(16 * w.ts); font.weight: Font.DemiBold }
        Flickable {
            width: parent.width; height: parent.height - (w.cfg.title ? 28 : 0)
            contentWidth: width; contentHeight: edit.implicitHeight
            clip: true
            boundsBehavior: Flickable.StopAtBounds
            TextEdit {
                id: edit
                width: parent.width
                wrapMode: TextEdit.Wrap
                color: w.fg; selectionColor: Theme.primary; selectedTextColor: Theme.onPrimary
                font.family: w.cfg.mono ? "monospace" : Theme.font
                font.pixelSize: Math.round((w.cfg.fontSize || 15) * w.ts)
                text: w.cfg.text || ""
                // saved when it loses the keyboard (and typing keeps the desktop's keyboard)
                onActiveFocusChanged: {
                    Widgets.typing = activeFocus
                    if (!activeFocus && w.wid !== "" && text !== (w.cfg.text || "")) Widgets.set(w.wid, "text", text)
                }
                Keys.onEscapePressed: edit.focus = false
                DText { visible: edit.text === "" && !edit.activeFocus; text: "Click to write…"; color: w.subc; font: edit.font }
            }
        }
    }
}
