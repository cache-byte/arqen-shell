import QtQuick
import qs.config
import qs.components
import qs.services

// A small on-screen keyboard drawn inside the lock screen (the normal keyboard is a separate window,
// and the lock screen covers every other window). Keys go to the password field through Osk, which
// sends them to the lock screen while it is locked.
Rectangle {
    id: ko
    property real scaleU: 1
    property bool light: false
    readonly property color fg: light ? "#1B1B20" : "white"
    function tint(a) { return light ? Qt.rgba(0, 0, 0, a) : Qt.rgba(1, 1, 1, a) }
    signal hide()
    radius: 22
    color: light ? ko.tint(0.82) : Qt.rgba(0.08, 0.08, 0.1, 0.78)
    border.width: 1; border.color: ko.tint(0.12)

    readonly property var rowsSpec: {
        const r = Osk.rows
        const ch = a => a.map(c => ({ c: c, w: 1 }))
        const out = []
        if (Osk.layer === "letters") {
            out.push(Osk.chars("1234567890").map(c => ({ c: c, w: 1 })).concat([{ k: "BackSpace", i: "backspace", w: 1.5, mod: true }]))
            out.push(ch(r[0]))
            out.push(ch(r[1]).concat([{ k: "Return", i: "keyboard_return", w: 1.8, enter: true }]))
            out.push([{ a: "shift", i: "shift", w: 1.5, mod: true }].concat(ch(r[2])))
            for (let i = 3; i < r.length; i++) out.push(ch(r[i]))
        } else {
            out.push(ch(r[0]).concat([{ k: "BackSpace", i: "backspace", w: 1.5, mod: true }]))
            out.push(ch(r[1]))
            out.push([{ a: Osk.layer === "symbols" ? "sym2" : "sym1", t: Osk.layer === "symbols" ? "=\\<" : "?123", w: 1.5, mod: true }].concat(ch(r[2])).concat([{ k: "Return", i: "keyboard_return", w: 1.8, enter: true }]))
        }
        out.push([
            { a: Osk.layer === "letters" ? "sym1" : "abc", t: Osk.layer === "letters" ? "?123" : "ABC", w: 1.4, mod: true },
            { a: "lang", i: "language", t: Osk.lang.id.toUpperCase(), w: 1.4, mod: true },
            { k: "space", t: Osk.lang.name, w: 5, space: true },
            { a: "hide", i: "keyboard_hide", w: 1.4, mod: true }
        ])
        return out
    }
    function act(s) {
        if (s.c !== undefined) Osk.type(s.c)
        else if (s.k !== undefined) Osk.key(s.k)
        else if (s.a === "shift") Osk.tapShift()
        else if (s.a === "sym1") Osk.layer = "symbols"
        else if (s.a === "sym2") Osk.layer = "symbols2"
        else if (s.a === "abc") Osk.layer = "letters"
        else if (s.a === "lang") Osk.nextLanguage()
        else if (s.a === "hide") ko.hide()
    }

    // keep clicks on the keyboard from reaching what is behind it
    MouseArea { anchors.fill: parent }
    Column {
        id: keysCol
        anchors { fill: parent; margins: 10 }
        spacing: 6
        Repeater {
            model: ko.rowsSpec
            delegate: Item {
                id: rowItem
                required property var modelData
                readonly property real units: modelData.reduce((a, s) => a + s.w, 0)
                readonly property real unit: (width - (modelData.length - 1) * 6) / Math.max(1, units)
                width: keysCol.width
                height: (keysCol.height - (ko.rowsSpec.length - 1) * 6) / ko.rowsSpec.length
                Row {
                    anchors.centerIn: parent
                    spacing: 6
                    Repeater {
                        model: rowItem.modelData
                        delegate: Rectangle {
                            id: key
                            required property var modelData
                            readonly property bool lit: (modelData.a === "shift" && (Osk.shift || Osk.caps))
                            width: rowItem.unit * modelData.w; height: rowItem.height
                            radius: Math.min(14, height / 3)
                            color: modelData.enter ? Theme.primary : lit ? Theme.primary
                                 : kma.pressed ? ko.tint(0.32) : (modelData.mod ? ko.tint(0.10) : ko.tint(0.18))
                            Icon { visible: key.modelData.i !== undefined && !key.modelData.t; anchors.centerIn: parent; name: key.modelData.i || ""; size: Math.min(24, parent.height * 0.5)
                                   color: key.modelData.enter || key.lit ? Theme.onPrimary : ko.fg }
                            DText {
                                visible: key.modelData.i === undefined || !!key.modelData.t
                                anchors.centerIn: parent
                                renderType: Text.QtRendering
                                text: key.modelData.c !== undefined ? Osk.shown_(key.modelData.c) : (key.modelData.t || "")
                                color: ko.fg
                                font.pixelSize: Math.min(22, Math.max(10, key.height * 0.42))
                                elide: Text.ElideRight
                                width: Math.min(implicitWidth, key.width - 4)
                            }
                            MouseArea { id: kma; anchors.fill: parent; onClicked: ko.act(key.modelData) }
                        }
                    }
                }
            }
        }
    }
}
