import QtQuick
import QtQuick.Shapes
import qs.config

// A connected device: what it is (its icon) in a soft circle, with its battery as a ring round it.
// Still: nothing moves unless the battery changes.
Item {
    id: dbg
    property string icon: "bluetooth"
    property real battery: -1                 // 0..1, or -1 when unknown
    property int size: 72
    implicitWidth: size; implicitHeight: size

    Rectangle {
        anchors.fill: parent
        anchors.margins: 6
        radius: width / 2
        color: Theme.secondaryContainer
        Icon { anchors.centerIn: parent; name: dbg.icon; size: Math.round(dbg.size * 0.42); color: Theme.onSecondaryContainer }
    }
    // the battery ring
    Shape {
        anchors.fill: parent
        visible: dbg.battery >= 0
        preferredRendererType: Shape.CurveRenderer
        ShapePath {
            strokeColor: Theme.tile; strokeWidth: 4; fillColor: "transparent"
            PathAngleArc { centerX: dbg.size / 2; centerY: dbg.size / 2; radiusX: dbg.size / 2 - 2; radiusY: radiusX; startAngle: 0; sweepAngle: 360 }
        }
        ShapePath {
            strokeColor: dbg.battery < 0.2 ? "#FF5A5A" : Theme.primary; strokeWidth: 4; fillColor: "transparent"; capStyle: ShapePath.RoundCap
            PathAngleArc { centerX: dbg.size / 2; centerY: dbg.size / 2; radiusX: dbg.size / 2 - 2; radiusY: radiusX; startAngle: -90; sweepAngle: 360 * Math.max(0.02, dbg.battery) }
        }
    }
}
