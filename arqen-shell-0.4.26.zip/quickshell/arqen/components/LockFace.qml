import Quickshell
import Quickshell.Hyprland
import QtQuick
import qs.config
import qs.components
import qs.services

// What the lock screen shows, laid out from Settings > Lock screen: the background, the clock, the
// date, a message, battery and notifications, you and your password, what is playing.
// Used by the lock screen itself and, small, as the preview in Settings (`preview: true`: nothing
// takes the keyboard, sizes follow the box it is in).
Item {
    id: face
    property bool preview: false
    property string status: ""               // "", "checking", "wrong"
    property int shake: 0
    signal submit(string password)
    signal typing()                          // typing again after a wrong password
    function focusField() { if (!preview) pw.forceActiveFocus() }
    // Keys from the on-screen keyboard. Every lock surface (one per screen) gets each key, so the
    // password field you are looking at fills in whichever screen the keyboard was used on.
    // (TextInput.insert takes the position first: without it nothing was typed.)
    Connections { target: Ui; function onLockEventChanged() {
        const event = Ui.lockEvent.v
        if (face.preview || !Ui.locked || !event) return
        if (event.startsWith("char:") || event.startsWith("text:")) pw.insert(pw.cursorPosition, event.slice(5))
        else if (event === "key:BackSpace") pw.remove(Math.max(0, pw.cursorPosition - 1), pw.cursorPosition)
        else if (event === "key:Return") { const t = pw.text; if (t !== "") { pw.text = ""; face.submit(t) } }
        else if (event === "key:space") pw.insert(pw.cursorPosition, " ")
        face.focusField()
    } }

    // Print Screen works on the lock screen too: the screen under the pointer is saved straight to the screenshots folder
    // (the capture screen and the "what to do with it" card cannot be shown over the lock, so it just saves)
    property string shotNote: ""
    function lockShot() {
        const name = Hyprland.focusedMonitor?.name
        const cmd = Config.captureCmd(["shot", name ? "output:" + name : "screen"])
        cmd.splice(cmd.indexOf("sh"), 0, "ARQEN_ASK=0")          // the last value wins: save, do not ask
        Quickshell.execDetached(cmd)
        face.shotNote = "Screenshot saved"
        shotNoteTimer.restart()
    }
    Shortcut { sequence: "Print"; enabled: !face.preview && Ui.locked; onActivated: face.lockShot() }
    Timer { id: shotNoteTimer; interval: 2200; onTriggered: face.shotNote = "" }
    Rectangle {
        visible: face.shotNote !== "" && !face.preview
        z: 60
        anchors { horizontalCenter: parent.horizontalCenter; top: parent.top; topMargin: 28 }
        width: noteRow.implicitWidth + 28; height: 38; radius: 19
        color: face.glass(0.22); border.width: 1; border.color: Qt.rgba(face.fg.r, face.fg.g, face.fg.b, 0.18)
        Row { id: noteRow; anchors.centerIn: parent; spacing: 8
              Icon { name: "screenshot_monitor"; size: 18; color: face.fg; anchors.verticalCenter: parent.verticalCenter }
              DText { text: face.shotNote; color: face.fg; font.pixelSize: 13; anchors.verticalCenter: parent.verticalCenter } }
    }

    readonly property var c: Config.c
    // light or dark: follows the system mode (Settings > Appearance) unless chosen here (Settings > Power and lock)
    readonly property bool light: c.lockMode === "light" || (c.lockMode !== "dark" && !Theme.dark)
    readonly property color fg: light ? "#1B1B20" : "white"
    function glass(a) { return light ? Qt.rgba(1, 1, 1, Math.min(0.9, a * 3.2)) : Qt.rgba(1, 1, 1, a) }
    // the lock screen's own on-screen keyboard (other windows cannot be shown over the lock)
    readonly property bool oskOn: !preview && Ui.locked && Osk.shown
    readonly property real oskH: Math.min(height * 0.42, 300)
    readonly property real oskW: Math.min(width - 24, 920)
    // one unit: a thousandth of the height (of the width, on a tall screen: a rotated screen no longer cuts the clock off)
    readonly property real u: Math.min(height, width * 0.9) / 1000
    readonly property string pic: {
        const p = c.lockImage || c.wallpaper || ""
        return p !== "" && !/\.(mp4|webm|mkv|mov|m4v|avi)$/i.test(p) ? "file://" + p : ""
    }
    readonly property bool framed: bgLayer.framed
    readonly property string align: c.lockClockAlign === "left" || c.lockClockAlign === "right" ? c.lockClockAlign : "center"
    // text on a frame colour or a picture: light, unless the colour is chosen light
    readonly property color dateCol: clockText.colTop

    SystemClock { id: clock; precision: SystemClock.Minutes }

    // ---- background: the picture (blurred and darkened as set, or inside a frame) ----
    LockBackground {
        id: bgLayer
        anchors.fill: parent
        cfg: face.c
        accent: Theme.primary
        source: face.pic
        preview: face.preview
        light: face.light
    }

    // ---- the clock ----
    Column {
        id: clockCol
        readonly property real pad: 70 * face.u
        x: face.align === "left" ? pad : face.align === "right" ? face.width - width - pad : (face.width - width) / 2
        y: face.c.lockClockPlace === "middle" ? (face.height - height) / 2 - 120 * face.u : 90 * face.u
        spacing: 0
        DText {
            visible: face.c.lockShowDate
            anchors.horizontalCenter: parent.horizontalCenter
            renderType: Text.QtRendering
            text: Qt.formatDate(clock.date, face.c.lockDateFormat || "dddd d MMMM")
            color: face.dateCol
            font.pixelSize: Math.max(8, Math.round(40 * face.u)); font.weight: Font.Medium
        }
        LockClockText {
            id: clockText
            anchors.horizontalCenter: parent.horizontalCenter
            cfg: face.c
            light: face.light
            accent: Theme.primary
            family: Theme.font
            date: clock.date
            u: face.u
            h24: face.c.clock24
        }
        DText {
            visible: (face.c.lockMessage || "") !== ""
            anchors.horizontalCenter: parent.horizontalCenter
            width: Math.min(implicitWidth, face.width * 0.7)
            horizontalAlignment: Text.AlignHCenter
            wrapMode: Text.Wrap
            renderType: Text.QtRendering
            text: face.c.lockMessage || ""
            color: face.fg; opacity: 0.85
            font.pixelSize: Math.max(7, Math.round(24 * face.u))
        }
    }

    // ---- battery and notifications waiting ----
    Rectangle {
        x: clockCol.x + (clockCol.width - width) / 2
        y: clockCol.y + clockCol.height + 24 * face.u
        z: 2
        visible: face.c.lockShowInfo && (Power.hasBattery || Notifs.count > 0)
        width: infoRow.implicitWidth + 32 * face.u; height: 44 * face.u; radius: height / 2
        color: face.glass(0.14)
        Row {
            id: infoRow
            anchors.centerIn: parent; spacing: 16 * face.u
            Row {
                visible: Power.hasBattery; spacing: 6 * face.u
                Icon { renderType: Text.QtRendering; name: Power.charging ? "battery_charging_full" : "battery_full"; size: Math.max(6, 20 * face.u); color: face.fg; anchors.verticalCenter: parent.verticalCenter }
                DText { renderType: Text.QtRendering; text: Power.pct + "%"; color: face.fg; font.pixelSize: Math.max(6, Math.round(16 * face.u)); anchors.verticalCenter: parent.verticalCenter }
            }
            Row {
                visible: Notifs.count > 0; spacing: 6 * face.u
                Icon { renderType: Text.QtRendering; name: "notifications"; size: Math.max(6, 20 * face.u); color: face.fg; anchors.verticalCenter: parent.verticalCenter }
                DText { renderType: Text.QtRendering; text: Notifs.count; color: face.fg; font.pixelSize: Math.max(6, Math.round(16 * face.u)); anchors.verticalCenter: parent.verticalCenter }
            }
        }
    }

    // ---- you and your password ----
    Column {
        anchors.horizontalCenter: parent.horizontalCenter
        // higher while the keyboard is up, so the password field is never behind it
        y: face.oskOn ? Math.max(8, Math.min(face.framed ? face.height * 0.80 : face.height * 0.62, face.height - face.oskH - 28 - height))
                      : (face.framed ? face.height * 0.80 : face.height * 0.62)
        Behavior on y { NumberAnimation { duration: 200; easing.type: Easing.OutCubic } }
        spacing: face.framed ? 8 * face.u : 14 * face.u
        z: 3
        Avatar { visible: face.c.lockShowUser && !face.framed; anchors.horizontalCenter: parent.horizontalCenter; size: Math.max(16, Math.round(72 * face.u)) }
        DText {
            visible: face.c.lockShowUser && !face.framed
            anchors.horizontalCenter: parent.horizontalCenter
            renderType: Text.QtRendering
            text: User.name; color: face.fg; font.pixelSize: Math.max(7, Math.round(20 * face.u)); font.weight: Font.Medium
        }
        Rectangle {
            id: field
            anchors.horizontalCenter: parent.horizontalCenter
            width: face.preview ? 330 * face.u : 300; height: face.preview ? 52 * face.u : 48; radius: height / 2
            color: face.glass(0.16)
            border.width: face.preview ? 1 : 2
            border.color: face.status === "wrong" ? "#FF5A5A" : (pw.activeFocus ? Theme.primary : "transparent")
            transform: Translate { id: shakeT }
            TextInput {
                id: pw
                visible: !face.preview
                anchors { fill: parent; leftMargin: 22; rightMargin: 52 }
                clip: true                       // a long password scrolls inside the field instead of spilling out of it
                verticalAlignment: TextInput.AlignVCenter
                echoMode: TextInput.Password
                passwordCharacter: "●"
                color: face.fg; font.pixelSize: 16; font.family: Theme.font
                focus: !face.preview
                enabled: !face.preview && face.status !== "checking"
                onAccepted: { const t = text; text = ""; face.submit(t) }
                onTextChanged: if (text !== "" && face.status === "wrong") face.typing()
                onEnabledChanged: if (enabled) forceActiveFocus()
            }
            DText {
                visible: pw.text === ""
                anchors { left: parent.left; leftMargin: face.preview ? 18 * face.u : 22; verticalCenter: parent.verticalCenter }
                renderType: Text.QtRendering
                text: face.status === "checking" ? "Checking…" : "Password"
                color: Qt.rgba(face.fg.r, face.fg.g, face.fg.b, 0.55); font.pixelSize: face.preview ? Math.max(6, Math.round(17 * face.u)) : 15
            }
            Rectangle {
                visible: !face.preview && face.c.oskOnLock
                anchors { right: parent.right; rightMargin: 48; verticalCenter: parent.verticalCenter }
                width: 32; height: 32; radius: 16
                color: oskMa.containsMouse ? Theme.primary : face.glass(0.12)
                Icon { anchors.centerIn: parent; renderType: Text.QtRendering; name: "keyboard"; size: 18; color: face.fg }
                MouseArea { id: oskMa; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor
                    onClicked: { Osk.shown = !Osk.shown; face.focusField() } }
            }
            Rectangle {
                visible: !face.preview
                anchors { right: parent.right; rightMargin: 6; verticalCenter: parent.verticalCenter }
                width: 32; height: 32; radius: 16
                color: goMa.containsMouse ? Theme.primary : face.glass(0.18)
                Icon { anchors.centerIn: parent; renderType: Text.QtRendering; name: "arrow_forward"; size: 16; color: goMa.containsMouse ? Theme.onPrimary : face.fg }
                MouseArea { id: goMa; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor
                            onClicked: { const t = pw.text; pw.text = ""; face.submit(t) } }
            }
            Connections { target: face; function onShakeChanged() { shakeAnim.restart() } }
            SequentialAnimation {
                id: shakeAnim
                NumberAnimation { target: shakeT; property: "x"; to: -12; duration: 50 }
                NumberAnimation { target: shakeT; property: "x"; to: 10; duration: 70 }
                NumberAnimation { target: shakeT; property: "x"; to: -6; duration: 60 }
                NumberAnimation { target: shakeT; property: "x"; to: 0; duration: 80; easing.type: Easing.OutCubic }
            }
        }
        DText {
            anchors.horizontalCenter: parent.horizontalCenter
            visible: face.status === "wrong"
            renderType: Text.QtRendering
            text: "That is not the password"
            color: "#FF8A8A"; font.pixelSize: 13
        }
    }

    // ---- what is playing ----
    Rectangle {
        visible: face.c.lockShowMedia && (Media.has || face.preview) && !face.oskOn
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.bottom: parent.bottom; anchors.bottomMargin: 32 * face.u
        width: Math.min(face.preview ? face.width * 0.5 : 380, face.width - 80 * face.u); height: 56 * face.u; radius: height / 2
        color: face.glass(0.14)
        Rectangle {
            id: art
            x: 8 * face.u; anchors.verticalCenter: parent.verticalCenter
            width: 40 * face.u; height: width; radius: width / 2; clip: true
            color: face.glass(0.12)
            Image { anchors.fill: parent; source: Media.art; fillMode: Image.PreserveAspectCrop; asynchronous: true; visible: Media.art !== "" }
            Icon { anchors.centerIn: parent; visible: Media.art === ""; name: "music_note"; size: Math.max(6, 20 * face.u); color: face.fg }
        }
        Column {
            anchors { left: art.right; leftMargin: 10 * face.u; right: ctl.left; rightMargin: 6 * face.u; verticalCenter: parent.verticalCenter }
            DText { width: parent.width; elide: Text.ElideRight; renderType: Text.QtRendering; text: Media.has ? Media.title : "What is playing"; color: face.fg; font.pixelSize: Math.max(6, Math.round(14 * face.u)); font.weight: Font.Medium }
            DText { width: parent.width; elide: Text.ElideRight; renderType: Text.QtRendering; text: Media.has ? Media.artist : "Artist"; color: Qt.rgba(face.fg.r, face.fg.g, face.fg.b, 0.65); font.pixelSize: Math.max(5, Math.round(12 * face.u)) }
        }
        Row {
            id: ctl
            anchors { right: parent.right; rightMargin: 8 * face.u; verticalCenter: parent.verticalCenter }
            spacing: 2 * face.u
            Repeater {
                model: [["skip_previous", "prev"], [Media.playing ? "pause" : "play_arrow", "toggle"], ["skip_next", "next"]]
                delegate: Rectangle {
                    required property var modelData
                    width: 36 * face.u; height: width; radius: width / 2
                    color: bma.containsMouse ? face.glass(0.18) : "transparent"
                    Icon { anchors.centerIn: parent; renderType: Text.QtRendering; name: parent.modelData[0]; size: Math.max(6, 22 * face.u); color: face.fg }
                    MouseArea { id: bma; anchors.fill: parent; hoverEnabled: true; enabled: !face.preview
                                onClicked: { const f = parent.modelData[1]; if (f === "prev") Media.prev(); else if (f === "next") Media.next(); else Media.toggle() } }
                }
            }
        }
    }

    LockOsk {
        light: face.light
        visible: face.oskOn
        z: 10
        width: face.oskW; height: face.oskH
        x: (face.width - width) / 2
        y: face.height - height - 12
        onHide: { Osk.shown = false; face.focusField() }
    }
}
