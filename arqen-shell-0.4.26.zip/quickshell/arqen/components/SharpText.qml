import QtQuick
import qs.config

// Text drawn at twice its size and then shrunk to `size`. Colour emoji (and some scripts) are drawn
// from a bitmap at the font size; on a scaled screen that bitmap was blown up and looked blurry.
// Drawn big and shrunk, they stay sharp. Centre it (anchors.centerIn), as its box is twice as big.
Text {
    property real size: 20
    font.pixelSize: Math.round(size * 2)
    font.family: Theme.font
    scale: 0.5
    color: Theme.text
    horizontalAlignment: Text.AlignHCenter
    verticalAlignment: Text.AlignVCenter
}
