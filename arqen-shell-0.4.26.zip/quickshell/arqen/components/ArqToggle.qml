import QtQuick
import qs.config

// The on / off switch used everywhere. Off: an outlined track with a small grey knob and a cross;
// on: a filled track in the accent colour with a large knob and a tick. The knob grows while pressed.
Item {
    id: t
    property bool checked: false
    signal toggled(bool value)
    implicitWidth: 52; implicitHeight: 32
    readonly property bool pressed: ma.pressed

    Rectangle {
        id: track
        anchors.fill: parent
        radius: height / 2
        color: t.checked ? Theme.primary : (Theme.dark ? Qt.rgba(1, 1, 1, 0.08) : Qt.rgba(0, 0, 0, 0.06))
        border.width: t.checked ? 0 : 2
        border.color: Theme.dark ? Qt.rgba(1, 1, 1, 0.35) : Qt.rgba(0, 0, 0, 0.38)
        antialiasing: true
        Behavior on color { ColorAnimation { duration: 150 } }
    }
    Rectangle {
        id: knob
        readonly property real d: t.pressed ? 28 : (t.checked ? 24 : 16)
        width: d; height: d; radius: d / 2
        antialiasing: true
        anchors.verticalCenter: parent.verticalCenter
        x: t.checked ? t.width - d - (t.height - d) / 2 : (t.height - d) / 2
        color: t.checked ? Theme.onPrimary : (Theme.dark ? Qt.rgba(1, 1, 1, 0.55) : Qt.rgba(0, 0, 0, 0.5))
        Behavior on x { NumberAnimation { duration: 300; easing.type: Easing.OutBack; easing.overshoot: Motion.os(1.6) } }
        Behavior on width { NumberAnimation { duration: 220; easing.type: Easing.OutBack; easing.overshoot: Motion.os(2) } }
        Behavior on height { NumberAnimation { duration: 220; easing.type: Easing.OutBack; easing.overshoot: Motion.os(2) } }
        Behavior on color { ColorAnimation { duration: 150 } }
        Icon {
            anchors.centerIn: parent
            name: t.checked ? "check" : "close"
            size: t.checked ? 16 : 11
            color: t.checked ? Theme.primary : (Theme.dark ? "#1E1E24" : "#FFFFFF")
            opacity: knob.d >= 14 ? 1 : 0
        }
    }
    MouseArea { id: ma; anchors.fill: parent; cursorShape: Qt.PointingHandCursor; onClicked: t.toggled(!t.checked) }
}
