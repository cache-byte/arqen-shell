# What the shell uses

`install.sh` lists these and lets you choose. On a system that is not Fedora (or if you chose "shell only"), install them yourself from your distribution's repositories. The names below are Fedora's; most are the same elsewhere. Anything missing only switches off the feature in the last column.

| Group | Packages (Fedora names) | Needed for |
|---|---|---|
| core | hyprland, quickshell | the shell cannot run without these (Hyprland 0.55+ reads `hyprland.lua`) |
| qt | qt6-qtdeclarative, qt6-qtsvg, qt6-qtwayland, qt6-qtmultimedia, qt6-qtimageformats | Qt 6 parts Quickshell uses; video wallpapers, images |
| portals | xdg-desktop-portal, xdg-desktop-portal-hyprland, xdg-desktop-portal-gtk, hyprland-guiutils | file pickers, screen sharing |
| audio | pipewire, wireplumber, pipewire-pulseaudio, pipewire-utils, pulseaudio-utils, sound-theme-freedesktop | volume, microphone, sounds |
| network | NetworkManager (and BlueZ for Bluetooth) | Wi-Fi, Bluetooth |
| media | playerctl, cava, ffmpeg-free | music widget and its beat, pictures for video wallpapers |
| display | brightnessctl, upower, hyprsunset | brightness, battery, night light |
| capture | grim, slurp, wf-recorder, ImageMagick | screenshots, recordings, picture editing |
| clipboard | wl-clipboard, cliphist, wtype | clipboard history, typing from the on-screen keyboard |
| theming | qt6ct, qt5ct, adw-gtk3-theme | other apps following the shell colours |
| fonts | rsms-inter-fonts, google-noto-color-emoji-fonts | interface font, emoji |
| tools | python3, python3-gobject, gnome-keyring, libnotify, xdg-utils, curl, git, inotify-tools | helper scripts, keyring, downloads |
| apps | kitty, nautilus | default terminal and file manager (any others work) |
| rgb | openrgb, openrgb-udev-rules | Settings > Lighting (RGB on connected devices) |
| controllers | steam-devices | game controller access |

Also downloaded from GitHub (no package): the **Material Symbols Rounded** icon font (`~/.local/share/fonts`; without it icons show as words) and the **Bibata** cursor.

Start the shell with `qs -c arqen` (copy the `quickshell/arqen` folder to `~/.config/quickshell/arqen`), or add `exec-once = qs -c arqen` to your Hyprland config.
