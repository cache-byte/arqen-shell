#!/usr/bin/env bash
# Arqen shell installer for a fresh Fedora (Hyprland + Quickshell).
# Run it as your normal user (it asks for sudo when it needs it). It can be run again safely.
set -euo pipefail

# ---- name and warning (shown once per run: install.sh shows it and update.sh, which it calls, stays quiet) ----
if [ -z "${ARQEN_WARNED:-}" ]; then
  export ARQEN_WARNED=1
  R=""; N=""; B=""
  if [ -t 1 ] && [ -z "${NO_COLOR:-}" ]; then R=$'\033[1;31m'; B=$'\033[1;36m'; N=$'\033[0m'; fi
  printf '\n%s' "$B"
  cat <<'ART'
    _    ____   ___  _____ _   _
   / \  |  _ \ / _ \| ____| \ | |
  / _ \ | |_) | | | |  _| |  \| |
 / ___ \|  _ <| |_| | |___| |\  |
/_/   \_\_| \_\\__\_\_____|_| \_|
ART
  printf '%s   a Hyprland + Quickshell shell\n\n' "$N"
  printf '%s!!  THIS SHELL WAS MADE FULLY WITH CLAUDE AI AND MAY HAVE ERRORS. TRY IT AT YOUR OWN RISK,%s\n' "$R" "$N"
  printf '%s    AS THE CREATOR WILL NOT BE LIABLE FOR ANY BROKEN CONFIGS, SETTINGS ETC.%s\n' "$R" "$N"
  printf '%s    THE SHELL WAS MADE AS A TEST, NOT REALLY AS A DAILY DRIVER.  !!%s\n\n' "$R" "$N"
fi

HERE="$(cd "$(dirname "$0")" && pwd)"
CFG="$HOME/.config"
STAMP="$(date +%Y%m%d-%H%M%S)"

[ "$EUID" -eq 0 ] && { echo "Run as your normal user (it will use sudo)."; exit 1; }

# ---- what the shell uses ----
# group id | what it is for | Fedora packages. Everything is optional except that the shell needs Hyprland and Quickshell to run.
# group id | what it is for | Fedora packages (one group per line; the same list uninstall.sh reads)
DEPS="$(cat "$HERE/quickshell/arqen/scripts/deps.txt")"
# also fetched from the internet (no package): the Material Symbols icon font (needed for the icons) and the Bibata cursor.

# packages the shell brings are written down (only the ones that were not installed yet), so uninstall.sh can offer to remove just those
PKGLOG="$HOME/.config/arqen/packages-installed"
record_new() { mkdir -p "$HOME/.config/arqen"; local p; for p in "$@"; do rpm -q "$p" >/dev/null 2>&1 || grep -qx -- "$p" "$PKGLOG" 2>/dev/null || echo "$p" >> "$PKGLOG"; done; }

show_deps() {
  printf 'The shell uses these (Fedora package names; other distros: install the same things from their repositories):\n\n'
  printf '%s\n' "$DEPS" | while IFS='|' read -r id why pk; do printf '  %-12s %s\n' "$id" "$why"; printf '  %-12s %s\n' '' "$pk"; done
  printf '\n  plus the Material Symbols icon font and the Bibata cursor (downloaded from GitHub).\n\n'
}

IS_FEDORA=0; grep -qi fedora /etc/os-release 2>/dev/null && command -v dnf >/dev/null 2>&1 && IS_FEDORA=1
DO_DEPS=0; PKGS=""; SKIPPED=""; WANT_CORE=0
show_deps
choice="${ARQEN_DEPS:-}"
if [ "$IS_FEDORA" = 0 ]; then
  echo "This is not a Fedora system, so the dependencies are not installed for you: the shell is installed and you"
  echo "install the list above yourself (it is also in DEPENDENCIES.md)."
  choice=none
elif [ -z "$choice" ]; then
  if [ -t 0 ]; then
    echo "  1) install everything above (recommended on Fedora)"
    echo "  2) let me choose which parts to install"
    echo "  3) install the shell only; I will install the dependencies myself"
    read -r -p "Choose 1, 2 or 3 [1]: " a
    case "$a" in 2) choice=pick ;; 3) choice=none ;; *) choice=all ;; esac
  else
    choice=all
  fi
fi
case "$choice" in
  all)  DO_DEPS=1 ;;
  pick) DO_DEPS=1 ;;
  *)    DO_DEPS=0 ;;
esac
while IFS='|' read -r id why pk; do
  take=1
  if [ "$choice" = pick ]; then
    read -r -p "  Install $id ($why)? [Y/n] " a </dev/tty
    case "$a" in n|N|no|NO) take=0 ;; esac
  fi
  [ "$choice" = none ] || [ "$choice" = skip ] && take=0
  if [ "$take" = 1 ]; then PKGS="$PKGS $pk"; [ "$id" = core ] && WANT_CORE=1; else SKIPPED="$SKIPPED $pk"; fi
done <<EOF
$DEPS
EOF
[ -n "$PKGS" ] || DO_DEPS=0
mkdir -p "$HOME/.config/arqen"
# update.sh leaves what was not wanted alone
printf '%s\n' $SKIPPED > "$HOME/.config/arqen/deps-skipped"
# update.sh: no package installing when none was wanted
if [ "$DO_DEPS" = 0 ]; then export ARQEN_NODEPS=1; else unset ARQEN_NODEPS; fi

if [ "$DO_DEPS" = 1 ]; then
echo "==> Repositories"
  sudo dnf install -y dnf-plugins-core
  have() { dnf repoquery --quiet --available "$1" 2>/dev/null | grep -q . ; }
  copr() { sudo dnf copr enable -y "$1" || echo "   (COPR $1 not usable for this Fedora release, skipping)"; }
  # Hyprland 0.55+ (it reads hyprland.lua) comes from the lionheartp COPR, which also has a matching Quickshell.
  # Other Hyprland COPRs are switched off so they cannot bring the old .conf-only build back.
  copr lionheartp/Hyprland
  LH="$(dnf repolist --all 2>/dev/null | awk 'tolower($1) ~ /lionheartp/ {print $1; exit}' || true)"
  if [ -n "$LH" ]; then
    for c in $(dnf copr list --enabled 2>/dev/null | awk '{print $1}' | grep -i hyprland | grep -vi lionheartp | sed 's#^copr.fedorainfracloud.org/##'); do
      sudo dnf copr disable -y "$c" >/dev/null 2>&1 && echo "   switched off the COPR $c (replaced by lionheartp/Hyprland)"
    done
  else
    # lionheartp has nothing for this Fedora release: the older sources (hyprland.conf)
    have hyprland   || copr ashbuk/Hyprland-Fedora
  fi
  have quickshell || copr errornointernet/quickshell
  have quickshell || copr nett00n/hyprland
  if [ "$WANT_CORE" = 1 ]; then
echo "==> Hyprland and Quickshell"
  record_new hyprland quickshell
  sudo dnf install -y hyprland quickshell || {
    echo
    echo "!! Could not install hyprland and/or quickshell from any repo."
    echo "   Run:  dnf repoquery hyprland quickshell   and send what it shows."
    exit 1
  }
  
  if [ -n "${LH:-}" ]; then
    # an older Hyprland already on the system (from another repo) is replaced by the lionheartp build
    sudo dnf distro-sync -y --repo="$LH" --repo=fedora --repo=updates hyprland >/dev/null 2>&1 \
      && echo "   Hyprland: $(rpm -q --qf '%{version}' hyprland) from lionheartp" || echo "   (Hyprland stays as installed)"
  fi
  fi
  echo "==> Everything else the shell uses (missing optional packages are skipped)"
  # (power modes: Fedora's tuned-ppd, already there; power-profiles-daemon would clash with it)
  OTHERS=""; for p in $PKGS; do case "$p" in hyprland|quickshell) ;; *) OTHERS="$OTHERS $p" ;; esac; done
  [ -z "$OTHERS" ] || { record_new $OTHERS; sudo dnf install -y --skip-unavailable --skip-broken $OTHERS; } \
    || echo "   (some packages could not be installed; the shell still runs, a few features may not)"
fi

echo "==> Icon font (Material Symbols)"
FONT_DIR="$HOME/.local/share/fonts"
mkdir -p "$FONT_DIR"
if [ ! -f "$FONT_DIR/MaterialSymbolsRounded.ttf" ] && ! command -v curl >/dev/null 2>&1; then
  echo "   curl is missing: download MaterialSymbolsRounded.ttf (github.com/google/material-design-icons, variablefont folder) into $FONT_DIR yourself"
elif [ ! -f "$FONT_DIR/MaterialSymbolsRounded.ttf" ]; then
  curl -fL -o "$FONT_DIR/MaterialSymbolsRounded.ttf" \
    "https://github.com/google/material-design-icons/raw/master/variablefont/MaterialSymbolsRounded%5BFILL%2CGRAD%2Copsz%2Cwght%5D.ttf"
  fc-cache -f
fi

mkdir -p "$CFG/hypr" "$CFG/quickshell" "$CFG/arqen" "$HOME/Pictures/Wallpapers" "$HOME/Desktop"

echo "==> Hyprland config"
# A fresh system has no Hyprland config yet: start from a small one that runs the shell. An existing
# config is kept (backed up) and only gets the lines the shell needs (update.sh below).
HL="$CFG/hypr/hyprland.lua"; HC="$CFG/hypr/hyprland.conf"
IPC="~/.config/quickshell/arqen/scripts/ipc call arqen"
FRESH_CONF=0
if [ ! -f "$HL" ] && [ ! -f "$HC" ]; then
  FRESH_CONF=1
  cat > "$HC" <<CONF
# Hyprland, set up for the Arqen shell (written by install.sh; edit freely).
# Gaps, rounding, blur, screens, the shell's shortcuts (Super+I settings, Super+Space search, Super+Tab
# desktops, Super+N control centre, Super+L lock ...): Arqen Settings writes them to arqen-overrides.conf,
# read at the end of this file.

\$terminal = kitty
\$files = nautilus

exec-once = qs -c arqen

input {
    follow_mouse = 1
    touchpad {
        natural_scroll = true
    }
}

# Super alone: launcher
bindr = SUPER, Super_L, exec, $IPC toggle launcher
bindr = SUPER, Super_R, exec, $IPC toggle launcher
bind = SUPER, Return, exec, \$terminal
bind = SUPER, E, exec, \$files
bind = SUPER, Q, killactive
bind = SUPER, F, fullscreen, 1
bind = SUPER SHIFT, F, fullscreen, 0
bind = SUPER, left, movefocus, l
bind = SUPER, right, movefocus, r
bind = SUPER, up, movefocus, u
bind = SUPER, down, movefocus, d
CONF
  for i in 1 2 3 4 5 6 7 8 9; do
    printf 'bind = SUPER, %s, workspace, %s\nbind = SUPER SHIFT, %s, movetoworkspace, %s\n' "$i" "$i" "$i" "$i" >> "$HC"
  done
  cat >> "$HC" <<'CONF'
# move / resize windows with Super + left / right mouse button
bindm = SUPER, mouse:272, movewindow
bindm = SUPER, mouse:273, resizewindow

# Arqen Settings (last, so what you set there wins)
source = ~/.config/hypr/arqen-overrides.conf
CONF
  echo "   wrote ~/.config/hypr/hyprland.conf"
else
  # the shell must start with Hyprland: add it only when no Hyprland file starts it already
  # (in any form: "qs -c arqen", "qs -c arqen -d", ...; the "ipc call" lines do not count)
  if grep -rhs 'qs -c arqen' "$CFG/hypr" "$CFG/systemd/user" "$CFG/autostart" --include='*.lua' --include='*.conf' --include='*.service' --include='*.desktop' | grep -v ' ipc ' | grep -q .; then
    echo "   your Hyprland config already starts the shell: left as it is"
  elif [ -f "$HL" ]; then
    cp "$HL" "$HL.bak-$STAMP"
    printf '\n-- the Arqen shell\nhl.on("hyprland.start", function()\n    hl.exec_cmd("qs -c arqen")\nend)\n' >> "$HL"
    echo "   hyprland.lua now starts the shell (backup: hyprland.lua.bak-$STAMP)"
  else
    cp "$HC" "$HC.bak-$STAMP"
    printf '\n# the Arqen shell\nexec-once = qs -c arqen\n' >> "$HC"
    echo "   hyprland.conf now starts the shell (backup: hyprland.conf.bak-$STAMP)"
  fi
  if [ ! -f "$HL" ] && ! grep -q 'arqen-overrides.conf' "$HC"; then
    printf '\n# Arqen Settings writes Hyprland settings here\nsource = ~/.config/hypr/arqen-overrides.conf\n' >> "$HC"
  fi
fi
# the first overrides file (Arqen Settings rewrites it; hyprland.lua uses arqen.lua instead)
[ -f "$HL" ] || [ -e "$CFG/hypr/arqen-overrides.conf" ] || cat > "$CFG/hypr/arqen-overrides.conf" <<'OVR'
monitor = , preferred, auto, auto
general {
  gaps_in = 4
  gaps_out = 10
  border_size = 1
}
decoration {
  rounding = 14
}
OVR

# Hyprland 0.55+ runs hyprland.lua. A fresh system gets the starter config above as hyprland.conf, so on 0.55+
# it is converted right now (the same converter as tools/switch-to-lua.sh) and hyprland.conf is set aside.
# An existing hyprland.lua is never touched here: update.sh adds the few lines the shell needs to it.
if [ "$FRESH_CONF" = 1 ]; then
  hver="$(rpm -q --qf '%{version}\n' hyprland 2>/dev/null | head -n1)"
  hmaj="$(echo "$hver" | cut -d. -f1)"; hmin="$(echo "$hver" | cut -d. -f2)"
  if [ "${hmaj:-0}" -gt 0 ] 2>/dev/null || [ "${hmin:-0}" -ge 55 ] 2>/dev/null; then
    echo "==> Hyprland $hver reads hyprland.lua: converting the starter config"
    if [ "$(uname -m)" = "x86_64" ] && python3 -I "$HERE/tools/convert-hypr.py" "$CFG/hypr" "$HERE/tools/hyprlang2lua" >/dev/null 2>&1 && [ -s "$HL" ]; then
      if command -v luac >/dev/null 2>&1 && ! { luac -p "$HL" && luac -p "$CFG/hypr/arqen.lua"; } 2>/dev/null; then
        rm -f "$HL" "$CFG/hypr/arqen.lua"
        echo "   (the converted Lua did not pass a syntax check: keeping hyprland.conf)"
      else
        mv "$HC" "$HC.disabled"
        echo "   wrote ~/.config/hypr/hyprland.lua (the .conf is kept as hyprland.conf.disabled)"
      fi
    else
      rm -f "$HL"
      echo "   (could not convert here: keeping hyprland.conf; tools/switch-to-lua.sh does it later)"
    fi
  fi
fi

# An existing hyprland.conf (no hyprland.lua yet): backed up, converted to hyprland.lua and set aside as
# hyprland.conf.disabled, and Quickshell taken from lionheartp too (tools/switch-to-lua.sh does all of it;
# it leaves everything alone if Hyprland is older than 0.55 or the conversion fails).
if [ "$FRESH_CONF" = 0 ] && [ ! -f "$HL" ] && [ -f "$HC" ] && [ -x "$(command -v python3)" ]; then
  echo "==> Your hyprland.conf: moving to hyprland.lua"
  bash "$HERE/tools/switch-to-lua.sh" || echo "   (hyprland.conf stays in use; see the messages above)"
fi

if [ "$DO_DEPS" = 1 ]; then
echo "==> Services"
systemctl --user enable --now pipewire wireplumber 2>/dev/null || true
sudo systemctl enable --now NetworkManager bluetooth 2>/dev/null || true
# Wi-Fi and Bluetooth are the ones the system already has (NetworkManager, and the Bluetooth service every distro ships);
# nothing is replaced or removed. Only if a minimal install has no Bluetooth service at all is it added.
command -v bluetoothctl >/dev/null 2>&1 || { record_new bluez; sudo dnf install -y --skip-unavailable bluez; } >/dev/null 2>&1 || true
fi

echo "==> The shell itself, desktop portal, app theming, keyring ... (update.sh)"
bash "$HERE/update.sh"

cat <<MSG

Installed. Log out and pick "Hyprland" on the login screen.
  Super: launcher   Super+Space: search   Super+I: settings   Super+Tab: desktops
  Super+Enter: terminal   Super+E: files   Super+Q: close   Print: screenshot / recording
Once you are in Hyprland, run ./update.sh from this folder one more time: a few things (dragging
windows by their top edge, the desktop portal check) can only be set up inside a running Hyprland.
Wallpapers: put pictures or videos in ~/Pictures/Wallpapers and pick one in Settings > Appearance.
If the shell does not show up:  qs -c arqen   in a terminal shows why.
MSG
