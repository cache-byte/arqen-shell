import QtQuick
import Quickshell
import qs.config
import qs.services

// A plugin's desktop widget (its DesktopWidget.qml), on the desktop and in Settings' previews.
// Arqen draws the card (in the look picked in Settings > Desktop); the plugin draws what is on it.
// It gets pluginApi, screen, widgetData (its settings on the desktop: size, look...) and widgetScale
// (Small 0.8, Medium 1, Large 1.3). Its own size is measured so the desktop's grid gives it enough
// cells. A plugin that fails to load shows why.
Item {
    id: host
    property var cfg: ({})
    readonly property string pid: String(cfg.type || "").replace(/^plugin:/, "")
    readonly property var plug: Plugins.find(pid)
    readonly property real k: Widgets.scaleOf(cfg.size)

    readonly property string look: cfg.look || "Glass"
    Rectangle {
        anchors.fill: ld
        visible: ld.status === Loader.Ready && host.look !== "Clear"
        radius: Math.min(Theme.radius * 1.4, width / 2, height / 2)
        color: Widgets.bg(host.look)
        border.width: host.look === "Glass" || host.look === "Solid" ? 1 : 0
        border.color: Theme.stroke
    }
    Loader {
        id: ld
        anchors.centerIn: parent
        active: host.plug !== null && Plugins.isEnabled(host.pid)
        source: host.plug ? Plugins.entryUrl(host.plug, "desktopWidget") : ""
        onLoaded: {
            const it = ld.item
            if ("pluginApi" in it) it.pluginApi = Plugins.api(host.pid)
            if ("screen" in it) it.screen = Quickshell.screens[0]
            host.push()
        }
        // its size, as it asks for it
        width: item ? (item.implicitWidth || 200) : 0
        height: item ? (item.implicitHeight || 120) : 0
        onWidthChanged: if (item) Widgets.measure(host.cfg.type, width / host.k, height / host.k)
        onHeightChanged: if (item) Widgets.measure(host.cfg.type, width / host.k, height / host.k)
    }
    function push() {
        const it = ld.item
        if (!it) return
        if ("widgetData" in it) it.widgetData = cfg
        if ("widgetScale" in it) it.widgetScale = k
    }
    onCfgChanged: push()
    onKChanged: push()

    Rectangle {
        visible: ld.status === Loader.Error || host.plug === null
        anchors.fill: parent
        radius: Theme.radius
        color: Theme.panel
        border.width: 1; border.color: Theme.stroke
        Column {
            anchors.centerIn: parent
            width: parent.width - 24
            spacing: 6
            Icon { anchors.horizontalCenter: parent.horizontalCenter; name: "extension_off"; size: 28; color: "#FF5A5A" }
            DText {
                width: parent.width; horizontalAlignment: Text.AlignHCenter; wrapMode: Text.Wrap
                text: host.plug === null ? "The plugin \"" + host.pid + "\" is not installed or is off" : (host.plug.name + " could not load. Settings > Plugins shows why")
                font.pixelSize: 12; color: Theme.subtext
            }
        }
    }
}
