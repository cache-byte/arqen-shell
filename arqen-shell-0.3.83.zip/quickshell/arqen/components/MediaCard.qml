import Quickshell
import Quickshell.Widgets
import QtQuick
import QtQuick.Effects
import qs.config
import qs.services

// What is playing, as a card (like a phone's media card): the cover blurred behind, the cover,
// the title running along when it is too long, the artist, a progress line you can drag, and
// previous / play / next. Bars dance while it plays. Used by the panel's media item (its pop-up)
// and the desktop's media widget. With nothing playing it says so, and offers nothing to press.
Rectangle {
    id: mc
    property bool solid: true                // false: see-through like the other desktop widgets
    // as a desktop widget: its look (Widgets.bg) and options
    property var cfg: null
    readonly property string look: cfg ? (cfg.look || "Glass") : ""
    readonly property bool showProgress: cfg ? cfg.progress !== false : true
    readonly property bool blurBg: (cfg ? cfg.blur !== false : Config.c.mediaPopBlur) && !Power.saving
    readonly property bool showArt: cfg ? cfg.art !== false : true
    readonly property bool showArtist: cfg ? cfg.artist !== false : true
    readonly property bool showBars: cfg ? cfg.bars !== false : true
    // what moves to the beat: from the desktop widget's options, or (the panel's pop-up) the panel's setting
    readonly property string vizKind: cfg ? (cfg.viz ?? "Bars") : (Config.c.mediaPopViz === "Off" ? "Off" : (Config.c.mediaPopKind === "Same" ? Config.c.mediaViz : Config.c.mediaPopKind))
    readonly property bool vizBehind: cfg ? cfg.vizPos === "Behind" : Config.c.mediaPopViz !== "Bottom"
    readonly property string vizColor: cfg ? (cfg.vizColor ?? "Accent") : Config.c.mediaVizColor
    readonly property int vizN: cfg ? Math.round(cfg.vizBars ?? 12) : 12
    readonly property real vizH: (cfg ? (cfg.vizHeight ?? 45) : 45) / 100
    readonly property bool pulseOn: cfg ? cfg.pulse !== false : Config.c.mediaPulse
    readonly property bool glowOn: (cfg ? cfg.glow !== false : true) && !Power.saving
    readonly property bool rippleOn: (cfg ? cfg.ripple === true : false) && !Power.saving
    readonly property real sens: cfg ? (cfg.sens ?? 100) / 100 : 1
    readonly property real bass: Media.playing && Beat.available ? Math.min(1, Beat.bass * sens) : 0
    BeatUser { on: Media.playing && mc.visible && (mc.vizKind !== "Off" || mc.pulseOn || mc.glowOn || mc.rippleOn) }
    readonly property bool showControls: cfg ? cfg.controls !== false : true
    readonly property color fgc: cfg ? Widgets.fgOf(cfg) : Theme.text
    readonly property color subc: cfg ? Widgets.subOf(cfg) : Theme.subtext
    readonly property real ts: cfg ? Widgets.ts(cfg) : 1
    implicitWidth: 400
    // the pop-up asks for its height: cover + progress, and a strip of its own for the beat when that is at the bottom
    readonly property real vizBand: cfg === null && vizKind !== "Off" && !vizBehind ? 38 : 0
    implicitHeight: cfg === null ? 14 + artSize + (showProgress && Media.length > 0 ? 34 : 14) + 14 + vizBand : 168
    radius: cfg ? Widgets.radiusOf(cfg) : Theme.radius
    color: cfg ? Widgets.bgOf(cfg) : (solid ? Theme.cardSolid : Theme.panel)
    border.width: cfg ? Widgets.borderW(cfg) : 1; border.color: cfg ? Widgets.borderCol(cfg) : Theme.stroke
    // shadow behind the card (Shadow option)
    Rectangle { z: -1; visible: (cfg ? Widgets.shadowA(cfg) : 0) > 0; anchors { fill: parent; topMargin: 5; leftMargin: -1; rightMargin: -1; bottomMargin: -4 }
                radius: parent.radius; color: Qt.rgba(0, 0, 0, (cfg ? Widgets.shadowA(cfg) : 0)) }

    readonly property bool tall: cfg === null || height >= 150
    // a narrow desktop card (resized tall and thin): everything stacks, cover on top, words, buttons, progress
    readonly property bool stacked: cfg !== null && tall && width < 280
    readonly property real artSize: showArt ? (cfg === null ? 100 : stacked ? Math.max(40, Math.min(width - 28, height - 190)) : Math.min(height - 28, tall ? 96 : height - 24)) : (cfg === null ? 60 : 0)

    // ---- the cover, big and blurred, behind everything (inside the card's rounded corners; only
    // when the cover really loaded: a cover file already deleted showed a grey square) ----
    ClippingRectangle {
        anchors.fill: parent; anchors.margins: mc.border.width
        radius: Math.max(0, mc.radius - mc.border.width)
        color: "transparent"
        visible: mc.blurBg && bgArt.status === Image.Ready
        Image {
            id: bgArt
            anchors.fill: parent
            source: mc.blurBg ? Media.art : ""
            fillMode: Image.PreserveAspectCrop
            asynchronous: true
            visible: false
            sourceSize.width: 256
        }
        MultiEffect {
            anchors.fill: parent
            source: bgArt
            autoPaddingEnabled: false
            blurEnabled: true; blur: 1.0; blurMax: 64
            opacity: 0.45
            saturation: 0.2
        }
        Rectangle { anchors.fill: parent; color: mc.color; opacity: 0.35 }
    }

    // ---- the visualizer: along the bottom, behind everything, or (Blob) a swelling shape behind the cover ----
    readonly property bool blobKind: vizKind === "Blob"
    BeatViz {
        id: vz
        visible: mc.vizKind !== "Off"
        kind: mc.vizKind
        n: kind === "Wave" ? 9 : (kind === "Blob" ? 16 : mc.vizN)
        tint: mc.vizColor; accent: Theme.primary; text: mc.fgc; sens: mc.sens
        // Blob: round, centred on the cover (its edge reaches past it); others: a band full width
        x: mc.blobKind ? cover.x + cover.width / 2 - width / 2 : mc.border.width + 8
        y: mc.blobKind ? cover.y + cover.height / 2 - height / 2
                       : mc.height - height - mc.border.width - (mc.vizBehind ? 0 : 8)
        width: mc.blobKind ? cover.width * 1.9 : mc.width - 2 * (mc.border.width + 8)
        height: mc.blobKind ? width : (mc.cfg === null && !mc.vizBehind ? 26 : Math.max(10, (mc.vizBehind ? mc.height - 2 * mc.border.width : mc.height * 0.42) * mc.vizH * (mc.vizBehind ? 1 : 1.4)))
        opacity: mc.blobKind ? 0.9 : (mc.vizBehind ? 0.3 : 0.9)
        z: mc.blobKind ? 0 : (mc.vizBehind ? 0 : 3)
    }

    // ---- cover ----
    ClippingRectangle {
        id: cover
        z: 1
        visible: mc.showArt
        x: mc.stacked ? (mc.width - width) / 2 : 14; y: mc.tall ? 14 : (mc.height - height) / 2
        width: mc.artSize; height: width
        radius: mc.cfg && mc.cfg.artShape === "Circle" ? width / 2 : mc.cfg && mc.cfg.artShape === "Square" ? 3 : Math.max(10, Theme.radius - 6)
        color: Theme.tile
        Image {
            id: coverImg
            anchors.fill: parent
            source: Media.art
            fillMode: Image.PreserveAspectCrop
            asynchronous: true
            sourceSize.width: 256
            opacity: status === Image.Ready ? 1 : 0
            Behavior on opacity { NumberAnimation { duration: 300 } }
        }
        // no cover: the player's own icon (Vivaldi, Spotify...), else a note
        AppIcon {
            anchors.centerIn: parent
            visible: coverImg.status !== Image.Ready && Media.entry !== null
            entry: Media.entry
            size: Math.round(mc.artSize * 0.5)
        }
        Icon { anchors.centerIn: parent; visible: coverImg.status !== Image.Ready && Media.entry === null; name: Media.has ? "music_note" : "music_off"; size: Math.round(mc.artSize * 0.42); color: Theme.subtext }
        // beats with the bass while it plays (a soft sway when there is no cava)
        scale: !Media.playing ? 0.96 : (mc.pulseOn ? (Beat.available ? 1 + 0.12 * mc.bass : 1 + 0.015 * Math.sin(beat.v * Math.PI * 2)) : 1)
        Behavior on scale { NumberAnimation { duration: Media.playing ? 70 : 300; easing.type: Easing.OutCubic } }
    }
    // a glow round the cover that swells with the bass: a few soft rounded layers
    Repeater {
        model: mc.glowOn && mc.showArt && Media.playing ? 3 : 0
        delegate: Rectangle {
            required property int index
            z: 0
            x: cover.x - (index + 1) * 5 * (0.4 + mc.bass); y: cover.y - (index + 1) * 5 * (0.4 + mc.bass)
            width: cover.width + 2 * (index + 1) * 5 * (0.4 + mc.bass); height: width
            radius: cover.radius + (index + 1) * 5
            color: Theme.primary
            opacity: (0.05 + 0.2 * mc.bass) / (index + 1)
        }
    }
    // rings that spread out from the cover on every strong beat
    Item {
        id: rings
        property real last: 0
        visible: mc.rippleOn && mc.showArt
        Connections {
            target: mc
            function onBassChanged() {
                if (!rings.visible || mc.bass < 0.6 || Date.now() - rings.last < 280) return
                rings.last = Date.now(); ringAnim.restart()
            }
        }
        Rectangle {
            id: ringR
            property real t: 0
            x: cover.x + cover.width / 2 - width / 2; y: cover.y + cover.height / 2 - height / 2
            width: cover.width * (1 + 0.7 * t); height: width; radius: width / 2
            color: "transparent"; border.width: 2; border.color: Theme.primary
            opacity: 0.8 * (1 - t)
            visible: t > 0
        }
        NumberAnimation { id: ringAnim; target: ringR; property: "t"; from: 0.01; to: 1; duration: 700; easing.type: Easing.OutCubic; onFinished: ringR.t = 0 }
    }
    Item {
        id: beat
        property real v: 0
        NumberAnimation on v { from: 0; to: 1; duration: 900; loops: Animation.Infinite; running: Media.playing && mc.visible }
    }

    // ---- the words ----
    Item {
        id: words
        // (on the short card the words stop before the buttons)
        anchors { left: mc.showArt && !mc.stacked ? cover.right : parent.left; leftMargin: 14; right: parent.right; rightMargin: mc.tall || !mc.showControls ? 14 : ctl.width + 18; top: mc.stacked ? cover.bottom : cover.top; topMargin: mc.stacked ? 10 : 0 }
        height: mc.showArt && !mc.stacked ? cover.height : (mc.tall ? 64 : 40)
        // app, and the dancing bars
        Row {
            id: appRow
            spacing: 6
            visible: mc.tall
            AppIcon { visible: Media.entry !== null; entry: Media.entry; size: 14; anchors.verticalCenter: parent.verticalCenter }
            DText { text: Media.app || "Nothing playing"; font.pixelSize: Math.round(11 * mc.ts); color: mc.subc; anchors.verticalCenter: parent.verticalCenter }
            Row {
                anchors.verticalCenter: parent.verticalCenter
                spacing: 2
                visible: Media.playing && mc.showBars
                Repeater {
                    model: 4
                    delegate: Rectangle {
                        required property int index
                        width: 3; radius: 1.5
                        anchors.bottom: parent.bottom
                        height: 3 + 9 * Beat.bar(index * 4, 16, beat.v * Math.PI * 2 + index * 1.3)
                        color: Theme.primary
                    }
                }
            }
        }
        // the title: runs along when it does not fit
        Item {
            id: titleBox
            y: mc.tall ? appRow.height + 4 : 0
            width: parent.width; height: titleText.implicitHeight
            clip: true
            DText {
                id: titleText
                readonly property real over: implicitWidth - titleBox.width
                text: Media.title || "Nothing playing"
                font.pixelSize: Math.round((mc.tall ? 17 : 14) * mc.ts); font.weight: Font.DemiBold
                color: mc.fgc
                x: 0
                SequentialAnimation on x {
                    running: titleText.over > 4 && mc.visible
                    loops: Animation.Infinite
                    PauseAnimation { duration: 2200 }
                    NumberAnimation { to: -titleText.over; duration: Math.max(1500, titleText.over * 28); easing.type: Easing.InOutSine }
                    PauseAnimation { duration: 1600 }
                    NumberAnimation { to: 0; duration: 500; easing.type: Easing.InOutSine }
                }
                onTextChanged: x = 0
            }
        }
        DText {
            visible: mc.showArtist
            anchors { top: titleBox.bottom; topMargin: 2 }
            width: parent.width; elide: Text.ElideRight
            text: Media.artist; color: mc.subc; font.pixelSize: Math.round((mc.tall ? 13 : 11) * mc.ts)
        }
    }

    // ---- progress: drag or click to jump ----
    Item {
        id: prog
        visible: mc.tall && Media.length > 0 && mc.showProgress
        anchors { left: parent.left; right: parent.right; leftMargin: 14; rightMargin: 14; top: mc.showArt && !mc.stacked ? cover.bottom : ctl.bottom; topMargin: 8 }
        height: 22
        property real dragFrac: -1
        readonly property real f: dragFrac >= 0 ? dragFrac : Media.progress
        Rectangle {
            id: track
            anchors { left: parent.left; right: parent.right; verticalCenter: parent.verticalCenter }
            anchors.leftMargin: 40; anchors.rightMargin: 40
            height: progMa.containsMouse || progMa.pressed ? 6 : 4; radius: height / 2
            color: Theme.tile
            Behavior on height { NumberAnimation { duration: 120 } }
            Rectangle {
                width: Math.max(parent.height, parent.width * prog.f); height: parent.height; radius: parent.radius
                color: Theme.primary
                Behavior on width { enabled: prog.dragFrac < 0; NumberAnimation { duration: 450 } }
            }
            Rectangle {
                visible: progMa.containsMouse || progMa.pressed
                x: parent.width * prog.f - width / 2; anchors.verticalCenter: parent.verticalCenter
                width: 12; height: 12; radius: 6; color: Theme.primary
            }
        }
        DText { anchors.left: parent.left; anchors.verticalCenter: parent.verticalCenter; text: Media.time(Media.length * prog.f); font.pixelSize: 10; color: Theme.subtext }
        DText { anchors.right: parent.right; anchors.verticalCenter: parent.verticalCenter; text: Media.time(Media.length); font.pixelSize: 10; color: Theme.subtext }
        MouseArea {
            id: progMa
            anchors.fill: track; anchors.margins: -8
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            function at(mx) { return Math.max(0, Math.min(1, (mx - 8) / track.width)) }
            onPressed: mouse => prog.dragFrac = at(mouse.x)
            onPositionChanged: mouse => { if (pressed) prog.dragFrac = at(mouse.x) }
            onReleased: { Media.seek(prog.dragFrac); prog.dragFrac = -1 }
        }
    }

    // ---- controls ----
    Row {
        id: ctl
        visible: mc.showControls
        x: mc.stacked ? (mc.width - width) / 2 : mc.tall ? (mc.showArt ? cover.x + cover.width + 10 : 10) : mc.width - width - 10
        y: mc.stacked ? words.y + words.height + 8 : mc.tall ? (mc.showArt ? cover.y + cover.height - height + 2 : words.y + words.height + 6) : (mc.height - height) / 2
        spacing: 6
        opacity: Media.has ? 1 : 0.4
        Repeater {
            model: [["skip_previous", "prev"], [Media.playing ? "pause" : "play_arrow", "toggle"], ["skip_next", "next"]]
            delegate: Rectangle {
                id: cb
                required property var modelData
                readonly property bool main: modelData[1] === "toggle"
                width: main ? 42 : 34; height: width; radius: width / 2
                color: main ? Theme.primary : (cbm.containsMouse ? Theme.hover : "transparent")
                scale: cbm.pressed ? 0.88 : 1
                Behavior on scale { NumberAnimation { duration: 140; easing.type: Easing.OutBack } }
                Icon { anchors.centerIn: parent; name: cb.modelData[0]; size: cb.main ? 26 : 22; color: cb.main ? Theme.onPrimary : Theme.text }
                MouseArea {
                    id: cbm
                    anchors.fill: parent; hoverEnabled: true
                    cursorShape: Qt.PointingHandCursor
                    onClicked: { const f = cb.modelData[1]; if (f === "prev") Media.prev(); else if (f === "next") Media.next(); else Media.toggle() }
                }
            }
        }
    }
}
