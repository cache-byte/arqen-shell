import Quickshell
import Quickshell.Wayland
import Quickshell.Hyprland
import QtQuick
import qs.config
import qs.components
import qs.services

// The edge panel: windows pushed off the screen (services/EdgeTuck.qml) wait here as icons.
//  - folded, it is a thin line on the screen edge; click it (or point at it and wait) to open it
//  - open, click an icon to bring that window back (middle-click closes it), or "bring all back"
//  - drag the line (or the panel's grip) anywhere: it goes to the nearest screen edge, at that
//    spot, and stays there (Config.c.edgeSide / edgeAlong)
// It only shows while something is tucked away.
Scope {
    id: sc

    readonly property var items: EdgeTuck.tucked
    readonly property int n: items.length
    readonly property string side: ["left", "right", "top", "bottom"].indexOf(Config.c.edgeSide) >= 0 ? Config.c.edgeSide : "right"
    readonly property bool vert: side === "left" || side === "right"
    readonly property var scr: Quickshell.screens.find(s => s.name === Hyprland.focusedMonitor?.name) ?? Quickshell.screens[0]

    // sizes
    readonly property int icon: 40
    readonly property int cell: icon + 12
    readonly property int pad: 8
    readonly property int grip: 22
    readonly property int maxCells: Math.max(1, Math.floor(((vert ? (scr?.height ?? 1080) : (scr?.width ?? 1920)) - 160 - grip - (n > 1 ? cell : 0)) / cell))
    readonly property int shownCells: Math.min(n, maxCells)
    // length of the open panel along the edge, and its thickness
    readonly property int panelLen: grip + shownCells * cell + (n > 1 ? cell : 0) + 2 * pad
    readonly property int panelThick: cell + 2 * pad
    readonly property int lineLen: Math.min(120, 44 + n * 12)
    // the window: a fixed size while it shows (resizing a screen-edge window as it animates would
    // flicker), with room for the springy overshoot
    readonly property int winLen: Math.max(panelLen, lineLen) + 28
    readonly property int winThick: panelThick + 26

    readonly property string tipSide: side === "right" ? "left" : side === "left" ? "right" : side === "top" ? "bottom" : "top"
    property bool expanded: false
    property bool dragging: false
    property real gx: 0                     // the pointer while dragging, on the screen
    property real gy: 0

    // where a drag would put it: the nearest edge, and how far along
    readonly property var target: {
        const w = scr?.width ?? 1920, h = scr?.height ?? 1080
        const d = { left: gx, right: w - gx, top: gy, bottom: h - gy }
        let s = "right"
        for (const k of ["left", "right", "top", "bottom"]) if (d[k] < d[s]) s = k
        const v = s === "left" || s === "right"
        const along = v ? (gy - winLen / 2) / Math.max(1, h - winLen) : (gx - winLen / 2) / Math.max(1, w - winLen)
        return { side: s, along: Math.max(0, Math.min(1, along)) }
    }

    // open / fold, springy
    property real ex: 0
    NumberAnimation { id: exIn; target: sc; property: "ex"; to: 1; duration: 420; easing.type: Easing.OutBack; easing.overshoot: Motion.os(1.3) }
    NumberAnimation { id: exOut; target: sc; property: "ex"; to: 0; duration: 200; easing.type: Easing.InCubic }
    readonly property bool exWant: expanded && n > 0 && !dragging
    onExWantChanged: { if (exWant) { exOut.stop(); exIn.restart() } else { exIn.stop(); exOut.restart() } }
    onNChanged: if (n === 0) expanded = false

    // something was just tucked: open for a moment so you see where it went
    property bool peeking: false
    Connections {
        target: EdgeTuck
        function onTuckedOne() { sc.peeking = true; sc.expanded = true; fold.restart() }
    }
    // folds itself a little after the pointer leaves (not while you are on it)
    Timer { id: fold; interval: 2600; onTriggered: if (!win.hovered) { sc.expanded = false; sc.peeking = false } }

    // ---------- the outline that follows a drag (the panel itself stays put: no flicker) ----------
    PanelWindow {
        id: ghost
        screen: sc.scr
        visible: sc.dragging
        color: "transparent"
        anchors { top: true; bottom: true; left: true; right: true }
        exclusionMode: ExclusionMode.Ignore
        WlrLayershell.namespace: "arqen-edge-drag"
        WlrLayershell.layer: WlrLayer.Overlay
        WlrLayershell.keyboardFocus: WlrKeyboardFocus.None
        mask: Region {}
        Rectangle {
            readonly property bool v: sc.target.side === "left" || sc.target.side === "right"
            width: v ? 6 : sc.lineLen
            height: v ? sc.lineLen : 6
            radius: 3
            color: Theme.tertiary
            x: sc.target.side === "left" ? 4 : sc.target.side === "right" ? ghost.width - width - 4
               : sc.target.along * Math.max(0, ghost.width - sc.winLen) + (sc.winLen - width) / 2
            y: sc.target.side === "top" ? 4 : sc.target.side === "bottom" ? ghost.height - height - 4
               : sc.target.along * Math.max(0, ghost.height - sc.winLen) + (sc.winLen - height) / 2
            Behavior on x { NumberAnimation { duration: 120; easing.type: Easing.OutCubic } }
            Behavior on y { NumberAnimation { duration: 120; easing.type: Easing.OutCubic } }
        }
        Rectangle {   // the pointer: what you are carrying
            x: sc.gx - width / 2; y: sc.gy - height / 2
            width: 44; height: 44; radius: 22
            color: Qt.rgba(Theme.tertiary.r, Theme.tertiary.g, Theme.tertiary.b, 0.22)
            border.width: 2; border.color: Theme.tertiary
            Icon { anchors.centerIn: parent; name: "open_with"; size: 22; color: Theme.tertiary }
        }
    }

    // ---------- the edge panel ----------
    PanelWindow {
        id: win
        screen: sc.scr
        visible: sc.n > 0
        color: "transparent"
        readonly property bool hovered: hov.hovered
        anchors {
            left: sc.side === "left" || !sc.vert
            right: sc.side === "right"
            top: sc.side === "top" || sc.vert
            bottom: sc.side === "bottom"
        }
        margins {
            top: sc.vert ? Math.round(Math.max(0, Math.min(1, Config.c.edgeAlong)) * Math.max(0, (screen?.height ?? 1080) - sc.winLen)) : 0
            left: sc.vert ? 0 : Math.round(Math.max(0, Math.min(1, Config.c.edgeAlong)) * Math.max(0, (screen?.width ?? 1920) - sc.winLen))
        }
        implicitWidth: sc.vert ? sc.winThick : sc.winLen
        implicitHeight: sc.vert ? sc.winLen : sc.winThick
        exclusionMode: ExclusionMode.Ignore
        WlrLayershell.namespace: "arqen-edge"
        WlrLayershell.layer: WlrLayer.Top
        WlrLayershell.keyboardFocus: WlrKeyboardFocus.None
        // only the line, or the open panel, takes the pointer: the rest of the window lets clicks through
        // (the open panel slides with a transform: its click area is taken from a box that stays put)
        mask: Region { item: sc.ex > 0.02 ? panelHit : lineHit }
        Item { id: panelHit; x: panel.x; y: panel.y; width: panel.width; height: panel.height }
        Binding { target: win.contentItem; property: "opacity"; value: Ui.hideChrome ? 0 : 1 }

        // where this window is on the screen (a drag works out the pointer's place from it)
        function origin() {
            const w = screen?.width ?? 1920, h = screen?.height ?? 1080
            return { x: sc.side === "right" ? w - width : (sc.vert ? 0 : margins.left),
                     y: sc.side === "bottom" ? h - height : (sc.vert ? margins.top : 0) }
        }

        HoverHandler { id: hov; onHoveredChanged: if (!hovered && sc.expanded) fold.restart(); else fold.stop() }

        // click away (while opened on purpose): fold
        HyprlandFocusGrab {
            windows: [win]
            active: sc.expanded && !sc.peeking && win.visible
            onCleared: sc.expanded = false
        }

        // ---- the line on the edge (folded) ----
        Item {
            id: lineHit
            width: sc.vert ? 18 : sc.lineLen + 16
            height: sc.vert ? sc.lineLen + 16 : 18
            x: sc.side === "left" ? 0 : sc.side === "right" ? win.width - width : (win.width - width) / 2
            y: sc.side === "top" ? 0 : sc.side === "bottom" ? win.height - height : (win.height - height) / 2
            Rectangle {
                id: line
                property real thick: lineMa.containsMouse || lineMa.pressed ? 7 : 5
                Behavior on thick { NumberAnimation { duration: 220; easing.type: Easing.OutBack; easing.overshoot: Motion.os(2) } }
                width: sc.vert ? thick : sc.lineLen
                height: sc.vert ? sc.lineLen : thick
                radius: thick / 2
                anchors.centerIn: parent
                anchors.horizontalCenterOffset: sc.side === "left" ? -3 : sc.side === "right" ? 3 : 0
                anchors.verticalCenterOffset: sc.side === "top" ? -3 : sc.side === "bottom" ? 3 : 0
                color: Theme.tertiary
                opacity: (1 - Math.min(1, sc.ex)) * (lineMa.containsMouse ? 1 : 0.8)
                // pops in when the first window gets tucked
                scale: sc.n > 0 ? 1 : 0.2
                Behavior on scale { NumberAnimation { duration: 380; easing.type: Easing.OutBack; easing.overshoot: Motion.os(2) } }
            }
            DragArea {
                id: lineMa
                anchors.fill: parent
                onTapped: { sc.peeking = false; sc.expanded = true }
                onMoving: p => sc.dragMove(p)
                onDropped: sc.dragEnd()
            }
            HoverTip {
                hovered: lineMa.containsMouse && !lineMa.pressed && sc.ex < 0.1
                text: sc.n === 1 ? "1 window tucked away" : sc.n + " windows tucked away"
                side: sc.tipSide
            }
        }

        // ---- the open panel ----
        Rectangle {
            id: panel
            width: sc.vert ? sc.panelThick : sc.panelLen
            height: sc.vert ? sc.panelLen : sc.panelThick
            readonly property real gapEdge: 10
            x: sc.side === "left" ? gapEdge : sc.side === "right" ? win.width - width - gapEdge : (win.width - width) / 2
            y: sc.side === "top" ? gapEdge : sc.side === "bottom" ? win.height - height - gapEdge : (win.height - height) / 2
            // slides out of the edge and springs a little
            transform: Translate {
                x: sc.side === "left" ? -(1 - sc.ex) * (panel.width + 14) : sc.side === "right" ? (1 - sc.ex) * (panel.width + 14) : 0
                y: sc.side === "top" ? -(1 - sc.ex) * (panel.height + 14) : sc.side === "bottom" ? (1 - sc.ex) * (panel.height + 14) : 0
            }
            opacity: Math.min(1, sc.ex * 1.6)
            visible: sc.ex > 0.01
            radius: Math.min(Theme.radius + 4, sc.panelThick / 2)
            color: Theme.glass
            border.width: 1; border.color: Theme.stroke

            Grid {
                id: col
                anchors.centerIn: parent
                columns: sc.vert ? 1 : 1000
                spacing: 0
                horizontalItemAlignment: Grid.AlignHCenter
                verticalItemAlignment: Grid.AlignVCenter

                // grip: drag the open panel too
                Item {
                    width: sc.vert ? sc.cell : sc.grip
                    height: sc.vert ? sc.grip : sc.cell
                    Rectangle {
                        anchors.centerIn: parent
                        width: sc.vert ? 22 : 4; height: sc.vert ? 4 : 22; radius: 2
                        color: gripMa.containsMouse || gripMa.pressed ? Theme.tertiary : Theme.subtext
                        opacity: 0.7
                    }
                    DragArea { id: gripMa; anchors.fill: parent; onTapped: sc.expanded = false; onMoving: p => sc.dragMove(p); onDropped: sc.dragEnd() }
                    HoverTip { hovered: gripMa.containsMouse && !gripMa.pressed; text: "Drag to move, click to fold"; side: sc.tipSide }
                }

                Repeater {
                    model: sc.items.slice(0, sc.shownCells)
                    delegate: Item {
                        id: it
                        required property var modelData
                        required property int index
                        readonly property var entry: Apps.byId(modelData.cls)
                        width: sc.cell; height: sc.cell
                        Rectangle {
                            anchors.fill: parent; anchors.margins: 3; radius: 14
                            color: ima.containsMouse ? Theme.hover : "transparent"
                            Behavior on color { ColorAnimation { duration: 100 } }
                        }
                        AppIcon {
                            id: ic
                            anchors.centerIn: parent
                            size: sc.icon
                            entry: it.entry ?? null
                            source: it.entry ? "" : (it.modelData.cls || "application-x-executable")
                            scale: ima.pressed ? 0.84 : (ima.containsMouse ? 1.1 : 1)
                            Behavior on scale { NumberAnimation { duration: 240; easing.type: Easing.OutBack; easing.overshoot: Motion.os(2.4) } }
                        }
                        // new ones pop in, one after another when the panel opens
                        property int born: 0
                        Component.onCompleted: born = 100000
                        Enter { trigger: sc.openSerial + it.born; delay: 40 + it.index * 35; from: 0.6 }
                        HoverTip {
                            hovered: ima.containsMouse
                            text: (it.modelData.title || it.entry?.name || it.modelData.cls) + "\nClick: bring back  ·  Middle-click: close"
                            side: sc.tipSide
                        }
                        MouseArea {
                            id: ima
                            anchors.fill: parent
                            hoverEnabled: true
                            cursorShape: Qt.PointingHandCursor
                            acceptedButtons: Qt.LeftButton | Qt.MiddleButton
                            onClicked: mouse => {
                                // (read everything first: bringing it back removes this icon, and with it this code's context)
                                const a = it.modelData.address, mid = mouse.button === Qt.MiddleButton, dock = sc
                                if (dock.n <= 1) dock.expanded = false
                                if (mid) EdgeTuck.close(a)
                                else EdgeTuck.restore(a)
                            }
                        }
                    }
                }

                // more than fit: the rest are counted (they come back with "bring all back")
                // and "bring all back" itself
                Item {
                    visible: sc.n > 1
                    width: sc.cell; height: sc.cell
                    Rectangle {
                        anchors.centerIn: parent
                        width: sc.icon; height: sc.icon; radius: sc.icon / 2
                        color: allMa.containsMouse ? Theme.tertiary : Theme.tertiaryContainer
                        scale: allMa.pressed ? 0.86 : (allMa.containsMouse ? 1.08 : 1)
                        Behavior on scale { NumberAnimation { duration: 240; easing.type: Easing.OutBack; easing.overshoot: Motion.os(2.4) } }
                        Behavior on color { ColorAnimation { duration: 120 } }
                        Icon {
                            anchors.centerIn: parent
                            visible: sc.n <= sc.shownCells
                            name: "select_window"; size: 20
                            color: allMa.containsMouse ? Theme.onTertiary : Theme.onTertiaryContainer
                        }
                        DText {
                            anchors.centerIn: parent
                            visible: sc.n > sc.shownCells
                            text: "+" + (sc.n - sc.shownCells)
                            font.pixelSize: 13; font.weight: Font.Bold
                            color: allMa.containsMouse ? Theme.onTertiary : Theme.onTertiaryContainer
                        }
                    }
                    HoverTip { hovered: allMa.containsMouse; text: "Bring all " + sc.n + " back"; side: sc.tipSide }
                    MouseArea {
                        id: allMa
                        anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor
                        onClicked: { sc.expanded = false; EdgeTuck.restoreAll() }
                    }
                }
            }
        }
    }

    property int openSerial: 0
    onExpandedChanged: if (expanded) openSerial++

    // dragging: the panel does not move meanwhile, so its place on the screen + the pointer's place
    // in it = the pointer's place on the screen
    function dragMove(p) { const o = win.origin(); gx = o.x + p.x; gy = o.y + p.y; dragging = true }
    function dragEnd() {
        if (!dragging) return
        Config.c.edgeSide = target.side
        Config.c.edgeAlong = Math.round(target.along * 1000) / 1000
        dragging = false
    }

    // a press that turns into a drag moves the panel (`moving`, in window coordinates); a plain
    // click is `tapped`. (An inline component cannot see the ids above, hence the signals.)
    component DragArea: MouseArea {
        id: da
        signal tapped()
        signal moving(point p)
        signal dropped()
        hoverEnabled: true
        preventStealing: true
        cursorShape: moved ? Qt.ClosedHandCursor : Qt.PointingHandCursor
        property real px: 0
        property real py: 0
        property bool moved: false
        onPressed: mouse => { px = mouse.x; py = mouse.y; moved = false }
        onPositionChanged: mouse => {
            if (!pressed) return
            if (!moved && Math.abs(mouse.x - px) + Math.abs(mouse.y - py) < 8) return
            moved = true
            da.moving(da.mapToItem(null, mouse.x, mouse.y))
        }
        onReleased: { if (moved) da.dropped(); else da.tapped(); moved = false }
        onCanceled: { if (moved) da.dropped(); moved = false }
    }
}
