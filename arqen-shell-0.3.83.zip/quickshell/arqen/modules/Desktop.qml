import Quickshell
import Quickshell.Wayland
import Quickshell.Io
import Quickshell.Widgets
import Quickshell.Services.UPower
import QtQuick
import QtQuick.Layouts
import QtQuick.Shapes
import Qt.labs.folderlistmodel
import qs.config
import qs.components
import qs.services
import qs.settings

// The desktop: app shortcuts and widgets on a grid, behind every window.
//   click an app = open it
//   press and hold (an app or a widget) = pick it up, drag it, let go = it snaps to the nearest
//   free spot (two app icons swap places). Positions are saved in Config.c.desktopPos.
//   right-click = options (the desktop: wallpaper, display, settings; an app or widget: remove it)
// Apps get here by dragging them out of the launcher (press and hold one there); widgets are
// added from the right-click menu or Settings > Desktop.
// Files and folders: whatever is in ~/Desktop shows up here too (right-click > New folder / New
// text file, or save something there). Click = open, right-click = rename, move to trash ...
PanelWindow {
    id: win
    screen: Quickshell.screens[0]
    visible: true
    color: "transparent"
    anchors { top: true; bottom: true; left: true; right: true }
    margins { top: Ui.rTop + Ui.gap; bottom: Ui.rBottom + Ui.gap; left: Ui.rLeft + Ui.gap; right: Ui.rRight + Ui.gap }
    exclusionMode: ExclusionMode.Ignore
    WlrLayershell.layer: WlrLayer.Bottom
    WlrLayershell.namespace: "arqen-desktop"
    // the keyboard only while a name is being typed (rename / new folder)
    WlrLayershell.keyboardFocus: renaming !== "" ? WlrKeyboardFocus.Exclusive : (Widgets.typing || editingWidget !== "") ? WlrKeyboardFocus.OnDemand : WlrKeyboardFocus.None

    // ---------- files in ~/Desktop ----------
    readonly property string deskDir: Config.home + "/Desktop"
    property var files: []                      // [{ name, path, dir }]
    FolderListModel {
        id: dirModel
        folder: "file://" + win.deskDir
        showDirs: true
        showDirsFirst: true
        showDotAndDotDot: false
        showHidden: false
        sortField: FolderListModel.Name
    }
    function readFiles() {
        const out = []
        for (let i = 0; i < dirModel.count; i++)
            out.push({ name: dirModel.get(i, "fileName"), path: dirModel.get(i, "filePath"), dir: dirModel.get(i, "fileIsDir") })
        files = out
    }
    Connections {
        target: dirModel
        ignoreUnknownSignals: true
        function onCountChanged() { Qt.callLater(win.readFiles) }
        function onStatusChanged() { Qt.callLater(win.readFiles) }
        function onRowsInserted() { Qt.callLater(win.readFiles) }
        function onRowsRemoved() { Qt.callLater(win.readFiles) }
        function onDataChanged() { Qt.callLater(win.readFiles) }
        function onModelReset() { Qt.callLater(win.readFiles) }
    }
    // a theme icon for a file, by its extension
    function fileIcon(f) {
        if (f.dir) return "folder"
        const m = /\.([^.]+)$/.exec(f.name.toLowerCase())
        const e = m ? m[1] : ""
        const map = {
            txt: "text-x-generic", md: "text-x-generic", log: "text-x-generic", conf: "text-x-generic",
            pdf: "application-pdf", html: "text-html", htm: "text-html", sh: "text-x-script", py: "text-x-script",
            mp4: "video-x-generic", mkv: "video-x-generic", webm: "video-x-generic", mov: "video-x-generic", avi: "video-x-generic",
            mp3: "audio-x-generic", flac: "audio-x-generic", ogg: "audio-x-generic", wav: "audio-x-generic", m4a: "audio-x-generic", opus: "audio-x-generic",
            zip: "package-x-generic", tar: "package-x-generic", gz: "package-x-generic", xz: "package-x-generic", zst: "package-x-generic",
            "7z": "package-x-generic", rar: "package-x-generic", rpm: "package-x-generic", flatpakref: "package-x-generic",
            doc: "x-office-document", docx: "x-office-document", odt: "x-office-document", rtf: "x-office-document",
            xls: "x-office-spreadsheet", xlsx: "x-office-spreadsheet", ods: "x-office-spreadsheet", csv: "x-office-spreadsheet",
            ppt: "x-office-presentation", pptx: "x-office-presentation", odp: "x-office-presentation",
            iso: "media-optical", desktop: "application-x-executable", appimage: "application-x-executable"
        }
        return map[e] ?? "text-x-generic"
    }
    function isPicture(f) { return !f.dir && /\.(png|jpe?g|webp|gif|bmp|svg)$/i.test(f.name) }
    function openFile(f) {
        if (/\.desktop$/i.test(f.name)) Quickshell.execDetached(["gio", "launch", f.path])
        else Quickshell.execDetached(["xdg-open", f.path])
    }
    function trashFile(f) { Quickshell.execDetached(["gio", "trash", f.path]) }
    // new folder / file with a free name, then let the user name it
    function newItem(folder) {
        // files and folders were hidden: show them, or the new one would not appear
        if (!Config.c.desktopFiles) Config.c.desktopFiles = true
        const base = folder ? "New folder" : "New file.txt"
        let name = base, n = 2
        while (files.some(f => f.name === name)) {
            name = folder ? base + " " + n : "New file " + n + ".txt"
            n++
        }
        const path = deskDir + "/" + name
        Quickshell.execDetached(["sh", "-c", (folder ? "mkdir -p \"$1\"" : "[ -e \"$1\" ] || : > \"$1\""), "new", path])
        // put it where the menu was opened
        expect(name, cellAt(menuX - cellW / 2, menuY - cellH / 2, 1, 1))
        startRename(name)
    }
    // files about to appear (new, or dropped here) and the cell they should get: { key: { c, r } }
    property var pending: ({})
    function expect(name, cell) { const p = Object.assign({}, pending); p["file:" + name] = cell; pending = p }
    onFilesChanged: {
        // a cut file that has gone (pasted somewhere else) is no longer shown faded
        if (cutPaths.length > 0) cutPaths = cutPaths.filter(p => files.some(f => f.path === p))
        const keys = Object.keys(pending)
        if (keys.length === 0) return
        const pos = Object.assign({}, Config.c.desktopPos || {})
        const left = {}
        let changed = false
        for (const k of keys) {
            if (!files.some(f => "file:" + f.name === k)) { left[k] = pending[k]; continue }
            const want = pending[k]
            if (want && freeFor(k, want.c, want.r, 1, 1)) { pos[k] = want; changed = true }
        }
        pending = left
        if (changed) Config.c.desktopPos = pos
    }

    // ---- files dragged in from Files (or anything else that drags files) ----
    // Dropped files are moved here (or copied: Settings > Desktop); each lands on the free spot
    // nearest to where it was dropped.
    function dropUrls(urls, move, px, py) {
        const paths = []
        for (let i = 0; i < urls.length; i++) {
            const u = String(urls[i])
            if (!u.startsWith("file://")) continue
            paths.push(decodeURIComponent(u.slice(7)))
        }
        if (paths.length === 0) return
        // which cells: around the drop point, skipping taken ones
        let c0 = cellAt(px - cellW / 2, py - cellH / 2, 1, 1)
        const taken = {}
        const cells = []
        for (const p of paths) {
            let best = null, bd = 1e9
            for (let c = 0; c < cols; c++) for (let r = 0; r < rows; r++) {
                if (taken[c + "," + r] || !freeFor("", c, r, 1, 1)) continue
                const d = (c - c0.c) * (c - c0.c) + (r - c0.r) * (r - c0.r)
                if (d < bd) { bd = d; best = { c: c, r: r } }
            }
            if (best) taken[best.c + "," + best.r] = true
            cells.push(best)
        }
        const toMove = []
        for (let i = 0; i < paths.length; i++) {
            const p = paths[i]
            const name = p.replace(/\/+$/, "").split("/").pop()
            const already = p.replace(/\/+$/, "") === deskDir + "/" + name
            if (cells[i]) {
                if (already) {   // just a new place on the grid
                    const pos = Object.assign({}, Config.c.desktopPos || {})
                    pos["file:" + name] = cells[i]
                    Config.c.desktopPos = pos
                } else expect(name, cells[i])
            }
            if (!already) toMove.push(p)
        }
        if (toMove.length > 0)
            Quickshell.execDetached(["sh", "-c",
                // (a sandboxed app's file comes as a portal copy under /run/user/…/doc: always copied)
                "op=\"$1\"; d=\"$2\"; shift 2; for f; do case \"$op:$f\" in move:/run/user/*/doc/*|copy:*) cp -rn -- \"$f\" \"$d\" ;; *) mv -n -- \"$f\" \"$d\" ;; esac; done",
                "drop", move ? "move" : "copy", deskDir + "/"].concat(toMove))
    }
    // Anything that drags files (any file manager, a browser's downloads, an archive manager...):
    // file links as a URL list, or as plain text (one path or file:// link per line) from some apps
    function dragPaths(d) {
        const out = []
        if (d.hasUrls) for (let i = 0; i < d.urls.length; i++) out.push(String(d.urls[i]))
        if (out.length === 0 && d.hasText)
            for (const l of String(d.text).split(/\r?\n/)) {
                const t = l.trim()
                if (t.startsWith("file://")) out.push(t)
                else if (t.startsWith("/")) out.push("file://" + encodeURI(t))
            }
        return out
    }
    property bool dropping: false               // something is being dragged over the desktop
    DropArea {
        anchors.fill: parent
        onEntered: drag => {
            const ok = drag.hasUrls || drag.hasText
            if (!ok) { drag.accepted = false; return }
            win.dropping = true
            // the app is told "copy" either way: the desktop moves the files itself when it should,
            // so no file manager ever deletes or keeps anything on its own after the drop
            drag.accept(Qt.CopyAction)
        }
        onExited: win.dropping = false
        onDropped: drop => {
            win.dropping = false
            const urls = win.dragPaths(drop)
            if (urls.length === 0) return
            // Settings > Desktop: move them here (default) or leave the originals and copy
            const move = (Config.c.desktopDrop || "move") === "move"
            // the files on the desktop were switched off: switch them on, or the dropped ones would not show
            if (!Config.c.desktopFiles) Config.c.desktopFiles = true
            win.dropUrls(urls, move, drop.x, drop.y)
            drop.accept(Qt.CopyAction)
        }
    }
    // while dragging over it: a soft outline, so you can see the desktop will take it
    Rectangle {
        anchors.fill: parent
        radius: Theme.radius
        color: Qt.rgba(Theme.primary.r, Theme.primary.g, Theme.primary.b, 0.06)
        border.width: 2; border.color: Qt.rgba(Theme.primary.r, Theme.primary.g, Theme.primary.b, 0.6)
        opacity: win.dropping ? 1 : 0
        visible: opacity > 0
        Behavior on opacity { NumberAnimation { duration: 160 } }
    }
    // ---- renaming ----
    property string editingWidget: ""            // the widget whose editor is open on the desktop (its id)
    property string renaming: ""                // the file's current name while the box is up
    function startRename(name) { renaming = name; renameField.text = name; Qt.callLater(renameField.focusInput) }
    function finishRename(newName) {
        const from = renaming
        renaming = ""
        newName = (newName || "").trim()
        if (newName === "" || newName === from || newName.indexOf("/") >= 0) return
        if (files.some(f => f.name === newName)) return
        // keep its place on the grid
        const pos = Object.assign({}, Config.c.desktopPos || {})
        if (pos["file:" + from]) { pos["file:" + newName] = pos["file:" + from]; delete pos["file:" + from] }
        Config.c.desktopPos = pos
        Quickshell.execDetached(["mv", "-n", "--", deskDir + "/" + from, deskDir + "/" + newName])
    }

    SystemClock { id: clock; precision: SystemClock.Minutes }
    // the launcher finds the desktop through this to drop apps on it
    Component.onCompleted: { Ui.desktop = win; Quickshell.execDetached(["mkdir", "-p", deskDir]); syncKeys() }
    Component.onDestruction: if (Ui.desktop === win) Ui.desktop = null

    // ---------- the grid ----------
    readonly property int iconSize: Config.c.desktopIconSize
    readonly property int cellW: iconSize + 46
    readonly property int cellH: iconSize + 50
    readonly property int cols: Math.max(1, Math.floor(width / cellW))
    readonly property int rows: Math.max(1, Math.floor(height / cellH))
    readonly property real ox: Math.floor((width - cols * cellW) / 2)
    readonly property real oy: Math.floor((height - rows * cellH) / 2)


    // everything on the desktop: { key, kind: "app" | "widget", ref, w, h }
    readonly property var things: {
        const out = []
        if (Config.c.desktopIcons) {
            for (const id of (Config.c.desktopApps || []))
                if (Apps.byId(id)) out.push({ key: "app:" + id, kind: "app", ref: id, w: 1, h: 1 })
        }
        if (Config.c.desktopFiles) {
            for (const f of win.files) out.push({ key: "file:" + f.name, kind: "file", ref: f.path, file: f, w: 1, h: 1 })
        }
        if (Config.c.desktopWidgetsOn) {
            // each its own size (Settings > Desktop > Widgets: Small / Medium / Large)
            for (const wd of (Config.c.desktopWidgets || [])) {
                if (!Widgets.types[wd.type]) continue
                const sz = Widgets.cells(wd)
                out.push({ key: "widget:" + wd.id, kind: "widget", ref: wd.type, w: sz[0], h: sz[1], cfg: Widgets.cfg(wd) })
            }
        }
        return out
    }

    // The items by key, and the list of keys the Repeater uses: that list is only replaced when items are added or
    // removed, so changing an option of a widget updates it in place (it used to rebuild every icon and widget)
    readonly property var thingMap: { const m = {}; for (const t of things) m[t.key] = t; return m }
    property var thingKeys: []
    property string thingKeysSig: ""
    onThingsChanged: syncKeys()
    function syncKeys() {
        const k = things.map(t => t.key), sig = k.join("\n")
        if (sig !== thingKeysSig) { thingKeysSig = sig; thingKeys = k }
    }

    // Where everything goes: its saved spot when that is free and on screen, otherwise the first
    // free spot (top-left, going down each column). { key: { c, r } or null when it does not fit }
    function place(list, saved, cols, rows) {
        const occ = {}
        const out = {}
        function fits(c, r, w, h) {
            if (c < 0 || r < 0 || c + w > cols || r + h > rows) return false
            for (let y = r; y < r + h; y++) for (let x = c; x < c + w; x++) if (occ[x + "," + y]) return false
            return true
        }
        function take(key, c, r, w, h) {
            for (let y = r; y < r + h; y++) for (let x = c; x < c + w; x++) occ[x + "," + y] = true
            out[key] = { c: c, r: r }
        }
        const later = []
        for (const t of list) {
            const sp = saved[t.key]
            if (sp && fits(sp.c, sp.r, t.w, t.h)) take(t.key, sp.c, sp.r, t.w, t.h)
            else later.push(t)
        }
        for (const t of later) {
            let done = false
            for (let c = 0; c < cols && !done; c++)
                for (let r = 0; r < rows && !done; r++)
                    if (fits(c, r, t.w, t.h)) { take(t.key, c, r, t.w, t.h); done = true }
            if (!done) out[t.key] = null
        }
        return out
    }
    readonly property var placed: place(things, Config.c.desktopPos || {}, cols, rows)

    // ---------- moving things ----------
    property string dragKey: ""
    property var ghost: null              // { c, r, w, h } where the dragged thing would land

    function thing(key) { return things.find(t => t.key === key) ?? null }
    function cellAt(px, py, w, h) {
        return {
            c: Math.max(0, Math.min(cols - w, Math.round((px - ox) / cellW))),
            r: Math.max(0, Math.min(rows - h, Math.round((py - oy) / cellH)))
        }
    }
    // the thing (other than `key`) covering cell c, r
    function occupant(key, c, r) {
        for (const t of things) {
            if (t.key === key) continue
            const p = placed[t.key]
            if (p && c >= p.c && c < p.c + t.w && r >= p.r && r < p.r + t.h) return t
        }
        return null
    }
    function freeFor(key, c, r, w, h) {
        if (c < 0 || r < 0 || c + w > cols || r + h > rows) return false
        for (let y = r; y < r + h; y++) for (let x = c; x < c + w; x++) if (occupant(key, x, y)) return false
        return true
    }
    // The spot a thing dropped with its top-left corner at (px, py) ends up in:
    // { c, r, swap: key of the icon it swaps with, or "" }
    function target(key, px, py) {
        const t = thing(key)
        if (!t) return null
        const want = cellAt(px, py, t.w, t.h)
        if (freeFor(key, want.c, want.r, t.w, t.h)) return { c: want.c, r: want.r, swap: "" }
        const o = occupant(key, want.c, want.r)
        if (o && t.w === 1 && t.h === 1 && o.w === 1 && o.h === 1) return { c: want.c, r: want.r, swap: o.key }
        // nearest free spot
        let best = null, bd = 1e9
        for (let c = 0; c <= cols - t.w; c++) {
            for (let r = 0; r <= rows - t.h; r++) {
                if (!freeFor(key, c, r, t.w, t.h)) continue
                const d = (c - want.c) * (c - want.c) + (r - want.r) * (r - want.r)
                if (d < bd) { bd = d; best = { c: c, r: r, swap: "" } }
            }
        }
        return best
    }
    // An app dragged out of the launcher. (px, py) = the icon's top-left in this window.
    function addAppAt(appId, px, py) {
        if (!appId) return
        const key = "app:" + appId
        const pos = {}
        for (const th of things) { const p = placed[th.key]; if (p && th.key !== key) pos[th.key] = { c: p.c, r: p.r } }
        // the spot under the pointer, or the nearest free one
        const want = cellAt(px, py, 1, 1)
        let spot = null
        if (freeFor(key, want.c, want.r, 1, 1)) spot = want
        else {
            let bd = 1e9
            for (let c = 0; c < cols; c++) for (let r = 0; r < rows; r++) {
                if (!freeFor(key, c, r, 1, 1)) continue
                const d = (c - want.c) * (c - want.c) + (r - want.r) * (r - want.r)
                if (d < bd) { bd = d; spot = { c: c, r: r } }
            }
        }
        if (spot) pos[key] = { c: spot.c, r: spot.r }
        const apps = (Config.c.desktopApps || []).filter(x => x !== appId)
        apps.push(appId)
        Config.c.desktopApps = apps
        Config.c.desktopIcons = true
        Config.c.desktopPos = pos
    }
    function removeApp(appId) { Config.c.desktopApps = (Config.c.desktopApps || []).filter(x => x !== appId) }
    function addWidget(type) { Widgets.add(type) }
    function removeWidget(wid) { Widgets.remove(wid) }

    // ---------- right-click menu ----------
    property var menuItems: []
    property real menuX: 0
    property real menuY: 0
    function openMenu(items, x, y) { menuItems = items; menuX = x; menuY = y }
    function closeMenu() { menuItems = [] }

    // ---- cut / copy / paste, shared with file managers through the clipboard ----
    property var cutPaths: []                   // cut and not pasted yet: shown faded
    // no longer faded once the file has gone (pasted somewhere else), or something else was copied
    // (done in the onFilesChanged handler above: a property has only one handler)
    Process {
        running: true
        command: ["wl-paste", "--watch", "echo", "c"]
        stdout: SplitParser { onRead: if (win.cutPaths.length > 0 && !cutCheck.running) cutCheck.running = true }
    }
    Process {
        id: cutCheck
        command: ["sh", Quickshell.shellDir + "/scripts/file-clip.sh", "get"]
        stdout: StdioCollector {
            onStreamFinished: {
                const l = text.split("\n").map(x => x.trim()).filter(x => x !== "")
                const paths = l.slice(1).filter(u => u.startsWith("file://")).map(u => decodeURIComponent(u.slice(7)))
                if (l[0] !== "cut" || !win.cutPaths.every(p => paths.indexOf(p) >= 0)) win.cutPaths = []
            }
        }
    }
    function clipFiles(paths, cut) {
        cutPaths = cut ? paths : []
        Quickshell.execDetached(["sh", Quickshell.shellDir + "/scripts/file-clip.sh", "set", cut ? "cut" : "copy"].concat(paths))
    }
    property real pasteX: 0
    property real pasteY: 0
    function paste(x, y) { pasteX = x; pasteY = y; if (!pasteProc.running) pasteProc.running = true }
    Process {
        id: pasteProc
        command: ["sh", Quickshell.shellDir + "/scripts/file-clip.sh", "get"]
        stdout: StdioCollector {
            onStreamFinished: {
                const l = text.split("\n").map(x => x.trim()).filter(x => x !== "")
                if (l.length < 2 || (l[0] !== "copy" && l[0] !== "cut")) return
                const urls = l.slice(1).filter(u => u.startsWith("file://"))
                if (urls.length === 0) return
                const cut = l[0] === "cut"
                if (!Config.c.desktopFiles) Config.c.desktopFiles = true
                win.dropUrls(urls, cut, win.pasteX, win.pasteY)
                // a cut is used up once pasted (as in file managers)
                if (cut) { win.cutPaths = []; Quickshell.execDetached(["sh", Quickshell.shellDir + "/scripts/file-clip.sh", "clear"]) }
            }
        }
    }
    function desktopMenu() {
        return [
            { icon: "content_paste", text: "Paste", act: () => win.paste(win.menuX, win.menuY) },
            { k: "sep" },
            { icon: "create_new_folder", text: "New folder", act: () => win.newItem(true) },
            { icon: "note_add", text: "New text file", act: () => win.newItem(false) },
            { icon: "folder_open", text: "Open Desktop folder", act: () => QuickSettings.openFolder(win.deskDir) },
            { k: "sep" },
            { icon: "wallpaper", text: "Change wallpaper", act: () => Ui.openSettings("wallpaper") },
            { icon: "brightness_6", text: "Display settings", act: () => Ui.openSettings("display") },
            { k: "sep" },
            { icon: "apps", text: "Add apps: hold one in the launcher and drag it here", act: () => Ui.toggle("launcher") },
            { icon: "widgets", text: "Add a widget…", act: () => win.pickWidget(win.menuX, win.menuY) },
            { icon: "settings", text: "Open settings", act: () => Ui.openSettings("") }
        ]
    }
    // where the pointer was (in an item) as window coordinates
    function at(item, mx, my) { return item.mapToItem(null, mx, my) }

    // empty desktop: right-click = menu, click = close it
    MouseArea {
        anchors.fill: parent
        acceptedButtons: Qt.LeftButton | Qt.RightButton
        onClicked: mouse => {
            if (mouse.button === Qt.RightButton) win.openMenu(win.desktopMenu(), mouse.x, mouse.y)
            else win.closeMenu()
        }
    }

    function drop(key, px, py) {
        const t = target(key, px, py)
        if (!t) return
        // keep everything where it is now (so nothing else jumps around), then move this one
        const pos = {}
        for (const th of things) { const p = placed[th.key]; if (p) pos[th.key] = { c: p.c, r: p.r } }
        if (t.swap !== "" && placed[key]) pos[t.swap] = { c: placed[key].c, r: placed[key].r }
        pos[key] = { c: t.c, r: t.r }
        Config.c.desktopPos = pos
    }

    // ---------- drawing ----------
    Rectangle {   // where the dragged thing will land
        visible: win.dragKey !== "" && win.ghost !== null
        x: win.ghost ? win.ox + win.ghost.c * win.cellW + 4 : 0
        y: win.ghost ? win.oy + win.ghost.r * win.cellH + 4 : 0
        width: win.ghost ? win.ghost.w * win.cellW - 8 : 0
        height: win.ghost ? win.ghost.h * win.cellH - 8 : 0
        radius: 18
        color: Qt.rgba(1, 1, 1, 0.10)
        border.width: 2
        border.color: Theme.accent
    }

    Repeater {
        model: win.thingKeys
        delegate: Item {
            id: it
            required property string modelData      // the key: the item itself is looked up, so a changed option does not rebuild every item
            readonly property var thing: win.thingMap[modelData] ?? ({ key: modelData, kind: "", ref: "", w: 1, h: 1, cfg: ({}) })
            readonly property var pos: win.placed[modelData] ?? null
            readonly property bool isApp: thing.kind === "app"
            readonly property bool isFile: thing.kind === "file"
            readonly property var entry: isApp ? Apps.byId(thing.ref) : null
            property bool dragging: false
            property real dx: 0
            property real dy: 0
            visible: pos !== null
            width: thing.w * win.cellW
            height: thing.h * win.cellH
            x: dragging ? dx : (pos ? win.ox + pos.c * win.cellW : 0)
            y: dragging ? dy : (pos ? win.oy + pos.r * win.cellH : 0)
            z: dragging ? 10 : 1
            scale: dragging ? 1.06 : 1
            // cut (waiting to be pasted somewhere): faded
            opacity: dragging ? 0.9 : (isFile && win.cutPaths.indexOf(thing.file.path) >= 0 ? 0.45 : 1)
            Behavior on opacity { NumberAnimation { duration: 150 } }
            Behavior on x { enabled: !it.dragging; NumberAnimation { duration: 180; easing.type: Easing.OutCubic } }
            Behavior on y { enabled: !it.dragging; NumberAnimation { duration: 180; easing.type: Easing.OutCubic } }
            Behavior on scale { NumberAnimation { duration: 120 } }

            // A file dragged straight away (no press and hold): a real drag and drop, so it can go into
            // any file manager (moved there, or copied: the file manager decides, as with any drag);
            // let go on the desktop again and it just takes that spot. (Press and hold = arrange.)
            readonly property string fileUrl: isFile ? "file://" + encodeURI(thing.file.path) : ""
            Drag.dragType: Drag.Automatic
            Drag.supportedActions: Qt.MoveAction | Qt.CopyAction
            Drag.proposedAction: Qt.MoveAction
            Drag.mimeData: isFile ? ({ "text/uri-list": fileUrl + "\r\n", "text/plain": thing.file.path }) : ({})
            Drag.hotSpot.x: width / 2
            Drag.hotSpot.y: height / 2
            Drag.onDragFinished: dropAction => { it.Drag.active = false }

            // Below the content, so buttons inside a widget still get their clicks.
            MouseArea {
                id: ma
                anchors.fill: parent
                hoverEnabled: true
                preventStealing: true
                pressAndHoldInterval: 450
                acceptedButtons: Qt.LeftButton | Qt.RightButton
                cursorShape: it.dragging ? Qt.ClosedHandCursor : ((it.isApp || it.isFile) ? Qt.PointingHandCursor : Qt.ArrowCursor)
                property real gx: 0
                property real gy: 0
                onPressAndHold: mouse => {
                    if (mouse.button !== Qt.LeftButton) return
                    win.closeMenu()
                    gx = mouse.x; gy = mouse.y
                    it.dx = it.x; it.dy = it.y
                    it.dragging = true
                    win.dragKey = it.thing.key
                    const t = win.target(it.thing.key, it.x, it.y)
                    win.ghost = t ? { c: t.c, r: t.r, w: it.thing.w, h: it.thing.h } : null
                }
                property real px0: 0
                property real py0: 0
                onPressed: mouse => { px0 = mouse.x; py0 = mouse.y }
                onPositionChanged: mouse => {
                    // a file pulled away at once: hand it to the system's drag and drop
                    if (!it.dragging && pressed && it.isFile && !it.Drag.active
                        && Math.abs(mouse.x - px0) + Math.abs(mouse.y - py0) > 12) {
                        win.closeMenu()
                        it.Drag.active = true
                        return
                    }
                    if (!it.dragging) return
                    const p = ma.mapToItem(null, mouse.x, mouse.y)       // window coordinates, like it.x / it.y
                    it.dx = p.x - gx
                    it.dy = p.y - gy
                    const t = win.target(it.thing.key, it.dx, it.dy)
                    win.ghost = t ? { c: t.c, r: t.r, w: it.thing.w, h: it.thing.h } : null
                }
                function finish(save) {
                    if (!it.dragging) return
                    const key = it.thing.key, px = it.dx, py = it.dy
                    it.dragging = false
                    win.dragKey = ""
                    win.ghost = null
                    if (save) win.drop(key, px, py)
                }
                onReleased: finish(true)
                onCanceled: finish(false)
                onDoubleClicked: mouse => { if (!it.isApp && !it.isFile) { win.closeMenu(); win.editingWidget = it.thing.key.slice(7) } }
                onClicked: mouse => {
                    const p = win.at(ma, mouse.x, mouse.y)
                    if (mouse.button === Qt.RightButton) {
                        const m = it.thing
                        if (it.isFile) {
                            const f = m.file
                            win.openMenu([
                                { icon: "open_in_new", text: "Open", act: () => win.openFile(f) },
                                { k: "sep" },
                                { icon: "content_cut", text: "Cut", act: () => win.clipFiles([f.path], true) },
                                { icon: "content_copy", text: "Copy", act: () => win.clipFiles([f.path], false) },
                                { k: "sep" },
                                { icon: "drive_file_rename_outline", text: "Rename", act: () => win.startRename(f.name) },
                                { icon: "link", text: "Copy path", act: () => Quickshell.execDetached(["wl-copy", "--", f.path]) },
                                { icon: "folder_open", text: "Show in Files", act: () => QuickSettings.openFolder(win.deskDir) },
                                { k: "sep" },
                                { icon: "delete", text: "Move to trash", danger: true, act: () => win.trashFile(f) }
                            ], p.x, p.y)
                            return
                        }
                        win.openMenu(it.isApp
                            ? [{ icon: "open_in_new", text: "Open " + (it.entry?.name ?? ""), act: () => { if (it.entry) it.entry.execute() } },
                               { icon: "delete", text: "Remove from desktop", danger: true, act: () => win.removeApp(m.ref) }]
                            : [{ icon: "tune", text: "Customise widget", act: () => { win.closeMenu(); win.editingWidget = m.key.slice(7) } },
                               { icon: "settings", text: "All options in Settings", act: () => { Ui.editWidget = m.key.slice(7); Ui.openSettings("desktop") } },
                               { icon: "photo_size_select_large", text: "Resize (pull its corner)", act: () => { win.closeMenu(); win.editingWidget = m.key.slice(7) } },
                               { icon: "palette", text: "Look: " + Widgets.looks[(Widgets.looks.indexOf(m.cfg.look) + 1) % Widgets.looks.length],
                                 act: () => Widgets.set(m.key.slice(7), "look", Widgets.looks[(Widgets.looks.indexOf(m.cfg.look) + 1) % Widgets.looks.length]) },
                               { k: "sep" },
                               { icon: "delete", text: "Remove widget", danger: true, act: () => win.removeWidget(m.key.slice(7)) }],
                            p.x, p.y)
                        return
                    }
                    win.closeMenu()
                    if (it.isApp && it.entry) it.entry.execute()
                    else if (it.isFile) win.openFile(it.thing.file)
                }
            }

            // ---- an app ----
            Item {
                visible: it.isApp
                anchors.fill: parent
                Rectangle { anchors { fill: parent; margins: 4 } radius: 18; color: (ma.containsMouse || it.dragging) ? Qt.rgba(1, 1, 1, 0.12) : "transparent" }
                AppIcon {
                    anchors.horizontalCenter: parent.horizontalCenter
                    y: 8
                    size: win.iconSize
                    entry: it.entry
                }
                DText {
                    anchors { bottom: parent.bottom; left: parent.left; right: parent.right; bottomMargin: 8; leftMargin: 4; rightMargin: 4 }
                    text: it.entry?.name ?? ""
                    color: "white"; style: Text.Outline; styleColor: "#66000000"
                    horizontalAlignment: Text.AlignHCenter; elide: Text.ElideRight; font.pixelSize: 12
                }
            }

            // ---- a file or folder ----
            Item {
                visible: it.isFile
                anchors.fill: parent
                Rectangle { anchors { fill: parent; margins: 4 } radius: 18; color: (ma.containsMouse || it.dragging) ? Qt.rgba(1, 1, 1, 0.12) : "transparent" }
                AppIcon {
                    visible: !(it.isFile && win.isPicture(it.thing.file))
                    anchors.horizontalCenter: parent.horizontalCenter
                    y: 8
                    size: win.iconSize
                    source: it.isFile ? win.fileIcon(it.thing.file) : ""
                }
                ClippingRectangle {   // pictures show themselves
                    visible: it.isFile && win.isPicture(it.thing.file)
                    anchors.horizontalCenter: parent.horizontalCenter
                    y: 8
                    width: win.iconSize; height: win.iconSize
                    radius: 10
                    color: Qt.rgba(1, 1, 1, 0.1)
                    Image {
                        anchors.fill: parent
                        source: (it.isFile && win.isPicture(it.thing.file)) ? "file://" + it.thing.file.path : ""
                        sourceSize: Qt.size(win.iconSize * 2, win.iconSize * 2)
                        fillMode: Image.PreserveAspectCrop
                        asynchronous: true
                    }
                }
                DText {
                    anchors { bottom: parent.bottom; left: parent.left; right: parent.right; bottomMargin: 8; leftMargin: 4; rightMargin: 4 }
                    text: it.isFile ? it.thing.file.name : ""
                    color: "white"; style: Text.Outline; styleColor: "#66000000"
                    horizontalAlignment: Text.AlignHCenter; elide: Text.ElideMiddle; font.pixelSize: 12
                }
            }

            HoverTip { hovered: ma.containsMouse && !it.dragging && (it.isApp || it.isFile); text: it.isFile ? it.thing.file.name : (it.entry?.name ?? "") }

            // ---- a widget ----
            Loader {
                id: wl
                active: !it.isApp && !it.isFile
                anchors { fill: parent; margins: 6 }
                sourceComponent: {
                    const r = String(it.thing.ref)
                    return r === "clock" ? clockW : r === "calendar" ? calW : r === "note" ? noteW
                         : r.startsWith("plugin:") ? pluginW : mediaW
                }
                // its settings (size, look, its own options)
                Binding { target: wl.item; property: "cfg"; value: it.thing.cfg; when: wl.item !== null }
                // a note saves its text under its id
                Binding { target: wl.item; property: "wid"; value: it.thing.key.slice(7); when: wl.item !== null && it.thing.ref === "note" }
            }
            // the widget being edited
            Rectangle {
                visible: !it.isApp && !it.isFile && win.editingWidget === it.thing.key.slice(7)
                anchors { fill: parent; margins: 3 }
                radius: Theme.radius + 3
                color: "transparent"
                border.width: 2; border.color: Theme.primary
            }
        }
    }

    // ---------- the menu ----------
    Rectangle {
        id: menu
        visible: win.menuItems.length > 0
        z: 100
        width: 300
        height: menuCol.implicitHeight + 16
        x: Math.min(win.menuX, win.width - width - 8)
        y: Math.min(win.menuY, win.height - height - 8)
        radius: 20
        color: Theme.panel
        border.width: 1
        border.color: Theme.stroke
        MouseArea { anchors.fill: parent; acceptedButtons: Qt.AllButtons }   // clicks inside stay inside
        Column {
            id: menuCol
            x: 8; y: 8
            width: parent.width - 16
            Repeater {
                model: win.menuItems
                delegate: Item {
                    id: mi
                    required property var modelData
                    readonly property bool sep: modelData.k === "sep"
                    width: menuCol.width
                    height: sep ? 9 : 42
                    Rectangle { visible: mi.sep; anchors.centerIn: parent; width: parent.width - 20; height: 1; color: Theme.divider }
                    Rectangle { visible: !mi.sep; anchors.fill: parent; radius: 14; color: mima.containsMouse ? Theme.hover : "transparent" }
                    Row {
                        visible: !mi.sep
                        x: 12; anchors.verticalCenter: parent.verticalCenter
                        spacing: 12
                        Icon { name: mi.modelData.icon ?? ""; size: 20; color: mi.modelData.danger ? "#FF5A5A" : Theme.text; anchors.verticalCenter: parent.verticalCenter }
                        DText { text: mi.modelData.text ?? ""; width: mi.width - 56; elide: Text.ElideRight; font.pixelSize: 13
                            color: mi.modelData.danger ? "#FF5A5A" : Theme.text; anchors.verticalCenter: parent.verticalCenter }
                    }
                    MouseArea {
                        id: mima
                        visible: !mi.sep
                        anchors.fill: parent
                        hoverEnabled: true
                        cursorShape: Qt.PointingHandCursor
                        onClicked: { const act = mi.modelData.act; win.closeMenu(); if (act) Qt.callLater(act) }
                    }
                }
            }
        }
    }

    // ---------- add a widget: a list, where the menu was ----------
    function pickWidget(x, y) {
        const items = []
        for (const t of Widgets.order) {
            const info = Widgets.types[t]
            if (info) items.push({ icon: info.icon, text: info.name + "  ·  " + info.sub, act: () => { win.addWidget(t); Qt.callLater(() => { const l = Config.c.desktopWidgets || []; if (l.length) win.editingWidget = l[l.length - 1].id }) } })
        }
        openMenu(items, x, y)
    }

    // ---------- the widget editor: the options of one widget, on the desktop itself ----------
    // The widget stays where it is and shows every change at once. Esc or Done closes it.
    readonly property var editedThing: editingWidget === "" ? null : (things.find(t => t.key === "widget:" + editingWidget) ?? null)
    onEditedThingChanged: if (editingWidget !== "" && editedThing === null) editingWidget = ""
    MouseArea {   // a click on the empty desktop leaves the editor
        anchors.fill: parent
        visible: win.editingWidget !== ""
        z: 125
        acceptedButtons: Qt.LeftButton | Qt.RightButton
        onClicked: win.editingWidget = ""
    }
    // pull this corner to resize the widget (same arc as the control centre tiles); it snaps to the desktop's cells.
    // At the window's level, above the layer that closes the editor on a click elsewhere (it sat under that and could not be pulled)
    Item {
        id: rz
        visible: win.editedThing !== null
        z: 126
        readonly property var pl: win.editedThing ? win.placed[win.editedThing.key] : null
        readonly property real wr: pl && win.editedThing ? win.ox + (pl.c + win.editedThing.w) * win.cellW - 6 : 0     // the widget's right edge (it has a 6 px margin)
        readonly property real wb: pl && win.editedThing ? win.oy + (pl.r + win.editedThing.h) * win.cellH - 6 : 0
        width: 40; height: 40
        x: wr - width / 2 - 4; y: wb - height / 2 - 4
        Rectangle {
            anchors.centerIn: parent
            width: 30; height: 30; radius: 15
            scale: rzMa.pressed ? 1.15 : (rzMa.containsMouse ? 1.1 : 1)
            Behavior on scale { NumberAnimation { duration: 120; easing.type: Easing.OutCubic } }
            color: Theme.primary
            border.width: 2; border.color: Theme.panel
            Shape {
                anchors.centerIn: parent; width: 16; height: 16
                layer.enabled: true; layer.samples: 4
                ShapePath {
                    strokeColor: Theme.onPrimary; strokeWidth: 3; fillColor: "transparent"; capStyle: ShapePath.RoundCap
                    PathAngleArc { centerX: 2; centerY: 2; radiusX: 12; radiusY: 12; startAngle: 5; sweepAngle: 80 }
                }
            }
        }
        MouseArea {
            id: rzMa
            anchors.fill: parent
            hoverEnabled: true
            preventStealing: true
            cursorShape: Qt.SizeFDiagCursor
            property real sx: 0
            property real sy: 0
            property int sw: 1
            property int sh: 1
            onPressed: mouse => {
                const p = rzMa.mapToItem(null, mouse.x, mouse.y)
                sx = p.x; sy = p.y
                sw = win.editedThing ? win.editedThing.w : 1; sh = win.editedThing ? win.editedThing.h : 1
            }
            onPositionChanged: mouse => {
                if (!pressed || !win.editedThing) return
                const p = rzMa.mapToItem(null, mouse.x, mouse.y)
                const c0 = rz.pl ? rz.pl.c : 0, r0 = rz.pl ? rz.pl.r : 0
                const nw = Math.max(1, Math.min(win.cols - c0, sw + Math.round((p.x - sx) / win.cellW)))
                const nh = Math.max(1, Math.min(win.rows - r0, sh + Math.round((p.y - sy) / win.cellH)))
                const id = win.editingWidget
                if (nw !== win.editedThing.w) Widgets.set(id, "cw", nw)
                if (nh !== win.editedThing.h) Widgets.set(id, "ch", nh)
            }
        }
    }

    Rectangle {
        id: editor
        visible: win.editedThing !== null
        z: 130
        readonly property var pl: win.editedThing ? win.placed[win.editedThing.key] : null
        readonly property real wx: pl ? win.ox + pl.c * win.cellW : 0
        readonly property real wy: pl ? win.oy + pl.r * win.cellH : 0
        readonly property real ww: win.editedThing ? win.editedThing.w * win.cellW : 0
        readonly property real wh: win.editedThing ? win.editedThing.h * win.cellH : 0
        readonly property real freeR: win.width - (wx + ww) - 26
        readonly property real freeL: wx - 26
        readonly property bool side: Math.max(freeR, freeL) >= 300             // room beside the widget
        readonly property bool onRight: freeR >= Math.min(400, freeL)
        readonly property real freeB: win.height - (wy + wh) - 26
        readonly property real freeT: wy - 26
        // moved by dragging its title (back to its place for the next widget)
        property real dx: 0
        property real dy: 0
        Connections { target: win; function onEditingWidgetChanged() { editor.dx = 0; editor.dy = 0 } }
        // beside the widget, on the side with the most room (narrower if need be); when there is no room beside it
        // (a big widget on a small or scaled screen) above or below it, so the widget's corner stays free to pull
        width: side ? Math.min(400, onRight ? freeR : freeL) : Math.min(400, win.width - 24)
        height: side ? Math.min(win.height - 24, 640) : Math.max(240, Math.min(640, Math.max(freeB, freeT)))
        x: Math.max(12, Math.min(win.width - width - 12, (side ? (onRight ? wx + ww + 14 : wx - 14 - width) : wx) + dx))
        y: Math.max(12, Math.min(win.height - height - 12, (side ? wy : (freeB >= freeT ? wy + wh + 14 : wy - 14 - height)) + dy))
        radius: 22
        color: Theme.panel
        border.width: 1; border.color: Theme.stroke
        MouseArea { anchors.fill: parent; acceptedButtons: Qt.AllButtons }
        Shortcut { sequence: "Escape"; enabled: win.editingWidget !== ""; onActivated: win.editingWidget = "" }
        // drag the title to move this box out of the way
        MouseArea {
            width: parent.width; height: 56
            cursorShape: pressed ? Qt.ClosedHandCursor : Qt.OpenHandCursor
            property real px: 0
            property real py: 0
            onPressed: mouse => { const p = mapToItem(editor.parent, mouse.x, mouse.y); px = p.x; py = p.y }
            onPositionChanged: mouse => {
                if (!pressed) return
                const p = mapToItem(editor.parent, mouse.x, mouse.y)
                editor.dx += p.x - px; editor.dy += p.y - py
                px = p.x; py = p.y
            }
        }
        Column {
            anchors { fill: parent; margins: 12 }
            spacing: 8
            Row {
                width: parent.width; spacing: 8
                Icon { name: win.editedThing ? (Widgets.types[win.editedThing.ref]?.icon ?? "widgets") : "widgets"; size: 22; anchors.verticalCenter: parent.verticalCenter }
                DText {
                    width: parent.width - 220; elide: Text.ElideRight; anchors.verticalCenter: parent.verticalCenter
                    text: win.editedThing ? (Widgets.types[win.editedThing.ref]?.name ?? "Widget") : ""
                    font.pixelSize: 16; font.weight: Font.DemiBold
                }
                ArqButton { text: "Remove"; onClicked: { const id = win.editingWidget; win.editingWidget = ""; Widgets.remove(id) } }
                ArqButton { text: "Done"; primary: true; onClicked: win.editingWidget = "" }
            }
            Flickable {
                width: parent.width; height: parent.height - 48
                contentWidth: width; contentHeight: edCol.implicitHeight
                clip: true
                boundsBehavior: Flickable.StopAtBounds
                Column {
                    id: edCol
                    width: parent.width
                    // size: pull the corner of the widget
                    SRow {
                        width: parent.width
                        compact: true
                        title: "Size"; subtitle: "Pull the round corner of the widget to resize it"; icon: "photo_size_select_large"
                        DText { text: win.editedThing ? win.editedThing.w + " × " + win.editedThing.h : ""; color: Theme.subtext; font.pixelSize: 12 }
                    }
                    WidgetOptions { width: parent.width; wid: win.editingWidget }
                }
            }
        }
    }

    // ---------- rename / name a new item ----------
    MouseArea {   // click outside the box = keep the name as it is
        anchors.fill: parent
        visible: win.renaming !== ""
        z: 110
        onClicked: win.finishRename(renameField.text)
    }
    Rectangle {
        visible: win.renaming !== ""
        z: 120
        width: 380; height: renameCol.implicitHeight + 32
        anchors.centerIn: parent
        radius: 22
        color: Theme.panel
        border.width: 1; border.color: Theme.stroke
        MouseArea { anchors.fill: parent }
        Column {
            id: renameCol
            x: 16; y: 16; width: parent.width - 32
            spacing: 12
            DText { text: "Name"; font.weight: Font.Medium }
            ArqField {
                id: renameField
                width: parent.width
                iconName: "edit"
                closesOnEscape: false
                onEscaped: win.renaming = ""
                onAccepted: win.finishRename(text)
            }
            Row {
                anchors.right: parent.right
                spacing: 8
                ArqButton { text: "Cancel"; onClicked: win.renaming = "" }
                ArqButton { text: "Save"; primary: true; onClicked: win.finishRename(renameField.text) }
            }
        }
        Shortcut { sequence: "Escape"; enabled: win.renaming !== ""; onActivated: win.renaming = "" }
    }

    // ---------- widgets (components/ClockWidget, MediaCard, and plugins'; their settings: Widgets) ----------
    Component { id: clockW; ClockWidget {} }
    Component { id: calW; CalendarWidget {} }
    Component { id: noteW; NoteWidget {} }
    Component { id: mediaW; MediaCard { solid: false } }
    Component { id: pluginW; PluginDesktopWidget {} }
}
