import Quickshell
import Quickshell.Wayland
import Quickshell.Hyprland
import QtQuick
import qs.config
import qs.components
import qs.services

// "A new version is out. Update?" Shown once on the screen you are using (not on every screen), a corner card
// that does not take the keyboard. Later = until the next start, Skip = not this version again.
Variants {
    model: Quickshell.screens
    PanelWindow {
        id: w
        required property var modelData
        screen: modelData
        readonly property bool main: (Hyprland.focusedMonitor?.name ?? "") === modelData.name || Quickshell.screens.length === 1
        readonly property bool on: (Updater.prompt || Updater.state === "updating") && main
        property real t: 0
        NumberAnimation { id: tIn; target: w; property: "t"; to: 1; duration: 300; easing.type: Easing.OutCubic }
        NumberAnimation { id: tOut; target: w; property: "t"; to: 0; duration: 160; easing.type: Easing.InCubic }
        onOnChanged: { if (on) { tOut.stop(); tIn.restart() } else { tIn.stop(); tOut.restart() } }
        visible: t > 0.001

        color: "transparent"
        anchors { top: true; right: true }
        margins { top: 56; right: 16 }
        implicitWidth: Math.min(380, Math.max(240, modelData.width - 32))
        implicitHeight: card.height
        exclusionMode: ExclusionMode.Ignore
        WlrLayershell.namespace: "arqen-update"
        WlrLayershell.layer: WlrLayer.Overlay
        WlrLayershell.keyboardFocus: WlrKeyboardFocus.None

        Rectangle {
            id: card
            width: parent.width
            height: col.implicitHeight + 32
            radius: Theme.radius + 8
            color: Theme.cardSolid
            border.width: 1; border.color: Theme.stroke
            opacity: w.t
            y: (1 - w.t) * -12

            Column {
                id: col
                x: 16; y: 16
                width: parent.width - 32
                spacing: 12
                DText { text: Updater.state === "updating" ? "Updating Arqen shell" : "Update available"; font.pixelSize: 16; font.weight: Font.DemiBold }
                DText {
                    width: parent.width; wrapMode: Text.WordWrap; color: Theme.subtext; font.pixelSize: 13
                    text: Updater.state === "updating" ? Updater.message
                        : "Version " + Updater.latest + " is on GitHub (you have " + Config.version + "). Your settings are kept. The shell restarts when it is done."
                }
                Flow {
                    visible: Updater.state !== "updating"
                    width: parent.width; spacing: 8
                    ArqButton { text: "Update now"; primary: true; onClicked: Updater.install() }
                    ArqButton { text: "Later"; onClicked: Updater.later() }
                    ArqButton { text: "Skip this version"; onClicked: Updater.skip() }
                }
            }
        }
    }
}
