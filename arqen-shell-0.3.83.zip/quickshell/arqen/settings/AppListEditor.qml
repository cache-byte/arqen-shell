import QtQuick
import QtQuick.Layouts
import qs.config
import qs.components
import qs.services

// Edits a list of desktop-entry ids stored in Config.c[key] (the pinned apps):
//  - top: the list itself, in order, as icons. Point at one for ‹ › (move) and × (remove)
//  - below: every app as an icon. Click one to add it (click again to take it off); a tick marks
//    the ones already in the list. Type to narrow it down.
ColumnLayout {
    id: ed
    property string key: "pinned"
    readonly property var items: Config.c[key] || []
    spacing: 0
    Layout.fillWidth: true

    function setItems(a) { Config.c[key] = a }
    function has(id) { return ed.items.includes(id) }
    function toggle(id) { setItems(has(id) ? ed.items.filter(x => x !== id) : ed.items.concat([id])) }
    function move(i, d) {
        const j = i + d
        if (j < 0 || j >= ed.items.length) return
        const a = ed.items.slice(); a.splice(j, 0, a.splice(i, 1)[0]); setItems(a)
    }

    // an app as an icon with its name underneath
    component AppCell: Item {
        id: cell
        property var entry: null
        property string label: entry?.name ?? ""
        property bool ticked: false
        property bool hovered: cma.containsMouse
        signal clicked()
        width: 84; height: 92
        Rectangle { anchors.fill: parent; radius: 16; color: cma.containsMouse ? Theme.hover : "transparent" }
        AppIcon { id: ic; entry: cell.entry; size: 44; anchors { horizontalCenter: parent.horizontalCenter; top: parent.top; topMargin: 10 } }
        Rectangle {   // tick: already pinned
            visible: cell.ticked
            width: 20; height: 20; radius: 10
            color: Theme.primary
            anchors { right: ic.right; bottom: ic.bottom; margins: -5 }
            Icon { anchors.centerIn: parent; name: "check"; size: 14; color: Theme.onPrimary }
        }
        DText {
            anchors { top: ic.bottom; topMargin: 6; left: parent.left; right: parent.right; leftMargin: 4; rightMargin: 4 }
            text: cell.label; font.pixelSize: 11; horizontalAlignment: Text.AlignHCenter
            elide: Text.ElideRight; maximumLineCount: 2; wrapMode: Text.Wrap
        }
        MouseArea { id: cma; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: cell.clicked() }
        HoverTip { hovered: cma.containsMouse; text: cell.label }
    }

    // ---- the list, in order ----
    Flow {
        Layout.fillWidth: true; Layout.margins: 12
        spacing: 4
        DText { visible: ed.items.length === 0; text: "Nothing yet. Click apps below to add them."; color: Theme.subtext; font.pixelSize: 13; topPadding: 8; bottomPadding: 8; leftPadding: 6 }
        Repeater {
            model: ed.items
            delegate: AppCell {
                id: pc
                required property string modelData
                required property int index
                entry: Apps.byId(modelData)
                label: entry?.name ?? (modelData + " (not installed)")
                // move left / right, remove
                Row {
                    visible: pc.hovered
                    anchors { top: parent.top; horizontalCenter: parent.horizontalCenter; topMargin: -2 }
                    spacing: 2
                    Repeater {
                        model: [{ i: "chevron_left", a: -1, on: pc.index > 0 }, { i: "close", a: 0, on: true }, { i: "chevron_right", a: 1, on: pc.index < ed.items.length - 1 }]
                        delegate: Rectangle {
                            required property var modelData
                            visible: modelData.on
                            width: 22; height: 22; radius: 11
                            color: modelData.a === 0 ? "#E5484D" : Theme.cardSolid
                            border.width: 1; border.color: Theme.stroke
                            Icon { anchors.centerIn: parent; name: parent.modelData.i; size: 15; color: parent.modelData.a === 0 ? "white" : Theme.text }
                            MouseArea {
                                anchors.fill: parent; cursorShape: Qt.PointingHandCursor
                                onClicked: { const a = parent.modelData.a; const i = pc.index; if (a === 0) ed.toggle(pc.modelData); else Qt.callLater(() => ed.move(i, a)) }
                            }
                        }
                    }
                }
                onClicked: {}
            }
        }
    }
    Rectangle { Layout.fillWidth: true; Layout.leftMargin: 18; Layout.rightMargin: 18; implicitHeight: 1; color: Theme.divider }

    // ---- every app ----
    Item {
        Layout.fillWidth: true; implicitHeight: 64
        ArqField { id: f; anchors { fill: parent; margins: 9; leftMargin: 18; rightMargin: 18 } placeholder: "Find an app…"; iconName: "search" }
    }
    Flickable {
        Layout.fillWidth: true
        Layout.preferredHeight: Math.min(grid.implicitHeight, 380)
        Layout.leftMargin: 12; Layout.rightMargin: 12; Layout.bottomMargin: 12
        contentHeight: grid.implicitHeight
        clip: true
        boundsBehavior: Flickable.StopAtBounds
        Flow {
            id: grid
            width: parent.width
            spacing: 4
            Repeater {
                model: Apps.search(f.text)
                delegate: AppCell {
                    required property var modelData
                    entry: modelData
                    ticked: ed.has(modelData.id)
                    onClicked: ed.toggle(modelData.id)
                }
            }
        }
    }
}
