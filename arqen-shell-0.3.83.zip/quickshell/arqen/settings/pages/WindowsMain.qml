import QtQuick
import QtQuick.Layouts
import qs.config
import qs.components
import qs.services
import qs.settings

// Dedicated, searchable home for window-management preferences.
ColumnLayout {
    width: parent.width
    spacing: 16

    SHeader { text: "Window behaviour"; key: "windowMode" }
    SGroup {
        SRow {
            key: "windowMode"
            title: "How apps open"
            subtitle: "Choose the default Hyprland layout for new windows. Floating is the default."
            icon: "window"
            SChoices {
                maxWidth: 420
                model: ["Floating", "Dwindle", "Master", "Scrolling"]
                current: (Config.c.windowMode || "floating").charAt(0).toUpperCase() + (Config.c.windowMode || "floating").slice(1)
                onPicked: v => Config.c.windowMode = v.toLowerCase()
            }
        }
        SliderRow { key: "gapsIn"; title: "Gap between windows"; icon: "space_dashboard"; suffix: " px"; from: 0; to: 24; value: Config.c.gapsIn; onMoved: v => Config.c.gapsIn = Math.round(v) }
        SliderRow { key: "gapsOut"; title: "Gap to screen edge"; icon: "fit_screen"; suffix: " px"; from: 0; to: 48; value: Config.c.gapsOut; onMoved: v => Config.c.gapsOut = Math.round(v) }
        SliderRow { key: "winRounding"; title: "Corner radius"; icon: "rounded_corner"; suffix: " px"; from: 0; to: 32; value: Config.c.winRounding; onMoved: v => Config.c.winRounding = Math.round(v) }
        SliderRow { key: "borderSize"; title: "Border width"; icon: "border_style"; suffix: " px"; from: 0; to: 5; value: Config.c.borderSize; onMoved: v => Config.c.borderSize = Math.round(v) }
    }
    DText {
        Layout.fillWidth: true
        wrapMode: Text.WordWrap
        color: Theme.subtext
        font.pixelSize: 12
        text: Config.c.windowMode === "floating" ? "New apps open floating and centred. Floating is the default; tiled windows continue to follow Hyprland's normal behaviour." : Config.c.windowMode === "scrolling" ? "Scrolling requires the Hyprscrolling plugin to be installed and enabled in Hyprland." : "New windows use Hyprland's " + Config.c.windowMode + " layout. Tiled-window movement remains controlled by Hyprland."
    }
    SHeader { text: "Desktops overview"; key: "overviewDir" }
    SGroup {
        SRow { key: "overviewDir"; title: "Layout"; icon: "grid_view"
            subtitle: "Vertical: four desktops in view (two by two), scroll down for more. Horizontal: four in a row, scroll to the right"
            SChoices { model: ["Vertical", "Horizontal"]; current: Config.c.overviewDir === "horizontal" ? "Horizontal" : "Vertical"
                       onPicked: v => Config.c.overviewDir = v.toLowerCase() } }
    }

    SHeader { visible: Config.c.showAdvanced; text: "Window handle"; key: "winHandle,winHandleColor,winHandleCustom,winHandleSize,winHandlePosition" }
    SGroup { visible: Config.c.showAdvanced;
        SRow { key: "winHandle"; title: "Handle on windows"; subtitle: "Show a handle for window actions"; icon: "drag_handle"; ArqToggle { checked: Config.c.winHandle; onToggled: v => Config.c.winHandle = v } }
        SRow { key: "winHandleColor"; visible: Config.c.winHandle; title: "Colour"; icon: "palette"; SChoices { model: ["Accent", "Custom"]; current: Config.c.winHandleColor === "custom" ? "Custom" : "Accent"; onPicked: v => Config.c.winHandleColor = v.toLowerCase() } }
        SRow { key: "winHandleCustom"; visible: Config.c.winHandle && Config.c.winHandleColor === "custom"; title: "Handle colour"; icon: "colorize"; SSwatches { colors: ["#FFFFFF", "#F5E6D3", "#FFB74D", "#FF7A7A", "#F48FB1", "#B39DDB", "#82B1FF", "#80DEEA", "#A5D6A7", "#2A2A33", "#111114"]; value: Config.c.winHandleCustom; onPicked: hex => Config.c.winHandleCustom = hex } }
        SliderRow { key: "winHandleSize"; visible: Config.c.winHandle; title: "Size"; icon: "photo_size_select_large"; suffix: " %"; from: 70; to: 150; step: 5; value: Config.c.winHandleSize; onMoved: v => Config.c.winHandleSize = Math.round(v) }
        SRow { key: "winHandlePosition"; visible: Config.c.winHandle; title: "Position on window"; icon: "drag_handle"; SChoices { maxWidth: 340; model: ["top-start", "top-center", "top-end", "bottom-start", "bottom-center", "bottom-end", "left-start", "left-center", "left-end", "right-start", "right-center", "right-end"]; current: Config.c.winHandlePosition || "top-center"; onPicked: v => Config.c.winHandlePosition = v } }
    }

    SHeader { visible: Config.c.showAdvanced; text: "Windows pushed off the screen"; key: "edgeTuck,edgeTuckPart,cursorWarp,edgeSide,edgeAlong" }
    SGroup { visible: Config.c.showAdvanced;
        SRow { key: "edgeTuck"; title: "Tuck them into the edge panel"
            subtitle: "A window dragged almost off the screen goes to a small panel on the screen edge (a thin line until you click it). Click its icon there to bring it back, all of it on the screen"
            icon: "side_navigation"
            ArqToggle { checked: Config.c.edgeTuck; onToggled: v => Config.c.edgeTuck = v } }
        SliderRow { key: "edgeTuckPart"; visible: Config.c.edgeTuck; title: "How far off the screen"; subtitle: "How much of a window has to be off the screen"; icon: "open_in_full"; suffix: " %"; from: 50; to: 98; step: 1
            enabled: Config.c.edgeTuck
            value: Config.c.edgeTuckPart; onMoved: v => Config.c.edgeTuckPart = Math.round(v) }
        SRow { key: "cursorWarp"; title: "Pointer jumps to a focused window"; subtitle: "Off: the pointer stays where it is when a window is brought up (from the dock, the edge panel or a notification)"; icon: "arrow_selector_tool"
            ArqToggle { checked: Config.c.cursorWarp; onToggled: v => Config.c.cursorWarp = v } }
        SRow { title: "Where the panel is"; subtitle: "Drag its line (or the grip on the open panel) to any screen edge"; icon: "drag_pan"
            ArqButton { text: "Back to the right edge"; onClicked: { Config.c.edgeSide = "right"; Config.c.edgeAlong = 0.5 } } }
        SRow { visible: EdgeTuck.tucked.length > 0; title: EdgeTuck.tucked.length + " tucked away now"; icon: "select_window"
            ArqButton { text: "Bring all back"; onClicked: EdgeTuck.restoreAll() } }
    }

    SMore {}
}
