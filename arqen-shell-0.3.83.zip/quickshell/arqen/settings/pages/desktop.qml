import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Io
import qs.config
import qs.components
import qs.services
import qs.settings

ColumnLayout {
    id: pg
    width: parent.width; spacing: 16

    // the widget whose options are open (one at a time); "Customise widget" on the desktop opens it here
    property string editing: Ui.editWidget
    onEditingChanged: Ui.editWidget = editing
    Connections { target: Ui; function onEditWidgetChanged() { if (pg.editing !== Ui.editWidget) pg.editing = Ui.editWidget } }

    SHeader { text: "On the desktop"; key: "desktopIcons,desktopFiles,desktopDrop,desktopIconSize" }
    SGroup {
        SRow { key: "desktopIcons"; title: "Apps"; subtitle: "To add one: open the launcher, press and hold an app and drag it here. Right-click it on the desktop to remove it"; icon: "apps"
            ArqToggle { checked: Config.c.desktopIcons; onToggled: v => Config.c.desktopIcons = v } }
        SRow { key: "desktopFiles"; title: "Files and folders"; subtitle: "What is in your Desktop folder. Right-click the desktop for New folder / New text file"; icon: "folder"
            ArqToggle { checked: Config.c.desktopFiles; onToggled: v => Config.c.desktopFiles = v } }
        SRow { key: "desktopDrop"; title: "Files dragged onto the desktop"; subtitle: (Config.c.desktopDrop || "move") === "move" ? "Moved into your Desktop folder" : "Copied; the originals stay where they were"; icon: "drive_file_move"
            SChoices { model: ["move", "copy"]; current: Config.c.desktopDrop || "move"; onPicked: v => Config.c.desktopDrop = v } }
        SliderRow { key: "desktopIconSize"; title: "Icon size"; subtitle: "Also sets the size of the grid"; icon: "photo_size_select_large"; suffix: " px"; from: 40; to: 96; step: 1
            value: Config.c.desktopIconSize; onMoved: v => Config.c.desktopIconSize = Math.round(v) }
        SRow { title: "Arrange"; subtitle: "Press and hold an icon or widget, then drag it. It snaps to the grid. Right-click the desktop for more"; icon: "drag_pan"
            ArqButton { text: "Reset positions"; onClicked: Config.c.desktopPos = ({}) } }
    }

    // ---- where screenshots and recordings are saved: the system's folder picker ----
    property string picking: ""                 // "shotDir" | "recDir" while the picker is open
    function pick(key) {
        if (picker.running) return
        picking = key
        picker.command = ["python3", "-I", Quickshell.shellDir + "/scripts/pick-folder.py",
                          key === "shotDir" ? "Where to save screenshots" : "Where to save screen recordings",
                          key === "shotDir" ? Config.shotDir : Config.recDir]
        picker.running = true
    }
    Process {
        id: picker
        stdout: StdioCollector {
            onStreamFinished: {
                const p = text.trim()
                if (p !== "" && pg.picking !== "") Config.c[pg.picking] = p
                pg.picking = ""
            }
        }
        onExited: code => { if (code !== 0) pg.picking = "" }
    }
    SHeader { text: "Screenshots and recordings"; key: "shotDir,shotClipboard,captureAfter,captureAfterSecs,recDir" }
    SGroup {
        SRow { key: "shotDir"; title: "Save screenshots in"; subtitle: Config.tilde(Config.shotDir); icon: "photo_camera"
            ArqButton { text: pg.picking === "shotDir" ? "Choosing…" : "Choose…"; enabled: pg.picking === ""; onClicked: pg.pick("shotDir") }
            ArqButton { text: "Open"; onClicked: QuickSettings.openFolder(Config.shotDir) } }
        SRow { key: "shotClipboard"; title: "Copy screenshots to the clipboard"; subtitle: "Every screenshot is also ready to paste (Ctrl+V) into a chat, a document or an image editor"; icon: "content_paste"
            ArqToggle { checked: Config.c.shotClipboard; onToggled: v => Config.c.shotClipboard = v } }
        SRow { key: "captureAfter"; title: "After a screenshot or recording"
            subtitle: Config.c.captureAfter === "ask" ? "A preview in the corner: save, copy, edit, rename or delete it" : "Saved straight away (screenshots also go on the clipboard)"
            icon: "preview"
            SChoices { model: ["Ask", "Just save"]; current: Config.c.captureAfter === "ask" ? "Ask" : "Just save"
                       onPicked: v => Config.c.captureAfter = v === "Ask" ? "ask" : "save" } }
        SliderRow { key: "captureAfterSecs"; visible: Config.c.captureAfter === "ask"; title: "Save by itself after"
            subtitle: "Resting the pointer on the preview stops the clock"; icon: "timer"; from: 0; to: 30; step: 1
            display: Config.c.captureAfterSecs > 0 ? Config.c.captureAfterSecs + " s" : "Waits"
            value: Config.c.captureAfterSecs; onMoved: v => Config.c.captureAfterSecs = Math.round(v) }
        SRow { key: "recDir"; title: "Save screen recordings in"; subtitle: Config.tilde(Config.recDir); icon: "videocam"
            ArqButton { text: pg.picking === "recDir" ? "Choosing…" : "Choose…"; enabled: pg.picking === ""; onClicked: pg.pick("recDir") }
            ArqButton { text: "Open"; onClicked: QuickSettings.openFolder(Config.recDir) } }
    }

    // ---------- widgets ----------
    SHeader { text: "Widgets"; key: "desktopWidgetsOn" }
    SGroup {
        SRow { key: "desktopWidgetsOn"; title: "Widgets on the desktop"
            subtitle: (Config.c.desktopWidgets || []).length === 0 ? "None yet: add one below"
                    : (Config.c.desktopWidgets.length + (Config.c.desktopWidgets.length === 1 ? " widget" : " widgets")) + ". Press and hold one on the desktop to move it; right-click it for its size, look and more"
            icon: "widgets"
            ArqToggle { checked: Config.c.desktopWidgetsOn; onToggled: v => Config.c.desktopWidgetsOn = v } }
    }

    // ---- add one: a gallery of live previews ----
    DText { text: "Add a widget"; font.pixelSize: 13; font.weight: Font.Medium; color: Theme.subtext; leftPadding: 12 }
    Flow {
        Layout.fillWidth: true
        spacing: 12
        Repeater {
            model: Widgets.order
            delegate: Rectangle {
                id: gt
                required property string modelData
                readonly property var info: Widgets.types[modelData]
                width: Math.max(190, Math.floor((pg.width - 24) / 3)); height: 214
                radius: Config.c.tileRadius + 2
                color: gm.containsMouse ? Theme.hover : Theme.card
                Behavior on color { ColorAnimation { duration: 120 } }
                scale: gm.pressed ? 0.97 : 1
                Behavior on scale { NumberAnimation { duration: 140; easing.type: Easing.OutBack } }
                WidgetPreview {
                    x: 10; y: 10; width: parent.width - 20; height: 120
                    wd: ({ type: gt.modelData })
                }
                Column {
                    x: 14; y: 140; width: parent.width - 28
                    spacing: 2
                    DText { text: gt.info.name; font.pixelSize: 14; font.weight: Font.DemiBold }
                    DText { width: parent.width; text: gt.info.sub; font.pixelSize: 11; color: Theme.subtext; elide: Text.ElideRight }
                }
                Rectangle {
                    anchors.right: parent.right; anchors.bottom: parent.bottom; anchors.margins: 10
                    width: addRow.implicitWidth + 20; height: 30; radius: 15
                    color: Theme.primary
                    Row {
                        id: addRow
                        anchors.centerIn: parent; spacing: 4
                        Icon { name: "add"; size: 16; color: Theme.onPrimary; anchors.verticalCenter: parent.verticalCenter }
                        DText { text: "Add"; font.pixelSize: 12; font.weight: Font.DemiBold; color: Theme.onPrimary; anchors.verticalCenter: parent.verticalCenter }
                    }
                }
                MouseArea {
                    id: gm
                    anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor
                    onClicked: { Widgets.add(gt.modelData); const l = Config.c.desktopWidgets; pg.editing = l[l.length - 1].id }
                }
            }
        }
    }

    // ---- the ones on the desktop: a preview, and their options ----
    DText { visible: (Config.c.desktopWidgets || []).length > 0; text: "On your desktop"; font.pixelSize: 13; font.weight: Font.Medium; color: Theme.subtext; leftPadding: 12; Layout.topMargin: 4 }
    Repeater {
        model: Config.c.desktopWidgets || []
        delegate: SCard {
            id: wc
            required property var modelData
            required property int index
            readonly property var info: Widgets.types[modelData.type] ?? { name: modelData.type, icon: "widgets", sub: "", options: [], sizes: { S: [1, 1], M: [1, 1], L: [1, 1] } }
            readonly property var cfg: Widgets.cfg(modelData)
            readonly property bool open: pg.editing === modelData.id
            spacing: 14
            RowLayout {
                Layout.fillWidth: true
                spacing: 16
                WidgetPreview {
                    Layout.preferredWidth: 190; Layout.preferredHeight: 112
                    wd: wc.modelData
                }
                ColumnLayout {
                    Layout.fillWidth: true
                    spacing: 4
                    DText { text: wc.info.name; font.pixelSize: 15; font.weight: Font.DemiBold }
                    DText {
                        Layout.fillWidth: true; wrapMode: Text.Wrap
                        text: Widgets.cells(wc.modelData).join(" × ") + " cells  ·  " + wc.cfg.look + "  ·  pull its corner on the desktop to resize"
                        font.pixelSize: 12; color: Theme.subtext
                    }
                    Row {
                        spacing: 8
                        topPadding: 6
                        ArqButton { text: wc.open ? "Done" : "Customise"; primary: !wc.open; onClicked: pg.editing = wc.open ? "" : wc.modelData.id }
                        ArqButton { text: "Remove"; onClicked: { if (wc.open) pg.editing = ""; Widgets.remove(wc.modelData.id) } }
                        ArqButton { visible: wc.info.plugin !== undefined; text: "Plugin settings"; onClicked: Plugins.openSettings(wc.info.plugin) }
                    }
                }
                ColumnLayout {
                    spacing: 2
                    TrayButton { round: true; icon: "arrow_upward"; size: 18; tip: "Earlier in the list"; opacity: wc.index > 0 ? 1 : 0.3; onClicked: Widgets.move(wc.modelData.id, -1) }
                    TrayButton { round: true; icon: "arrow_downward"; size: 18; tip: "Later in the list"; opacity: wc.index < (Config.c.desktopWidgets || []).length - 1 ? 1 : 0.3; onClicked: Widgets.move(wc.modelData.id, 1) }
                }
            }
            // ---- its options ----
            ColumnLayout {
                visible: wc.open
                Layout.fillWidth: true
                spacing: 0
                WidgetOptions { Layout.fillWidth: true; wid: wc.modelData.id }
            }
        }
    }
}
