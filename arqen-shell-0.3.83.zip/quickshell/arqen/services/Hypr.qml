pragma Singleton
import Quickshell
import Quickshell.Hyprland
import QtQuick
import qs.config

// Every command the shell sends to Hyprland, in the form Hyprland understands right now.
// With hyprland.conf (hyprlang) a dispatch is "workspace 2"; with hyprland.lua (0.55+)
// `hyprctl dispatch X` runs `hl.dispatch(X)`, so it must be Lua: "hl.dsp.focus({ workspace = 2 })",
// and `hyprctl keyword` is gone (hl.* through `hyprctl eval` instead). Config.hyprLua says which.
Singleton {
    id: root
    readonly property bool lua: Config.hyprLua

    // Lua string literal (addresses, regexes, commands: plain ASCII)
    function q(s) { return "\"" + String(s).replace(/\\/g, "\\\\").replace(/"/g, "\\\"") + "\"" }
    function addr(a) { return "0x" + String(a || "").replace(/^0x/, "") }
    function wsLua(w) { return typeof w === "number" ? String(w) : q(w) }
    // Until the shell knows which config Hyprland reads (a moment after it starts), commands wait:
    // sent too early they went out in the wrong form ("togglespecialworkspace edge" to a Lua Hyprland)
    property var waiting: []
    function send(legacy, luaExpr) {
        if (!Config.hyprChecked) { waiting.push([legacy, luaExpr]); return }
        Hyprland.dispatch(lua ? luaExpr : legacy)
    }
    Connections {
        target: Config
        function onHyprCheckedChanged() {
            if (!Config.hyprChecked) return
            const w = root.waiting; root.waiting = []
            for (const c of w) root.send(c[0], c[1])
        }
    }

    // the same, as a shell command (for scripts and plugin buttons)
    function shQuote(s) { return "'" + String(s).replace(/'/g, "'\\''") + "'" }
    function shellDispatch(legacy, luaExpr) { return "hyprctl dispatch " + shQuote(lua ? luaExpr : legacy) }

    // ---- screen filter: a shader over the whole screen ("" = none) ----
    function screenShader(path) {
        if (lua) Quickshell.execDetached(["hyprctl", "eval", "hl.config({ decoration = { screen_shader = " + q(path) + " } })"])
        else Quickshell.execDetached(["hyprctl", "keyword", "decoration:screen_shader", path])
    }

    // ---- how apps open: floating or tiled, for every window now and for each new one ----
    function setFloating(a, on) {
        const sel = "address:" + addr(a)
        send((on ? "setfloating " : "settiled ") + sel, "hl.dsp.window.float({ action = \"" + (on ? "set" : "unset") + "\", window = " + q(sel) + " })")
    }
    // layout first (so tiled windows are laid out by the new one), then float / tile every window
    function applyWindowMode() {
        const m = Config.c.windowMode || "floating"
        const lay = (m === "master" || m === "scrolling") ? m : "dwindle"
        if (lua) Quickshell.execDetached(["hyprctl", "eval", "hl.config({ general = { layout = \"" + lay + "\" } })"])
        else Quickshell.execDetached(["hyprctl", "keyword", "general:layout", lay])
        modeTimer.restart()
    }
    Timer {
        id: modeTimer
        interval: 350
        onTriggered: {
            const on = (Config.c.windowMode || "floating") === "floating"
            for (const t of Hyprland.toplevels.values) {
                if (!t.wayland) continue
                if (t.lastIpcObject && t.lastIpcObject.fullscreen) continue
                root.setFloating(t.address, on)
            }
        }
    }
    Connections {
        target: Config.c
        function onWindowModeChanged() { if (Config.hyprChecked) root.applyWindowMode() }
    }
    Connections {
        target: Hyprland
        function onRawEvent(ev) {
            if (ev.name !== "openwindow" || !Config.hyprChecked) return
            if ((Config.c.windowMode || "floating") !== "floating") return
            const f = String(ev.data).split(",")
            if (f.length < 1 || f[0] === "") return
            root.setFloating(f[0], true)
            root.send("centerwindow", "hl.dsp.window.center()")
        }
    }

    // While a filter is on, redraw the whole screen every frame (0 = no damage tracking): partial redraws under
    // a full-screen shader are the usual cause of flicker and torn patches. Back to normal (2) when it is off.
    function fullRedraw(on) {
        if (lua) Quickshell.execDetached(["hyprctl", "eval", "pcall(hl.config, { debug = { damage_tracking = " + (on ? 0 : 2) + " } })"])
        else Quickshell.execDetached(["hyprctl", "keyword", "debug:damage_tracking", on ? "0" : "2"])
    }

    // ---- desktops ----
    function workspace(w) { send("workspace " + w, "hl.dsp.focus({ workspace = " + wsLua(w) + " })") }
    // keep a desktop alive while empty (or not)
    function persist(id, on) {
        if (lua) Quickshell.execDetached(["hyprctl", "eval", "hl.workspace_rule({ workspace = " + q(String(id)) + ", persistent = " + (on ? "true" : "false") + " })"])
        else Quickshell.execDetached(["hyprctl", "keyword", "workspace", id + ", persistent:" + (on ? "true" : "false")])
    }

    // ---- windows ----
    function focusWindow(a) { send("focuswindow address:" + addr(a), "hl.dsp.focus({ window = " + q("address:" + addr(a)) + " })") }
    // follow = false: the window goes, you stay
    function moveToWorkspace(a, ws, follow) {
        send((follow ? "movetoworkspace " : "movetoworkspacesilent ") + ws + ",address:" + addr(a),
             "hl.dsp.window.move({ workspace = " + wsLua(ws) + ", follow = " + (follow ? "true" : "false") + ", window = " + q("address:" + addr(a)) + " })")
    }
    function moveActiveToWorkspace(ws, follow) {
        send((follow ? "movetoworkspace " : "movetoworkspacesilent ") + ws,
             "hl.dsp.window.move({ workspace = " + wsLua(ws) + ", follow = " + (follow ? "true" : "false") + " })")
    }
    function moveWindowTo(a, x, y) {
        x = Math.round(x); y = Math.round(y)
        send("movewindowpixel exact " + x + " " + y + ",address:" + addr(a),
             "hl.dsp.window.move({ x = " + x + ", y = " + y + ", window = " + q("address:" + addr(a)) + " })")
    }
    // an exact size (a floating window)
    function resizeWindowTo(a, w, h) {
        w = Math.round(w); h = Math.round(h)
        send("resizewindowpixel exact " + w + " " + h + ",address:" + addr(a),
             "hl.dsp.window.resize({ x = " + w + ", y = " + h + ", window = " + q("address:" + addr(a)) + " })")
    }
    // screens on / off
    function dpms(on) { send("dpms " + (on ? "on" : "off"), "hl.dsp.dpms({ action = " + q(on ? "on" : "off") + " })") }
    // put a window above the others
    function raiseWindow(a) { send("alterzorder top,address:" + addr(a), "hl.dsp.window.alter_zorder({ mode = \"top\", window = " + q("address:" + addr(a)) + " })") }
    // show / hide a hidden ("special") desktop by its name without "special:"
    function toggleSpecial(name) { send("togglespecialworkspace " + name, "hl.dsp.workspace.toggle_special(" + q(name) + ")") }
    function closeWindow(a) { send("closewindow address:" + addr(a), "hl.dsp.window.close({ window = " + q("address:" + addr(a)) + " })") }

    // float / tile a window, and full screen / maximise the focused one (the window handle)
    function toggleFloat(a) { send("togglefloating address:" + addr(a), "hl.dsp.window.float({ action = \"toggle\", window = " + q("address:" + addr(a)) + " })") }
    function fullscreenActive(maximized) {
        send(maximized ? "fullscreen 1" : "fullscreen 0", "hl.dsp.window.fullscreen({ mode = " + q(maximized ? "maximized" : "fullscreen") + ", action = \"toggle\" })")
    }

    // ---- as shell commands ----
    readonly property string cmdClose: shellDispatch("killactive", "hl.dsp.window.close()")
    readonly property string cmdMaximize: shellDispatch("fullscreen 1", "hl.dsp.window.fullscreen({ mode = \"maximized\", action = \"toggle\" })")
    readonly property string cmdExit: shellDispatch("exit", "hl.dsp.exit()")
    // float a window by title, give it a size and centre it (used for the Settings window)
    function cmdFloatResize(titleRegex, w, h) {
        const sel = "title:" + titleRegex
        return shellDispatch("setfloating " + sel, "hl.dsp.window.float({ action = \"set\", window = " + q(sel) + " })")
            + " && " + shellDispatch("resizewindowpixel exact " + w + " " + h + "," + sel, "hl.dsp.window.resize({ x = " + w + ", y = " + h + ", window = " + q(sel) + " })")
            + " && " + shellDispatch("centerwindow", "hl.dsp.window.center()")
    }
}
