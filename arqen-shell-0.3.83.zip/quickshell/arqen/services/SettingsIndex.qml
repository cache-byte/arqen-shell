pragma Singleton
import Quickshell
import QtQuick

// What the search box can find in Settings. Clicking a result opens that page.
Singleton {
    // every settings page: title and icon. System (you, this computer) first, then grouped like GNOME
    // Settings: connections, the screen, sound, how things look, then the shell's own parts.
    readonly property var pages: ({
        connections:   { t: "Wi-Fi and Bluetooth",     i: "wifi",            c: "#2F7BF5" },
        display:       { t: "Display",                  i: "desktop_windows", c: "#43A047" },
        input:         { t: "Mouse and keyboard",        i: "mouse",           c: "#43A047" },
        windows:       { t: "Windows",                  i: "web_asset",        c: "#43A047" },
        rgb:           { t: "Lighting",                 i: "lightbulb",       c: "#E8A33D" },
        power:         { t: "Power and lock",          i: "battery_charging_full", c: "#2FBF71" },
        sounds:        { t: "Sound and notifications", i: "volume_up",       c: "#7A5AF5" },
        wallpaper:     { t: "Appearance",              i: "palette",         c: "#F0507A" },
        panels:        { t: "Panels",                  i: "dock_to_bottom",  c: "#3E91FF" },
        desktop:       { t: "Desktop",                 i: "home",            c: "#1E88E5" },
        launcher:      { t: "Launcher and search",     i: "apps",            c: "#C2408A" },
        keybinds:      { t: "Keyboard shortcuts",      i: "keyboard",        c: "#3E91FF" },
        apps:          { t: "Apps",                     i: "install_desktop",            c: "#3E91FF" },
        plugins:       { t: "Plugins",                 i: "extension",       c: "#8E5AF5" },
        datetime:      { t: "Date and time",            i: "schedule",        c: "#6C6CD8" },
        about:         { t: "System",                  i: "settings",        c: "#6C6CD8" }
    })
    readonly property var order: ["about", "datetime", "connections", "display", "input", "windows", "power", "rgb", "sounds", "wallpaper",
                                  "panels", "desktop", "launcher", "keybinds", "apps", "plugins"]
    // old page names that now live elsewhere
    function pageOf(k) { return k === "lockscreen" || k === "powermenu" ? "power" : k === "hyprland" ? "windows" : k === "defaultapps" ? "apps" : k === "advanced" ? "about" : k === "appearance" ? "wallpaper" : k === "notifications" ? "sounds" : k === "panelitems" ? "panels" : (pages[k] ? k : "about") }

    // t = title, p = settings page, i = icon, k = extra search words
    readonly property var entries: [
        { t: "Lock screen light or dark", p: "lockscreen", i: "contrast", k: "lock screen dark light mode follow system colours theme" },
        { t: "Shortcut cheat sheet", p: "keybinds", i: "keyboard", k: "show shortcuts at login startup help list keys" },
        { t: "RGB lighting", p: "rgb", i: "lightbulb", k: "openrgb keyboard mouse fans ram led lights colour color follow wallpaper accent" },
        { t: "Time zone", p: "datetime", i: "public", k: "clock date time ntp automatic 24 hour 12 hour" },
        { t: "Touchpad", p: "input", i: "touchpad_mouse", k: "tap to click natural scrolling two finger scroll disable while typing pointer speed acceleration" },
        { t: "Mouse", p: "input", i: "mouse", k: "pointer speed acceleration sensitivity left handed flat natural scroll" },
        { t: "Keyboard layouts", p: "input", i: "language", k: "physical keyboard layout variant language xkb us gb fr de switch input source" },
        { t: "Key repeat", p: "input", i: "keyboard", k: "repeat rate delay numlock keyboard layout options" },
        { t: "Hyprland options", p: "hyprland", i: "tune", k: "compositor decoration layouts dwindle master cursor gestures misc render xwayland vrr tearing" },
        { t: "Wi-Fi", p: "connections", i: "wifi", k: "wireless network internet" },
        { t: "Bluetooth", p: "connections", i: "bluetooth", k: "pair devices headphones connect forget" },
        { t: "Connected devices", p: "connections", i: "earbuds", k: "bluetooth battery earbuds airpods headphones left right ear sound test speaker" },
        { t: "Game controllers", p: "connections", i: "sports_esports", k: "controller gamepad joystick xbox playstation dualsense switch test tester buttons remap swap" },
        { t: "Advanced network settings", p: "connections", i: "lan", k: "networkmanager ethernet vpn" },
        { t: "Volume", p: "sounds", i: "volume_up", k: "audio sound loud quiet" },
        { t: "Microphone volume", p: "sounds", i: "mic", k: "input mic record gain level sensitivity" },
        { t: "Where notification pop-ups appear", p: "sounds", i: "notifications_active", k: "toast position corner top bottom left right centre center screen" },
        { t: "Mute", p: "sounds", i: "volume_off", k: "audio silent" },
        { t: "Output device", p: "sounds", i: "speaker", k: "speakers headphones audio" },
        { t: "Do not disturb", p: "sounds", i: "notifications_off", k: "dnd silence popups" },
        { t: "Pop-up duration", p: "sounds", i: "timer", k: "notification toast seconds" },
        { t: "Screen scale", p: "display", i: "brightness_6", k: "resolution hidpi zoom size monitor" },
        { t: "Window layout", p: "windows", i: "web_asset", k: "floating dwindle master scrolling tile apps window mode" },
        { t: "Gap between windows", p: "windows", i: "grid_view", k: "gaps spacing tiling" },
        { t: "Gap to screen edge", p: "windows", i: "fit_screen", k: "gaps outer margin" },
        { t: "Window corner radius", p: "windows", i: "rounded_corner", k: "rounding round" },
        { t: "Border width", p: "windows", i: "border_outer", k: "outline window" },
        { t: "Blur", p: "wallpaper", i: "blur_on", k: "transparency frosted glass panel popup windows control centre" },
        { t: "On-screen display", p: "display", i: "keyboard", k: "osd volume brightness keyboard backlight caps lock num lock media keys popup position vertical horizontal" },
        { t: "Wallpaper transition", p: "wallpaper", i: "animation", k: "fade slide push zoom wipe circle blur animation change speed" },
        { t: "Animations", p: "display", i: "animation", k: "motion effects" },
        { t: "Dark mode", p: "wallpaper", i: "dark_mode", k: "light theme night" },
        { t: "Accent colour", p: "wallpaper", i: "palette", k: "color theme highlight" },
        { t: "Accent colour from the wallpaper", p: "wallpaper", i: "colorize", k: "color theme dynamic automatic" },
        { t: "Video wallpaper", p: "wallpaper", i: "movie", k: "live animated background mp4 webm" },
        { t: "Transparency", p: "wallpaper", i: "opacity", k: "opacity glass panel popup see-through" },
        { t: "Rounded corners", p: "wallpaper", i: "rounded_corner", k: "corner radius rounding round panel popup tiles square" },
        { t: "Font", p: "wallpaper", i: "font_download", k: "typeface text shell app size" },
        { t: "App theme", p: "wallpaper", i: "web_asset", k: "gtk theme adw-gtk3 adwaita gnome flatpak qt kde dark light match" },
        { t: "Icon theme", p: "wallpaper", i: "interests", k: "icons papirus adwaita" },
        { t: "Cursor", p: "wallpaper", i: "arrow_selector_tool", k: "mouse pointer cursor theme size bibata" },
        { t: "Match the shell in other apps", p: "wallpaper", i: "palette", k: "flatpak gnome gtk qt dark mode accent follow system theme" },
        { t: "Wallpaper", p: "wallpaper", i: "wallpaper", k: "background image picture" },
        { t: "Name tips", p: "about", i: "tooltip", k: "tooltip hover name label delay seconds" },
        { t: "Add or remove panels", p: "panels", i: "add", k: "panel multiple second bar taskbar new extra delete" },
        { t: "Panel position", p: "panels", i: "dock_to_bottom", k: "edge top bottom left right dock bar taskbar placement align" },
        { t: "Panel items", p: "panels", i: "view_column", k: "arrange move left centre center right order items elements remove add taskbar layout" },
        { t: "Panel thickness", p: "panels", i: "height", k: "bar size height" },
        { t: "Hide panels automatically", p: "panels", i: "unfold_less", k: "autohide auto hide panel taskbar slide" },
        { t: "Panel length", p: "panels", i: "straighten", k: "bar width shorter" },
        { t: "Panel distance from the screen edge", p: "panels", i: "open_in_full", k: "floating detached margin sidebar popups distance spacing screen edge" },
        { t: "App icon size", p: "panels", i: "photo_size_select_large", k: "dock bigger smaller icons" },
        { t: "Item size", p: "panels", i: "zoom_in", k: "panel buttons bigger smaller status icons" },
        { t: "Clock font size", p: "panels", i: "format_size", k: "time text bigger smaller" },
        { t: "Item padding", p: "panels", i: "padding", k: "taskbar spacing gap tighter icons space" },
        { t: "Pinned apps", p: "panels", i: "push_pin", k: "dock favourites favorites taskbar" },
        { t: "Show running apps", p: "panels", i: "apps", k: "dock taskbar open windows" },
        { t: "Clock", p: "panels", i: "schedule", k: "time date stacked inline 24-hour am pm format layout" },
        { t: "Desktop indicator style", p: "wallpaper", i: "workspaces", k: "workspaces desktops numbers roman numerals letters custom own characters symbols emoji japanese kanji boxes dots" },
        { t: "Bounce", p: "display", i: "sports_basketball", k: "animation spring springy bounce overshoot motion elastic animations" },
        { t: "Touchpad gestures", p: "wallpaper", i: "swipe", k: "three four finger fingers touchpad swipe workspaces desktops overview trackpad gestures 3 4" },
        { t: "Control centre tiles", p: "panels", i: "tune", k: "quick settings toggles move resize hide add edit sidebar caffeine" },
        { t: "Image search", p: "desktop", i: "image_search", k: "lens reverse image search screen region find picture web screenshot" },
        { t: "Arqen version", p: "about", i: "info", k: "version about shell arqen release number update" },
        { t: "Power menu", p: "powermenu", i: "power_settings_new", k: "power menu buttons order rearrange colours accent shape size columns shut down restart log out sleep lock" },
        { t: "Countdown before shutting down", p: "powermenu", i: "timer", k: "shut down restart log out lock sleep power off countdown timer seconds theme cancel animation flip slide pop fade roll drop zoom speed colour" },
        { t: "Screenshots and recording", p: "desktop", i: "screenshot_region", k: "screenshot screen recording record window region capture video folder save location where path" },
        { t: "Clipboard", p: "panels", i: "content_paste", k: "clipboard history cliphist copy paste clear" },
        { t: "Apps on the desktop", p: "desktop", i: "apps", k: "icons desktop shortcuts drag launcher show" },
        { t: "Desktop widgets", p: "desktop", i: "widgets", k: "clock battery system widget" },
        { t: "Arrange the desktop", p: "desktop", i: "drag_pan", k: "move icons grid positions reset hold" },
        { t: "Windows pushed off the screen", p: "windows", i: "side_navigation", k: "edge panel tuck off screen lost window side bar dock border" },
        { t: "Launcher position", p: "launcher", i: "open_with", k: "app drawer super key where" },
        { t: "Launcher layout", p: "launcher", i: "view_module", k: "app drawer grid list" },
        { t: "Launcher size", p: "launcher", i: "aspect_ratio", k: "app drawer width height" },
        { t: "Launcher icon size", p: "launcher", i: "photo_size_select_large", k: "app drawer" },
        { t: "Search position", p: "launcher", i: "open_with", k: "super space where" },
        { t: "Search layout", p: "launcher", i: "view_module", k: "grid list results" },
        { t: "Search size", p: "launcher", i: "aspect_ratio", k: "width height" },
        { t: "Search suggestions", p: "launcher", i: "lightbulb", k: "recommended apps folders topics" },
        { t: "Screen corners", p: "wallpaper", i: "fullscreen", k: "rounded screen corners radius display edge" },
        { t: "Secondary and tertiary colours", p: "wallpaper", i: "palette", k: "accent colour wheel custom primary secondary tertiary colors" },
        { t: "Panel islands", p: "panels", i: "view_column", k: "islands split separate left centre center right floating pills" },
        { t: "System sounds", p: "sounds", i: "music_note", k: "sound theme event sounds notification sound beep click charger battery screenshot shutter" },
        { t: "On-screen keyboard", p: "input", i: "keyboard", k: "osk virtual touch keyboard emoji gif giphy language layout api key" },
        { t: "Screens", p: "display", i: "desktop_windows", k: "monitor display resolution refresh rate hz scale rotation position second screen external hdmi check modes" },
        { t: "After a screenshot or recording", p: "desktop", i: "preview", k: "screenshot recording preview save copy edit rename delete ask corner" },
        { t: "Media widget", p: "desktop", i: "music_note", k: "media music player widget desktop playing spotify" },
        { t: "Media on the panel", p: "panels", i: "music_note", k: "media music player panel item playing now cover" },
        { t: "Window handle", p: "windows", i: "drag_handle", k: "window handle popup move close minimise maximise full screen hover top bar delay colour" },
        { t: "Plugins", p: "plugins", i: "extension", k: "plugin plugins widget widgets add import export share extension" },
        { t: "Import a plugin", p: "plugins", i: "download", k: "plugin import install zip tar" },
        { t: "Make a plugin", p: "plugins", i: "add", k: "plugin create new make develop write" },
        { t: "Laptop or desktop", p: "power", i: "laptop", k: "device type kind computer laptop desktop detect chassis" },
        { t: "Sleep, lock and screen off when idle", p: "power", i: "bedtime", k: "idle away timeout dim screen off blank lock sleep suspend minutes" },
        { t: "Closing the lid", p: "power", i: "laptop_chromebook", k: "lid close laptop sleep lock screen off hibernate external monitor" },
        { t: "Microphone and camera indicators", p: "panels", i: "privacy_tip", k: "privacy microphone mic camera webcam screen sharing in use dot indicator" },
        { t: "Lock screen", p: "lockscreen", i: "lock", k: "lock screen password clock login" },
        { t: "Lock screen clock", p: "lockscreen", i: "schedule", k: "lock clock style big tall stacked small size colour accent white custom gradient position left right date format" },
        { t: "Lock screen frame", p: "lockscreen", i: "category", k: "lock picture frame shape heart circle rounded arch blob colour" },
        { t: "Lock screen picture", p: "lockscreen", i: "image", k: "lock background wallpaper image blur darken dim" },
        { t: "Lock screen message", p: "lockscreen", i: "chat", k: "lock text message found owner contact" },
        { t: "Power mode", p: "power", i: "speed", k: "power profile saver balanced performance battery" },
        { t: "Battery notifications", p: "power", i: "battery_alert", k: "battery low critical full charged percentage warning sleep hibernate shut down" },
        { t: "Reset all settings", p: "about", i: "restart_alt", k: "reset default defaults factory restore everything start over" },
        { t: "Open shell config", p: "about", i: "tune", k: "json file edit" },
        { t: "Profile picture", p: "about", i: "account_circle", k: "avatar face user photo name account" },
        { t: "Keyboard shortcuts", p: "keybinds", i: "keyboard", k: "keybinds keys hotkeys bind shortcut super combination change turn off" },
        { t: "Add a keyboard shortcut", p: "keybinds", i: "add", k: "keybind hotkey open app run command" },
        { t: "Default apps", p: "apps", i: "open_in_new", k: "default browser email files terminal text editor pictures videos music pdf open with mime" },
        { t: "Start apps at login", p: "apps", i: "rocket_launch", k: "autostart startup login boot run automatically" },
        { t: "About apps", p: "apps", i: "info", k: "installed flatpak rpm snap appimage uninstall remove version package source" },
        { t: "Default web browser", p: "apps", i: "public", k: "browser chrome firefox vivaldi brave links" },
        { t: "Saved passwords", p: "about", i: "key", k: "keyring password unlock login browser chrome brave gnome-keyring secrets" },
        { t: "About this system", p: "about", i: "info", k: "version fedora hyprland" }
    ]

    function pageTitle(p) { const k = pageOf(p); return pages[k] ? pages[k].t : "" }
    function pageColor(p) { const k = pageOf(p); return pages[k] ? pages[k].c : "#3E91FF" }

    function search(q) {
        q = (q || "").toLowerCase().trim()
        if (q === "") return []
        const hits = []
        for (const e of entries) {
            const t = e.t.toLowerCase()
            const k = (e.k || "").toLowerCase()
            const pg = pageTitle(e.p).toLowerCase()
            let s = 0
            if (t.startsWith(q)) s = 4
            else if (t.includes(q)) s = 3
            else if (k.split(" ").some(w => w.startsWith(q))) s = 2
            else if (k.includes(q) || pg.includes(q)) s = 1
            if (s > 0) hits.push({ e: e, s: s })
        }
        hits.sort((a, b) => b.s - a.s)
        return hits.map(h => h.e)
    }
}
