pragma Singleton
import Quickshell
import Quickshell.Io
import QtQuick
import qs.config

// Looks at the shell's GitHub repo for a newer version and offers to install it.
// It reads one file (the version in config/Config.qml on the main branch) every few hours; nothing else is
// sent. Installing downloads the repo as a .tar.gz, runs its update.sh (your settings are kept) and restarts the shell.
Singleton {
    id: root
    readonly property string repo: "cache-byte/arqen-shell"
    readonly property string branch: "main"
    property string state: "idle"          // idle | checking | uptodate | available | updating | failed
    property string latest: ""
    property string message: ""
    property bool dismissed: false         // "Later" for this run
    readonly property bool enabled: Config.c.updateCheck !== false
    // the card on the screen: a new version, found by itself, not skipped, not put off
    readonly property bool prompt: state === "available" && !dismissed && latest !== (Config.c.updateSkipped || "")

    function parts(v) { return String(v).split(".").map(n => parseInt(n) || 0) }
    function newer(a, b) {            // a newer than b
        const x = parts(a), y = parts(b)
        for (let i = 0; i < Math.max(x.length, y.length); i++) {
            const d = (x[i] || 0) - (y[i] || 0)
            if (d !== 0) return d > 0
        }
        return false
    }

    function init() { first.start() }
    function check() {
        if (state === "checking" || state === "updating") return
        state = "checking"; message = ""
        checkProc.running = true
    }
    function later() { dismissed = true }
    function skip() { Config.c.updateSkipped = latest; dismissed = true }
    function install() {
        if (state === "updating") return
        state = "updating"; message = "Downloading ..."
        installProc.running = true
    }

    Timer { id: first; interval: 30000; onTriggered: if (root.enabled) root.check() }
    Timer { interval: 6 * 3600 * 1000; repeat: true; running: root.enabled; onTriggered: root.check() }

    Process {
        id: checkProc
        command: ["curl", "-fsSL", "--max-time", "20", "https://raw.githubusercontent.com/" + root.repo + "/" + root.branch + "/quickshell/arqen/config/Config.qml"]
        stdout: StdioCollector {
            onStreamFinished: {
                const m = text.match(/version:\s*"(\d+(?:\.\d+)*)"/)
                if (!m) { root.state = "failed"; root.message = "Could not read the version from GitHub."; return }
                root.latest = m[1]
                if (root.newer(m[1], Config.version)) { root.state = "available"; root.dismissed = false }
                else { root.state = "uptodate" }
            }
        }
        onExited: code => { if (code !== 0 && root.state === "checking") { root.state = "failed"; root.message = "Could not reach GitHub (no internet?)." } }
    }

    // download, unpack, run update.sh (no package installs), then restart the shell
    Process {
        id: installProc
        command: ["sh", "-c",
            'set -e; d=$(mktemp -d); trap "rm -rf $d" EXIT; '
            + 'curl -fsSL --max-time 120 "https://github.com/$1/archive/refs/heads/$2.tar.gz" | tar -xz -C "$d" --strip-components=1; '
            + '[ -f "$d/update.sh" ] && [ -d "$d/quickshell/arqen" ] || { echo "The download is not a shell package."; exit 3; }; '
            + 'cd "$d"; ARQEN_NODEPS=1 ARQEN_WARNED=1 bash ./update.sh', "sh", root.repo, root.branch]
        stdout: StdioCollector { id: out }
        stderr: StdioCollector { id: err }
        onExited: code => {
            if (code === 0) {
                root.message = "Updated. Restarting ..."
                Quickshell.execDetached(["sh", "-c", "sleep 1; pkill -x quickshell; while pgrep -x quickshell >/dev/null; do sleep 0.2; done; setsid qs -c arqen >/dev/null 2>&1 &"])
            } else {
                root.state = "failed"
                const e = (err.text || out.text || "").trim().split("\n").slice(-1)[0]
                root.message = "The update did not finish" + (e ? ": " + e : ".")
            }
        }
    }
}
