import QtQuick
import Quickshell
import qs.config        // Theme: colours, font
import qs.components    // Icon, HoverTip ...

// A panel button. It reads its settings with pluginApi.setting("name", fallback); they change as soon as
// you move them in Settings > Plugins.
Item {
    id: root
    property var pluginApi: null        // given by the shell
    property real barSize: 28           // given by the shell: how big panel items are
    readonly property int px: pluginApi ? pluginApi.setting("size", 18) : 18
    implicitWidth: barSize + 8
    implicitHeight: barSize + 8

    Rectangle {
        anchors.centerIn: parent
        width: root.barSize; height: width; radius: width / 2
        color: mouse.containsMouse ? Theme.hover : "transparent"
        Icon {
            anchors.centerIn: parent
            name: root.pluginApi ? root.pluginApi.setting("icon", "waving_hand") : "waving_hand"
            size: root.px
            color: root.pluginApi ? root.pluginApi.setting("tint", "#FFFFFF") : Theme.text
        }
    }
    MouseArea {
        id: mouse
        anchors.fill: parent
        hoverEnabled: true
        onClicked: {
            const urgency = root.pluginApi && root.pluginApi.setting("loud", false) ? "critical" : "normal"
            // the time is in the text: the shell shows two identical notifications from one app (within 90 s) as one,
            // so without it a second click would seem to do nothing
            Quickshell.execDetached(["notify-send", "-a", "Hello plugin", "-u", urgency, root.pluginApi ? root.pluginApi.setting("message", "Hello!") : "Hello!", Qt.formatTime(new Date(), "HH:mm:ss")])
        }
    }
    HoverTip { hovered: mouse.containsMouse; text: "Say hello" }
}
