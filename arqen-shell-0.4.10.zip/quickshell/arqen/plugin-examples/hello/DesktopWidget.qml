import QtQuick
import qs.config
import qs.components
import qs.services

// A desktop widget: the shell draws the card; this is what is on it. Sizes are multiplied by widgetScale.
Item {
    id: root
    property var pluginApi: null
    property var widgetData: ({})       // given by the shell: this widget's look
    property real widgetScale: 1
    implicitWidth: 200 * widgetScale
    implicitHeight: 90 * widgetScale

    DText {
        anchors.centerIn: parent
        width: parent.width - 24
        horizontalAlignment: Text.AlignHCenter
        wrapMode: Text.Wrap
        text: root.pluginApi ? root.pluginApi.setting("message", "Hello!") : "Hello!"
        font.pixelSize: 22 * root.widgetScale
        color: Widgets.fg(root.widgetData.look)
    }
}
