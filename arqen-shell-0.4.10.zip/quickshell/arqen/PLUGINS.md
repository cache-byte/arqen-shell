# Writing an Arqen plugin

A plugin adds something to the shell: a button on a panel, a widget on the desktop, a button in the
control centre, a window of its own, or a helper that runs in the background. It is a folder with a
`manifest.json` and a few QML files (QML is the language the whole shell is written in). There is
nothing to build: save a file and the shell loads it again by itself.

**The short version:** a plugin is `manifest.json` + one `.qml` file. Settings are a list in the manifest,
the shell draws the settings page for you.

There is a ready example: **Settings > Plugins > Hello** (its folder is `~/.config/quickshell/widgets/hello`).
Copy it and change it.

---

## 1. A plugin in two files

Make a folder in `~/.config/quickshell/widgets/`:

```sh
mkdir -p ~/.config/quickshell/widgets/greeter && cd ~/.config/quickshell/widgets/greeter
```

**`manifest.json`**

```json
{
  "id": "greeter",
  "name": "Greeter",
  "version": "1.0.0",
  "author": "You",
  "description": "Says hello",
  "entryPoints": { "barWidget": "BarWidget.qml" },
  "options": [
    { "key": "message", "type": "text", "label": "What it says", "default": "Hello!" }
  ]
}
```

- `id` is the folder name (letters, numbers, `-`).
- `entryPoints` says which parts it has (section 3).
- `options` are its settings (section 2).

**`BarWidget.qml`**

```qml
import QtQuick
import Quickshell
import qs.config        // Theme: colours, font
import qs.components    // Icon, DText, HoverTip, ArqButton ...

Item {
    id: root
    property var pluginApi: null     // the shell gives every part this
    property real barSize: 28        // the shell gives panel items this: how big they should be
    implicitWidth: barSize + 8
    implicitHeight: barSize + 8

    Icon { anchors.centerIn: parent; name: "waving_hand"; size: 18; color: Theme.text }
    MouseArea {
        id: mouse
        anchors.fill: parent
        hoverEnabled: true
        onClicked: Quickshell.execDetached(["notify-send", root.pluginApi.setting("message", "Hello!")])
    }
    HoverTip { hovered: mouse.containsMouse; text: "Say hello" }
}
```

Open **Settings > Plugins** (press **Reload** if it is not there), open **Greeter**, turn it on and press
**Add to the panel**. Click the icon: a notification appears. Change the message in its settings and click
again: it follows at once. Edit the QML, save: the plugin reloads.

If something is wrong, the plugin's row says so in red and `qs log -c arqen` has the details.

---

## 2. Settings: the `options` list

Each option is one line in `manifest.json`. The shell shows them in **Settings > Plugins** (open the
plugin's row), saves every change as it is made, and gives each one a reset arrow back to its `default`.

| `type`    | What you see           | Other fields                                         | The value is |
|-----------|------------------------|------------------------------------------------------|--------------|
| `toggle`  | an on / off switch     |                                                      | `true` / `false` |
| `slider`  | a slider               | `min`, `max`, `step`, `suffix` (e.g. `" px"`)        | a number |
| `choice`  | buttons to pick one    | `choices`: `["a", "b", "c"]`                         | the text picked |
| `text`    | a text box             | `placeholder`                                        | text |
| `color`   | colour swatches        |                                                      | `"#RRGGBB"` |
| `button`  | a button               | `run`: a command (`["notify-send", "Hi"]` or `"date > /tmp/x"`), `buttonText` | (nothing is saved) |
| `section` | a small heading        | `label`                                              | |
| `info`    | a line of grey text    | `text`                                               | |

Every option can have `key` (its name; not for `button`, `section`, `info`), `label`, `description`
(a line under the label), `icon` (a [Material Symbols](https://fonts.google.com/icons) name) and `default`.

```json
"options": [
  { "type": "section", "label": "Look" },
  { "key": "size",  "type": "slider", "label": "Size", "min": 12, "max": 32, "step": 1, "default": 18, "suffix": " px" },
  { "key": "loud",  "type": "toggle", "label": "Warning style", "default": false },
  { "key": "icon",  "type": "choice", "label": "Icon", "choices": ["star", "bolt"], "default": "star" },
  { "type": "button", "label": "Test it", "buttonText": "Run", "run": ["notify-send", "Test"] }
]
```

**Using a setting in your QML** (any part):

```qml
pluginApi.setting("size", 18)         // read it (the 18 is used if it was never set)
pluginApi.setSetting("size", 20)      // change it and keep it (written to settings.json in the plugin's folder)
```

Anything that reads a setting this way updates by itself when it changes.

Want something `options` can't do (a list you add to, a picture ...)? Add a `settings` part (section 3)
and draw your own page; it is shown under the options, with a **Save** button.

---

## 3. The parts a plugin can have

Each is a `.qml` file named in `entryPoints`. Have as many as you like.

| entryPoints key       | Usual file name           | What it is                         | The shell gives it                           |
|-----------------------|---------------------------|------------------------------------|----------------------------------------------|
| `barWidget`           | `BarWidget.qml`           | an item on a panel                 | `pluginApi`, `screen`, `barSize`, `vertical` |
| `desktopWidget`       | `DesktopWidget.qml`       | a widget on the desktop            | `pluginApi`, `widgetData`, `widgetScale`     |
| `controlCenterWidget` | `ControlCenterWidget.qml` | a button in the control centre     | `pluginApi`, `screen`                        |
| `panel`               | `Panel.qml`               | a window of its own                | `pluginApi`, `screen`                        |
| `settings`            | `Settings.qml`            | your own settings page (optional)  | `pluginApi`                                  |
| `main`                | `Main.qml`                | runs in the background             | `pluginApi`                                  |

Declare what you use as properties: `property var pluginApi: null`, `property real barSize: 28`.
Say how big the part is with `implicitWidth` / `implicitHeight`.

- **Desktop widget:** the shell draws the card and lets you move it; you draw what is on it. Multiply
  sizes by `widgetScale` (Small 0.8, Medium 1, Large 1.3). Text colour: `Widgets.fg(widgetData.look)`
  (`import qs.services`).
- **Window (`Panel.qml`):** open it with `pluginApi.openPanel(screen, button)` (it appears next to
  `button`) or `pluginApi.togglePanel(...)`. Esc or a click elsewhere closes it. Its size:
  `property real contentPreferredWidth: 600` and `property real contentPreferredHeight: 500`.
- **Background (`Main.qml`):** timers, programs, keyboard commands. Other parts reach it through
  `pluginApi.mainInstance` (to share a list, a timer ...).

## 4. `pluginApi`

| | |
|---|---|
| `setting(key, fallback)`, `setSetting(key, value)` | read / change a setting (section 2) |
| `pluginSettings`, `saveSettings()` | all settings as one object, and keeping it (the long way) |
| `pluginId`, `pluginDir`, `manifest` | its id, its folder, its manifest |
| `openPanel(screen, button)`, `closePanel(screen)`, `togglePanel(screen, button)` | its window |
| `withCurrentScreen(fn)` | calls `fn(screen)` with the screen you are on |
| `mainInstance` | its `Main.qml` |

---

## 5. Buttons, sliders and the rest: the shell's own pieces

Use these and the plugin looks like the shell (dark / light mode, accent colour and font follow by themselves).

```qml
import qs.config        // Theme.text, Theme.subtext, Theme.primary (accent), Theme.onPrimary,
                        // Theme.tile (soft background), Theme.hover, Theme.radius, Theme.font, Theme.dark
import qs.components
```

| Piece | Use | What to set |
|---|---|---|
| `ArqButton` | a button | `text`, `icon`, `size: "S" \| "M" \| "L"`, `primary: true` (accent colour); `onClicked` |
| `ArqSlider` | a slider | `from`, `to`, `value`, `stepSize`; `onMoved: v => ...`. `pill: true` = the big kind, `vertical: true` stands it up |
| `ArqToggle` | an on / off switch | `checked`; `onToggled: v => ...` |
| `ArqField` | a text box | `text`, `placeholder`, `iconName`; `onEdited`, `onAccepted` |
| `DText` | text (the shell's font) | like a normal `Text` |
| `Icon` | an icon | `name` (Material Symbols name), `size`, `color` |
| `HoverTip` | a name tip on hover | `hovered`, `text` |
| `ArqScrollBar` | a scroll bar for a `Flickable` / `ListView` | `flick: yourFlickable` |

```qml
Column {
    spacing: 10
    ArqButton { text: "Do it"; icon: "bolt"; primary: true; onClicked: console.log("clicked") }
    ArqSlider {
        width: 220; from: 0; to: 100; stepSize: 5
        value: pluginApi.setting("level", 50)
        onMoved: v => pluginApi.setSetting("level", v)
    }
    ArqToggle { checked: pluginApi.setting("on", true); onToggled: v => pluginApi.setSetting("on", v) }
}
```

For your own `Settings.qml` page, rows like the shell's are in `import qs.settings`:
`SRow { title; subtitle; icon }` (put a control inside), `SliderRow { title; value; from; to; step; suffix; onMoved }`,
`SChoices { model; current; onPicked }`, `SSwatches { value; onPicked }`.

Services: `import qs.services` gives `Media` (what is playing), `Audio` (volume), `Power` (battery),
`Notifs`, `Widgets`, `Gadgets` (Bluetooth devices, controllers).

### Quickshell.Widgets

Quickshell's own widget helpers, `import Quickshell.Widgets`
([docs](https://quickshell.org/docs/v0.3.0/types/Quickshell.Widgets/)). Handy ones:

| Type | What it does |
|---|---|
| `IconImage` | draws an icon from the system theme: `IconImage { source: Quickshell.iconPath("firefox"); implicitSize: 32 }` |
| `ClippingRectangle` | a rectangle that cuts its content to its rounded corners (a picture with rounded corners) |
| `WrapperRectangle` | a rectangle (colour, radius, border) that sizes itself around ONE child, with `margin` |
| `WrapperItem` | the same without a background: just padding around one child |
| `WrapperMouseArea` | a click area that sizes itself around one child: `WrapperMouseArea { onClicked: ...; Icon { ... } }` |

```qml
import Quickshell
import Quickshell.Widgets
import qs.config
import qs.components

// a rounded label that fits its text, clickable
WrapperMouseArea {
    onClicked: console.log("hi")
    WrapperRectangle {
        color: Theme.tile; radius: 14; margin: 8
        DText { text: "Hello" }
    }
}
```

---

## 6. Doing things

Anything Quickshell can do (see quickshell.org):

```qml
import Quickshell.Io

// run a program and read what it prints
Process {
    id: proc
    command: ["sh", "-c", "date +%H:%M"]
    stdout: StdioCollector { onStreamFinished: console.log(text) }
}
// proc.running = true   runs it

// a command you can bind to a key:  qs -c arqen ipc call plugin:greeter hello
IpcHandler {
    target: "plugin:greeter"
    function hello(): void { Quickshell.execDetached(["notify-send", "Hello"]) }
}
```

Also available: `FileView` (read / write files), `Quickshell.Services.Mpris`, `Pipewire`, `UPower`,
`Bluetooth`, `Quickshell.Hyprland`, `SystemTray`.

**Notifications:** the shell shows two identical notifications from the same app (same title and text, within
90 seconds) as one, so a plugin that sends the same text on every click looks stuck. Put something that
changes in the text, like the time (the Hello example does).

## 7. Share it

**Settings > Plugins**, open the plugin, **Export**: you get a `.zip` (your own `settings.json` is left
out). Others use **Import a plugin**. Add a `preview.png` to the folder for its picture in Settings, and a
`README.md` to explain it.

## Problems

- **Not in the list:** `manifest.json` must be valid JSON (no comma after the last item) and sit in the
  plugin's own folder. Press **Reload**.
- **Red text in its row:** a file named in `entryPoints` is missing, or the plugin uses something Arqen
  does not have (plugins made for other shells, such as Noctalia's, don't work).
- **"could not load":** a mistake in the QML. `qs log -c arqen` shows the file and line.
- **A setting does nothing:** check the `key` is spelled the same in the manifest and in
  `pluginApi.setting("key", ...)`.
