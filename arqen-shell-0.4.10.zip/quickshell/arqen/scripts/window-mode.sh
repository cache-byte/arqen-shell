#!/usr/bin/env bash
# window-mode.sh MODE KIND [ADDRESS]   MODE: floating|dwindle|master|scrolling   KIND: lua|legacy
# Sets Hyprland's layout and floats / tiles the windows that are open (only ADDRESS when given: a window that
# has just opened; the shell's own windows, Settings included, follow the mode too). Prints what went wrong, or "ok".
#   window-mode.sh remember   writes down the size of every floating window per app (~/.cache/arqen/winsizes.json),
#                             so an app that gets floated later opens at the size it had last time.
mode="${1:-floating}"; kind="${2:-legacy}"; only="${3:-}"
cache="${XDG_CACHE_HOME:-$HOME/.cache}/arqen"; sizes="$cache/winsizes.json"

if [ "$mode" = remember ]; then
  mkdir -p "$cache"
  hyprctl clients -j 2>/dev/null | python3 -I -c '
import json, sys, os
p = sys.argv[1]
try: mem = json.load(open(p))
except Exception: mem = {}
try: cl = json.load(sys.stdin)
except Exception: sys.exit(0)
for c in cl:
    cls = c.get("class") or c.get("initialClass") or ""
    if not cls or not c.get("mapped", True) or not c.get("floating") or c.get("fullscreen"): continue
    if cls.startswith(("org.quickshell", "quickshell")): continue
    w, h = c.get("size", [0, 0])
    if w < 320 or h < 240: continue
    mem[cls] = [int(w), int(h)]
tmp = p + ".tmp"
json.dump(mem, open(tmp, "w")); os.replace(tmp, p)
' "$sizes"
  exit 0
fi

case "$mode" in master|scrolling) lay="$mode" ;; *) lay=dwindle ;; esac
want=false; [ "$mode" = floating ] && want=true
err=""
note() { [ -n "$1" ] && err="$err $1;"; }
mv_to() { # address x y
  if [ "$kind" = lua ]; then hyprctl dispatch "hl.dsp.window.move({ x = $2, y = $3, window = \"address:$1\" })" >/dev/null 2>&1
  else hyprctl dispatch movewindowpixel "exact $2 $3,address:$1" >/dev/null 2>&1; fi
}
rs_to() { # address w h
  if [ "$kind" = lua ]; then hyprctl dispatch "hl.dsp.window.resize({ x = $2, y = $3, window = \"address:$1\" })" >/dev/null 2>&1
  else hyprctl dispatch resizewindowpixel "exact $2 $3,address:$1" >/dev/null 2>&1; fi
}

if [ -z "$only" ]; then
  if [ "$kind" = lua ]; then
    o="$(hyprctl eval "hl.config({ general = { layout = \"$lay\" } })" 2>&1)"
  else
    o="$(hyprctl keyword general:layout "$lay" 2>&1)"
  fi
  case "$o" in ""|ok*|*"ok"*) ;; *) note "layout: $o" ;; esac
  sleep 0.4
fi

[ -n "$only" ] && sleep 0.15     # the window has only just opened
list="$(hyprctl clients -j 2>/dev/null)" || { echo "hyprctl clients failed"; exit 1; }
addrs="$(printf '%s' "$list" | python3 -I -c '
import json, sys
want = sys.argv[1] == "true"; only = sys.argv[2]
for c in json.load(sys.stdin):
    if not c.get("mapped", True): continue
    if only and c.get("address") != only: continue
    if c.get("fullscreen"): continue
    if only:
        # small pop-ups, tooltips and menus (Steam, browsers ...) are left exactly as the app made them
        w, h = c.get("size", [0, 0])
        if w < 320 or h < 240: continue
        if c.get("xwayland") and not c.get("title"): continue
    if bool(c.get("floating")) != want: print(c["address"])
' "$want" "$only")"

for a in $addrs; do
  if [ "$kind" = lua ]; then
    o="$(hyprctl dispatch "hl.dsp.window.float({ action = \"toggle\", window = \"address:$a\" })" 2>&1)"
  else
    o="$(hyprctl dispatch togglefloating "address:$a" 2>&1)"
  fi
  case "$o" in ""|ok*|*"ok"*) ;; *) note "float $a: $o" ;; esac
done

# A window that was tiled and has just been floated: the app's size from last time if known, centred on its screen
# (only that window; a window the app floated itself keeps the size and place the app chose)
if [ -n "$only" ] && [ -n "$addrs" ] && [ "$want" = true ]; then
  sleep 0.1
  place="$(hyprctl clients -j 2>/dev/null | python3 -I -c '
import json, subprocess, sys
only = sys.argv[1]; p = sys.argv[2]
try: mem = json.load(open(p))
except Exception: mem = {}
try: mons = json.loads(subprocess.run(["hyprctl", "monitors", "-j"], capture_output=True, text=True).stdout)
except Exception: mons = []
for c in json.load(sys.stdin):
    if c.get("address") != only: continue
    cls = c.get("class") or c.get("initialClass") or ""
    w, h = mem.get(cls, c.get("size", [0, 0]))
    m = next((m for m in mons if m.get("id") == c.get("monitor")), mons[0] if mons else None)
    if not m: break
    sc = m.get("scale") or 1
    mw, mh = m["width"] / sc, m["height"] / sc
    if m.get("transform", 0) % 2: mw, mh = mh, mw
    r = m.get("reserved", [0, 0, 0, 0])
    ax, ay = m["x"] + r[0], m["y"] + r[1]
    aw, ah = mw - r[0] - r[2], mh - r[1] - r[3]
    w, h = min(w, aw), min(h, ah)
    print(int(w), int(h), int(ax + (aw - w) / 2), int(ay + (ah - h) / 2))
' "$only" "$sizes")"
  if [ -n "$place" ]; then
    set -- $place
    rs_to "$only" "$1" "$2"
    mv_to "$only" "$3" "$4"
  fi
fi
[ -z "$err" ] && echo ok || echo "$err"
