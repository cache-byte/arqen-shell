```
    _    ____   ___  _____ _   _
   / \  |  _ \ / _ \| ____| \ | |
  / _ \ | |_) | | | |  _| |  \| |
 / ___ \|  _ <| |_| | |___| |\  |
/_/   \_\_| \_\\__\_\_____|_| \_|
```

# Arqen shell — a Hyprland + Quickshell shell (version 0.4.19)

> **!! THIS SHELL WAS MADE FULLY WITH CLAUDE AI AND MAY HAVE ERRORS. TRY IT AT YOUR OWN RISK, AS THE CREATOR WILL NOT BE LIABLE FOR ANY BROKEN CONFIGS, SETTINGS ETC. THE SHELL WAS MADE AS A TEST, NOT REALLY AS A DAILY DRIVER. !!**

## What you get
A panel (clock, desktops, tray, control centre), launcher and search, notifications, desktop overview, lock screen, on-screen keyboard, screenshots and recordings, RGB lighting through OpenRGB, clipboard history, wallpapers (pictures and videos), and a Settings app. Everything is set in Settings (`Super+I`).

## Install
```
unzip arqen-shell-*.zip && cd arqen-merged
./install.sh
```
The installer shows the name, the warning and the list of everything the shell uses, then asks:

1. install everything (Fedora),
2. choose which parts to install, or
3. install the shell only and install the dependencies yourself.

On a system that is not Fedora, only the shell is installed; the list is in [DEPENDENCIES.md](DEPENDENCIES.md). What you decline is remembered (`~/.config/arqen/deps-skipped`) and `update.sh` leaves it alone. Set `ARQEN_DEPS=all` or `ARQEN_DEPS=none` to skip the question.

Then log out and pick **Hyprland** on the login screen. Once inside, run `./update.sh` once more (a few things can only be set up in a running Hyprland).

## Everyday keys
`Super` launcher · `Super+Space` search · `Super+I` settings · `Super+Tab` desktops · `Super+N` control centre · `Super+L` lock · `Super+Enter` terminal · `Super+E` files · `Super+Q` close · `Print` screenshot or recording.

## Update and remove
- `./update.sh` — puts a new version in place and repairs the setup (safe to repeat).
- `./uninstall.sh` — takes the shell out again (also: Settings > System > Uninstall makes it in your Downloads folder, to run from another desktop). It asks which of the packages the shell installed to keep or delete (all, group by group, or none; dnf shows what else would go before anything is removed).
- `tools/` — `check.sh`, `switch-to-lua.sh` / `switch-to-conf.sh` (Hyprland config format), `gnome-session-reset.sh` (if GNOME bounces you back to the login screen).

## Something wrong?
Run `qs -c arqen` in a terminal to see why the shell does not start. Settings > System has "Show more settings" for the rarely needed options and a reset to the defaults. What changed in each version: [CHANGELOG.md](CHANGELOG.md).

## Credits
Made with Claude (Anthropic). Built on Hyprland and Quickshell. Ideas from DankMaterialShell, HyprMod, skwd-wall and GNOME. Looks: Papirus, Bibata, Material Symbols, Inter, adw-gtk3, qt6ct. Parts it uses: NetworkManager, BlueZ, PipeWire, cava, playerctl, grim, slurp, wf-recorder, wtype, wl-clipboard, cliphist, brightnessctl, UPower, ImageMagick, hyprlang2lua. GIF search: GIPHY. Image search: Google Lens. Each belongs to its own project and license.
