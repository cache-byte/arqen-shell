import QtQuick
import QtQuick.Layouts
import Quickshell
import qs.config
import qs.components
import qs.services

// The settings of a plugin, made from the "options" list in its manifest.json (no QML needed):
//   { "key": "size", "label": "Size", "type": "slider", "min": 1, "max": 10, "step": 1, "default": 5, "suffix": " px" }
//   type: toggle | slider | choice ("choices": [...]) | text | color | button ("run": a command) | section | info
// Every change is saved as it is made, each option has a reset arrow, and the plugin follows at once.
ColumnLayout {
    id: po
    property var pluginApi: null
    property var options: []
    spacing: 0

    function value(o) { const v = pluginApi ? pluginApi.pluginSettings[o.key] : undefined; return v === undefined ? o.default : v }
    function put(o, v) { if (pluginApi) pluginApi.setSetting(o.key, v) }
    function same(o) { return String(po.value(o)) === String(o.default) }
    function runIt(o) {
        const r = o.run
        if (Array.isArray(r)) Quickshell.execDetached(r.map(String))
        else if (typeof r === "string" && r !== "") Quickshell.execDetached(["sh", "-c", r])
    }

    Repeater {
        model: po.options
        delegate: Loader {
            id: ld
            required property var modelData
            Layout.fillWidth: true
            Layout.preferredHeight: item ? item.implicitHeight : 0
            sourceComponent: modelData.type === "section" ? secC : modelData.type === "info" ? infoC : modelData.type === "slider" ? sliC : rowC
            onLoaded: { item.od = modelData; item.width = Qt.binding(() => ld.width) }
        }
    }

    Component {
        id: secC
        Item {
            property var od: ({})
            implicitHeight: 28
            DText { x: 12; anchors.bottom: parent.bottom; anchors.bottomMargin: 4; text: parent.od.label ?? ""; font.pixelSize: 12; font.weight: Font.DemiBold; color: Theme.subtext }
        }
    }
    Component {
        id: infoC
        Item {
            property var od: ({})
            implicitHeight: t.implicitHeight + 12
            DText { id: t; x: 12; y: 6; width: parent.width - 24; wrapMode: Text.Wrap; text: parent.od.text ?? parent.od.label ?? ""; font.pixelSize: 12; color: Theme.subtext }
        }
    }
    Component {
        id: sliC
        SliderRow {
            id: sr
            property var od: ({})
            compact: true
            title: od.label ?? od.key ?? ""; subtitle: od.description ?? ""; icon: od.icon ?? ""
            resetHandled: true
            changed: !po.same(od)
            onReset: po.put(od, od.default)
            from: od.min ?? 0; to: od.max ?? 100; step: od.step ?? 1; suffix: od.suffix ?? ""
            value: !isNaN(pending) ? pending : Number(po.value(od) ?? from)
            // saved a moment after the slider rests, not at every pixel
            property real pending: NaN
            onMoved: v => { pending = v; commit.restart() }
            Timer { id: commit; interval: 80; onTriggered: if (!isNaN(sr.pending)) { po.put(sr.od, sr.pending); sr.pending = NaN } }
        }
    }
    Component {
        id: rowC
        SRow {
            id: rr
            property var od: ({})
            compact: true
            title: od.label ?? od.key ?? ""; subtitle: od.description ?? ""; icon: od.icon ?? ""
            resetHandled: od.type !== "button"
            changed: od.type !== "button" && !po.same(od)
            onReset: po.put(od, od.default)
            ArqToggle {
                visible: rr.od.type === "toggle"
                checked: !!po.value(rr.od)
                onToggled: v => po.put(rr.od, v)
            }
            SChoices {
                compact: true
                visible: rr.od.type === "choice"
                model: (rr.od.choices || []).map(String)
                current: String(po.value(rr.od) ?? "")
                onPicked: v => po.put(rr.od, v)
            }
            SSwatches {
                visible: rr.od.type === "color"
                value: String(po.value(rr.od) ?? "#FFFFFF")
                onPicked: hex => po.put(rr.od, hex)
            }
            ArqField {
                visible: rr.od.type === "text"
                readonly property real naturalWidth: 190
                width: 190; implicitHeight: 32
                placeholder: rr.od.placeholder ?? ""
                text: String(po.value(rr.od) ?? "")
                onEdited: po.put(rr.od, text)
            }
            ArqButton {
                visible: rr.od.type === "button"
                text: rr.od.buttonText ?? rr.od.label ?? "Run"
                primary: rr.od.primary === true
                onClicked: po.runIt(rr.od)
            }
        }
    }
}
