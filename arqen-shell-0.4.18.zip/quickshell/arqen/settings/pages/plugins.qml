import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Io
import qs.config
import qs.components
import qs.services
import qs.settings

// Settings > Plugins: the ones you have (on / off; click one for its settings and what it can do),
// importing and exporting them. They live in ~/.config/quickshell/widgets (services/Plugins.qml).
ColumnLayout {
    id: pg
    width: parent.width; spacing: 16

    // ---- file pickers (the system's own dialogs) ----
    property string picking: ""
    property string exportId: ""
    Process {
        id: picker
        stdout: StdioCollector {
            onStreamFinished: {
                const p = text.trim()
                if (p !== "") {
                    if (pg.picking === "import") Plugins.importFrom(p)
                    else if (pg.picking === "export") Plugins.exportTo(pg.exportId, p)
                }
                pg.picking = ""
            }
        }
        onExited: code => { if (code !== 0) pg.picking = "" }
    }
    function pickImport(folder) {
        if (picker.running) return
        picking = "import"
        picker.command = folder
            ? ["python3", "-I", Quickshell.shellDir + "/scripts/pick-folder.py", "Import a plugin folder", Quickshell.env("HOME")]
            : ["python3", "-I", Quickshell.shellDir + "/scripts/pick-file.py", "open", "Import a plugin", Quickshell.env("HOME") + "/Downloads",
               "*.zip", "*.tar.gz", "*.tgz", "*.tar.xz", "*.tar.bz2", "*.tar.zst", "*.tar"]
        picker.running = true
    }
    function pickExport(p) {
        if (picker.running) return
        picking = "export"; exportId = p.id
        picker.command = ["python3", "-I", Quickshell.shellDir + "/scripts/pick-file.py", "save", "Export " + p.name, Quickshell.env("HOME"), p.id + ".zip"]
        picker.running = true
    }

    // the plugin that is open (its settings and buttons); "Plugin settings" elsewhere opens one
    property string open: Ui.pluginFocus
    onOpenChanged: Ui.pluginFocus = open
    Connections { target: Ui; function onPluginFocusChanged() { if (pg.open !== Ui.pluginFocus) pg.open = Ui.pluginFocus } }
    property string removing: ""

    // what a plugin can add, in plain words: two kinds of widget
    readonly property var parts: [["barWidget", "Panel widget", "a widget on a panel"],
                                  ["desktopWidget", "Desktop widget", "a widget on the desktop"]]
    function addsText(p) {
        const e = p?.parts ?? {}
        const l = parts.filter(x => !!e[x[0]]).map(x => x[2])
        if ((p?.manifest?.options ?? []).length > 0) l.push("settings you can change here")
        return l.length ? "Adds " + l.join(", ") : "Adds nothing yet"
    }

    // ---- what this page is ----
    SCard {
        spacing: 8
        DText { text: "What are plugins?"; font.pixelSize: 15; font.weight: Font.Medium }
        DText {
            Layout.fillWidth: true; wrapMode: Text.Wrap; color: Theme.subtext; font.pixelSize: 13
            text: "A plugin is a small add-on that gives the shell a new widget: one on a panel, one on the desktop, or both. Each one is a folder (or a .zip) made by you or someone else."
        }
        DText {
            Layout.fillWidth: true; wrapMode: Text.Wrap; color: Theme.subtext; font.pixelSize: 13
            text: "1.  Import it below.    2.  Turn it on (the switch on its row).    3.  Open its row and press the button that puts it where you want it."
        }
    }

    // ---- getting plugins ----
    SHeader { text: "Add plugins" }
    SGroup {
        SRow { title: "Import a plugin"; subtitle: "A .zip or .tar.gz, or a folder. Importing one you have updates it and keeps its settings"; icon: "download"
            ArqButton { text: pg.picking === "import" ? "Choosing…" : "File…"; primary: true; onClicked: pg.pickImport(false) }
            ArqButton { text: "Folder…"; onClicked: pg.pickImport(true) } }
        SRow { title: "Plugins folder"; subtitle: Config.tilde(Plugins.dir) + "  ·  changes there are picked up by themselves"; icon: "folder"
            ArqButton { text: "Open"; onClicked: Plugins.openFolder("") }
            ArqButton { text: "Reload"; onClicked: Plugins.reload() } }
        SRow { title: "Writing your own"; subtitle: "A working plugin in five minutes: one manifest, one QML file"; icon: "code"
            ArqButton { text: "Guide"; onClicked: Quickshell.execDetached(["xdg-open", Quickshell.shellDir + "/PLUGINS.md"]) } }
        SRow {
            visible: Plugins.status !== ""
            title: Plugins.status
            icon: /^Could not|not imported/.test(Plugins.status) ? "error" : "check_circle"
            iconColor: /^Could not|not imported/.test(Plugins.status) ? "#FF5A5A" : Theme.secondaryContainer
        }
    }

    // ---- the ones you have ----
    SHeader { text: Plugins.list.length > 0 ? "Installed  ·  " + Plugins.list.length : "Installed" }
    SGroup {
        SRow { visible: Plugins.list.length === 0; title: "No plugins yet"; subtitle: "Press File… or Folder… above to import one, or put its folder in the plugins folder. Nothing is needed for the shell to work: plugins only add extras"; icon: "extension" }
        Repeater {
            model: Plugins.list
            delegate: Item {
                id: pc
                required property var modelData
                readonly property var p: modelData
                readonly property var m: p.manifest ?? ({})
                readonly property var eps: p.parts ?? ({})
                readonly property bool on: Plugins.isEnabled(p.id)
                readonly property bool bad: p.error !== ""
                readonly property bool showing: pg.open === p.id
                Layout.fillWidth: true
                implicitHeight: head.height + (showing ? more.implicitHeight + 8 : 0)
                clip: true

                // ---- the row: picture, name, what it adds, on / off ----
                Item {
                    id: head
                    width: parent.width; height: 76
                    Rectangle { anchors.fill: parent; anchors.margins: 4; radius: Math.max(0, Theme.radius - 6); color: hma.containsMouse && !pc.showing ? Theme.hover : "transparent" }
                    MouseArea { id: hma; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: pg.open = pc.showing ? "" : pc.p.id }
                    Rectangle {
                        x: 18; anchors.verticalCenter: parent.verticalCenter
                        width: 44; height: 44; radius: 12; color: pc.bad ? Qt.rgba(1, 0.35, 0.35, 0.18) : Theme.secondaryContainer; clip: true
                        Image { anchors.fill: parent; visible: !!pc.p.preview; source: pc.p.preview ? "file://" + pc.p.preview : ""; fillMode: Image.PreserveAspectCrop; asynchronous: true; sourceSize.width: 96 }
                        Icon { anchors.centerIn: parent; visible: !pc.p.preview; name: pc.bad ? "extension_off" : "extension"; size: 22; color: pc.bad ? "#FF5A5A" : Theme.onSecondaryContainer }
                    }
                    Column {
                        x: 76; anchors.verticalCenter: parent.verticalCenter
                        width: parent.width - x - 18 - tog.width - 40
                        spacing: 2
                        DText { width: parent.width; text: pc.p.name + (pc.m.version ? "  " : ""); font.pixelSize: 15; elide: Text.ElideRight
                            DText { x: parent.implicitWidth; anchors.baseline: parent.baseline; text: pc.m.version ? "v" + pc.m.version : ""; font.pixelSize: 11; color: Theme.subtext } }
                        DText {
                            width: parent.width; elide: Text.ElideRight
                            text: pc.bad ? pc.p.error : (pc.on ? "" : "Off  ·  ") + pg.addsText(pc.p)
                            font.pixelSize: 12; color: pc.bad ? "#FF6A6A" : Theme.subtext
                        }
                    }
                    Icon {
                        anchors { right: tog.left; rightMargin: 12; verticalCenter: parent.verticalCenter }
                        name: "expand_more"; size: 20; color: Theme.subtext
                        rotation: pc.showing ? 180 : 0
                        Behavior on rotation { NumberAnimation { duration: 160; easing.type: Easing.OutCubic } }
                    }
                    ArqToggle {
                        id: tog
                        anchors { right: parent.right; rightMargin: 18; verticalCenter: parent.verticalCenter }
                        visible: !pc.bad
                        checked: pc.on
                        onToggled: v => Plugins.setEnabled(pc.p.id, v)
                    }
                }

                // ---- open: what it is, what you can do, its settings ----
                ColumnLayout {
                    id: more
                    visible: pc.showing
                    x: 76; y: head.height
                    width: parent.width - x - 18
                    spacing: 12
                    DText {
                        visible: text !== ""
                        Layout.fillWidth: true; wrapMode: Text.Wrap
                        text: (pc.m.description || "") + (pc.m.author ? (pc.m.description ? "  " : "") + "By " + pc.m.author + "." : "")
                        font.pixelSize: 12; color: Theme.subtext
                    }
                    DText {
                        visible: (pc.p.warnings ?? []).length > 0
                        Layout.fillWidth: true; wrapMode: Text.Wrap
                        text: "Worth fixing in its manifest.json:\n" + (pc.p.warnings ?? []).map(w => "•  " + w).join("\n")
                        font.pixelSize: 12; color: "#E6A23C"
                    }
                    DText {
                        visible: !pc.on && !pc.bad
                        Layout.fillWidth: true; wrapMode: Text.Wrap
                        text: "It is off. Turn it on with the switch to use it."
                        font.pixelSize: 12; color: Theme.subtext
                    }
                    DText {
                        visible: pc.on && !pc.bad
                        Layout.fillWidth: true; wrapMode: Text.Wrap
                        text: pg.addsText(pc.p) + ". Use the buttons below to put it there."
                        font.pixelSize: 12; color: Theme.subtext
                    }
                    Flow {
                        Layout.fillWidth: true
                        spacing: 8
                        ArqButton { visible: !!pc.eps.desktopWidget && pc.on && !pc.bad; text: "Add to the desktop"; onClicked: Widgets.add("plugin:" + pc.p.id) }
                        ArqButton {
                            visible: !!pc.eps.barWidget && pc.on && !pc.bad
                            readonly property bool placed: Config.panelOf("plugin:" + pc.p.id) !== null
                            text: placed ? "On a panel" : "Add to the panel"
                            enabled: !placed
                            opacity: placed ? 0.6 : 1
                            onClicked: if (!placed && Config.panelsNow.length) Config.addElement(Config.panelsNow[0].id, "plugin:" + pc.p.id)
                        }
                        ArqButton { text: pg.picking === "export" && pg.exportId === pc.p.id ? "Choosing…" : "Export"; onClicked: pg.pickExport(pc.p) }
                        ArqButton { text: "Folder"; onClicked: Plugins.openFolder(pc.p.id) }
                        ArqButton {
                            text: pg.removing === pc.p.id ? "Remove it?" : "Remove"
                            primary: pg.removing === pc.p.id
                            onClicked: { if (pg.removing === pc.p.id) { pg.removing = ""; Plugins.remove(pc.p.id) } else pg.removing = pc.p.id }
                        }
                    }
                    // its settings: the "options" of its manifest (saved as you change them)
                    Rectangle {
                        readonly property bool hasOptions: (pc.m.options ?? []).length > 0
                        visible: hasOptions && pc.on && !pc.bad
                        Layout.fillWidth: true
                        Layout.preferredHeight: visible ? setCol.implicitHeight + 32 : 0
                        radius: Math.max(0, Theme.radius - 6)
                        color: Theme.tile
                        ColumnLayout {
                            id: setCol
                            x: 16; y: 16; width: parent.width - 32
                            spacing: 12
                            DText { text: "Settings"; font.pixelSize: 13; font.weight: Font.Medium }
                            PluginOptions {
                                id: popts
                                Layout.fillWidth: true
                                options: pc.m.options ?? []
                                // set from code, not by a binding: Plugins.api() may make the plugin's api object (which would loop)
                                function refreshApi() { pluginApi = pc.showing && pc.on ? Plugins.api(pc.p.id) : null }
                                Component.onCompleted: refreshApi()
                                Connections { target: pc; function onShowingChanged() { popts.refreshApi() }; function onOnChanged() { popts.refreshApi() } }
                                Connections { target: Plugins; function onListChanged() { popts.refreshApi() } }
                            }
                        }
                    }
                    Item { implicitHeight: 4 }
                }
                Rectangle { anchors { bottom: parent.bottom; left: parent.left; right: parent.right; leftMargin: 18; rightMargin: 18 } height: 1; color: Theme.divider }
            }
        }
    }
}
