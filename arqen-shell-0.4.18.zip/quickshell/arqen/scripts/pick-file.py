#!/usr/bin/env python3
"""Ask for a file with the system's own file picker; print the chosen path (nothing if cancelled).

  pick-file.py open TITLE START_FOLDER [PATTERNS...]     e.g. *.zip *.tar.gz
  pick-file.py save TITLE START_FOLDER SUGGESTED_NAME

Tries the desktop portal (the same dialog apps use, follows the system theme), then zenity, then kdialog.
"""
import os
import shutil
import subprocess
import sys
from urllib.parse import unquote, urlparse

mode = sys.argv[1] if len(sys.argv) > 1 else "open"
title = sys.argv[2] if len(sys.argv) > 2 else ("Save as" if mode == "save" else "Choose a file")
start = sys.argv[3] if len(sys.argv) > 3 else os.path.expanduser("~")
rest = sys.argv[4:]
name = rest[0] if mode == "save" and rest else ""
patterns = rest if mode == "open" else []
while start and not os.path.isdir(start):
    start = os.path.dirname(start)


def portal():
    try:
        from gi.repository import Gio, GLib
    except Exception:
        return None
    bus = Gio.bus_get_sync(Gio.BusType.SESSION, None)
    token = "arqen%d" % os.getpid()
    sender = bus.get_unique_name()[1:].replace(".", "_")
    handle = "/org/freedesktop/portal/desktop/request/%s/%s" % (sender, token)
    loop = GLib.MainLoop()
    result = {"path": None, "done": False}

    def on_response(_c, _s, _p, _i, _sig, params):
        code, res = params.unpack()
        if code == 0 and res.get("uris"):
            result["path"] = unquote(urlparse(res["uris"][0]).path)
        result["done"] = True
        loop.quit()

    bus.signal_subscribe("org.freedesktop.portal.Desktop", "org.freedesktop.portal.Request", "Response",
                         handle, None, Gio.DBusSignalFlags.NO_MATCH_RULE, on_response)
    opts = {"handle_token": GLib.Variant("s", token), "modal": GLib.Variant("b", True)}
    if start:
        opts["current_folder"] = GLib.Variant("ay", (start + "\0").encode())
    if mode == "save" and name:
        opts["current_name"] = GLib.Variant("s", name)
    if patterns:
        flt = ("Plugins", [(0, p) for p in patterns])
        opts["filters"] = GLib.Variant("a(sa(us))", [flt, ("All files", [(0, "*")])])
    method = "SaveFile" if mode == "save" else "OpenFile"
    try:
        bus.call_sync("org.freedesktop.portal.Desktop", "/org/freedesktop/portal/desktop",
                      "org.freedesktop.portal.FileChooser", method,
                      GLib.Variant("(ssa{sv})", ("", title, opts)), None, Gio.DBusCallFlags.NONE, 5000, None)
    except Exception:
        return None
    GLib.timeout_add_seconds(3600, loop.quit)
    loop.run()
    return (result["path"] or "") if result["done"] else None


path = portal()
if path is None and shutil.which("zenity"):
    cmd = ["zenity", "--file-selection", "--title", title]
    if mode == "save":
        cmd += ["--save", "--confirm-overwrite", "--filename", os.path.join(start, name)]
    else:
        cmd += ["--filename", start.rstrip("/") + "/"]
        if patterns:
            cmd += ["--file-filter", "Plugins | " + " ".join(patterns), "--file-filter", "All files | *"]
    r = subprocess.run(cmd, capture_output=True, text=True)
    path = r.stdout.strip() if r.returncode == 0 else ""
if path is None and shutil.which("kdialog"):
    if mode == "save":
        r = subprocess.run(["kdialog", "--title", title, "--getsavefilename", os.path.join(start, name)], capture_output=True, text=True)
    else:
        r = subprocess.run(["kdialog", "--title", title, "--getopenfilename", start, " ".join(patterns)], capture_output=True, text=True)
    path = r.stdout.strip() if r.returncode == 0 else ""
print(path or "")
