#!/usr/bin/env python3
"""Arqen plugins, kept in ~/.config/quickshell/widgets.

  plugins.py list   PLUGINS_DIR                     one JSON line: every plugin found and its manifest
  plugins.py import SOURCE PLUGINS_DIR              SOURCE: a .zip / .tar(.gz/.xz/.bz2/.zst) / a folder.
                                                    Every plugin inside (a folder with manifest.json) is copied
                                                    in; a plugin already there is replaced (its settings kept)
  plugins.py export PLUGIN_FOLDER DEST              DEST ending .zip: a zip, else a .tar.gz. Without settings.json

A plugin is a folder with:
  manifest.json     { "name", "description", "version", "author", "options": [ ... ] }   (all optional; the id is the folder name)
  BarWidget.qml     an item on a panel          (at least one of the two.
  DesktopWidget.qml a widget on the desktop     the names are fixed: nothing is declared in the manifest)
  preview.png, README.md, settings.json (your own settings, never exported)
"""
import json
import os
import re
import shutil
import sys
import tarfile
import tempfile
import zipfile


def out(obj):
    print(json.dumps(obj), flush=True)


def read_manifest(d):
    with open(os.path.join(d, "manifest.json"), encoding="utf-8") as f:
        return json.load(f)


def safe_id(s):
    s = re.sub(r"[^A-Za-z0-9._-]+", "-", str(s or "")).strip("-.")
    return s or "plugin"


FOREIGN = re.compile(r"^\s*import\s+qs\.(Commons|Widgets|Services|Modules|Helpers)\b", re.M)


def uses_other_shell(d):
    """A plugin written for Noctalia (its qs.Commons / qs.Widgets modules), which Arqen does not carry."""
    for cur, _dirs, files in os.walk(d):
        for f in files:
            if f.endswith(".qml"):
                try:
                    with open(os.path.join(cur, f), encoding="utf-8", errors="replace") as fh:
                        if FOREIGN.search(fh.read()):
                            return True
                except OSError:
                    pass
    return False


PARTS = {"barWidget": "BarWidget.qml", "desktopWidget": "DesktopWidget.qml"}
OPTION_TYPES = {"toggle", "slider", "choice", "text", "color", "button", "section", "info"}
NEEDS_KEY = {"toggle", "slider", "choice", "text", "color"}
API_LINE = re.compile(r"^\s*property\s+var\s+pluginApi\b", re.M)


def check_options(opts):
    """Mistakes in the manifest's options, in plain words (the plugin still works; the settings form skips them)."""
    if not isinstance(opts, list):
        return ['"options" must be a list: [ { ... }, { ... } ]']
    w, keys = [], set()
    for i, o in enumerate(opts, 1):
        if not isinstance(o, dict):
            w.append("option %d is not an { ... } object" % i); continue
        t = o.get("type")
        n = "option %d (%s)" % (i, o.get("key") or o.get("label") or t)
        if t not in OPTION_TYPES:
            w.append('%s: type "%s" is not one of %s' % (n, t, ", ".join(sorted(OPTION_TYPES)))); continue
        if t in NEEDS_KEY:
            k = o.get("key")
            if not k or not isinstance(k, str):
                w.append('%s needs a "key"' % n)
            elif k in keys:
                w.append('%s: the key "%s" is used twice' % (n, k))
            else:
                keys.add(k)
        if t == "slider" and not all(isinstance(o.get(x), (int, float)) for x in ("min", "max")):
            w.append('%s: a slider needs numbers "min" and "max"' % n)
        if t == "slider" and isinstance(o.get("min"), (int, float)) and isinstance(o.get("max"), (int, float)) and o["min"] >= o["max"]:
            w.append('%s: "min" must be below "max"' % n)
        if t == "choice" and not (isinstance(o.get("choices"), list) and o.get("choices")):
            w.append('%s: a choice needs a list "choices": ["a", "b"]' % n)
        if t == "button" and not o.get("run"):
            w.append('%s: a button needs "run"' % n)
    return w


def cmd_list(pdir):
    os.makedirs(pdir, exist_ok=True)
    found = []
    for name in sorted(os.listdir(pdir)):
        d = os.path.join(pdir, name)
        if not os.path.isdir(d) or name.startswith("."):
            continue
        item = {"folder": name, "dir": d, "manifest": None, "error": "", "warnings": [], "parts": {}}
        if not os.path.isfile(os.path.join(d, "manifest.json")):
            item["error"] = "no manifest.json"
        else:
            try:
                m = read_manifest(d)
                if not isinstance(m, dict):
                    raise ValueError("it must be { ... }")
                m["id"] = name                                    # the folder name is the id: nothing to get wrong
                item["manifest"] = m
                # the two parts: BarWidget.qml and DesktopWidget.qml (an old manifest may name other files)
                eps = m.get("entryPoints") if isinstance(m.get("entryPoints"), dict) else {}
                for key, fname in PARTS.items():
                    f = eps.get(key) if isinstance(eps.get(key), str) else fname
                    if os.path.isfile(os.path.join(d, f)):
                        item["parts"][key] = f
                old = [k for k in eps if k not in PARTS]
                if not item["parts"]:
                    item["error"] = "needs BarWidget.qml and/or DesktopWidget.qml in its folder"
                elif uses_other_shell(d):
                    item["error"] = "made for another shell (it needs modules Arqen does not have)"
                else:
                    for f in item["parts"].values():
                        with open(os.path.join(d, f), encoding="utf-8", errors="replace") as fh:
                            if not API_LINE.search(fh.read()):
                                item["error"] = "%s needs the line:  property var pluginApi: null" % f
                                break
                if old:
                    item["warnings"].append("%s: Arqen plugins only have a panel widget and a desktop widget, so this is ignored" % ", ".join(old))
                if "options" in m:
                    item["warnings"] += check_options(m["options"])
            except Exception as e:
                item["error"] = "manifest.json: %s" % e
        item["preview"] = os.path.join(d, "preview.png") if os.path.isfile(os.path.join(d, "preview.png")) else ""
        item["hasSettings"] = os.path.isfile(os.path.join(d, "settings.json"))
        found.append(item)
    out({"plugins": found})


def find_plugins(root, depth=4):
    res = []
    for cur, dirs, files in os.walk(root):
        if cur[len(root):].count(os.sep) > depth:
            dirs[:] = []
            continue
        if "manifest.json" in files:
            res.append(cur)
            dirs[:] = []                       # a plugin's own folders are not more plugins
        dirs[:] = [x for x in dirs if not x.startswith(".") and x not in ("node_modules", "__MACOSX")]
    return res


def within(base, target):
    base = os.path.realpath(base)
    return os.path.realpath(target).startswith(base + os.sep) or os.path.realpath(target) == base


def extract(src, dest):
    low = src.lower()
    if zipfile.is_zipfile(src):
        with zipfile.ZipFile(src) as z:
            for m in z.infolist():
                if not within(dest, os.path.join(dest, m.filename)):
                    raise ValueError("unsafe path in the archive: " + m.filename)
            z.extractall(dest)
        return
    if low.endswith(".zst") or low.endswith(".tzst"):
        import subprocess
        r = subprocess.run(["tar", "--zstd", "-xf", src, "-C", dest], capture_output=True, text=True)
        if r.returncode != 0:
            raise ValueError(r.stderr.strip() or "could not unpack")
        return
    with tarfile.open(src) as t:
        for m in t.getmembers():
            if not within(dest, os.path.join(dest, m.name)) or m.issym() or m.islnk():
                if m.issym() or m.islnk():
                    continue
                raise ValueError("unsafe path in the archive: " + m.name)
        members = [m for m in t.getmembers() if not (m.issym() or m.islnk() or m.isdev())]
        try:
            t.extractall(dest, members=members, filter="data")      # Python 3.12+: the safe way
        except TypeError:
            t.extractall(dest, members=members)


def cmd_import(src, pdir):
    os.makedirs(pdir, exist_ok=True)
    src = os.path.expanduser(src)
    if not os.path.exists(src):
        out({"error": "not found: " + src}); return
    tmp = tempfile.mkdtemp(prefix="arqen-plugin-")
    imported, errors = [], []
    try:
        if os.path.isdir(src):
            roots = find_plugins(src)
        else:
            try:
                extract(src, tmp)
            except Exception as e:
                out({"error": "could not unpack: %s" % e}); return
            roots = find_plugins(tmp)
        if not roots:
            out({"error": "no plugin found (a plugin is a folder with a manifest.json)"}); return
        for r in roots:
            try:
                m = read_manifest(r)
            except Exception as e:
                errors.append("%s: %s" % (os.path.basename(r), e)); continue
            pid = safe_id(m.get("id") or os.path.basename(r))
            target = os.path.join(pdir, pid)
            keep = None
            if os.path.isfile(os.path.join(target, "settings.json")):
                with open(os.path.join(target, "settings.json"), "rb") as f:
                    keep = f.read()
            if os.path.realpath(r) == os.path.realpath(target):
                imported.append(pid); continue
            if os.path.exists(target):
                shutil.rmtree(target)
            shutil.copytree(r, target, symlinks=False, ignore=shutil.ignore_patterns(".git", "__MACOSX", "*.pyc"))
            if keep is not None:
                with open(os.path.join(target, "settings.json"), "wb") as f:
                    f.write(keep)
            imported.append(pid)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    out({"imported": imported, "errors": errors})


def cmd_export(folder, dest):
    folder = os.path.abspath(os.path.expanduser(folder))
    dest = os.path.expanduser(dest)
    if not os.path.isfile(os.path.join(folder, "manifest.json")):
        out({"error": "not a plugin (no manifest.json)"}); return
    try:
        pid = safe_id(read_manifest(folder).get("id") or os.path.basename(folder))
    except Exception:
        pid = os.path.basename(folder)
    skip = {"settings.json", ".git", "__pycache__"}
    os.makedirs(os.path.dirname(os.path.abspath(dest)) or ".", exist_ok=True)
    if dest.lower().endswith(".zip"):
        with zipfile.ZipFile(dest, "w", zipfile.ZIP_DEFLATED) as z:
            for cur, dirs, files in os.walk(folder):
                dirs[:] = [d for d in dirs if d not in skip]
                for f in files:
                    if f in skip:
                        continue
                    p = os.path.join(cur, f)
                    z.write(p, os.path.join(pid, os.path.relpath(p, folder)))
    else:
        if not re.search(r"\.(tar\.gz|tgz)$", dest.lower()):
            dest += ".tar.gz"
        with tarfile.open(dest, "w:gz") as t:
            t.add(folder, arcname=pid, filter=lambda ti: None if os.path.basename(ti.name) in skip else ti)
    out({"exported": dest})


if __name__ == "__main__":
    a = sys.argv[1:]
    try:
        if a[:1] == ["list"]:
            cmd_list(a[1])
        elif a[:1] == ["import"]:
            cmd_import(a[1], a[2])
        elif a[:1] == ["export"]:
            cmd_export(a[1], a[2])
        else:
            print(__doc__)
    except Exception as e:
        out({"error": str(e)})
