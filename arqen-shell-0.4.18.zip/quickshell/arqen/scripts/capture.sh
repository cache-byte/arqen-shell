#!/bin/sh
# Screenshots and screen recordings.
#   capture.sh shot   TARGET            picture to $ARQEN_SHOT_DIR (also on the clipboard)
#   capture.sh record TARGET [AUDIO]    video to $ARQEN_REC_DIR, until wf-recorder is stopped
# (the folders chosen in Settings > Desktop; by default ~/Pictures/Screenshots and ~/Videos/Screenrecordings)
# ARQEN_ASK=1: the shell asks what to do with it first (Settings > Desktop > After a screenshot): the file
# is written hidden (".Screenshot_....png") and "CAPTURED shot|rec PATH" is printed for the shell, which
# saves (unhides), copies, edits, renames or deletes it.
#   capture.sh freeze OUTPUT FILE       the screen as it is right now, for the capture screen
#   capture.sh crop FILE WxH+X+Y        a part of that frozen picture becomes the screenshot
# TARGET: "geo:X,Y WxH" (chosen in Arqen's capture screen), "output:NAME", or, to choose here,
#         screen | window | region.   AUDIO: none (default) | system | mic
what="$1"; target="$2"; audio="${3:-none}"
SHOTS="${ARQEN_SHOT_DIR:-$HOME/Pictures/Screenshots}"
RECS="${ARQEN_REC_DIR:-$HOME/Videos/Screenrecordings}"
# the folder's name for messages: ~/Pictures/Screenshots -> "Pictures/Screenshots"
nice() { case "$1" in "$HOME"/*) echo "${1#"$HOME"/}" ;; *) echo "$1" ;; esac; }

# a notification (notify-send if it is there, else straight over D-Bus)
notify() {   # icon title body [timeout ms]
  if command -v notify-send >/dev/null 2>&1; then
    notify-send -a Arqen -i "$1" -t "${4:-5000}" "$2" "$3" 2>/dev/null
  else
    gdbus call --session --dest org.freedesktop.Notifications --object-path /org/freedesktop/Notifications \
      --method org.freedesktop.Notifications.Notify Arqen 0 "$1" "$2" "$3" '[]' '{}' "${4:-5000}" >/dev/null 2>&1
  fi
}
ask="${ARQEN_ASK:-0}"
hide() { [ "$ask" = 1 ] && echo "." || echo ""; }
shotfile() { mkdir -p "$SHOTS"; echo "$SHOTS/$(hide)Screenshot_$(date +%F_%H-%M-%S).png"; }
# open the folder a file is in, with the file selected when the file manager can do that
showfile() {
  gdbus call --session --dest org.freedesktop.FileManager1 --object-path /org/freedesktop/FileManager1 \
    --method org.freedesktop.FileManager1.ShowItems "['file://$1']" "" >/dev/null 2>&1 \
    || sh "$(dirname "$0")/open-folder.sh" "$(dirname "$1")" >/dev/null 2>&1 \
    || gio open "$(dirname "$1")" >/dev/null 2>&1
}
# a notification that shows FILE in its folder when clicked (waits in the background for the click)
notify_file() {   # icon title body file [timeout ms]
  if command -v notify-send >/dev/null 2>&1; then
    (
      # a picture is sent along, so the notification shows it (like a phone's "Screenshot saved")
      case "$4" in
        *.png|*.jpg) act="$(timeout 3600 notify-send -a Arqen -i "$1" -t "${5:-6000}" -h "string:image-path:$4" -A "default=Show in folder" --wait "$2" "$3" 2>/dev/null)" ;;
        *)           act="$(timeout 3600 notify-send -a Arqen -i "$1" -t "${5:-6000}" -A "default=Show in folder" --wait "$2" "$3" 2>/dev/null)" ;;
      esac
      [ "$act" = default ] && showfile "$4"
    ) </dev/null >/dev/null 2>&1 &
  else
    notify "$1" "$2" "$3" "$5"
  fi
}
saved() {    # a finished screenshot: put it on the clipboard, tell (or hand it to the shell to ask)
  # on the clipboard at once (Settings > Desktop > Copy screenshots to the clipboard)
  [ "${ARQEN_CLIP:-1}" = 1 ] && wl-copy --type image/png < "$1" 2>/dev/null
  if [ "$ask" = 1 ]; then echo "CAPTURED shot $1"; return; fi
  if [ "${ARQEN_CLIP:-1}" = 1 ]; then clip=" Copied, ready to paste."; else clip=""; fi
  notify_file "$1" "Screenshot taken" "$(basename "$1") in $(nice "$SHOTS").$clip Click to show it" "$1"
}

case "$what" in
  freeze)   # capture.sh freeze OUTPUT FILE
    out="$3"
    rm -f "$out"
    # -t png: the temporary name has no .png ending, and newer grim guesses the format from it
    grim -t png ${target:+-o "$target"} "$out.tmp" 2>/dev/null || grim -t png "$out.tmp" || exit 1
    mv -f "$out.tmp" "$out"
    exit 0 ;;
  crop)
    f="$(shotfile)"
    if command -v magick >/dev/null 2>&1; then magick "$target" -crop "$3" +repage "$f"
    elif command -v convert >/dev/null 2>&1; then convert "$target" -crop "$3" +repage "$f"
    else cp "$target" "$f"; fi
    rm -f "$target"
    [ -s "$f" ] && saved "$f"
    exit 0 ;;
esac
sleep 0.25                      # let the capture screen / control centre get out of the way

focused_output() { hyprctl -j monitors 2>/dev/null | python3 -c 'import json,sys; m=[x for x in json.load(sys.stdin) if x.get("focused")]; print(m[0]["name"] if m else "")'; }
windows() {
  python3 - <<'PY'
import json, subprocess
mons = json.loads(subprocess.run(["hyprctl", "-j", "monitors"], capture_output=True, text=True).stdout or "[]")
shown = {m["activeWorkspace"]["id"] for m in mons} | {m.get("specialWorkspace", {}).get("id", 0) for m in mons}
for c in json.loads(subprocess.run(["hyprctl", "-j", "clients"], capture_output=True, text=True).stdout or "[]"):
    if c.get("mapped", True) and not c.get("hidden") and c["workspace"]["id"] in shown:
        print("%d,%d %dx%d" % (c["at"][0], c["at"][1], c["size"][0], c["size"][1]))
PY
}

case "$target" in
  geo:*)    set -- -g "${target#geo:}"; label="selection" ;;
  output:*) set -- -o "${target#output:}"; label="screen" ;;
  region)   geo="$(slurp)" || exit 0; set -- -g "$geo"; label="region" ;;
  window)   geo="$(windows | slurp -r)" || exit 0; set -- -g "$geo"; label="window" ;;
  *)        out="$(focused_output)"; if [ -n "$out" ]; then set -- -o "$out"; else set --; fi; label="screen" ;;
esac

stamp="$(date +%F_%H-%M-%S)"
if [ "$what" = record ]; then
  mkdir -p "$RECS"
  f="$RECS/$(hide)Recording_$stamp.mp4"
  case "$audio" in
    system) dev="$(pactl get-default-sink 2>/dev/null).monitor"; set -- "$@" --audio="$dev" ;;
    mic)    dev="$(pactl get-default-source 2>/dev/null)"; set -- "$@" --audio="$dev" ;;
  esac
  notify media-record "Recording started" "Stop it from the panel, the control centre or the Print key" 2500
  wf-recorder "$@" -f "$f" >/dev/null 2>&1
  if [ -s "$f" ] && [ "$ask" = 1 ]; then echo "CAPTURED rec $f"
  elif [ -s "$f" ]; then notify_file video-x-generic "Recording saved" "$(basename "$f") in $(nice "$RECS"). Click to show it" "$f"
  else notify dialog-error "Recording failed" "Nothing was saved"; fi
else
  f="$(shotfile)"
  grim "$@" "$f" && saved "$f"
fi
