import QtQuick
import qs.config
import qs.components
import qs.services

// A desktop widget: the shell draws the card; this is what is on it. Sizes are multiplied by widgetScale.
Item {
    id: root
    property var pluginApi: null        // keep this line: the shell fills it in
    property var widgetData: ({})       // given by the shell: this widget's look
    property real widgetScale: 1        // given by the shell: Small 0.8, Medium 1, Large 1.3
    implicitWidth: 200 * widgetScale
    implicitHeight: 90 * widgetScale

    DText {
        anchors.centerIn: parent
        width: parent.width - 24
        horizontalAlignment: Text.AlignHCenter
        wrapMode: Text.Wrap
        text: pluginApi.setting("message", "Hello!")
        font.pixelSize: 22 * root.widgetScale
        color: Widgets.fg(root.widgetData.look)
    }
}
