import QtQuick
import Quickshell
import qs.config        // Theme: colours, font
import qs.components    // Icon, HoverTip ...

// A panel button. The shell gives it `pluginApi` before it starts, so pluginApi.setting() can be used
// anywhere, and it follows the settings as soon as they change in Settings > Plugins.
Item {
    id: root
    property var pluginApi: null        // keep this line: the shell fills it in
    property real barSize: 28           // given by the shell: how big panel items are
    implicitWidth: barSize + 8
    implicitHeight: barSize + 8

    Rectangle {
        anchors.centerIn: parent
        width: root.barSize; height: width; radius: width / 2
        color: mouse.containsMouse ? Theme.hover : "transparent"
        Icon {
            anchors.centerIn: parent
            name: pluginApi.setting("icon", "waving_hand")
            size: pluginApi.setting("size", 18)
            color: pluginApi.setting("tint", "#FFFFFF")
        }
    }
    MouseArea {
        id: mouse
        anchors.fill: parent
        hoverEnabled: true
        onClicked: {
            const urgency = pluginApi.setting("loud", false) ? "critical" : "normal"
            // the time is in the text: the shell shows two identical notifications from one app (within 90 s) as one,
            // so without it a second click would seem to do nothing
            Quickshell.execDetached(["notify-send", "-a", "Hello plugin", "-u", urgency, pluginApi.setting("message", "Hello!"), Qt.formatTime(new Date(), "HH:mm:ss")])
        }
    }
    HoverTip { hovered: mouse.containsMouse; text: "Say hello" }
}
