# Writing an Arqen plugin

A plugin adds a **widget**: one on a panel (the bar), one on the desktop, or both. That is all a plugin
can be, so there is very little to get wrong. It is a folder with a `manifest.json` and one or two QML
files (QML is the language the whole shell is written in). Nothing to build: save a file and the shell
loads it again by itself.

**The whole idea:**

| File | What it is | Needed |
|---|---|---|
| `BarWidget.qml` | an item on a panel | one of these two, or both |
| `DesktopWidget.qml` | a widget on the desktop | |
| `manifest.json` | its name and its settings | yes |

The file names are fixed, so nothing has to be declared anywhere. The folder name is the plugin's id.
There is a ready example: **Settings > Plugins > Hello** (folder `~/.config/quickshell/widgets/hello`).
Copy it and change it.

---

## 1. A plugin in two files

```sh
mkdir -p ~/.config/quickshell/widgets/greeter && cd ~/.config/quickshell/widgets/greeter
```

**`manifest.json`**

```json
{
  "name": "Greeter",
  "description": "Says hello",
  "options": [
    { "key": "message", "type": "text", "label": "What it says", "default": "Hello!" }
  ]
}
```

(`version` and `author` can be added; every line is optional except that the file exists and is valid JSON.)

**`BarWidget.qml`**

```qml
import QtQuick
import Quickshell
import qs.config        // Theme: colours, font
import qs.components    // Icon, DText, HoverTip, ArqButton ...

Item {
    id: root
    property var pluginApi: null     // keep this line: the shell fills it in, before the widget starts
    property real barSize: 28        // the shell fills this in too: how big panel items are
    implicitWidth: barSize + 8
    implicitHeight: barSize + 8

    Icon { anchors.centerIn: parent; name: "waving_hand"; size: 18; color: Theme.text }
    MouseArea {
        id: mouse
        anchors.fill: parent
        hoverEnabled: true
        onClicked: Quickshell.execDetached(["notify-send", pluginApi.setting("message", "Hello!")])
    }
    HoverTip { hovered: mouse.containsMouse; text: "Say hello" }
}
```

Open **Settings > Plugins** (press **Reload** if it is not there), open **Greeter**, turn it on and press
**Add to the panel**. Click the icon: a notification appears. Change the message in its settings and click
again: it follows at once. Edit the QML, save: the plugin reloads.

A **desktop widget** is the same idea in `DesktopWidget.qml`: the shell draws the card and lets you move
it, you draw what is on it. Say how big it is with `implicitWidth` / `implicitHeight`, multiply sizes by
`widgetScale` (Small 0.8, Medium 1, Large 1.3), and take the text colour from `Widgets.fg(widgetData.look)`
(`import qs.services`). The Hello example has one.

**The rules, all of them:**
1. The folder has `manifest.json` and `BarWidget.qml` and/or `DesktopWidget.qml`.
2. Each widget file has the line `property var pluginApi: null`.
3. Colours and fonts come from `Theme`, so dark / light mode and the accent colour follow by themselves.

If one is broken, the plugin's row in **Settings > Plugins** says which in plain words (red for a plugin that
can't load, orange for a mistake in the settings list). `qs log -c arqen` has the QML details.

---

## 2. Settings: the `options` list

Each option is one line in `manifest.json`. The shell shows them in **Settings > Plugins** (open the
plugin's row), saves every change as it is made, and gives each one a reset arrow back to its `default`.

| `type`    | What you see           | Other fields                                         | The value is |
|-----------|------------------------|------------------------------------------------------|--------------|
| `toggle`  | an on / off switch     |                                                      | `true` / `false` |
| `slider`  | a slider               | `min`, `max`, `step`, `suffix` (e.g. `" px"`)        | a number |
| `choice`  | buttons to pick one    | `choices`: `["a", "b", "c"]`                         | the text picked |
| `text`    | a text box             | `placeholder`                                        | text |
| `color`   | colour swatches        |                                                      | `"#RRGGBB"` |
| `button`  | a button               | `run`: a command (`["notify-send", "Hi"]` or `"date > /tmp/x"`), `buttonText` | (nothing is saved) |
| `section` | a small heading        | `label`                                              | |
| `info`    | a line of grey text    | `text`                                               | |

Every option can have `key` (its name; needed for toggle, slider, choice, text and color), `label`,
`description` (a line under the label), `icon` (a [Material Symbols](https://fonts.google.com/icons) name)
and `default`.

```json
"options": [
  { "type": "section", "label": "Look" },
  { "key": "size",  "type": "slider", "label": "Size", "min": 12, "max": 32, "step": 1, "default": 18, "suffix": " px" },
  { "key": "loud",  "type": "toggle", "label": "Warning style", "default": false },
  { "key": "icon",  "type": "choice", "label": "Icon", "choices": ["star", "bolt"], "default": "star" },
  { "type": "button", "label": "Test it", "buttonText": "Run", "run": ["notify-send", "Test"] }
]
```

**Using a setting in your QML:**

```qml
pluginApi.setting("size", 18)         // read it (the 18 is used if it was never set)
pluginApi.setSetting("size", 20)      // change it and keep it (written to settings.json in the plugin's folder)
```

Anything that reads a setting this way updates by itself when it changes. If the manifest has a mistake
(a slider without `min` / `max`, a choice without `choices`, a key used twice) Settings > Plugins lists it
in orange under the plugin's name.

---

## 3. `pluginApi`

| | |
|---|---|
| `setting(key, fallback)`, `setSetting(key, value)` | read / change a setting (section 2) |
| `pluginId`, `pluginDir` | its id (the folder name) and its folder |

The widget also gets: **panel widget** `barSize` (how big), `screen`, `vertical` (true on a side panel);
**desktop widget** `widgetData`, `widgetScale`. Declare the ones you use as properties.

---

## 4. Buttons, sliders and the rest: the shell's own pieces

Use these and the plugin looks like the shell (dark / light mode, accent colour and font follow by themselves).

```qml
import qs.config        // Theme.text, Theme.subtext, Theme.primary (accent), Theme.onPrimary,
                        // Theme.tile (soft background), Theme.hover, Theme.radius, Theme.font, Theme.dark
import qs.components
```

| Piece | Use | What to set |
|---|---|---|
| `ArqButton` | a button | `text`, `icon`, `size: "S" \| "M" \| "L"`, `primary: true` (accent colour); `onClicked` |
| `ArqSlider` | a slider | `from`, `to`, `value`, `stepSize`; `onMoved: v => ...`. `pill: true` = the big kind, `vertical: true` stands it up |
| `ArqToggle` | an on / off switch | `checked`; `onToggled: v => ...` |
| `ArqField` | a text box | `text`, `placeholder`, `iconName`; `onEdited`, `onAccepted` |
| `DText` | text (the shell's font) | like a normal `Text` |
| `Icon` | an icon | `name` (Material Symbols name), `size`, `color` |
| `HoverTip` | a name tip on hover | `hovered`, `text` |
| `ArqScrollBar` | a scroll bar for a `Flickable` / `ListView` | `flick: yourFlickable` |

```qml
Column {
    spacing: 10
    ArqButton { text: "Do it"; icon: "bolt"; primary: true; onClicked: console.log("clicked") }
    ArqSlider {
        width: 220; from: 0; to: 100; stepSize: 5
        value: pluginApi.setting("level", 50)
        onMoved: v => pluginApi.setSetting("level", v)
    }
    ArqToggle { checked: pluginApi.setting("on", true); onToggled: v => pluginApi.setSetting("on", v) }
}
```

Services: `import qs.services` gives `Media` (what is playing), `Audio` (volume), `Power` (battery),
`Notifs`, `Widgets`, `Gadgets` (Bluetooth devices, controllers).

### Quickshell.Widgets

Quickshell's own widget helpers, `import Quickshell.Widgets`
([docs](https://quickshell.org/docs/v0.3.0/types/Quickshell.Widgets/)). Handy ones:

| Type | What it does |
|---|---|
| `IconImage` | draws an icon from the system theme: `IconImage { source: Quickshell.iconPath("firefox"); implicitSize: 32 }` |
| `ClippingRectangle` | a rectangle that cuts its content to its rounded corners (a picture with rounded corners) |
| `WrapperRectangle` | a rectangle (colour, radius, border) that sizes itself around ONE child, with `margin` |
| `WrapperItem` | the same without a background: just padding around one child |
| `WrapperMouseArea` | a click area that sizes itself around one child: `WrapperMouseArea { onClicked: ...; Icon { ... } }` |

```qml
import Quickshell
import Quickshell.Widgets
import qs.config
import qs.components

// a rounded label that fits its text, clickable
WrapperMouseArea {
    onClicked: console.log("hi")
    WrapperRectangle {
        color: Theme.tile; radius: 14; margin: 8
        DText { text: "Hello" }
    }
}
```

---

## 5. Doing things

Anything Quickshell can do (see quickshell.org):

```qml
import Quickshell.Io

// run a program and read what it prints
Process {
    id: proc
    command: ["sh", "-c", "date +%H:%M"]
    stdout: StdioCollector { onStreamFinished: console.log(text) }
}
// proc.running = true   runs it

// a command you can bind to a key:  qs -c arqen ipc call plugin:greeter hello
IpcHandler {
    target: "plugin:greeter"
    function hello(): void { Quickshell.execDetached(["notify-send", "Hello"]) }
}
```

Also available: `FileView` (read / write files), `Quickshell.Services.Mpris`, `Pipewire`, `UPower`,
`Bluetooth`, `Quickshell.Hyprland`, `SystemTray`. A timer or a program that runs all the time can live inside
your widget file (`Timer`, `Process`).

**Notifications:** the shell shows two identical notifications from the same app (same title and text, within
90 seconds) as one, so a plugin that sends the same text on every click looks stuck. Put something that
changes in the text, like the time (the Hello example does).

## 6. Share it

**Settings > Plugins**, open the plugin, **Export**: you get a `.zip` (your own `settings.json` is left
out). Others use **Import a plugin**. Add a `preview.png` to the folder for its picture in Settings, and a
`README.md` to explain it.

## Problems

- **Not in the list:** `manifest.json` must be valid JSON (no comma after the last item) and sit in the
  plugin's own folder. Press **Reload**.
- **"needs BarWidget.qml and/or DesktopWidget.qml":** the folder has neither file, or they are spelled
  differently (the names are exactly `BarWidget.qml` and `DesktopWidget.qml`).
- **"needs the line: property var pluginApi: null":** add that line at the top of the widget's root item.
- **"made for another shell":** plugins made for other shells (such as Noctalia's) don't work here.
- **"could not load":** a mistake in the QML. `qs log -c arqen` shows the file and line.
- **A setting does nothing:** check the `key` is spelled the same in the manifest and in
  `pluginApi.setting("key", ...)`.
