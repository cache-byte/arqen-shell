pragma Singleton
import Quickshell
import QtQuick
import qs.config

// The desktop's widgets: what kinds there are, their sizes (in grid cells), their looks and their own
// options. Each widget on the desktop is saved in Config.c.desktopWidgets as
//   { id, type, size: "S" | "M" | "L", look: "Solid" | "Glass" | "Accent" | "Clear", ...its options }
// Shared by the desktop (modules/Desktop.qml) and Settings > Desktop (their live previews).
Singleton {
    id: root

    // the shell's own widgets, then the ones plugins bring (their DesktopWidget.qml): "plugin:<id>"
    readonly property var types: {
        const t = Object.assign({}, baseTypes)
        for (const p of Plugins.desktopTypes) {
            const key = "plugin:" + p.id
            const m = measured[key] ?? [240, 140]
            const c = sz => [Math.max(1, Math.ceil((m[0] * scaleOf(sz) + 12) / cellW)), Math.max(1, Math.ceil((m[1] * scaleOf(sz) + 12) / cellH))]
            t[key] = { name: p.name, icon: "extension", sub: p.manifest.description || "From a plugin", plugin: p.id,
                       sizes: { S: c("S"), M: c("M"), L: c("L") }, options: [] }
        }
        return t
    }
    readonly property var order: ["clock", "media", "calendar", "note"].concat(Plugins.desktopTypes.map(p => "plugin:" + p.id))
    // the desktop's grid (modules/Desktop.qml)
    readonly property int cellW: Config.c.desktopIconSize + 46
    readonly property int cellH: Config.c.desktopIconSize + 50
    // a plugin widget's size by its own measure (at Medium), reported once it has loaded
    property var measured: ({})
    function measure(type, w, h) {
        w = Math.round(w); h = Math.round(h)
        if (!type || w <= 0 || h <= 0) return
        const old = measured[type]
        if (old && Math.abs(old[0] - w) < 4 && Math.abs(old[1] - h) < 4) return
        const m = Object.assign({}, measured); m[type] = [w, h]; measured = m
    }
    function scaleOf(size) { return size === "S" ? 0.8 : size === "L" ? 1.3 : 1 }
    // open a widget's settings (Settings > Desktop)
    function edit(id) { Ui.editWidget = id || ""; Ui.openSettings("desktop") }
    // Options: { key, name, icon, def } and one of  choices: [..]  |  toggle: true  |  slider: [from, to, step, suffix]
    //  |  color: true (swatches and a hex box)  |  text: true (a line of text);  showIf: [key, value] (value starting with
    //  "!" = anything but that). { section: "Name" } is a heading. Every widget also gets `commonOptions` below.
    readonly property var baseTypes: ({
        clock: {
            name: "Clock", icon: "schedule", sub: "The time and the date, digital, stacked or analogue",
            sizes: { S: [2, 1], M: [3, 2], L: [4, 2] },
            options: [
                { section: "Clock" },
                { key: "face", name: "Style", icon: "style", choices: ["Digital", "Stacked", "Analog"], def: "Digital" },
                { key: "hours", name: "Hours", icon: "nest_clock_farsight_digital", choices: ["Auto", "12-hour", "24-hour"], def: "Auto" },
                { key: "ampm", name: "AM / PM", icon: "contrast", toggle: true, def: true, showIf: ["hours", "!24-hour"] },
                { key: "seconds", name: "Seconds", icon: "timer", toggle: true, def: false },
                { key: "weight", name: "Digits", icon: "format_bold", choices: ["Light", "Regular", "Bold"], def: "Regular", showIf: ["face", "!Analog"] },
                { key: "align", name: "Side", icon: "format_align_center", choices: ["Left", "Centre", "Right"], def: "Centre", showIf: ["face", "Digital"] },
                { key: "marks", name: "Marks on the face", icon: "more_time", choices: ["None", "Ticks", "Numbers"], def: "Ticks", showIf: ["face", "Analog"] },
                { key: "timeColor", name: "Time colour", icon: "palette", choices: ["Accent", "Text", "Custom"], def: "Accent" },
                { key: "timeCustom", name: "Custom time colour", icon: "colorize", color: true, def: "#8FB4FF", showIf: ["timeColor", "Custom"] },
                { section: "Date" },
                { key: "date", name: "Show the date", icon: "calendar_today", toggle: true, def: true },
                { key: "dateFormat", name: "Date format", icon: "edit_calendar", choices: ["Long", "Short", "Day only", "Numeric"], def: "Long", showIf: ["date", true] }
            ]
        },
        media: {
            name: "Media", icon: "music_note", sub: "What is playing, with play / pause",
            sizes: { S: [3, 1], M: [4, 2], L: [5, 2] },
            options: [
                { section: "Media" },
                { key: "art", name: "Cover picture", icon: "image", toggle: true, def: true },
                { key: "artShape", name: "Cover shape", icon: "category", choices: ["Rounded", "Circle", "Square"], def: "Rounded", showIf: ["art", true] },
                { key: "blur", name: "Cover behind, blurred", icon: "blur_on", toggle: true, def: true },
                { key: "artist", name: "Artist", icon: "person", toggle: true, def: true },
                { key: "bars", name: "Little bars by the app name", icon: "equalizer", toggle: true, def: true },
                { key: "progress", name: "Progress line", icon: "linear_scale", toggle: true, def: true },
                { key: "controls", name: "Previous / play / next", icon: "play_circle", toggle: true, def: true },
                { section: "Moves to the beat" },
                { key: "viz", name: "Visualizer", icon: "graphic_eq", choices: ["Off", "Bars", "Mirror", "Dots", "Wave", "Blob"], def: "Bars" },
                { key: "vizPos", name: "Where", icon: "vertical_align_bottom", choices: ["Bottom", "Behind"], def: "Bottom", showIf: ["viz", "!Off"] },
                { key: "vizColor", name: "Colour", icon: "palette", choices: ["Accent", "Text", "Rainbow"], def: "Accent", showIf: ["viz", "!Off"] },
                { key: "vizBars", name: "How many", icon: "view_week", slider: [6, 32, 1, ""], def: 14, showIf: ["viz", "!Off"] },
                { key: "vizHeight", name: "Height", icon: "height", slider: [10, 100, 5, " %"], def: 45, showIf: ["viz", "!Off"] },
                { key: "pulse", name: "Cover beats with the bass", icon: "album", toggle: true, def: true },
                { key: "glow", name: "Glow round the cover", icon: "flare", toggle: true, def: true },
                { key: "ripple", name: "Rings spread from the cover", icon: "radio_button_checked", toggle: true, def: false },
                { key: "sens", name: "Strength", icon: "speed", slider: [20, 200, 10, " %"], def: 100 }
            ]
        },
        calendar: {
            name: "Calendar", icon: "calendar_month", sub: "A month, with today marked",
            sizes: { S: [2, 2], M: [3, 3], L: [4, 3] },
            options: [
                { section: "Calendar" },
                { key: "weekStart", name: "Week starts on", icon: "view_week", choices: ["Monday", "Sunday", "Saturday"], def: "Monday" },
                { key: "weekNumbers", name: "Week numbers", icon: "tag", toggle: true, def: false },
                { key: "today", name: "Today is marked with", icon: "today", choices: ["Circle", "Fill", "Underline"], def: "Underline" },
                { key: "header", name: "Month heading", icon: "title", choices: ["Month and year", "Month", "None"], def: "Month and year" },
                { key: "dim", name: "Fade other months' days", icon: "opacity", toggle: true, def: true },
                { key: "weekend", name: "Weekends in the accent colour", icon: "weekend", toggle: true, def: true },
                { section: "Small size" },
                { key: "compact", name: "Compact view when small", icon: "compress", choices: ["Auto", "Always", "Never"], def: "Auto" },
                { key: "compactText", name: "Compact shows", icon: "pin", choices: ["Numbers", "Words"], def: "Numbers", showIf: ["compact", "!Never"] },
                { key: "compactYear", name: "Show the year", icon: "event", toggle: true, def: true, showIf: ["compact", "!Never"] }
            ]
        },
        note: {
            name: "Note", icon: "sticky_note_2", sub: "A note on your desktop. Click it to write",
            sizes: { S: [2, 1], M: [3, 2], L: [4, 3] },
            options: [
                { section: "Note" },
                { key: "title", name: "Title", icon: "title", text: true, def: "" },
                { key: "mono", name: "Monospace text", icon: "code", toggle: true, def: false },
                { key: "fontSize", name: "Text size", icon: "format_size", slider: [10, 28, 1, " px"], def: 15 }
            ]
        }
    })
    // what every widget has, after its own
    readonly property var commonOptions: [
        { section: "Look" },
        { key: "look", name: "Background", icon: "palette", choices: ["Glass", "Solid", "Accent", "Clear", "Custom"], def: "Solid" },
        { key: "bgColor", name: "Background colour", icon: "format_color_fill", color: true, def: "#2A2A33", showIf: ["look", "Custom"] },
        { key: "opacity", name: "Background opacity", icon: "opacity", slider: [10, 100, 5, " %"], def: 60, showIf: ["look", "!Clear|Solid"] },
        { key: "radius", name: "Corner radius", icon: "rounded_corner", slider: [0, 60, 2, " px"], def: -1 },
        { key: "border", name: "Outline", icon: "border_outer", choices: ["Auto", "On", "Off"], def: "Auto" },
        { key: "borderWidth", name: "Outline thickness", icon: "line_weight", slider: [1, 6, 1, " px"], def: 1, showIf: ["border", "!Off"] },
        { key: "borderColor", name: "Outline colour", icon: "border_color", choices: ["Auto", "Accent", "Text"], def: "Auto", showIf: ["border", "!Off"] },
        { key: "textColor", name: "Text colour", icon: "format_color_text", choices: ["Auto", "Accent", "Custom"], def: "Auto" },
        { key: "textCustom", name: "Custom text colour", icon: "colorize", color: true, def: "#FFFFFF", showIf: ["textColor", "Custom"] },
        { key: "textScale", name: "Text size", icon: "format_size", slider: [70, 160, 5, " %"], def: 100 },
        { section: "Size" },
        { key: "cw", name: "Width", icon: "swap_horiz", slider: [0, 8, 1, " cells"], def: 0, autoZero: true },
        { key: "ch", name: "Height", icon: "swap_vert", slider: [0, 6, 1, " cells"], def: 0, autoZero: true },
        { key: "shadow", name: "Shadow", icon: "shadow", choices: ["None", "Soft", "Strong"], def: "None" }
    ]
    // the options to show for a widget (its own, then the common ones), with `showIf` applied
    function optionsFor(wd) {
        const t = types[wd?.type]
        const c = cfg(wd)
        const own = t ? t.options : []
        return own.concat(commonOptions).filter(o => {
            if (!o.showIf) return true
            const v = c[o.showIf[0]], want = o.showIf[1]
            // "!A|B" = anything but A or B
            return typeof want === "string" && want[0] === "!" ? want.slice(1).split("|").indexOf(String(v)) < 0 : v === want
        })
    }
    readonly property var looks: ["Glass", "Solid", "Accent", "Clear", "Custom"]
    readonly property var sizeNames: ({ S: "Small", M: "Medium", L: "Large" })

    // ---- one widget's settings (with the defaults filled in) ----
    function cfg(wd) {
        const t = types[wd?.type]
        const out = { size: "M", look: "Solid" }
        if (t) for (const o of t.options.concat(commonOptions)) if (o.key) out[o.key] = o.def
        out.size = "M"; out.look = "Solid"
        return Object.assign(out, wd || {})
    }
    function cells(wd) {
        const t = types[wd?.type]
        if (!t) return [1, 1]
        const c = cfg(wd), base = t.sizes[c.size] ?? t.sizes.M
        // a width and / or height of your own (in cells), "Auto" = the Small / Medium / Large preset
        return [c.cw > 0 ? c.cw : base[0], c.ch > 0 ? c.ch : base[1]]
    }
    // outline: thickness and colour
    function borderW(c) { return borderOn(c) ? Math.max(1, c.borderWidth ?? 1) : 0 }
    function borderCol(c) { return c.borderColor === "Accent" ? Theme.primary : c.borderColor === "Text" ? fgOf(c) : Theme.stroke }
    function shadowA(c) { return c.shadow === "Strong" ? 0.55 : c.shadow === "Soft" ? 0.28 : 0 }
    // the card colour for a look
    function bg(look) {
        if (look === "Solid") return Theme.cardSolid
        if (look === "Accent") return Theme.primaryContainer
        if (look === "Clear") return "transparent"
        return Theme.glassBase      // Glass: the shell's glass colour; bgOf sets how see-through it is
    }
    // ---- what a widget draws with: its background, corners, outline and text, from its settings ----
    function validHex(h, d) { return /^#[0-9a-fA-F]{6}$/.test(h || "") ? h : d }
    function bgOf(c) {
        const look = c.look || "Solid"
        if (look === "Clear") return "transparent"
        const base = look === "Custom" ? Qt.color(validHex(c.bgColor, "#2A2A33")) : Qt.color(bg(look))
        // Solid is always fully opaque; Glass is the shell's glass colour with the opacity you pick (see-through, blurred behind)
        const o = look === "Solid" ? 1 : Math.max(0.1, Math.min(1, (c.opacity ?? 60) / 100))
        return Qt.rgba(base.r, base.g, base.b, base.a * o)
    }
    function radiusOf(c) { return c.radius === undefined || c.radius < 0 ? Theme.radius : c.radius }
    function borderOn(c) {
        if (c.border === "On") return true
        if (c.border === "Off") return false
        const l = c.look || "Solid"
        return l === "Glass" || l === "Solid" || l === "Custom"
    }
    // dark text on a light custom background, light on a dark one
    function lum(col) { return 0.299 * col.r + 0.587 * col.g + 0.114 * col.b }
    function fgOf(c) {
        if (c.textColor === "Accent") return Theme.primary
        if (c.textColor === "Custom") return Qt.color(validHex(c.textCustom, "#FFFFFF"))
        if (c.look === "Custom") return lum(Qt.color(validHex(c.bgColor, "#2A2A33"))) > 0.6 ? "#16161A" : "#FFFFFF"
        return fg(c.look || "Solid")
    }
    function subOf(c) {
        if (c.textColor === "Accent" || c.textColor === "Custom" || c.look === "Custom") { const f = fgOf(c); return Qt.rgba(f.r, f.g, f.b, 0.7) }
        return sub(c.look || "Solid")
    }
    function ts(c) { return Math.max(0.5, Math.min(2, (c.textScale ?? 100) / 100)) }
    // a note is being typed in (the desktop takes the keyboard)
    property bool typing: false
    // the pointer is on a note (the desktop accepts the keyboard for the click)
    property bool noteHover: false

    function fg(look) { return look === "Accent" ? Theme.onPrimaryContainer : Theme.text }
    function sub(look) { return look === "Accent" ? Qt.rgba(Theme.onPrimaryContainer.r, Theme.onPrimaryContainer.g, Theme.onPrimaryContainer.b, 0.7) : Theme.subtext }

    // the Status widget is gone: saved ones are taken off the list (once the settings have loaded)
    Timer {
        interval: 3000; running: true
        onTriggered: {
            const l = Config.c.desktopWidgets || []
            if (l.some(w => w.type === "system" || w.type === "screentime")) Config.c.desktopWidgets = l.filter(w => w.type !== "system" && w.type !== "screentime")
        }
    }

    // ---- changing them ----
    function add(type) {
        Config.c.desktopWidgetsOn = true
        Config.c.desktopWidgets = (Config.c.desktopWidgets || []).concat([{ id: "w" + Date.now(), type: type, size: "M", look: "Solid" }])
    }
    function remove(id) {
        Config.c.desktopWidgets = (Config.c.desktopWidgets || []).filter(w => w.id !== id)
        const pos = Object.assign({}, Config.c.desktopPos || {})
        delete pos["widget:" + id]
        Config.c.desktopPos = pos
    }
    function set(id, key, value) {
        Config.c.desktopWidgets = (Config.c.desktopWidgets || []).map(w => {
            if (w.id !== id) return w
            const n = Object.assign({}, w); n[key] = value; return n
        })
    }
    function move(id, d) {
        const l = (Config.c.desktopWidgets || []).slice(), i = l.findIndex(w => w.id === id), j = i + d
        if (i < 0 || j < 0 || j >= l.length) return
        const t = l[i]; l[i] = l[j]; l[j] = t
        Config.c.desktopWidgets = l
    }
}
