pragma Singleton
import Quickshell
import Quickshell.Io
import QtQuick
import qs.config

// Plugins: a folder in ~/.config/quickshell/widgets with a manifest.json and one or both of
//   BarWidget.qml      an item on a panel
//   DesktopWidget.qml  a widget on the desktop
// The manifest's "options" make the plugin's settings page (settings/PluginOptions.qml). Every widget gets a
// `pluginApi` (setting(key, fallback), setSetting(key, value), pluginId, pluginDir) before it starts.
// Plugins use Arqen's own pieces (qs.config: Theme; qs.components: DText, Icon, ArqButton...), so they look
// like the rest of the shell. Settings > Plugins: on / off, settings, import, export. scripts/plugins.py does
// the file work and checks the plugin for mistakes.
Singleton {
    id: root
    function init() {}

    readonly property string dir: (Quickshell.env("XDG_CONFIG_HOME") || (Quickshell.env("HOME") + "/.config")) + "/quickshell/widgets"
    readonly property string script: Quickshell.shellDir + "/scripts/plugins.py"
    // every plugin found: { folder, dir, manifest, parts, error, warnings, preview, id, name }
    property var list: []
    property int revision: 0                  // goes up on Reload: the plugins' files are read again
    property string status: ""                // the last import / export / new: what happened

    readonly property var disabled: Config.c.pluginsDisabled || []
    function isEnabled(id) { return disabled.indexOf(id) < 0 }
    function setEnabled(id, on) {
        const d = disabled.filter(x => x !== id)
        if (!on) d.push(id)
        Config.c.pluginsDisabled = d
    }
    function find(id) { return list.find(p => p.id === id) ?? null }
    function errorOf(id) { return find(id)?.error ?? "" }
    // the plugins that run: on, and readable
    readonly property var running: list.filter(p => p.manifest && p.error === "" && isEnabled(p.id))
    function entryUrl(p, key) {
        const f = p?.parts?.[key]
        return f ? "file://" + p.dir + "/" + f + (revision > 0 ? "?r=" + revision : "") : ""
    }
    function has(p, key) { return !!(p?.parts?.[key]) }

    // ---- what the shell offers from them ----
    // panel items (Config.barElements adds these): "plugin:<id>"
    readonly property var barElements: running.filter(p => has(p, "barWidget"))
        .map(p => ({ id: "plugin:" + p.id, name: p.name, sub: p.manifest.description || "Plugin", icon: "extension", plugin: p.id }))
    onBarElementsChanged: Ui.pluginBarElements = barElements
    readonly property var desktopTypes: running.filter(p => has(p, "desktopWidget"))

    // ---- reading the folder ----
    Process {
        id: lister
        command: ["python3", root.script, "list", root.dir]
        stdout: StdioCollector {
            onStreamFinished: {
                let j = null
                try { j = JSON.parse(text) } catch (e) { return }
                root.list = (j.plugins || []).map(p => Object.assign(p, {
                    id: p.manifest?.id || p.folder,
                    name: p.manifest?.name || p.folder
                }))
            }
        }
    }
    function rescan() { if (!lister.running) lister.running = true; else again.restart() }
    function reload() { revision++; rescan() }
    Timer { id: again; interval: 400; onTriggered: root.rescan() }
    // changes in the folder (a plugin copied in by hand, edited...) are noticed
    Process {
        running: true
        command: ["sh", "-c", 'mkdir -p "$1"; command -v inotifywait >/dev/null || exit 0; exec inotifywait -m -q -e create,delete,moved_to,moved_from,close_write --format x "$1"', "watch", root.dir]
        stdout: SplitParser { onRead: soon.restart() }
    }
    Timer { id: soon; interval: 800; onTriggered: root.rescan() }
    Component.onCompleted: rescan()

    // ---- one pluginApi per running plugin ----
    property var apis: ({})
    function api(id) {
        if (apis[id]) return apis[id]
        const p = find(id)
        if (!p || !p.manifest) return null
        const a = apiC.createObject(root, { pluginId: id, pluginDir: p.dir, manifest: p.manifest })
        const m = Object.assign({}, apis); m[id] = a; apis = m
        return a
    }
    onListChanged: {
        // plugins gone: their api goes; a changed manifest is taken in
        const m = Object.assign({}, apis)
        let changed = false
        for (const id in m) {
            const p = find(id)
            if (!p) { m[id].destroy(); delete m[id]; changed = true }
            else m[id].manifest = p.manifest
        }
        if (changed) apis = m
    }
    Component {
        id: apiC
        QtObject {
            id: a
            property string pluginId
            property string pluginDir
            property var manifest: ({})
            // its settings: settings.json, else its defaults
            property var pluginSettings: ({})
            property var settingsFile: FileView {
                path: a.pluginDir + "/settings.json"
                blockLoading: true
                printErrors: false
                // what was saved, on top of the defaults (so a setting added in a newer version is there too)
                onLoaded: { try { a.pluginSettings = Object.assign(a.defaults(), JSON.parse(text()) || {}) } catch (e) { a.pluginSettings = a.defaults() } }
                onLoadFailed: a.pluginSettings = a.defaults()
            }
            // the defaults: "options" in the manifest (each one's "default"), plus metadata.defaultSettings
            function defaults() {
                const d = JSON.parse(JSON.stringify(manifest?.metadata?.defaultSettings ?? {}))
                for (const o of (manifest?.options ?? [])) if (o && o.key && o.default !== undefined && d[o.key] === undefined) d[o.key] = o.default
                return d
            }
            // the easy way to use a setting: setting("size", 5) reads it, setSetting("size", 6) changes it and keeps it
            function setting(key, fallback) { const v = pluginSettings ? pluginSettings[key] : undefined; return v === undefined ? fallback : v }
            function setSetting(key, value) {
                const s = Object.assign({}, pluginSettings)
                s[key] = value
                pluginSettings = s
                saveSettings()
            }
            function saveSettings() {
                const s = JSON.stringify(pluginSettings ?? {}, null, 2)
                Quickshell.execDetached(["sh", "-c", 'printf "%s\\n" "$2" > "$1/settings.json"', "save", pluginDir, s])
                // a new object, so everything showing the settings sees the change
                pluginSettings = JSON.parse(s)
            }
        }
    }

    // ---- Settings > Plugins ----
    function openSettings(id) { Ui.pluginFocus = id || ""; Ui.openSettings("plugins") }
    function openFolder(id) {
        const p = id ? find(id) : null
        Quickshell.execDetached(["sh", Quickshell.shellDir + "/scripts/open-folder.sh", p ? p.dir : dir])
    }
    function remove(id) {
        const p = find(id)
        if (!p) return
        // to the bin when there is one, so a mistake can be undone
        Quickshell.execDetached(["sh", "-c", 'gio trash -- "$1" 2>/dev/null || rm -rf -- "$1"', "rm", p.dir])
        status = "Moved \"" + p.name + "\" to the bin"
        soon.restart()
    }

    // import / export / new: through scripts/plugins.py; its answer is one line of JSON
    function run(args, done) { jobC.createObject(root, { command: ["python3", script].concat(args), done: done }) }
    Component {
        id: jobC
        Process {
            id: job
            property var done: null
            running: true
            stdout: StdioCollector {
                onStreamFinished: {
                    let j = {}
                    try { j = JSON.parse(text.trim().split("\n").pop()) } catch (e) { j = { error: text.trim() || "it did not work" } }
                    if (job.done) job.done(j)
                    job.destroy()
                }
            }
        }
    }
    function importFrom(path) {
        if (!path) return
        status = "Importing…"
        run(["import", path, dir], j => {
            if (j.error) { status = "Could not import: " + j.error; return }
            // imported plugins are on
            Config.c.pluginsDisabled = disabled.filter(x => (j.imported || []).indexOf(x) < 0)
            status = "Imported " + (j.imported || []).join(", ") + ((j.errors || []).length ? "  ·  not imported: " + j.errors.join("; ") : "")
            reload()
        })
    }
    function exportTo(id, dest) {
        const p = find(id)
        if (!p || !dest) return
        status = "Exporting…"
        run(["export", p.dir, dest], j => { status = j.error ? "Could not export: " + j.error : "Saved " + j.exported })
    }
}
