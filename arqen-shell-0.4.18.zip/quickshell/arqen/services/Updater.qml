pragma Singleton
import Quickshell
import Quickshell.Io
import QtQuick
import qs.config

// Looks in the shell's GitHub repo for a newer arqen-shell-X.Y.Z.zip and offers to install it: download it to
// Downloads, unpack, run update.sh (your settings are kept), then ask whether to delete the zip and folder, and restart.
// It only reads the repo's file list every few hours; nothing is sent.
Singleton {
    id: root
    readonly property string repo: "cache-byte/arqen-shell"
    readonly property string branch: "main"
    property string state: "idle"          // idle | checking | uptodate | available | updating | failed
    property string latest: ""
    property string message: ""
    property string zipUrl: ""
    readonly property string downloads: (Quickshell.env("XDG_DOWNLOAD_DIR") || (Quickshell.env("HOME") + "/Downloads"))
    readonly property string zipName: "arqen-shell-" + latest
    readonly property string zipPath: downloads + "/" + zipName + ".zip"
    readonly property string folderPath: downloads + "/" + zipName
    readonly property string stateFile: Quickshell.env("HOME") + "/.cache/arqen-update.state"
    property bool dismissed: false         // "Later" for this run
    readonly property bool enabled: Config.c.updateCheck !== false
    // the card on the screen: a new version, found by itself, not skipped, not put off
    readonly property bool prompt: state === "available" && !dismissed && latest !== (Config.c.updateSkipped || "")

    function parts(v) { return String(v).split(".").map(n => parseInt(n) || 0) }
    function newer(a, b) {            // a newer than b
        const x = parts(a), y = parts(b)
        for (let i = 0; i < Math.max(x.length, y.length); i++) {
            const d = (x[i] || 0) - (y[i] || 0)
            if (d !== 0) return d > 0
        }
        return false
    }

    // When the files are replaced, Quickshell reloads the shell and this singleton starts over, so the install runs on
    // its own (detached) and writes where it got to into a small file; this reads it back (now, and while it runs).
    function init() { first.start(); readState() }
    function readState() { if (!stateProc.running) stateProc.running = true }
    function check() {
        if (state === "checking" || state === "updating") return
        state = "checking"; message = ""
        checkProc.running = true
    }
    function later() { dismissed = true }
    function skip() { Config.c.updateSkipped = latest; dismissed = true }
    function install() {
        if (state === "updating" || zipUrl === "") return
        state = "updating"; message = "Downloading and installing ..."
        Quickshell.execDetached(["sh", "-c", 'mkdir -p "$(dirname "$4")"; printf "running\\n%s\\n%s\\n%s\\n" "$2" "$3" "$5" > "$4"; setsid nohup sh -c "$0" sh "$1" "$2" "$3" "$4" "$5" >/dev/null 2>&1 &', installScript, zipUrl, zipPath, folderPath, stateFile, latest])
    }
    // after the install (the shell has reloaded by itself): close the note, optionally deleting the downloaded zip and folder
    function finish(removeFiles) {
        const rm = (removeFiles ? 'rm -rf "' + zipPath + '" "' + folderPath + '"; ' : "") + 'rm -f "' + stateFile + '" "' + stateFile + '.log"'
        state = "idle"
        Quickshell.execDetached(["sh", "-c", rm])
    }

    Timer { id: first; interval: 30000; onTriggered: if (root.enabled) root.check() }
    Timer { interval: 6 * 3600 * 1000; repeat: true; running: root.enabled; onTriggered: root.check() }

    // Looks in the repo for the newest arqen-shell-X.Y.Z.zip: first the files in the repo's main folder, then the
    // newest release's files. Prints "ZIP version url" or "ERR why".
    Process {
        id: checkProc
        command: ["sh", "-c", `
            t=/tmp/arqen-upd.$$; l=$t.list; net=0; : > "$l"
            get() { code=$(curl -sSL --max-time 20 -o "$t" -w '%{http_code}' "$1" 2>/dev/null) || { net=1; return 1; }; [ "$code" = 200 ]; }
            pick() { # $1 = url prefix for bare names ("" = already a full url); names on stdin; appends "version url" lines
              while read -r n; do
                v=$(basename "$n" | grep -o '[0-9][0-9]*\\(\\.[0-9][0-9]*\\)\\+' | head -1); [ -n "$v" ] || continue
                case "$n" in http*) echo "$v $n";; *) echo "$v $1$n";; esac
              done >> "$l"; }
            if get "https://api.github.com/repos/$1/contents/?ref=$2"; then
              grep -o '"name": *"[^"]*\\.zip"' "$t" | sed 's/.*: *"//; s/"$//' | pick "https://raw.githubusercontent.com/$1/$2/"
            fi
            if get "https://api.github.com/repos/$1/releases/latest"; then
              grep -o '"browser_download_url": *"[^"]*\\.zip"' "$t" | sed 's/.*: *"//; s/"$//' | pick ""
            fi
            best=$(sort -V -k1,1 "$l" | tail -1); rm -f "$t" "$l"
            [ -n "$best" ] && { echo "ZIP $best"; exit 0; }
            [ "$net" = 1 ] && echo "ERR Could not reach GitHub (no internet?)." || echo "ERR No arqen-shell-X.Y.Z.zip found in the repository (or it is private)."
            `, "sh", root.repo, root.branch]
        stdout: StdioCollector {
            onStreamFinished: {
                const t = text.trim().split("\n").pop()
                const m = t.match(/^ZIP (\d+(?:\.\d+)*) (\S+)$/)
                if (!m) { root.state = "failed"; root.message = t.replace(/^ERR /, "") || "Could not read the version from GitHub."; return }
                root.latest = m[1]; root.zipUrl = m[2]
                if (root.newer(m[1], Config.version)) { root.state = "available"; root.dismissed = false }
                else { root.state = "uptodate" }
            }
        }
        onExited: code => { if (code !== 0 && root.state === "checking") { root.state = "failed"; root.message = "The check did not run." } }
    }

    // The install itself (arguments: zip url, zip path, folder, state file, version). Runs detached from the shell.
    readonly property string installScript:
        'zu="$1"; zp="$2"; fd="$3"; sf="$4"; ver="$5"\n'
        + 'fail() { printf "fail\\n%s\\n%s\\n%s\\n" "$zp" "$fd" "$1" > "$sf"; exit 1; }\n'
        + 'mkdir -p "$(dirname "$zp")"; curl -fL --max-time 300 -sS -o "$zp" "$zu" || fail "The download failed."\n'
        + 'rm -rf "$fd"; mkdir -p "$fd"; (unzip -q -o "$zp" -d "$fd" 2>/dev/null || python3 -m zipfile -e "$zp" "$fd") || fail "The zip could not be unpacked."\n'
        + 'u=$(find "$fd" -maxdepth 3 -name update.sh | head -1); [ -n "$u" ] && [ -d "$(dirname "$u")/quickshell/arqen" ] || fail "The zip is not a shell package (no update.sh with quickshell/arqen next to it)."\n'
        + 'cd "$(dirname "$u")"; ARQEN_NODEPS=1 ARQEN_WARNED=1 bash ./update.sh >"$sf.log" 2>&1 || fail "The installer did not finish (see $sf.log)."\n'
        + 'printf "done\\n%s\\n%s\\n%s\\n" "$zp" "$fd" "$ver" > "$sf"\n'

    // reads that file: running -> keep waiting, done -> ask about deleting, fail -> show why
    Process {
        id: stateProc
        command: ["sh", "-c", 'cat "$1" 2>/dev/null', "sh", root.stateFile]
        stdout: StdioCollector {
            onStreamFinished: {
                const l = text.split("\n")
                if (l.length < 4 || !l[0]) { if (root.state === "updating" && !installWait.running) root.state = "idle"; return }
                if (l[0] === "running") { root.state = "updating"; root.message = "Downloading and installing ..."; installWait.restart() }
                else if (l[0] === "done") { installWait.stop(); root.latest = l[3]; root.state = "installed"; root.message = "Updated to version " + l[3] + "." }
                else if (l[0] === "fail") { installWait.stop(); root.state = "failed"; root.message = l[3]; Quickshell.execDetached(["rm", "-f", root.stateFile]) }
            }
        }
    }
    Timer { id: installWait; interval: 1500; onTriggered: root.readState() }
}
