pragma Singleton
import Quickshell
import Quickshell.Io
import Quickshell.Hyprland
import QtQuick

// Single source of truth. The Settings app edits these values; they persist to
// ~/.config/arqen/config.json. Hyprland-related values are also written to
// ~/.config/hypr/arqen-overrides.conf (sourced by hyprland.conf), or ~/.config/hypr/arqen.lua
// (loaded by hyprland.lua) when Hyprland runs a Lua config.
Singleton {
    id: root
    readonly property string home: Quickshell.env("HOME")
    // the shell's version (Settings > System)
    readonly property string version: "0.3.88"
    // the folders screenshots and recordings go to (Settings > Desktop)
    readonly property string shotDir: (adapter.shotDir || "").trim() !== "" ? adapter.shotDir : home + "/Pictures/Screenshots"
    readonly property string recDir: (adapter.recDir || "").trim() !== "" ? adapter.recDir : home + "/Videos/Screenrecordings"
    // ~/… for showing a folder
    function tilde(p) { return String(p).indexOf(home + "/") === 0 ? "~" + String(p).slice(home.length) : String(p) }
    // scripts/capture.sh with those folders
    function captureCmd(args) {
        return ["env", "ARQEN_SHOT_DIR=" + shotDir, "ARQEN_REC_DIR=" + recDir, "ARQEN_ASK=" + (adapter.captureAfter === "ask" ? "1" : "0"), "ARQEN_CLIP=" + (adapter.shotClipboard ? "1" : "0"),
                "sh", Quickshell.shellDir + "/scripts/capture.sh"].concat(args)
    }
    property alias c: adapter

    // ---- defaults and resetting (the arrow buttons in Settings, "Reset everything" in System) ----
    readonly property ConfigData defaults: ConfigData {}
    function keyList(keys) { return (Array.isArray(keys) ? keys : String(keys).split(",")).map(k => k.trim()).filter(k => k !== "") }
    function same(a, b) { return JSON.stringify(a ?? null) === JSON.stringify(b ?? null) }
    function isDefault(keys) {
        for (const k of keyList(keys)) if (!same(adapter[k], defaults[k])) return false
        return true
    }
    function resetKeys(keys) {
        for (const k of keyList(keys)) if (!same(adapter[k], defaults[k])) adapter[k] = JSON.parse(JSON.stringify(defaults[k] ?? null))
    }
    // things that are yours rather than settings: each can be kept when resetting everything
    readonly property var keepGroups: ({
        wallpaper: ["wallpaper"],
        pinned:    ["pinned"],
        desktop:   ["desktopApps", "desktopPos", "desktopWidgets", "desktops"],
        shortcuts: ["keybinds", "unbinds", "shellKeys", "keyFullscreen", "keyMaximize", "keyFloat"]
    })
    // never reset: learned history and bookkeeping
    readonly property var history: ["appUsage", "recentApps", "knownElements"]
    // keep: names from keepGroups to leave as they are
    function resetAll(keep) {
        let skip = history.slice()
        for (const g of (keep || [])) skip = skip.concat(keepGroups[g] || [])
        const keys = Object.keys(defaults).filter(k => typeof defaults[k] !== "function" && !k.startsWith("objectName") && skip.indexOf(k) < 0)
        // the panels are rebuilt from the defaults when this list is empty
        for (const k of keys) {
            try { if (!same(adapter[k], defaults[k])) adapter[k] = JSON.parse(JSON.stringify(defaults[k] ?? null)) } catch (e) {}
        }
        // anything that did not go back (a second try, then say which)
        const left = []
        for (const k of keys) {
            try {
                if (same(adapter[k], defaults[k])) continue
                adapter[k] = defaults[k]
                if (!same(adapter[k], defaults[k])) left.push(k)
            } catch (e) { left.push(k) }
        }
        return left
    }

    // save shortly after the last change (a slider fires on every step), then tell Hyprland
    property double lastSave: 0
    Timer {
        id: saveTimer
        interval: 250
        onTriggered: { root.lastSave = Date.now(); file.writeAdapter(); hyprTimer.restart() }
    }
    // shell reloading or quitting right after a change: save it now
    Component.onDestruction: if (saveTimer.running) file.writeAdapter()

    FileView {
        id: file
        path: root.home + "/.config/arqen/config.json"
        watchChanges: true
        // Our own saves also count as "file changed". Reloading after them handed every list and
        // object setting (panels, layouts, desktop icons...) a fresh copy, which rebuilt everything
        // drawn from them: the flicker on every slider move or toggle. Only reload for edits made
        // by something else.
        onFileChanged: if (Date.now() - root.lastSave > 1500) reload()
        onAdapterUpdated: saveTimer.restart()
        onLoadFailed: error => { if (error === FileViewError.FileNotFound) { adapter.migrated = root.migrationLevel; root.lastSave = Date.now(); writeAdapter() } }
        onLoaded: root.migrate()

        adapter: ConfigData { id: adapter }
    }

    // ---- new defaults that reach configs saved before them (once each) ----
    readonly property int migrationLevel: 7
    function migrate() {
        if ((adapter.migrated || 0) >= migrationLevel) return
        // 2: no system sounds unless you choose a sound theme (Settings > Sound and notifications)
        if ((adapter.migrated || 0) < 2) adapter.soundTheme = ""
        // 4: name tips wait half a second
        if ((adapter.migrated || 0) < 4) adapter.tipSeconds = 0.5
        // 5: the song recognition tile is gone from the control centre
        if ((adapter.migrated || 0) < 5 && Array.isArray(adapter.ccTiles)) adapter.ccTiles = adapter.ccTiles.filter(t => t.id !== "song")
        // 6: blur behind see-through things is on
        if ((adapter.migrated || 0) < 6) adapter.blur = true
        if ((adapter.migrated || 0) < 7) adapter.toastPlace = "bottom-right"      // pop-ups now start at the bottom right
        adapter.migrated = migrationLevel
    }

    // ---- panels -------------------------------------------------------------
    // Everything that can be placed on a panel. Each panel has three sections: left / center / right
    // (top / middle / bottom when the panel is vertical). An element can sit on several panels,
    // but only once per panel.
    readonly property var barSections: ["left", "center", "right"]
    readonly property var edges: ["bottom", "top", "left", "right"]
    readonly property var aligns: ["start", "center", "end"]
    // the shell's own panel items, then the ones plugins bring (Settings > Plugins)
    readonly property var barElements: baseElements.concat(Ui.pluginBarElements)
    readonly property var baseElements: [
        { id: "workspaces",    name: "Desktops",           sub: "Desktop indicator, opens the desktop view", icon: "workspaces" },
        { id: "search",        name: "Search",             sub: "Search button",                     icon: "search" },
        { id: "launcher",      name: "Launcher",           sub: "App launcher button",               icon: "apps" },
        { id: "dock",          name: "App dock",           sub: "Pinned and running apps",           icon: "dock_to_bottom" },
        { id: "tray",          name: "App status icons",   sub: "Steam, Heroic and other tray apps", icon: "widgets" },
        { id: "clipboard",     name: "Clipboard",          sub: "Clipboard history popup",           icon: "content_paste" },
        { id: "keyboard",      name: "On-screen keyboard", sub: "Keys, emoji and GIFs on the screen",       icon: "keyboard" },
        { id: "media",         name: "Media",              sub: "What is playing; click for the media card", icon: "music_note" },
        { id: "control",       name: "Control centre",     sub: "Opens the sidebar: toggles, volume, notifications", icon: "tune" },
        { id: "clock",         name: "Clock",              sub: "Time and date",                     icon: "schedule" }
    ]
    readonly property var defaultLayout: ({
        left:   ["workspaces", "launcher", "search", "media"],
        center: ["dock"],
        right:  ["tray", "keyboard", "clipboard", "control", "clock"]
    })
    readonly property var knownIds: barElements.map(e => e.id)

    function elementInfo(id) { return barElements.find(e => e.id === id) ?? { id: id, name: id, sub: "", icon: "help" } }
    function defaultSection(id) { return String(id).startsWith("plugin:") ? "right" : (barSections.find(k => defaultLayout[k].indexOf(id) >= 0) ?? "center") }

    // put an element in its default section, in front of the element that follows it by default
    function insertDefault(lay, id) {
        const s = defaultSection(id)
        const d = defaultLayout[s] || []
        const after = d.slice(d.indexOf(id) + 1)
        const next = after.find(x => lay[s].indexOf(x) >= 0)
        if (next !== undefined) lay[s].splice(lay[s].indexOf(next), 0, id)
        else lay[s].push(id)
    }
    // unknown ids and duplicates dropped
    function cleanLayout(src) {
        src = src || {}
        const seen = {}
        const out = { left: [], center: [], right: [] }
        for (const s of barSections) {
            for (const id of (src[s] || [])) {
                if (knownIds.indexOf(id) >= 0 && !seen[id]) { seen[id] = true; out[s].push(id) }
            }
        }
        return out
    }
    // per-item size factors on a panel, { elementId: 0.5 .. 2.5 }
    function cleanSizes(src) {
        const out = {}
        if (!src) return out
        for (const id in src) {
            const f = Number(src[id])
            if (knownIds.indexOf(id) >= 0 && !isNaN(f) && Math.abs(f - 1) > 0.01) out[id] = Math.max(0.5, Math.min(2.5, f))
        }
        return out
    }
    function clamp(v, lo, hi, dflt) { v = Number(v); return isNaN(v) ? dflt : Math.max(lo, Math.min(hi, Math.round(v))) }
    function cleanPanel(p, i) {
        p = p || {}
        return {
            id: (typeof p.id === "string" && p.id !== "") ? p.id : "p" + (i + 1),
            edge: edges.indexOf(p.edge) >= 0 ? p.edge : "bottom",
            align: aligns.indexOf(p.align) >= 0 ? p.align : "center",
            length: clamp(p.length, 15, 100, 100),
            thickness: clamp(p.thickness, 32, 120, 56),
            layout: cleanLayout(p.layout),
            sizes: cleanSizes(p.sizes),
            autohide: p.autohide === true,
            islands: p.islands === true
        }
    }
    // the old single taskbar as panel 1 (every element it was missing put back, as it used to)
    function legacyPanel() {
        const lay = cleanLayout(adapter.barLayout)
        for (const id of knownIds) {
            if (!barSections.some(s => lay[s].indexOf(id) >= 0)) insertDefault(lay, id)
        }
        return cleanPanel({ id: "p1", edge: adapter.barEdge, align: adapter.barAlign,
                            length: adapter.barLength, thickness: adapter.barHeight, layout: lay }, 0)
    }
    function computePanels() {
        const src = adapter.panels
        if (!src || src.length === 0) return [legacyPanel()]
        const list = []
        const ids = {}
        for (let i = 0; i < src.length; i++) {
            const p = cleanPanel(src[i], i)
            if (ids[p.id]) continue
            ids[p.id] = true
            list.push(p)
        }
        // elements that are new since the last save go onto the first panel, once
        const known = adapter.knownElements || []
        for (const id of knownIds) {
            if (known.indexOf(id) >= 0) continue
            if (list.some(p => hasElement(p, id))) continue
            insertDefault(list[0].layout, id)
        }
        return list
    }
    readonly property var panelsNow: computePanels()

    // The panel ids, only reassigned when a panel is added or removed (so editing a panel
    // does not rebuild its window).
    property var panelIds: []
    function syncPanelIds() {
        const ids = panelsNow.map(p => p.id)
        if (ids.join(",") !== panelIds.join(",")) panelIds = ids
    }
    onPanelsNowChanged: syncPanelIds()
    Component.onCompleted: { syncPanelIds(); checkHypr() }

    function hasElement(p, id) { return barSections.some(s => p.layout[s].indexOf(id) >= 0) }
    function panel(id) { return panelsNow.find(p => p.id === id) ?? null }
    function panelIndex(id) { return panelsNow.findIndex(p => p.id === id) }
    // items that no longer exist (the retired Wallpaper Picker plugin, the separate Image search button) are dropped
    readonly property var retiredItems: ["plugin:wallpaper-picker", "lens"]
    function panelLayout(id) {
        const p = panel(id)
        if (!p) return { left: [], center: [], right: [] }
        const out = {}
        for (const k of ["left", "center", "right"]) out[k] = (p.layout[k] || []).filter(x => retiredItems.indexOf(x) < 0)
        return out
    }
    // first panel that shows this element (null if none)
    function panelOf(elementId) { return panelsNow.find(p => hasElement(p, elementId)) ?? null }
    function sectionOf(elementId) {
        const p = panelOf(elementId)
        if (!p) return "right"
        return barSections.find(s => p.layout[s].indexOf(elementId) >= 0) ?? "right"
    }
    // elements not on this panel yet
    function unplaced(id) { const p = panel(id); return p ? barElements.filter(e => !hasElement(p, e.id)) : [] }

    // ---- edits (all save straight away) ----
    function copyPanels() {
        return panelsNow.map(p => ({ id: p.id, edge: p.edge, align: p.align, length: p.length, thickness: p.thickness,
                                     layout: { left: p.layout.left.slice(), center: p.layout.center.slice(), right: p.layout.right.slice() },
                                     sizes: Object.assign({}, p.sizes), autohide: p.autohide, islands: p.islands }))
    }
    function savePanels(list) {
        adapter.knownElements = knownIds.slice()
        adapter.panels = list
    }
    function editPanel(id, fn) {
        const list = copyPanels()
        const p = list.find(x => x.id === id)
        if (!p) return
        fn(p)
        list[list.indexOf(p)] = cleanPanel(p, list.indexOf(p))
        savePanels(list)
    }
    function setPanel(id, key, value) {
        const p = panel(id)
        if (!p || p[key] === value) return
        editPanel(id, x => { x[key] = value })
    }
    function addPanel() {
        const list = copyPanels()
        const used = list.map(p => p.edge)
        const edge = ["top", "bottom", "left", "right"].find(e => used.indexOf(e) < 0) ?? "top"
        let n = list.length + 1
        while (list.some(p => p.id === "p" + n)) n++
        const id = "p" + n
        list.push(cleanPanel({ id: id, edge: edge, align: "center", length: 100, thickness: 48,
                               layout: { left: [], center: ["clock"], right: [] } }, list.length))
        savePanels(list)
        return id
    }
    function removePanel(id) {
        const list = copyPanels()
        if (list.length <= 1) return
        savePanels(list.filter(p => p.id !== id))
    }
    // drop an element into a section of a panel at a given position (drag and drop, or adding it)
    function placeElement(id, elementId, section, index) {
        editPanel(id, p => {
            for (const s of barSections) p.layout[s] = p.layout[s].filter(x => x !== elementId)
            const l = p.layout[section]
            const i = (index === undefined || index < 0) ? l.length : Math.min(index, l.length)
            l.splice(i, 0, elementId)
        })
    }
    function addElement(id, elementId) { placeElement(id, elementId, defaultSection(elementId), -1) }
    function removeElement(id, elementId) {
        editPanel(id, p => { for (const s of barSections) p.layout[s] = p.layout[s].filter(x => x !== elementId) })
    }
    function setItemSize(id, elementId, f) {
        editPanel(id, p => {
            const sz = Object.assign({}, p.sizes)
            if (Math.abs(f - 1) < 0.01) delete sz[elementId]
            else sz[elementId] = f
            p.sizes = sz
        })
    }
    function resetLayout(id) {
        editPanel(id, p => { p.layout = { left: defaultLayout.left.slice(), center: defaultLayout.center.slice(), right: defaultLayout.right.slice() } })
    }

    FileView {
        id: hyprFile
        path: root.home + "/.config/hypr/arqen-overrides.conf"
        // with hyprland.lua this file is never written: not finding it is normal
        printErrors: false
        // what is in the file already: only rewrite (and reload Hyprland) when something changed
        onLoaded: if (root.lastHypr === "") root.lastHypr = hyprFile.text()
    }
    property string lastHypr: ""
    // hyprland.lua (0.55+) loads this with `pcall(require, "arqen")`
    FileView {
        id: hyprLuaFile
        path: root.home + "/.config/hypr/arqen.lua"
        onLoaded: if (root.lastHyprLua === "") root.lastHyprLua = hyprLuaFile.text()
    }
    property string lastHyprLua: ""

    // ---- what this Hyprland understands ----
    // Window rules changed syntax in 0.53, plugin settings are errors unless the plugin is
    // loaded, and a hyprland.lua session wants Lua instead of hyprlang, so all of that is
    // checked before anything is written.
    property var hyprVer: null              // [major, minor, patch], null until known
    property bool hyprbarsLoaded: false
    property bool hyprLua: false            // Hyprland was started with hyprland.lua
    property bool hyprChecked: false
    readonly property bool newRules: hyprVer !== null && (hyprVer[0] > 0 || hyprVer[1] >= 53)
    Process {
        id: hyprInfo
        command: ["sh", "-c", "hyprctl version -j 2>/dev/null; echo; echo '@@PLUGINS@@'; hyprctl plugin list 2>/dev/null; echo; echo '@@EVAL@@'; hyprctl eval 'local _ = 1' 2>&1"]
        stdout: StdioCollector {
            onStreamFinished: {
                const parts = text.split("@@PLUGINS@@")
                const rest = (parts[1] || "").split("@@EVAL@@")
                let ver = null
                try {
                    const j = JSON.parse(parts[0])
                    const m = String(j.version || j.tag || "").match(/(\d+)\.(\d+)\.?(\d+)?/)
                    if (m) ver = [parseInt(m[1]), parseInt(m[2]), parseInt(m[3] || "0")]
                } catch (e) {}
                if (ver) root.hyprVer = ver
                root.hyprbarsLoaded = /hyprbars/i.test(rest[0] || "")
                // "ok" from the Lua config manager; hyprlang answers "eval is only supported with the lua config manager"
                root.hyprLua = /^\s*ok\b/.test(rest[1] || "")
                root.hyprChecked = ver !== null
                hyprTimer.restart()
            }
        }
    }
    function checkHypr() { if (!hyprInfo.running) hyprInfo.running = true }
    Connections {
        target: Hyprland
        function onRawEvent(event) { if (event.name === "configreloaded") root.checkHypr() }
    }

    function hex(c) { return "rgb(" + String(c).replace("#", "").slice(-6) + ")" }
    // The strip you drag windows by: just above the window, outside its border, see-through,
    // no title and no buttons (the plugin's buttons were never added).
    function dragStrip() { return { height: 10, color: "rgba(00000000)" } }
    // blur strength 1..10 -> Hyprland's blur size and number of passes
    function blurSize() { const v = Math.max(1, Math.min(10, adapter.blurStrength || 5)); return 2 + v }
    function blurPasses() { const v = Math.max(1, Math.min(10, adapter.blurStrength || 5)); return v <= 3 ? 1 : (v <= 6 ? 2 : (v <= 8 ? 3 : 4)) }
    // every layer of the shell that can be see-through (the wallpaper is not one of them)
    readonly property string blurNs: "^(arqen-(panel|sidebar|popup|toast|overview|desktop|countdown|power|window-handle|capture-after|display-confirm))$"
    function windowRules() {
        const a = adapter
        if (hyprVer === null) return ""           // not known yet: write nothing rather than the wrong syntax
        let t = ""
        // Floating is the default; tiled modes use Hyprland's built-in layouts.
        // (floating is done by the shell itself now, see Hypr.qml: a window rule stayed in force after the mode changed)
        t += "general { layout = " + ((a.windowMode === "master" || a.windowMode === "scrolling") ? a.windowMode : "dwindle") + " }\n"
        // blur behind the shell's own see-through surfaces (not the wallpaper); ignore_alpha keeps
        // the fully clear parts of full-screen layers (popups, desktop, overview) from being blurred
        if (a.blur) {
            t += newRules
                ? "layerrule {\n  name = arqen-blur\n  blur = on\n  blur_popups = on\n  ignore_alpha = 0.05\n  match:namespace = " + blurNs + "\n}\n"
                : "layerrule = blur, " + blurNs + "\nlayerrule = blurpopups, " + blurNs + "\nlayerrule = ignorealpha 0.05, " + blurNs + "\n"
        }
        // drag windows by their very top: an invisible hyprbars strip just above each window
        if (hyprbarsLoaded) {
            const d = dragStrip()
            t += "plugin {\n  hyprbars {\n"
                + "    enabled = true\n"
                + "    bar_height = " + d.height + "\n"
                + "    bar_color = " + d.color + "\n"
                + "    bar_title_enabled = false\n"
                + "    bar_part_of_window = false\n"
                + "    bar_precedence_over_border = false\n"
                + "    bar_padding = 0\n"
                + "    on_double_click = hyprctl dispatch fullscreen 1\n"
                + "  }\n}\n"
        }
        return t
    }

    // ---- keyboard shortcuts from Settings ----
    // the command a shortcut runs: an app through the shell (same as the launcher), or a command as is
    // how Hyprland reaches the shell: scripts/ipc hands it over through a pipe in a few
    // milliseconds (`qs ipc call` first loads Qt, which was the delay before the launcher opened)
    readonly property string ipcCall: "~/.config/quickshell/arqen/scripts/ipc call arqen "
    function bindCommand(b) { return b.kind === "app" ? ipcCall + "launch " + b.value : String(b.value || "") }
    // [key, what Arqen calls it, how]: "repeat" = held down repeats (and works on the lock screen),
    // "locked" = works on the lock screen, "pass" = the key still does its own job (Caps / Num Lock)
    readonly property var osdKeyList: [
        ["XF86AudioRaiseVolume", "volume-up", "repeat"], ["XF86AudioLowerVolume", "volume-down", "repeat"],
        ["XF86AudioMute", "mute", "locked"], ["XF86AudioMicMute", "mic-mute", "locked"],
        ["XF86MonBrightnessUp", "brightness-up", "repeat"], ["XF86MonBrightnessDown", "brightness-down", "repeat"],
        ["XF86KbdBrightnessUp", "kbd-up", "repeat"], ["XF86KbdBrightnessDown", "kbd-down", "repeat"],
        ["XF86AudioPlay", "play-pause", "locked"], ["XF86AudioPause", "play-pause", "locked"],
        ["XF86AudioNext", "next", "locked"], ["XF86AudioPrev", "prev", "locked"], ["XF86AudioStop", "stop", "locked"],
        ["XF86AudioRewind", "rewind", "locked"], ["XF86AudioForward", "forward", "locked"], ["XF86ScreenSaver", "lock", "locked"],
        ["Caps_Lock", "caps", "pass"], ["Num_Lock", "num", "pass"], ["Print", "capture", "plain"]
    ]
    function osdBindText(lua) {
        if (!adapter.osdKeys) return ""
        let t = ""
        for (const k of osdKeyList) {
            const cmd = ipcCall + "key " + k[1]
            // Caps Lock and Num Lock are themselves modifiers: when the key is let go, CAPS (Caps Lock
            // on) and / or MOD2 (Num Lock on) are part of the held modifiers, and a shortcut only fires
            // when the modifiers match exactly. So one shortcut for every combination.
            if (k[2] === "pass") {
                for (const m of [[], ["CAPS"], ["MOD2"], ["CAPS", "MOD2"]]) {
                    if (lua) t += "hl.bind(" + luaStr(m.concat([k[0]]).join(" + ")) + ", hl.dsp.exec_cmd(" + luaStr(cmd) + "), { release = true, non_consuming = true, description = " + luaStr("Arqen: " + k[1]) + " })\n"
                    else t += "bindrn = " + m.join(" ") + ", " + k[0] + ", exec, " + cmd + "\n"
                }
                continue
            }
            if (lua) {
                const opts = k[2] === "repeat" ? "repeating = true, locked = true" : (k[2] === "locked" ? "locked = true" : (k[2] === "plain" ? "release = false" : "release = true, non_consuming = true"))
                t += (k[2] === "pass" ? "" : "pcall(hl.unbind, " + luaStr(k[0]) + ")\n")
                   + "hl.bind(" + luaStr(k[0]) + ", hl.dsp.exec_cmd(" + luaStr(cmd) + "), { " + opts + ", description = " + luaStr("Arqen: " + k[1]) + " })\n"
            } else {
                const flag = k[2] === "repeat" ? "bindel" : (k[2] === "locked" ? "bindl" : (k[2] === "plain" ? "bind" : "bindrn"))
                t += (k[2] === "pass" ? "" : "unbind = , " + k[0] + "\n") + flag + " = , " + k[0] + ", exec, " + cmd + "\n"
            }
        }
        return t
    }
    // how many fingers the swipes use: what Settings says, or `auto` (3 with hyprland.conf, 4 with hyprland.lua)
    function gFingers(auto) { const n = Number(adapter.gestureFingers); return n === 3 || n === 4 ? n : auto }
    // the shell's own shortcuts: [id, name, what the shell is asked to do]
    readonly property var shellKeyList: [
        ["settings", "Open Settings", "settingsApp"], ["search", "Search", "toggle search"],
        ["overview", "Desktops overview", "toggle overview"], ["quick", "Control centre", "toggle quick"],
        ["clipboard", "Clipboard history", "toggle clipboard"], ["capture", "Screenshot or recording", "toggle capture"],
        ["lock", "Lock the screen", "lock"], ["power", "Power menu", "toggle power"],
        ["keyboard", "On-screen keyboard", "toggle keyboard"], ["draw", "Draw on the screen", "toggle draw"],
        ["minimize", "Minimise to the side panel", "minimize"]
    ]
    function shellKeyOf(id) {
        const own = adapter.shellKeys || {}
        if (id in own) return String(own[id] || "")
        return String(defaults.shellKeys[id] || "")
    }
    function bindText(lua) {
        const a = adapter
        let t = osdBindText(lua)
        // the shell's shortcuts first (yours below win when they use the same keys)
        for (const s of shellKeyList) {
            const parts = shellKeyOf(s[0]).split("+").map(x => x.trim()).filter(x => x !== "")
            if (parts.length === 0) continue
            const cmd = ipcCall + s[2]
            t += lua ? "pcall(hl.unbind, " + luaStr(parts.join(" + ")) + ")\n"
                       + "hl.bind(" + luaStr(parts.join(" + ")) + ", hl.dsp.exec_cmd(" + luaStr(cmd) + "), { description = " + luaStr(cmd) + " })\n"
                     : "unbind = " + parts.slice(0, -1).join(" ") + ", " + parts[parts.length - 1] + "\n"
                       + "bindd = " + parts.slice(0, -1).join(" ") + ", " + parts[parts.length - 1] + ", Arqen: " + s[1] + ", exec, " + cmd + "\n"
        }
        for (const k of (a.unbinds || [])) {
            const parts = String(k).split("+").map(x => x.trim()).filter(x => x !== "")
            if (parts.length === 0) continue
            t += lua ? "pcall(hl.unbind, " + luaStr(parts.join(" + ")) + ")\n"
                     : "unbind = " + parts.slice(0, -1).join(" ") + ", " + parts[parts.length - 1] + "\n"
        }
        // Floating is a separate action from fullscreen/maximise. Keep the default shortcuts
        // predictable: Super+F toggles floating, Super+Shift+F toggles fullscreen.
        const floatParts = String(a.keyFloat || "").split("+").map(x => x.trim()).filter(x => x !== "")
        if (floatParts.length) {
            // a hyprland.lua session has no `hyprctl dispatch togglefloating` (dispatch takes Lua there)
            t += lua ? "pcall(hl.unbind, " + luaStr(floatParts.join(" + ")) + ")\n"
                       + "hl.bind(" + luaStr(floatParts.join(" + ")) + ", hl.dsp.window.float({ action = \"toggle\" }), { description = \"Arqen: Toggle floating\" })\n"
                     : "unbind = " + floatParts.slice(0, -1).join(" ") + ", " + floatParts[floatParts.length - 1] + "\n"
                       + "bindd = " + floatParts.slice(0, -1).join(" ") + ", " + floatParts[floatParts.length - 1] + ", Arqen: Toggle floating, togglefloating\n"
        }
        // the shell's window shortcuts: full screen / maximise the focused window
        const winKeys = [[a.keyFullscreen, "fullscreen", "0", "Full screen (toggle)"], [a.keyMaximize, "maximized", "1", "Maximise (toggle)"]]
        for (const w of winKeys) {
            const parts = String(w[0] || "").split("+").map(x => x.trim()).filter(x => x !== "")
            if (parts.length === 0) continue
            t += lua ? "pcall(hl.unbind, " + luaStr(parts.join(" + ")) + ")\n"
                       + "hl.bind(" + luaStr(parts.join(" + ")) + ", hl.dsp.window.fullscreen({ mode = " + luaStr(w[1]) + ", action = \"toggle\" }), { description = " + luaStr("Arqen: " + w[3]) + " })\n"
                     : "unbind = " + parts.slice(0, -1).join(" ") + ", " + parts[parts.length - 1] + "\n"
                       + "bindd = " + parts.slice(0, -1).join(" ") + ", " + parts[parts.length - 1] + ", Arqen: " + w[3] + ", fullscreen, " + w[2] + "\n"
        }
        for (const b of (a.keybinds || [])) {
            const parts = String(b.keys || "").split("+").map(x => x.trim()).filter(x => x !== "")
            const cmd = bindCommand(b)
            if (parts.length === 0 || cmd === "") continue
            // remove whatever had these keys before, so the new shortcut wins
            t += lua ? "pcall(hl.unbind, " + luaStr(parts.join(" + ")) + ")\n"
                       + "hl.bind(" + luaStr(parts.join(" + ")) + ", hl.dsp.exec_cmd(" + luaStr(cmd) + "), { description = " + luaStr("Arqen: " + (b.label || cmd)) + " })\n"
                     : "unbind = " + parts.slice(0, -1).join(" ") + ", " + parts[parts.length - 1] + "\n"
                       + "bindd = " + parts.slice(0, -1).join(" ") + ", " + parts[parts.length - 1] + ", Arqen: " + String(b.label || cmd).replace(/,/g, " ") + ", exec, " + cmd + "\n"
        }
        return t
    }

    // window borders: the focused window's in the primary accent colour, the others faint
    function hyprHex(c, a) {
        const f = x => ("0" + Math.round(Math.max(0, Math.min(1, x)) * 255).toString(16)).slice(-2)
        return f(c.r) + f(c.g) + f(c.b) + f(a === undefined ? 1 : a)
    }
    function borderActive() { return "rgba(" + hyprHex(Theme.primary) + ")" }
    function borderInactive() { return "rgba(" + hyprHex(adapter.darkMode ? Qt.rgba(1, 1, 1, 1) : Qt.rgba(0, 0, 0, 1), 0.12) + ")" }

    // the screens' lines: your choices per screen, then one for any other screen
    // 1.75 is no longer offered (Hyprland refuses it for most screens): automatic instead
    function okScale(s) { return (s === undefined || s === null || s === "") ? "auto" : s }
    function monitorLines(lua) {
        const all = adapter.monitors || {}
        let t = ""
        for (const name of Object.keys(all)) {
            const m = all[name] || {}
            const mode = m.mode || "preferred"
            const pos = m.position || "auto"
            const sc = okScale(m.scale || adapter.scale || "auto")
            const tr = (Number(m.transform || 0) % 4)
            if (lua) {
                t += m.disabled ? "pcall(hl.monitor, { output = " + luaStr(name) + ", disabled = true })\n"
                    : "pcall(hl.monitor, { output = " + luaStr(name) + ", mode = " + luaStr(mode) + ", position = " + luaStr(pos)
                      + ", scale = " + luaScale(sc) + (tr ? ", transform = " + tr : "") + " })\n"
            } else {
                t += m.disabled ? "monitor = " + name + ", disable\n"
                    : "monitor = " + name + ", " + mode + ", " + pos + ", " + sc + (tr ? ", transform, " + tr : "") + "\n"
            }
        }
        t += lua ? "hl.monitor({ output = \"\", mode = \"preferred\", position = \"auto\", scale = " + luaScale(okScale(adapter.scale)) + " })\n"
                 : "monitor = , preferred, auto, " + okScale(adapter.scale) + "\n"
        return t
    }

    // ---- extra Hyprland options (Settings > Hyprland, Mouse and keyboard) ----
    readonly property var legacyOptNames: ({ "tap_to_click": "tap-to-click", "tap_and_drag": "tap-and-drag" })
    function optLegacyName(k) {
        const parts = k.split(".")
        const last = parts[parts.length - 1]
        if (legacyOptNames[last]) parts[parts.length - 1] = legacyOptNames[last]
        return parts.join(":")
    }
    function optLegacyVal(v) { return typeof v === "boolean" ? (v ? "true" : "false") : String(v) }
    function optLuaVal(v) { return typeof v === "boolean" ? (v ? "true" : "false") : (typeof v === "number" ? String(v) : luaStr(v)) }
    // what the shell sets unless you pick otherwise (Settings > Mouse and keyboard shows these as the value and the
    // row's reset arrow puts them back): natural scrolling is on for the touchpad
    readonly property var optDefaults: ({ "input.touchpad.natural_scroll": true })
    function effOpts() { return Object.assign({}, optDefaults, adapter.hyprOpts || {}) }
    function optsLegacy() {
        const o = effOpts()
        return Object.keys(o).sort().filter(k => o[k] !== undefined && o[k] !== null && o[k] !== "")
            .map(k => optLegacyName(k) + " = " + optLegacyVal(o[k]) + "\n").join("")
    }
    // every option on its own line in a pcall, so one name this Hyprland version does not know cannot stop the rest
    function optsLua() {
        const o = effOpts()
        let t = ""
        for (const k of Object.keys(o).sort()) {
            if (o[k] === undefined || o[k] === null || o[k] === "") continue
            const parts = k.split(".")
            let open = "", close = ""
            for (let i = 0; i < parts.length - 1; i++) { open += parts[i] + " = { "; close += " }" }
            t += "pcall(hl.config, { " + open + parts[parts.length - 1] + " = " + optLuaVal(o[k]) + close + " })\n"
        }
        return t
    }

    function hyprText() {
        const a = adapter
        return "# Generated by Arqen Settings - edit via the Settings app\n"
            + monitorLines(false)
            + "general {\n  gaps_in = " + a.gapsIn + "\n  gaps_out = " + a.gapsOut + "\n  border_size = " + a.borderSize
            + "\n  col.active_border = " + borderActive() + "\n  col.inactive_border = " + borderInactive() + "\n}\n"
            + "decoration {\n  rounding = " + a.winRounding + "\n  blur {\n    enabled = " + a.blur + "\n    popups = " + a.blur + "\n    size = " + blurSize() + "\n    passes = " + blurPasses() + "\n  }\n}\n"
            + "animations {\n  enabled = " + a.animations + "\n}\n"
            // the pointer stays where it is when a window is focused (from the dock, a notification...)
            + "cursor {\n  no_warps = " + (a.cursorWarp ? "false" : "true") + "\n}\n"
            // crisp window moves: blur only shows the wallpaper behind see-through windows (it is not
            // redrawn from the windows sliding past), dragged / resized windows follow the pointer at
            // once, and the move animation is short
            + "decoration {\n  blur {\n    new_optimizations = true\n    xray = true\n  }\n}\n"
            + "misc {\n  animate_mouse_windowdragging = false\n  animate_manual_resizes = false\n  allow_session_lock_restore = true\n}\n"
            + "input {\n  kb_layout = " + (a.realKbLayout || "us") + "\n  kb_variant = " + (a.realKbVariant || "") + (a.loginNum === "on" ? "\n  numlock_by_default = true" : "") + "\n}\n"
            + (a.animations ? "animation = windowsMove, 1, 2, default\n" : "")
            // new windows pop in with a little spring, desktops slide with one (Settings > Display > Motion > Bounce)
            + (a.animations && (a.bounce ?? 120) > 0
                ? "bezier = arqBounce, 0.34, " + (1 + 0.3 * (a.bounce ?? 120) / 120).toFixed(2) + ", 0.64, 1\n"
                  + "animation = windowsIn, 1, 4, arqBounce, popin 80%\n"
                  + "animation = workspaces, 1, 5, arqBounce, slide\n"
                : "")
            + (a.gestures
                ? "gesture = " + gFingers(3) + ", horizontal, workspace\n"
                  + "gesture = " + gFingers(3) + ", up, dispatcher, exec, " + ipcCall + "open overview\n"
                  + "gesture = " + gFingers(3) + ", down, dispatcher, exec, " + ipcCall + "close\n"
                : "")
            + (a.desktops || []).map(id => "workspace = " + id + ", persistent:true\n").join("")
            // ADW_DISABLE_PORTAL: installed (not Flatpak) libadwaita apps read dark / light and the accent
            // straight from GNOME's settings, so they follow even when the desktop portal is broken
            + (a.themeApps ? "env = QT_QPA_PLATFORMTHEME,qt6ct\nenv = ADW_DISABLE_PORTAL,1\n" : "")
            + (a.cursorTheme !== "" ? "env = XCURSOR_THEME," + a.cursorTheme + "\nenv = XCURSOR_SIZE," + a.cursorSize + "\n" : "")
            + optsLegacy()
            + windowRules()
            + bindText(false)
    }

    // ---- the same settings for hyprland.lua ----
    function luaStr(v) { return "\"" + String(v).replace(/\\/g, "\\\\").replace(/"/g, "\\\"").replace(/\n/g, "\\n") + "\"" }
    function luaScale(v) { const n = Number(v); return (String(v).trim() !== "" && !isNaN(n)) ? String(n) : luaStr("auto") }
    // dispatches as shell commands for the title-bar buttons (`hyprctl dispatch` runs hl.dispatch(...))
    readonly property string luaCmdClose: "hyprctl dispatch 'hl.dsp.window.close()'"
    readonly property string luaCmdMaximize: "hyprctl dispatch 'hl.dsp.window.fullscreen({ mode = \"maximized\", action = \"toggle\" })'"
    function luaWindowRules() {
        const a = adapter
        let t = ""
        if (a.blur)
            t += "hl.layer_rule({ name = \"arqen-blur\", match = { namespace = " + luaStr(blurNs) + " }, blur = true, blur_popups = true, ignore_alpha = 0.05 })\n"
        if (hyprbarsLoaded) {
            const d = dragStrip()
            // hl.plugin.hyprbars only exists once the plugin is loaded; its settings are errors before that
            t += "if hl.plugin and hl.plugin.hyprbars then\n"
                + "  pcall(hl.config, { plugin = { hyprbars = { enabled = true, bar_height = " + d.height + ", bar_color = " + luaStr(d.color)
                + ", bar_title_enabled = false, bar_part_of_window = false, bar_precedence_over_border = false, bar_padding = 0"
                + ", on_double_click = " + luaStr(luaCmdMaximize) + " } } })\n"
                + "end\n"
        }
        return t
    }
    function hyprLuaText() {
        const a = adapter
        const ipc = ipcCall
        let t = "-- Generated by Arqen Settings - edit via the Settings app.\n"
            + "-- hyprland.lua loads it with: pcall(require, \"arqen\")\n"
            + monitorLines(true)
            + "hl.config({\n"
            + "  general = { gaps_in = " + a.gapsIn + ", gaps_out = " + a.gapsOut + ", border_size = " + a.borderSize + ", layout = \"" + ((a.windowMode === "master" || a.windowMode === "scrolling") ? a.windowMode : "dwindle") + "\" },\n"
            + "  decoration = { rounding = " + a.winRounding + ", blur = { enabled = " + a.blur + ", popups = " + a.blur + ", size = " + blurSize() + ", passes = " + blurPasses() + " } },\n"
            + "  animations = { enabled = " + a.animations + " },\n"
            + "  input = { kb_layout = " + luaStr(a.realKbLayout || "us") + ", kb_variant = " + luaStr(a.realKbVariant || "") + (a.loginNum === "on" ? ", numlock_by_default = true" : "") + " },\n"
            + "})\n"
            // border colours (option names differ between Hyprland versions: try both, never fail)
            + "pcall(hl.config, { general = { col = { active_border = " + luaStr(borderActive()) + ", inactive_border = " + luaStr(borderInactive()) + " } } })\n"
            + "pcall(hl.config, { general = { [\"col.active_border\"] = " + luaStr(borderActive()) + ", [\"col.inactive_border\"] = " + luaStr(borderInactive()) + " } })\n"
            + "pcall(hl.config, { cursor = { no_warps = " + (a.cursorWarp ? "false" : "true") + " } })\n"
            + "pcall(hl.config, { decoration = { blur = { new_optimizations = true, xray = true } } })\n"
            + "pcall(hl.config, { misc = { animate_mouse_windowdragging = false, animate_manual_resizes = false } })\n"
            // a lock screen that restarts may take the lock again
            + "pcall(hl.config, { misc = { allow_session_lock_restore = true } })\n"
            + (a.animations ? "pcall(hl.animation, { leaf = \"windowsMove\", enabled = true, speed = 2, bezier = \"default\" })\n" : "")
            + (a.animations && (a.bounce ?? 120) > 0
                ? "pcall(hl.curve, \"arqBounce\", { type = \"bezier\", points = { { 0.34, " + (1 + 0.3 * (a.bounce ?? 120) / 120).toFixed(2) + " }, { 0.64, 1 } } })\n"
                  + "pcall(hl.animation, { leaf = \"windowsIn\", enabled = true, speed = 4, bezier = \"arqBounce\", style = \"popin 80%\" })\n"
                  + "pcall(hl.animation, { leaf = \"workspaces\", enabled = true, speed = 5, bezier = \"arqBounce\", style = \"slide\" })\n"
                : "")
        if (a.gestures)
            // 4 fingers: a Hyprland config usually already has the 3-finger swipes (workspace, and any older Arqen
            // ones), and a second gesture with the same fingers and direction is reported as an error
            t += "hl.gesture({ fingers = " + gFingers(4) + ", direction = \"horizontal\", action = \"workspace\" })\n"
                + "hl.gesture({ fingers = " + gFingers(4) + ", direction = \"up\", action = function() hl.exec_cmd(" + luaStr(ipc + "open overview") + ") end })\n"
                + "hl.gesture({ fingers = " + gFingers(4) + ", direction = \"down\", action = function() hl.exec_cmd(" + luaStr(ipc + "close") + ") end })\n"
        t += (a.desktops || []).map(id => "hl.workspace_rule({ workspace = " + luaStr(id) + ", persistent = true })\n").join("")
        if (a.themeApps) t += "hl.env(\"QT_QPA_PLATFORMTHEME\", \"qt6ct\")\nhl.env(\"ADW_DISABLE_PORTAL\", \"1\")\n"
        if (a.cursorTheme !== "") t += "hl.env(\"XCURSOR_THEME\", " + luaStr(a.cursorTheme) + ")\nhl.env(\"XCURSOR_SIZE\", " + luaStr(a.cursorSize) + ")\n"
        return t + optsLua() + luaWindowRules() + bindText(true)
    }

    Timer { id: reloadTimer; interval: 400; onTriggered: { Quickshell.execDetached(["hyprctl", "reload"]) } }
    // (the window look is also set straight on the running Hyprland: services/Hypr.qml, after each reload)

    Timer {
        id: hyprTimer
        interval: 700
        onTriggered: {
            if (!root.hyprChecked) return            // write nothing until we know which config Hyprland reads
            if (root.hyprLua) {
                const t = root.hyprLuaText()
                if (t !== root.lastHyprLua) {
                    root.lastHyprLua = t
                    hyprLuaFile.setText(t)
                    reloadTimer.restart()
                }
                return
            }
            const t = root.hyprText()
            if (t !== root.lastHypr) {
                root.lastHypr = t
                hyprFile.setText(t)
                reloadTimer.restart()      // do not rely on Hyprland noticing the file change
            }
        }
    }
}
