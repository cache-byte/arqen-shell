pragma Singleton
import Quickshell
import Quickshell.Io
import Quickshell.Hyprland
import QtQuick
import qs.config

// Every command the shell sends to Hyprland, in the form Hyprland understands right now.
// With hyprland.conf (hyprlang) a dispatch is "workspace 2"; with hyprland.lua (0.55+)
// `hyprctl dispatch X` runs `hl.dispatch(X)`, so it must be Lua: "hl.dsp.focus({ workspace = 2 })",
// and `hyprctl keyword` is gone (hl.* through `hyprctl eval` instead). Config.hyprLua says which.
Singleton {
    id: root
    readonly property bool lua: Config.hyprLua

    // Lua string literal (addresses, regexes, commands: plain ASCII)
    function q(s) { return "\"" + String(s).replace(/\\/g, "\\\\").replace(/"/g, "\\\"") + "\"" }
    function addr(a) { return "0x" + String(a || "").replace(/^0x/, "") }
    function wsLua(w) { return typeof w === "number" ? String(w) : q(w) }
    // Until the shell knows which config Hyprland reads (a moment after it starts), commands wait:
    // sent too early they went out in the wrong form ("togglespecialworkspace edge" to a Lua Hyprland)
    property var waiting: []
    function send(legacy, luaExpr) {
        if (!Config.hyprChecked) { waiting.push([legacy, luaExpr]); return }
        Hyprland.dispatch(lua ? luaExpr : legacy)
    }
    Connections {
        target: Config
        function onHyprCheckedChanged() {
            if (!Config.hyprChecked) return
            const w = root.waiting; root.waiting = []
            for (const c of w) root.send(c[0], c[1])
        }
    }

    // the same, as a shell command (for scripts and plugin buttons)
    function shQuote(s) { return "'" + String(s).replace(/'/g, "'\\''") + "'" }
    function shellDispatch(legacy, luaExpr) { return "hyprctl dispatch " + shQuote(lua ? luaExpr : legacy) }

    // ---- screen filter: a shader over the whole screen ("" = none) ----
    function screenShader(path) {
        if (lua) Quickshell.execDetached(["hyprctl", "eval", "hl.config({ decoration = { screen_shader = " + q(path) + " } })"])
        else Quickshell.execDetached(["hyprctl", "keyword", "decoration:screen_shader", path])
    }

    // ---- how apps open: floating or tiled, for every window now and for each new one ----
    // scripts/window-mode.sh sets the layout and toggles only the windows that are not already as wanted
    // (it asks Hyprland which are floating), and says what went wrong in `modeStatus` (Settings > Windows).
    property string modeStatus: ""
    property bool modeBusy: modeProc.running
    function applyWindowMode() {
        if (modeProc.running) { modeAgain = true; return }
        modeStatus = ""
        modeProc.command = ["bash", Quickshell.shellDir + "/scripts/window-mode.sh", Config.c.windowMode || "floating", lua ? "lua" : "legacy"]
        modeProc.running = true
    }
    property bool modeAgain: false

    // gaps, border and corner radius: set on the running Hyprland as soon as a slider moves
    property string lookStatus: ""
    function applyLook() { lookTimer.restart() }
    Timer {
        id: lookTimer
        interval: 120
        onTriggered: {
            if (!Config.hyprChecked) return
            if (lookProc.running) { lookTimer.restart(); return }
            const c = Config.c
            lookProc.command = ["bash", Quickshell.shellDir + "/scripts/live-look.sh", root.lua ? "lua" : "legacy",
                String(c.gapsIn), String(c.gapsOut), String(c.borderSize), String(c.winRounding)]
            lookProc.running = true
        }
    }
    Process {
        id: lookProc
        stdout: StdioCollector { onStreamFinished: root.lookStatus = text.trim() }
    }
    Connections {
        target: Config.c
        function onGapsInChanged() { root.applyLook() }
        function onGapsOutChanged() { root.applyLook() }
        function onBorderSizeChanged() { root.applyLook() }
        function onWinRoundingChanged() { root.applyLook() }
    }
    Process {
        id: modeProc
        stdout: StdioCollector { onStreamFinished: root.modeStatus = text.trim() }
        onExited: if (root.modeAgain) { root.modeAgain = false; root.applyWindowMode() }
    }
    Connections {
        target: Config.c
        function onWindowModeChanged() { if (Config.hyprChecked) root.applyWindowMode() }
    }
    // after a reload Hyprland may have gone back to the file's values: set the look again
    Timer { id: reapply; interval: 600; onTriggered: root.applyLook() }
    Connections {
        target: Hyprland
        function onRawEvent(ev) {
            if (ev.name === "configreloaded") { reapply.restart(); return }
            if (ev.name !== "openwindow" || !Config.hyprChecked) return
            const f = String(ev.data).split(",")
            if (f.length < 1 || f[0] === "") return
            // every new window, in every mode: floated in Floating, tiled in the others (a rule left over from an
            // earlier mode, or the app itself, may have made it float)
            Quickshell.execDetached(["bash", Quickshell.shellDir + "/scripts/window-mode.sh", Config.c.windowMode || "floating", root.lua ? "lua" : "legacy", root.addr(f[0])])
        }
    }

    // While a filter is on, redraw the whole screen every frame (0 = no damage tracking): partial redraws under
    // a full-screen shader are the usual cause of flicker and torn patches. Back to normal (2) when it is off.
    // The pointer is then drawn by the shell's renderer too (a hardware cursor plane next to a filtered, fully
    // redrawn screen can flicker or jump); back to automatic when the filter is off.
    function fullRedraw(on) {
        if (lua) Quickshell.execDetached(["hyprctl", "eval", "pcall(hl.config, { cursor = { no_hardware_cursors = " + (on ? 1 : 2) + " } })"])
        else Quickshell.execDetached(["hyprctl", "keyword", "cursor:no_hardware_cursors", on ? "1" : "2"])
        if (lua) Quickshell.execDetached(["hyprctl", "eval", "pcall(hl.config, { debug = { damage_tracking = " + (on ? 0 : 2) + " } })"])
        else Quickshell.execDetached(["hyprctl", "keyword", "debug:damage_tracking", on ? "0" : "2"])
    }

    // ---- desktops ----
    function workspace(w) { send("workspace " + w, "hl.dsp.focus({ workspace = " + wsLua(w) + " })") }
    // keep a desktop alive while empty (or not)
    function persist(id, on) {
        if (lua) Quickshell.execDetached(["hyprctl", "eval", "hl.workspace_rule({ workspace = " + q(String(id)) + ", persistent = " + (on ? "true" : "false") + " })"])
        else Quickshell.execDetached(["hyprctl", "keyword", "workspace", id + ", persistent:" + (on ? "true" : "false")])
    }

    // ---- windows ----
    function focusWindow(a) { send("focuswindow address:" + addr(a), "hl.dsp.focus({ window = " + q("address:" + addr(a)) + " })") }
    // follow = false: the window goes, you stay
    function moveToWorkspace(a, ws, follow) {
        send((follow ? "movetoworkspace " : "movetoworkspacesilent ") + ws + ",address:" + addr(a),
             "hl.dsp.window.move({ workspace = " + wsLua(ws) + ", follow = " + (follow ? "true" : "false") + ", window = " + q("address:" + addr(a)) + " })")
    }
    function moveActiveToWorkspace(ws, follow) {
        send((follow ? "movetoworkspace " : "movetoworkspacesilent ") + ws,
             "hl.dsp.window.move({ workspace = " + wsLua(ws) + ", follow = " + (follow ? "true" : "false") + " })")
    }
    function moveWindowTo(a, x, y) {
        x = Math.round(x); y = Math.round(y)
        send("movewindowpixel exact " + x + " " + y + ",address:" + addr(a),
             "hl.dsp.window.move({ x = " + x + ", y = " + y + ", window = " + q("address:" + addr(a)) + " })")
    }
    // an exact size (a floating window)
    function resizeWindowTo(a, w, h) {
        w = Math.round(w); h = Math.round(h)
        send("resizewindowpixel exact " + w + " " + h + ",address:" + addr(a),
             "hl.dsp.window.resize({ x = " + w + ", y = " + h + ", window = " + q("address:" + addr(a)) + " })")
    }
    // screens on / off
    function dpms(on) { send("dpms " + (on ? "on" : "off"), "hl.dsp.dpms({ action = " + q(on ? "on" : "off") + " })") }
    // put a window above the others
    function raiseWindow(a) { send("alterzorder top,address:" + addr(a), "hl.dsp.window.alter_zorder({ mode = \"top\", window = " + q("address:" + addr(a)) + " })") }
    // show / hide a hidden ("special") desktop by its name without "special:"
    function toggleSpecial(name) { send("togglespecialworkspace " + name, "hl.dsp.workspace.toggle_special(" + q(name) + ")") }
    function closeWindow(a) { send("closewindow address:" + addr(a), "hl.dsp.window.close({ window = " + q("address:" + addr(a)) + " })") }

    // float / tile a window, and full screen / maximise the focused one (the window handle)
    function toggleFloat(a) { send("togglefloating address:" + addr(a), "hl.dsp.window.float({ action = \"toggle\", window = " + q("address:" + addr(a)) + " })") }
    function fullscreenActive(maximized) {
        send(maximized ? "fullscreen 1" : "fullscreen 0", "hl.dsp.window.fullscreen({ mode = " + q(maximized ? "maximized" : "fullscreen") + ", action = \"toggle\" })")
    }

    // ---- as shell commands ----
    readonly property string cmdClose: shellDispatch("killactive", "hl.dsp.window.close()")
    readonly property string cmdMaximize: shellDispatch("fullscreen 1", "hl.dsp.window.fullscreen({ mode = \"maximized\", action = \"toggle\" })")
    readonly property string cmdExit: shellDispatch("exit", "hl.dsp.exit()")
    // float a window by title, give it a size and centre it (used for the Settings window)
    function cmdFloatResize(titleRegex, w, h) {
        const sel = "title:" + titleRegex
        return shellDispatch("setfloating " + sel, "hl.dsp.window.float({ action = \"set\", window = " + q(sel) + " })")
            + " && " + shellDispatch("resizewindowpixel exact " + w + " " + h + "," + sel, "hl.dsp.window.resize({ x = " + w + ", y = " + h + ", window = " + q(sel) + " })")
            + " && " + shellDispatch("centerwindow", "hl.dsp.window.center()")
    }
}
