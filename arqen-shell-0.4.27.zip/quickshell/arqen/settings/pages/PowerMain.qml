import QtQuick
import QtQuick.Layouts
import QtQuick.Shapes
import Quickshell
import Quickshell.Services.UPower
import qs.config
import qs.components
import qs.services
import qs.settings

// Power: the battery, power modes, this computer, what happens when it is left alone, the lid, and
// battery notifications. (The power menu has its own page.)
ColumnLayout {
    id: page
    width: parent.width; spacing: 16
    // live facts: read again every 5 seconds while the page is open

    readonly property var bat: UPower.displayDevice

    // ---------- the battery at a glance ----------
    SCard {
        visible: Power.hasBattery
        Item {
            Layout.fillWidth: true
            implicitHeight: 92
            RingPill {
                id: ring
                width: 92; height: 92
                anchors.verticalCenter: parent.verticalCenter
                level: Power.pct / 100
                stroke: 9
                color: Power.charging ? "#2FBF71" : (Power.pct <= Config.c.batteryLow ? "#E5484D" : Theme.primary)
                fill: Qt.rgba(color.r, color.g, color.b, 0.12)
                Column {
                    anchors.centerIn: parent
                    DText { anchors.horizontalCenter: parent.horizontalCenter; text: Power.pct + "%"; font.pixelSize: 20; font.weight: Font.DemiBold }
                    Icon { anchors.horizontalCenter: parent.horizontalCenter; visible: Power.plugged; name: "bolt"; size: 16; color: ring.color }
                }
            }
            Column {
                x: ring.width + 20
                width: parent.width - x
                anchors.verticalCenter: parent.verticalCenter
                spacing: 4
                DText {
                    font.pixelSize: 17
                    text: Power.charging ? "Charging" : (Power.plugged ? "Plugged in" : "On battery")
                }
                DText {
                    width: parent.width; wrapMode: Text.WordWrap; color: Theme.subtext; font.pixelSize: 13
                    text: Power.charging && page.bat.timeToFull > 0 ? "Full in about " + Power.duration(page.bat.timeToFull)
                        : (!Power.plugged && page.bat.timeToEmpty > 0 ? "About " + Power.duration(page.bat.timeToEmpty) + " left" : "")
                          + (page.bat.changeRate > 0 ? (Power.plugged ? "" : "  ·  ") + "using " + (Math.round(page.bat.changeRate * 10) / 10) + " W" : "")
                }
            }
        }
    }

    // ---------- power mode ----------
    SHeader { text: "Power mode" }
    SCard {
        RowLayout {
            Layout.fillWidth: true
            spacing: 10
            Repeater {
                model: [
                    { p: PowerProfile.PowerSaver, n: "Power saver", i: "battery_saver", s: "Longer battery, a bit slower" },
                    { p: PowerProfile.Balanced, n: "Balanced", i: "balance", s: "Speed when needed, quiet otherwise" },
                    { p: PowerProfile.Performance, n: "Performance", i: "speed", s: "Fastest; more heat and fan" }
                ]
                delegate: Rectangle {
                    id: pm
                    required property var modelData
                    readonly property bool on: PowerProfiles.profile === modelData.p
                    readonly property bool avail: modelData.p !== PowerProfile.Performance || PowerProfiles.hasPerformanceProfile
                    Layout.fillWidth: true
                    implicitHeight: 104
                    radius: 18
                    opacity: avail ? 1 : 0.4
                    color: on ? Theme.primary : (pmm.containsMouse ? Theme.hover : Theme.tile)
                    Behavior on color { ColorAnimation { duration: 120 } }
                    Column {
                        anchors { fill: parent; margins: 14 }
                        spacing: 4
                        Icon { name: pm.modelData.i; size: 26; color: pm.on ? Theme.onPrimary : Theme.text }
                        DText { width: parent.width; elide: Text.ElideRight; text: pm.modelData.n; font.pixelSize: 14; font.weight: Font.DemiBold; color: pm.on ? Theme.onPrimary : Theme.text }
                        DText { width: parent.width; wrapMode: Text.WordWrap; maximumLineCount: 2; elide: Text.ElideRight; font.pixelSize: 11
                                text: pm.avail ? pm.modelData.s : "Not offered by this computer"; color: pm.on ? Theme.onPrimary : Theme.subtext; opacity: 0.9 }
                    }
                    MouseArea { id: pmm; anchors.fill: parent; enabled: pm.avail; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: QuickSettings.setProfile(pm.modelData.p) }
                }
            }
        }
    }

    SHeader { text: "Shell saver"; key: "shellSaver" }
    SGroup {
        SRow { key: "shellSaver"; title: "Lighter shell"; icon: "eco"
            subtitle: (Power.saving ? "On now. " : "Off now. ") + "Slower music beat, no breathing animations, no cover blur, and the video wallpaper pauses. Auto turns it on while on battery"
            SChoices { model: ["Auto", "On", "Off"]; current: Config.c.shellSaver === "on" ? "On" : Config.c.shellSaver === "off" ? "Off" : "Auto"
                       onPicked: v => Config.c.shellSaver = v.toLowerCase() } }
    }

    // ---- this computer, and what happens when it is left alone ----
    function mins(v) { return v <= 0 ? "Never" : v < 60 ? v + " min" : Math.floor(v / 60) + " h" + (v % 60 ? " " + (v % 60) + " min" : "") }
    readonly property var lidNames: ["Sleep", "Lock", "Screen off", "Nothing", "Hibernate", "Shut down"]
    readonly property var lidIds: ["sleep", "lock", "screenoff", "nothing", "hibernate", "poweroff"]
    SHeader { visible: Config.c.showAdvanced; text: "This computer"; key: "deviceType" }
    SGroup { visible: Config.c.showAdvanced;
        SRow { key: "deviceType"; title: "Kind of computer"
            subtitle: "Found: " + (Idle.autoLaptop ? "a laptop" : "a desktop") + (Config.c.deviceType === "auto" ? "" : "  ·  set by hand to a " + Idle.kindName) + ". Laptops get lid and on-battery settings"
            icon: Idle.laptop ? "laptop" : "desktop_windows"
            SChoices { model: ["Auto", "Laptop", "Desktop"]; current: Config.c.deviceType === "laptop" ? "Laptop" : Config.c.deviceType === "desktop" ? "Desktop" : "Auto"
                       onPicked: v => Config.c.deviceType = v.toLowerCase() } }
    }

    SHeader { id: idleHead; text: "When you leave it alone"; key: "idleDim,idleOff,idleLock,idleSleep,idleSleepAC,lockBeforeSleep"
        Rectangle {
            anchors { left: parent.left; leftMargin: 190; verticalCenter: parent.verticalCenter }
            height: 24; radius: 12; width: tl.implicitWidth + 24
            color: Theme.hover
            DText { id: tl; anchors.centerIn: parent; font.pixelSize: Sizes.textS; color: Theme.subtext
                text: "Inactive for " + Idle.timerText + (Idle.kept && Idle.respect ? "  ·  held awake by an app" : "") }
        }
    }
    SGroup {
        SliderRow { key: "idleDim"; title: "Dim the screen after"; icon: "brightness_low"; from: 0; to: 30; step: 1
            display: page.mins(Config.c.idleDim)
            value: Config.c.idleDim; onMoved: v => Config.c.idleDim = Math.round(v) }
        SliderRow { key: "idleOff"; title: "Turn the screen off after"; icon: "desktop_access_disabled"; from: 0; to: 60; step: 1
            display: page.mins(Config.c.idleOff)
            value: Config.c.idleOff; onMoved: v => Config.c.idleOff = Math.round(v) }
        SliderRow { key: "idleLock"; title: "Lock after"; icon: "lock_clock"; from: 0; to: 60; step: 1
            display: page.mins(Config.c.idleLock)
            value: Config.c.idleLock; onMoved: v => Config.c.idleLock = Math.round(v) }
        SliderRow { key: "idleSleep"; title: Idle.laptop ? "Sleep after (on battery)" : "Sleep after"; icon: "bedtime"; from: 0; to: 120; step: 5
            display: page.mins(Config.c.idleSleep)
            value: Config.c.idleSleep; onMoved: v => Config.c.idleSleep = Math.round(v) }
        SliderRow { key: "idleSleepAC"; visible: Idle.laptop; title: "Sleep after (plugged in)"; icon: "power"; from: 0; to: 240; step: 5
            display: page.mins(Config.c.idleSleepAC)
            value: Config.c.idleSleepAC; onMoved: v => Config.c.idleSleepAC = Math.round(v) }
        SRow { key: "lockBeforeSleep"; title: "Lock when it goes to sleep"; subtitle: "Your password is asked for when it wakes"; icon: "lock"
            ArqToggle { checked: Config.c.lockBeforeSleep; onToggled: v => Config.c.lockBeforeSleep = v } }
        SRow { key: "idlePauseGames"; title: "Not while a game or a full screen window is open"
            subtitle: "A game played with a controller sends no key presses or mouse movement, so the computer would otherwise dim, lock or sleep during it. Games (Steam, Wine, gamescope) and full screen windows count as being used"
            icon: "sports_esports"
            ArqToggle { checked: Config.c.idlePauseGames !== false; onToggled: v => Config.c.idlePauseGames = v } }
        SRow { key: "idleIgnoreInhibit"; title: "Even when an app wants the screen awake"
            subtitle: "A video, a call, a browser tab that is playing something or a game can ask the computer not to dim, lock or sleep. Turn this on to do it anyway"
            icon: "do_not_disturb_on"
            ArqToggle { checked: Config.c.idleIgnoreInhibit === true; onToggled: v => Config.c.idleIgnoreInhibit = v } }
        SRow { title: "Idle watching"; subtitle: Idle.status + (Idle.lastEvent !== "" ? "  ·  last: " + Idle.lastEvent : ""); icon: "monitor_heart"
            ArqButton { text: "Re-check"; onClicked: Idle.rebuild() } }
        SRow { visible: Config.c.showAdvanced; title: "Kept awake by"; subtitle: "Playing a video, Caffeine (control centre) and apps that ask to stay awake. Slide to the left for never"; icon: "info" }
    }

    SHeader { text: "Closing the lid"; visible: Idle.laptop; key: "lidAction,lidActionAC,lidIgnoreExternal" }
    SGroup {
        visible: Idle.laptop
        SRow { key: "lidAction"; title: Power.hasBattery ? "On battery" : "When the lid closes"; icon: "laptop_chromebook"
            SDropdown { model: page.lidNames; currentIndex: Math.max(0, page.lidIds.indexOf(Config.c.lidAction))
                        onPicked: (i, label) => Config.c.lidAction = page.lidIds[i] } }
        SRow { key: "lidActionAC"; visible: Power.hasBattery; title: "Plugged in"; icon: "power"
            SDropdown { model: page.lidNames; currentIndex: Math.max(0, page.lidIds.indexOf(Config.c.lidActionAC))
                        onPicked: (i, label) => Config.c.lidActionAC = page.lidIds[i] } }
        SRow { key: "lidIgnoreExternal"; title: "Keep working on another screen"; subtitle: "With a screen plugged in, closing the lid does nothing"; icon: "monitor"
            ArqToggle { checked: Config.c.lidIgnoreExternal; onToggled: v => Config.c.lidIgnoreExternal = v } }
    }

    SHeader { text: "Battery notifications"; visible: Power.hasBattery; key: "batteryFullOn,batteryFull,batteryLowOn,batteryLow,batteryCriticalOn,batteryCritical,batteryCriticalAction,batteryPercent" }
    SGroup {
        visible: Power.hasBattery
        SRow { key: "batteryFullOn"; title: "Charged"; subtitle: "When charging reaches this. Below 100 % is handy if you stop charging early to look after the battery"; icon: "battery_full"
            ArqToggle { checked: Config.c.batteryFullOn; onToggled: v => Config.c.batteryFullOn = v } }
        SliderRow { key: "batteryFull"; visible: Config.c.batteryFullOn; title: "Charged at"; icon: "battery_charging_full"; suffix: " %"; from: 50; to: 100; step: 1
            value: Config.c.batteryFull; onMoved: v => Config.c.batteryFull = Math.round(v) }
        SRow { key: "batteryLowOn"; title: "Low"; subtitle: "Time to find the charger"; icon: "battery_3_bar"
            ArqToggle { checked: Config.c.batteryLowOn; onToggled: v => Config.c.batteryLowOn = v } }
        SliderRow { key: "batteryLow"; visible: Config.c.batteryLowOn; title: "Low at"; icon: "battery_2_bar"; suffix: " %"; from: 10; to: 50; step: 1
            value: Config.c.batteryLow; onMoved: v => { Config.c.batteryLow = Math.round(v); if (Config.c.batteryCritical >= Config.c.batteryLow) Config.c.batteryCritical = Config.c.batteryLow - 1 } }
        SRow { key: "batteryCriticalOn"; title: "Critically low"; subtitle: "An urgent notification that stays until you close it"; icon: "battery_alert"
            ArqToggle { checked: Config.c.batteryCriticalOn; onToggled: v => Config.c.batteryCriticalOn = v } }
        SliderRow { key: "batteryCritical"; visible: Config.c.batteryCriticalOn; title: "Critically low at"; icon: "battery_1_bar"; suffix: " %"; from: 2; to: 25; step: 1
            value: Config.c.batteryCritical; onMoved: v => Config.c.batteryCritical = Math.min(Math.round(v), Config.c.batteryLow - 1) }
        SRow { key: "batteryCriticalAction"; visible: Config.c.batteryCriticalOn; title: "Then"; subtitle: "A minute after the critical notification, unless the charger goes in"; icon: "power_settings_new"
            SChoices { model: ["do nothing", "sleep", "hibernate", "shut down"]
                current: ({ none: "do nothing", suspend: "sleep", hibernate: "hibernate", poweroff: "shut down" })[Config.c.batteryCriticalAction || "none"]
                onPicked: v => Config.c.batteryCriticalAction = ({ "do nothing": "none", sleep: "suspend", hibernate: "hibernate", "shut down": "poweroff" })[v] } }
        SRow { key: "batteryPercent"; title: "Percentage on the panel"; icon: "percent"
            ArqToggle { checked: Config.c.batteryPercent; onToggled: v => Config.c.batteryPercent = v } }
    }

    SMore {}
}
