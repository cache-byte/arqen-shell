# Arqen shell: what changed in each version

(The short guide is README.md.) Current version: 0.4.27.
> **!!! WARNING !!!** This shell is written with AI and you may encounter errors. **TRY AT YOUR OWN RISK.** pls and thank you :) **!!!!!!!!!!**

## New in 0.4.27
- The shell no longer dims, locks or sleeps the computer while a game is being played: a game used with a controller or a keyboard-less video sends no pointer or key activity, so the inactivity timer counted it as idle. While a window is full screen, or the focused window is a game (Steam, Wine, gamescope, Lutris, Heroic), the timer stays at 0. Switch: Settings > Power > "Not while a game or a full screen window is open" (on by default). Unverified live. A game that runs windowed under another name is not recognised; "Even when an app wants the screen awake" covers games that ask for it.

## New in 0.4.26
- Screen recording "failed" with the new steady-frame options: the recorder now tries the full options, then fewer, then none, so a recording is always made, and what the recorder said is kept in ~/.cache/arqen/recording.log (and its last line is shown if nothing was saved). Unverified live.

## New in 0.4.25
- Fixed "TypeError: Cannot read property 'charCodeAt' of undefined" (Desktop.qml) when the wallpaper-subject mask has fewer rows than expected. Unverified live.

## New in 0.4.24
- Plugins are removed from the shell altogether: the Plugins settings page, the plugin loader, panel / desktop plugin widgets, the example and PLUGINS.md are gone, and plugin items are dropped from saved panel layouts. Updating moves Arqen's own Hello example folder to the bin; any plugin folder you made yourself in ~/.config/quickshell/widgets is left alone (it is just no longer loaded).
- Screen recording: steady frames (60 by default, or 30) even when the screen is not changing (wf-recorder -D -r), and better quality (x264, CRF 18 by default). New in Settings > Desktop: "Recording frame rate" (30 / 60) and "Recording quality" (Standard / High / Best). Unverified live; a slow computer may still drop frames at 60 (use 30 or Standard).

## New in 0.4.23
- The Hello example plugin is off until you turn it on in Settings > Plugins (also switched off once on existing setups). Unverified live.

## New in 0.4.22
- Settings > Desktop > Widgets: under "Keep widgets off the subject" each widget now has its own switch, so some can keep off the wallpaper's subject and others may sit on it. Unverified live.

## New in 0.4.21
- Keyboard: Super + Shift + arrow keys resize the focused window and Super + Alt + arrow keys move it (hold to repeat; floating windows go 40 px at a time, tiled ones swap places or move their split). The modifiers can be changed or switched off in Settings > Keyboard shortcuts. Unverified live (the Lua-session forms for tiled windows especially).

## New in 0.4.20
- Settings > Plugins showed an empty page (a syntax error on one line of the page): fixed.
- New setting in Settings > Windows: "Focus a window by" Hovering / Clicking / Hover but typing waits for a click (Hyprland's input.follow_mouse 1 / 0 / 2). Unverified live.

## New in 0.4.19
- Update stuck on "Downloading and installing ...": the update that the shell runs by itself no longer tries the steps that need a terminal (window-drag plugin build, keyring set-up, sudo password), which could wait forever. The installer is stopped after 10 minutes with a message, and a "running" note older than 12 minutes is shown as a failed update instead of an endless wait. Unverified live.

## New in 0.4.18
- Idle steps (dim, screen off, lock, sleep) are now run from one inactivity timer instead of four separate watchers, and the timer is shown next to "When you leave it alone" ("Inactive for 0:42", with "held awake by an app" when a video, call or Caffeine is keeping the screen awake). If it never counts up, the compositor's idle detection is not working. Unverified live.

## New in 0.4.0
- The update now asks about deleting the zip and folder: installing replaces the shell's files, which reloads the shell and used to wipe the question. The install now runs on its own and leaves a note (~/.cache/arqen-update.state); the reloaded shell reads it and asks "Delete and restart / Keep them and restart". Unverified live (the script itself was tested with a fake zip).

## New in 0.3.99
- Default control centre layout fills its rows with no empty cells (sliders on the left, toggles in a 3 x 3 block beside them, battery and media output side by side; the output spans the row when there is no battery). Only applies if you have not rearranged your own layout.
- Pointer jumping: the pointer-warp options (workspace change, after keyboard use, persistent warps) are now all switched off with the rest of the shell's Hyprland settings, and while a screen filter is on the pointer is drawn in software (hardware cursor plane off), which can flicker next to a filtered screen. Unverified live.

## New in 0.3.98
- Updates now come from the zip: the shell looks in the GitHub repo (and the newest release) for the highest arqen-shell-X.Y.Z.zip. If it is newer than yours it asks; "Download and install" saves the zip to Downloads, unpacks it, runs the installer (settings kept), then asks whether to delete the zip and the unpacked folder, and restarts. Unverified live.

## New in 0.3.97
- Desktop widgets start Solid (your existing widgets are set to Solid once; Glass is still there as the see-through look).
- Every widget option has a reset arrow (back to that option's default) in the widget editor, and "Look for updates by itself" has one too.
- Scroll bars where a list is longer than its view: the Settings pages, the widget editor, app pickers, dropdowns and the picker lists (not the control centre). Faint until you scroll or point at them; drag them or click the track. Unverified live.

## New in 0.3.96
- Widgets: Glass and Solid are different now. Glass is see-through (the shell's glass colour, blurred behind, with the "Background opacity" you pick; 60 % unless you chose another), Solid is always fully opaque (and has no opacity slider).
- Widgets: a new soft shadow (fading rings around the card, a little more below it) replaces the hard offset one, on every widget (clock, calendar, note, media).
- Clock widget: the edit frame and the resize corner follow the clock's card (they used to stay at the edge of the widget's cells, a big gap away). Unverified live.

## New in 0.3.95
- Clock widget: "Time colour" is Accent / Text / Custom with a colour of your own (it replaces the accent switch). The Stacked style now follows "Date format" (it always showed "Saturday / 17 October"): Long, Short ("Sat / 17 Oct"), Day only, Numeric.

## New in 0.3.94
- Update check: it looks in more places (the version in config/Config.qml at the top of the repo or in quickshell/arqen, a VERSION file, the newest release or tag), and says what went wrong: "no internet" is told apart from "nothing to compare with on GitHub" (the repo has no shell files yet, or it is private). The installer finds update.sh in the download even when the repo has the package in a subfolder. Unverified live.

## New in 0.3.93
- Clock widget: the card (background, outline, corners, shadow) now hugs the time and date (or the dial), however big or small the widget is made, instead of filling the whole widget area.
- Dim / screen off / lock / sleep when idle: "Idle watching" in Settings > Power is shown to everyone again (it says what is being watched and what happened last); a new switch "Even when an app wants the screen awake" does it anyway when a video, a call or a playing browser tab asks the computer to stay awake (the usual reason nothing happens); the idle watcher is created with its import on its own line. Laptops: "Sleep after (plugged in)" is Never by default. Unverified live.

## New in 0.3.92
- Notes widget: it only takes the keyboard while the pointer is on it (the desktop accepts the keyboard only then, so the click lands), and stops taking keys when the pointer leaves. In 0.3.90 the desktop always took the keyboard, so a note you had clicked kept receiving what you typed anywhere. Unverified live.

## New in 0.3.91
- Keep widgets off the subject, better: the guess now learns the background from the picture's edges and outlines the real shape (a mask of cells) instead of one big box, so widgets only avoid the part that is really covered (a widget with a corner over an edge is fine). Tried on a car and a person; it can still be wrong on busy pictures.
- Clock widget: the time uses more of the card, the date grows with the card and is centred under the time, and the corners and outline are never bigger than the card can carry (a thin line on a small card).

## New in 0.3.90
- Notes widget: you can type in it while an app is open. The desktop used to ask for the keyboard only after the click, when Hyprland had already left the focus on the app, so the text went into the app. With a note on the desktop it now always accepts the keyboard when clicked.
- Floating mode: windows open at the size the app asks for again (and centred). They had all got the same size because they opened tiled and were floated afterwards. The float rule is back for Floating mode; in the other modes a window that opens floating is still tiled by the shell. Unverified live.

## New in 0.3.89
- Desktop widgets can stay off the wallpaper's main subject: Settings > Desktop > Widgets > "Keep widgets off the subject" (off by default). `scripts/subject.py` makes a rough guess from the picture (the busiest blob that differs from the rest; Python 3 with Pillow, or ImageMagick); a widget on it moves to the nearest free spot off it. Picture wallpapers only. It is a guess, so it can be wrong.
- Desktop grid: it now starts at the top left corner, right under the panels (a few pixels of room), so a widget such as the clock can sit at the very top of the screen.
- The "edge panel" is now the "minimize bar" (Settings > Windows). It stays on the screen edge as a thin line when nothing is minimized, so it can be moved first (switch: "Always show the minimize bar").
- Panel sizes: app icons 24 and other items 22 by default (also set once on existing installs; change them in Settings > Panels).

## New in 0.3.88
- Fixed "ReferenceError: Hypr is not defined" (config/Config.qml): the live gap / border / radius change from 0.3.86 called a service the config file cannot see, so it never ran, which is why the gap slider did nothing. It is now set from services/Hypr.qml, also again after every Hyprland reload.

## New in 0.3.87
- New windows now follow the mode in every mode (before, only Floating mode looked at them): in Dwindle / Master / Scrolling a new window that opened floating (an old float rule, or the app itself) is tiled. Unverified live.

## New in 0.3.86
- Gap between windows, gap to screen edge, border width and corner radius are set on the running Hyprland the moment a slider moves (`scripts/live-look.sh`, one setting at a time so one refused value cannot block the rest). If Hyprland refuses one, Settings > Windows shows what it said in red. Unverified live.

## New in 0.3.85
- The Settings window (and other shell windows) now follow "How apps open" like every other app: floating in Floating mode, tiled otherwise. In 0.3.84 they were skipped, so Settings opened tiled in Floating mode. A new window gets a moment to appear before it is checked.

## New in 0.3.84
- How apps open, third try: `scripts/window-mode.sh` now sets the layout and then asks Hyprland which windows are floating and toggles only the ones that are not as the mode wants (it uses the same toggle command the title-bar button uses). It runs for every open window at once, and for each new window in Floating mode. If Hyprland refuses something, Settings > Windows shows what it said in red. Unverified live.

## New in 0.3.83
- Updates: the shell looks at github.com/cache-byte/arqen-shell (the version in config/Config.qml on `main`) 30 seconds after it starts and every 6 hours, and shows a card with Update now / Later / Skip this version when a newer one is there. Update now downloads the repo, runs update.sh (settings kept, no package installs) and restarts the shell. Settings > About > Updates has Check now and a switch to turn the automatic check off. For it to work the repo must hold the package as is (update.sh at the top, `quickshell/arqen/...`), and the version in Config.qml must be raised for each release. Unverified live.

## New in 0.3.82
- The window handle is hidden unless "How apps open" is Floating.
- Changing the mode now sets the layout first and floats / tiles the windows a moment later, so windows are laid out by the new layout (Master). Unverified live.

## New in 0.3.81
- How apps open: Floating / Dwindle / Master / Scrolling now changes every open window at once (floating or tiled), and new windows follow the mode. The shell does this itself instead of with a Hyprland window rule, which stayed in force after the mode changed.
- Screen filters: while a filter is on, the screen is fully redrawn each frame (Hyprland damage tracking off) and back to normal when it is off, against flicker. Unverified live.

## New in 0.3.80
- Windows settings (gaps, corner radius, border width, how apps open) did not change anything: besides the config file and reload, the values are now also set directly on the running Hyprland (a moment after each change). Unverified live.

## New in 0.3.79
- Screen filters: the shaders now always output a fully opaque pixel (some outputs mixed in the old alpha and flickered), and a filter change is applied after a short pause so quick taps in the menu no longer stack shader swaps. Unverified live: if it still glitches, tell me which filter and what it looks like.

## New in 0.3.78
- Lighting (new Settings page, OpenRGB): the RGB on connected devices can follow the shell's accent colour (so the wallpaper), take a colour of your own, or be switched off; brightness; the OpenRGB server is kept running in the background for quick changes. Needs the `openrgb` package (installer group "rgb").
- Login screen picture: the picture is handed to AccountsService from a world-readable copy first (the service cannot always read a home folder), then from the home file; Settings > System says whether it worked and has a "Use on login screen" button; an existing picture is handed over once after the shell starts if the login screen has none (`scripts/set-face.sh`).

## New in 0.3.77
- Installer: shows the name as art and the new warning (red), lists everything the shell uses and lets you install all of it, choose parts, or install the shell only (automatic on a system that is not Fedora). What you decline is remembered and update.sh leaves it alone. New DEPENDENCIES.md.
- README is short now (the old one is CHANGELOG.md). Credits in Settings > System are five lines, with no logos downloaded.

## New in 0.3.76
- Your picture now reaches the login screen: besides ~/.face and ~/.face.icon it is sent to AccountsService (GDM, LightDM, GNOME and KDE login screens read it there; pictures over 1 MB are shrunk first). For SDDM, which reads ~/.face.icon itself, the `sddm` user is given access to pass through your home folder (setfacl, only when SDDM is installed). Remove picture clears it everywhere. (`scripts/set-face.sh`)
- Settings: a "Show more settings" switch at the bottom of the pages (off by default). Off hides fine-tuning: panel spacing and sizes, music-card and beat details, rounded-corner sliders, app-theme repair tools, window handle and edge-tuck options, Hyprland's own page, "Kept awake by", the kind of computer, name tips, error reporting. Picking a result in the settings search turns it on. The duplicate "Windows corners" pointer in Appearance is gone.
- More settings hide when what they depend on is off: clock layout and date format (with the time / date), music title width, artist and scrolling (when the pill shows only the cover), edge-tuck distance.

## New in 0.3.75
- Notifications: after a reload the notification server hands the kept notifications over again and each one was stamped with the current time (and could pop up again). A notification whose id and sender + text match what was saved now keeps its time and stays quiet. The times file is read before that happens. Notifications already in the list get one last "now" on the first reload after this update, then keep their times.

## New in 0.3.74
- Notifications keep the time they arrived across shell reloads. The times file was written with a plain file write that fails when ~/.local/state/arqen does not exist, so nothing was saved; it is now written through the shell (which creates the folder), and a time is also remembered by sender + text in case the ids start again after a reload.

## New in 0.3.73
- Capture: picking a window no longer makes the tool vanish and come back (0.3.72 froze the screen again right after the pick). The pencil now works on the live view of the picked window; the screen is only frozen again at the moment you press the capture button (when there is a drawing), so the only flash is the capture itself.

## New in 0.3.72
- Capture: the pencil no longer disappears after you pick a window. Once the window is in front the screen is frozen again (the overlay steps aside for a moment), so you can draw on it.
- Control centre: the header is one grid-sized pill (52 high, 40 px picture, name and "Up ..." chip). Battery health moved to the hover tip, so the card has no unlabelled numbers.
- Settings: the open page is freed when the window closes (less memory while idle).

## New in 0.3.71
- Capture: Space takes the picture / starts the recording, like Enter.
- Control centre: the two chips under your name now say what they are ("Up 17m", "Battery health 69%") and wrap instead of cutting off.
- Settings: in a narrow window the page title uses the whole line (the search field is below it), so it no longer shrinks to "Po...".

## New in 0.3.70
- Narrow settings window: sliders no longer run past the row (the reset button's hidden space is now taken off the room the controls get); the search field fills the header width and uses smaller padding when narrow, so its placeholder fits. Slim sliders are 24 high (28 held).

## New in 0.3.69
- No more "Arqen shell error" pop-up for qt.network.http2 "Received GOAWAY" / "Remote host signaled shutdown" (a server closing a logo download).

## New in 0.3.68
- No more "Arqen shell error" pop-up for "SSL handshake failed: certificate is not yet valid" (a settings logo fetched over https before the clock has synced).

## New in 0.3.67
- Bar: the real cause of the uneven pill ends. A QtQuick Grid with more columns than items keeps an empty trailing column and its spacing, so every section, slot, clock, control and workspace pill had extra space on its right. Horizontal grids now use one row with as many columns as items (columns -1, rows 1), which has no such column. 0.3.66's change did not help for this reason.

## New in 0.3.66
- Bar: every island had extra empty space on its trailing side (a 2-column Grid keeps an empty second column plus spacing when only one item shows). Slots and the clock now use the same open-ended Grid as the sections.

## New in 0.3.65
- Bar: workspaces, control, media and clock pills now share one inner padding (8); the battery and recording pills sit inside the control pill with an equal gap all round; the island's gap to the screen edge equals its gap to the top.

## New in 0.3.64
- Size grid: new `config/Sizes.qml` holds the S/M/L button template (32/44/52 high, 14/16/16 text, 16/24/32 padding, 16/20/24 icons, 4 px base).
- Panel: the left and right edge padding of the islands is now equal.
- Search/text fields are 44 high (M) with 24 padding and 20 icons; the pop-up search field is 52 (L); dropdowns and chips are 32 (S); settings rows, reset buttons and notification-group buttons snap to 32 / 16 px padding.
- Not yet on the grid: the bar's internal pill sizes, the lock screen, the media card, annotation bar and some pop-up layouts.

## New in 0.3.63

- update.sh no longer writes the general `~/.config/xdg-desktop-portal/portals.conf` (every desktop reads it, so a GNOME session was pointed at the Hyprland portal); only `hyprland-portals.conf`. A general one made by an older version is moved aside.
- New `tools/gnome-session-reset.sh`: if GNOME bounces back to the login screen after using Arqen, run it from a text console (Ctrl+Alt+F3). It checks disk space, moves that file aside, clears the Hyprland leftovers in your user services and shows the log lines to look at.

## New in 0.3.62

- The accent colour from the wallpaper changes at the click: it is picked from a tiny copy of the new picture that starts loading straight away (before it waited the 140 ms used to skip through quick clicks). For videos the frame is taken after 0.7 s instead of 1.5 s.

## New in 0.3.61

- Settings > Appearance > Wallpaper: a click on a picture sets it as the wallpaper at once (no preview step).
- Many wallpapers no longer slow the shell down: only the pictures near the visible part of the page are loaded (small copies), and those that scroll far away are let go. Before, every picture in the folder was loaded and decoded the moment the page opened. The tiles are now all one shape (16:9, the picture cropped to fit) so the page does not shift while pictures load.

## New in 0.3.60

- Settings > Lock screen: the floating preview is smaller and hops to the other side of the window when you point at it, so it never covers a button or slider.

## New in 0.3.59

- Desktops overview: adding and removing desktops no longer glitches. Only the card that is added or removed changes (before, all the cards were rebuilt: thumbnails went blank and the grid jumped). A new card grows in, the others slide and resize into place, and the view only scrolls to the new desktop when it is out of sight (and smoothly).
- Window thumbnails are no longer rebuilt when something else on the desktop changes; they may also grow a little bigger when there is room.

## New in 0.3.58

- Lock screen: Blur and Darken now also work with a picture frame (heart, circle...): they apply to the picture inside the shape (the colour round it stays as chosen).
- Settings > Lock screen: once the preview at the top has scrolled out of sight, a small live copy floats at the bottom right, so a change (blur, darken, shape...) can be seen without scrolling back up.

## New in 0.3.57

- Desktops overview has a search box (it has the keyboard as soon as it opens): type part of an app's name or window title and the matching windows glow with a breathing ring while the others fade; the first match's desktop scrolls into view; Enter jumps to it. Escape clears the search, then closes.

## New in 0.3.56

- Desktops overview: point at a window and a red close button shows in its corner; middle click closes it too. Closing an app lets the others grow to fill the space.

## New in 0.3.55

- Desktops overview, more like GNOME's: four desktops in view (two by two), scroll down for more. Settings > Windows > Desktops overview > Layout switches to Horizontal (four in a row, scroll to the right).
- Every window on a desktop is now visible: the windows share the card and shrink to fit (the fourth used to fall below the card and was cut off).
- Clicking an app in the overview, the dock or panel (and its previews) or a notification now brings it to the front and gives it the keyboard; the focus is sent again a few times so a closing pop-up cannot take it back.

## New in 0.3.54

- The notification list no longer groups notifications by app: each one is its own card, newest first. Settings > Sound and notifications > "Group by app" brings the stacks back.

## New in 0.3.53

- Notifications (and alarms, reminders, "screenshot saved") now appear at the **bottom right** by default. Still changeable in Settings > Sound and notifications > Where pop-ups appear. (Existing installs are moved to bottom right once.)
- Launcher: **Left / Right arrows** now move through the results while you are typing (they only moved the text cursor before). Up / Down and Enter work as before.
- Desktop media widget: resized tall and thin, it now stacks (cover, title and artist, buttons, progress) instead of letting the buttons and title run out of the card.
- Lighter on battery and resources:
  - New **Settings > Power > Shell saver** (Auto / On / Off). On (Auto = while on battery): the music beat runs at half speed, breathing animations stop, the media card skips cover blur and glow, and the video wallpaper pauses.
  - The video wallpaper also pauses while a full-screen window covers it.
  - Fewer background checks: network (every 30 s instead of 8; 6 s while a pop-up is open), camera/mic indicator (8 s instead of 4), window watcher (8 s / 0.8 s instead of 4 s / 0.5 s), music position (1 s instead of 0.5 s).
- The error pop-ups for a picture still being written (a fresh screenshot, a clipboard image) and for clicking a window that just closed no longer appear; the notification picture is tried again a few times instead.

## New in 0.3.52

- The clock pop-up is tidier:
  - the tabs are one rounded bar with a pill that slides (with a little spring) to the chosen tab, which shows its name; the others are icons, with a dot on Alarms or Timers while something there is set. The pages fade into each other.
  - Calendar: the month sits on a card, and what is on the chosen day on a card under it, with a proper "nothing on this day" mark.
  - Reminders, Alarms and Timers show a round icon and a line of text when empty; the stopwatch time is bigger and turns accent-coloured, with an accent outline, while it runs.

## New in 0.3.51

- Fixed "ClockPanel.qml: TypeError: Cannot read property 'date' of undefined" (0.3.50): the reminder's time was worked out from a list of days that could still be empty while the page was being made; it is now worked out from the chosen day number directly.

## New in 0.3.50

- The clock pop-up's Alarms page has its own look now (not a copy of a phone app): the number wheels sit in a card with a lit band across the chosen row and "hr / min" beside them; days are rounded chips (Mon ... Sun); sound and snooze are rows with an icon badge, like Settings; alarms in the list are tinted tiles (brighter when on). The date line that was cut off at the top is fixed.
- Reminders and timers use the same number wheels instead of typing a time: a reminder has hour and minute wheels plus a choice of day (today, tomorrow, the next days); press New for a new one, click one to change it. A timer has hour, minute and second wheels, quick buttons (1 min ... 1 hour) that set the wheels, an optional label and Start.
- Stop is immediate: pressing Stop or Snooze on a ringing alarm now cuts the sound that is playing, instead of letting the clip finish.
- Pop-ups no longer cover each other: the ringing card sits nearest the screen edge, the "screenshot saved" card under it and notifications under that; they move out of the way as cards come and go.
- The "screenshot saved" card follows Settings > Sound and notifications > Where pop-ups appear, like notifications and the ringing card.

## New in 0.3.49

- Natural scrolling for the touchpad is on by default, and the switch tells the truth. Before, the install wrote it into hyprland.conf but Settings > Mouse and keyboard (using Hyprland's own default, off) showed it off, so it looked broken and an existing hyprland.lua or older install never had it. Now the shell itself sets `input.touchpad.natural_scroll = true` (in arqen-overrides.conf / arqen.lua) unless you choose otherwise: the switch shows On, turning it off is kept, and the row's reset arrow brings back On. The mouse's own "natural scroll" stays off by default.

## New in 0.3.48

- The Alarms page of the clock pop-up now works like Samsung's clock app:
  - the list: "Alarm in 8 hours 12 minutes" (or "All alarms are off") in the accent colour, a + button, and a card for each alarm with its big time, its name, "Tomorrow-Fri, 16 Oct" or "Every Wed", and a switch. Click a card to change it.
  - making or changing an alarm: two number wheels for the hour and minute (drag, mouse wheel, or click a neighbour; AM / PM beside them on a 12-hour clock), a card with when it rings, round day marks (M T W T F S S, Sunday in red), the alarm name on a line, Sound (on, or a notification only), Snooze (tap for how long and how many times), and Cancel | Save in a pill at the bottom. A bin beside the wheels deletes the alarm.
  - alarms from before keep working, with their snooze settings.
- The other pages (Calendar, Reminders, Timers, World) are unchanged for now.

## New in 0.3.47

- "Where pop-ups appear" (Settings > Sound and notifications) is now a 3 x 3 grid like the one used for the launcher and the on-screen display: click the spot on the screen (top, bottom, left, right, centre and the corners). Default: top centre.
- The ringing card for alarms, reminders and timers follows the same setting as notifications.

## New in 0.3.46

- Desktop widget options box (double-click a widget): it no longer covers the widget's resize corner on a big or scaled screen. It goes beside the widget on the side with more room (narrower if needed); when there is no room beside a big widget it goes below or above it. You can also drag its title to move it out of the way; it returns to its place for the next widget.
- Notification pop-ups now appear at the top centre of the screen by default. Settings > Sound and notifications > Where pop-ups appear: top left / centre / right, bottom left / centre / right. (Before, they followed the first panel's corner.)

## New in 0.3.45

- Microphone input volume:
  - Control centre: a new "Microphone" slider tile (same upright bar as volume and brightness; it shows a crossed-out mic while muted, and moving it unmutes). Right-click it for the input devices and Mute / Unmute microphone. It is in the default layout; if you already arranged your control centre, press edit (the pencil) and add "Microphone" from the tray under the grid. It is left out on a computer with no microphone.
  - Settings > Sound and notifications > Microphone: the input volume slider with a mute button, and the list of microphones to choose from.
- Not run on a real desktop yet.

## New in 0.3.44

- Alarms, reminders and timers now ring until you deal with them. A card drops in at the top of the screen (shaking bell, spreading ring) with Stop / Done, and Snooze when it may be snoozed; the alarm sound repeats until then. Stopping or snoozing ends the sound at once.
- Alarm snooze settings, per alarm: how long to wait before it rings again (1, 5, 10, 15 or 30 minutes) and how many times it may be snoozed (Off, 1, 3, 5 or 10). Set when the alarm is made, and click an alarm in the list to change them. New alarms start at 5 minutes, 3 times.
- An alarm that is not answered snoozes itself after 60 seconds (while it has snoozes left); after the last one it gives up with a "Missed" notification. Reminders and timers ring for 30 seconds. A reminder snoozes for 10 minutes, a timer for "+1 min".
- The panel clock shows a red "Stop" mark while something rings and a snooze mark with a countdown while something is snoozed (snoozes survive a shell restart).
- Not run on a real desktop yet; the alarm sound uses canberra-gtk-play or paplay.

## New in 0.3.43

- The clock pop-up's header shows an added time zone, small, next to the time here (city, its time, "+1d" when it is another day). With several zones added, click it or swipe it sideways to go through them (little dots show which). Add zones on the World page.
- The marks on the panel clock now count down: the soonest timer's time left, the next alarm and reminder as time to go (4:21, 12:05, 2h 05m, 1d 3h), the stopwatch's time, today's next event's time. They tick every second while something is set.
- The World search says "Already added" when the zone you typed is on the list already.

## New in 0.3.42

- Settings > Date and time, from your recording ("Waiting for internet time" for good, and Detect saying "no internet" although the computer is online):
  - Detect now asks five services in turn (ipinfo.io, ipapi.co, ip-api.com, worldtimeapi.org, ipwho.is) and, if none answers, says what each one replied, instead of a plain "no internet".
  - "Waiting for internet time" is now explained: the page checks whether a time service (chronyd or systemd-timesyncd) is running. If none is, a row offers to start it (or install chrony) in a terminal, then syncs the clock. Fedora ships chrony, which `timedatectl set-ntp` does not always start.
  - The Set automatically switch now follows the click at once.
- Still unverified: whether the time zone list picking works for you (the recording ended before a zone was chosen); if it does nothing, the message above the zone row says why.

## New in 0.3.41

- The panel clock shows what is set: small marks beside the time for an alarm, a running timer, the stopwatch, a reminder and an event today (the timer and stopwatch ones breathe). Point at the clock to read them (next alarm, time left on a timer, next reminder...).
- The clock pop-up's calendar now looks like the desktop calendar: weeks start on Monday, today has the accent bar under its number, weekends are in the accent colour, other months fade, the month arrows are plain icons, and the mouse wheel goes through the months. The chosen day is a soft round tile and days with something have a small dot.
- Clicking the clock is animated like the other buttons: a pill lights up under the pointer and stays while the calendar is open, and the clock squashes when pressed and springs back.

## New in 0.3.40

- Fixed "Failed to load configuration ... services/Media.qml: Property value set multiple times" (0.3.37 to 0.3.39): the media service had two handlers for the same change; they are one now. Nothing else changed.

## New in 0.3.39

- Lock screen picture frames are no longer deformed: the heart, circle, arch and blob keep their proportions (the box is square), and the rounded frame is drawn at its real size so its corners stay round.
- Lock screen clock "Gradient" colour: the digits are now drawn with a gradient fill on a canvas (the earlier mask effect left them plain on some setups). The digits may sit a pixel or two differently from the plain colour.

## New in 0.3.38

- The clock on the panel can be clicked. It opens a pop-up (also `qs -c arqen ipc call arqen toggle calendar`) with five pages:
  - Calendar: a month (arrows, click the title for today); a dot marks days that have something; click a day to see and add events (a name and an optional time, e.g. 14:30 or 7pm). An event with a time rings with a notification at that time.
  - Reminders: "Remind me to..." and when (10m, 2h, 14:30, tomorrow 9am, 2026-12-24 18:00), with quick buttons. A reminder that came due while the shell was off rings when it starts again.
  - Alarms: a time, a label and the days (none = once). A switch for each. Rings with a critical notification and an alarm sound (canberra-gtk-play, or paplay as the fallback).
  - Timers and stopwatch: stopwatch with laps; timers from quick buttons or a typed length (25m, 1h30m, 90s), with pause and a progress line; several at once.
  - World: the time in other places. Search any city or time zone (the list is read from the system), click to add; shows the day and the difference from here.
- Everything is kept in ~/.local/state/arqen/clocks.json. The one-second tick only runs while an alarm, reminder, timer or the stopwatch is waiting (or the pop-up is open) and it never starts a program, except one `date` call per added zone to read its UTC offset.
- Not run on a real desktop yet; please report anything off.

## New in 0.3.37

- Settings > Date and time did nothing when a time zone was picked, and showed "Not set". Fixes:
  - the message that says what is happening (asking for the password, done, failed) was at the bottom of the page, out of sight; it is now right above the time zone, in the accent colour when it worked and red when it did not;
  - a permission prompt nobody answers no longer leaves the page stuck: after 30 seconds the terminal way (sudo) is offered, and a second click says it is still waiting;
  - the current time zone is also read from /etc/localtime when timedatectl cannot say, so it is not "Not set" any more;
  - "Time zone from my location" (button "Detect"): looks the zone up from the computer's internet address (one request to ipapi.co, or worldtimeapi.org, only when pressed) and sets it;
  - after a time zone is set, the shell reloads once, since programs keep the zone they started with and the clocks would stay wrong.
- "Set automatically" is network time (the clock is exact); it never knew the time zone. The page now says so.

## New in 0.3.36

- More bounce: Settings > Display > Motion > Bounce (0 - 200 %, default 120 %). It scales every spring in the shell (new config/Motion.qml; each existing overshoot now goes through it, so 0 % switches the springs off and the Animations switch off turns them all off). Buttons and chips squash when pressed and grow a little under the pointer, then spring back; the music card, the display-change box and the power menu now open with a spring; and with Bounce above 0, new windows pop in with a small spring and desktops slide with one (written to Hyprland's file as the curve "arqBounce"; windowsMove is unchanged).
- Costs next to nothing: these are the same short animations as before with a different curve, and nothing runs while idle.

## New in 0.3.35

- Super+H now sends the focused window to the side panel (the same as the window handle's "Minimise to the side panel" button); with that feature off, or when the window is not known yet, it minimises the plain way as before.
- Less CPU, nothing visual removed (found by reading the code, not measured):
  - the camera-in-use check (privacy indicators) started two programs for every running process, every 3 seconds (about a thousand starts each time). It is now one `find` every 4 seconds, and nothing when the computer has no camera device.
  - the Caps / Num Lock light watcher started `cat` twice and `sleep` every 0.15 seconds, for as long as the shell ran (about 20 programs a second). It now reads the two files itself 4 times a second and starts nothing.
  - the window tracker (edge panel and window handle) asked Hyprland through `hyprctl` every 1.5 s (every 0.3 s while a window floats). Now every 4 s (every 0.5 s while a window floats); opening, closing, moving and focusing windows still refresh at once through Hyprland's events.
  - the music position is read every half second only while something is playing (not while paused).
  - the battery ring's safety repaint is every 10 s instead of every second (it repaints at once whenever anything changes).

## New in 0.3.34

- The button size guide (S 32 high, 16 px text, 16 padding, icon 16 | M 44 high, 20 icon, 24 padding | L 52 high, 24 icon, 32 padding; icon-only buttons are squares of the same height) applied to the buttons that were still hand-drawn with their own sizes. ArqButton (about 120 buttons) and the settings chips were already on it. Now also: the capture bar (mode and kind switches, round capture button 52, draw and close buttons 44, sound chips 32), the drawing toolbars (32 squares, 16 icons), the "Add panel" button, the recording label, the keyboard-shortcut recorder, dropdown rows, segmented switches, the reset button (52), the notification reply button (44), the lock screen's go button and the desktop remove button (32).
- Not changed on purpose: panel items and tray buttons (their size follows the panel's own size setting), round icon badges that are not buttons (search results, errors), the screen recording handle and anything inside the lock-screen clock.

## New in 0.3.33

- "Open" next to the wallpapers folder (and every other "open this folder" button: screenshots, recordings, Desktop, plugins, search) opened a terminal. `xdg-open` uses whatever is set for folders, and on some systems that is a terminal file manager (yazi, ranger ...). New scripts/open-folder.sh uses the default only when it is a normal app, otherwise the first graphical file manager it finds (Files, Dolphin, Thunar, Nemo, PCManFM, Caja), and xdg-open only as a last resort.
- Chrome and other Chromium browsers not following dark / light: besides the system setting (which they only follow when their own Mode in Settings > Appearance is "Device"), the browsers' flags files now carry --force-dark-mode while the shell is dark and not while it is light. Flags are read when the browser starts: close the browser fully once and open it again after switching. If it still ignores the mode, check chrome://settings/appearance > Mode = Device.

## New in 0.3.32

- The install / update warning is framed in exclamation marks (red in a terminal) instead of quotation marks.

## New in 0.3.31

- The install / update warning is red (when the output is a terminal; set NO_COLOR to turn that off) and the sentence is in quotation marks.

## New in 0.3.30

- Touchpad gestures: Settings > Desktop (wallpaper page) > "Fingers for the swipes": Automatic, 3 fingers or 4 fingers. Before, the number was fixed and not the same everywhere: 3 with hyprland.conf but 4 with hyprland.lua (a Lua config usually has its own 3-finger swipes, and a second gesture with the same fingers is an error), while the setting was called "Three-finger gestures". Automatic keeps exactly that, now it is visible and can be overridden. The log line "qt.qpa.wayland.input: Unexpected GestureStarted while already active" (shown when the count is changed mid-swipe) no longer becomes a notification.

## New in 0.3.29

- install.sh and update.sh print a warning first: "This shell is written with AI and you may encounter errors. TRY AT YOUR OWN RISK. pls and thank you :)" (once per run; install.sh shows it and its call to update.sh stays quiet). The same note is at the top of this README.

## New in 0.3.28

- Media and function keys, made safe for any keyboard or player: play / pause, next, previous and stop only call what the player says it supports (some players and keyboards logged errors otherwise); "Not available in <player>" is shown when it cannot; no player shows "Nothing playing". Volume, mute and the microphone key say "No sound output" / "No microphone" instead of doing nothing. The brightness keys say "No brightness control" (desktop PC, external screen, brightnessctl missing) instead of running a command that fails.
- New keys: Rewind and Forward (10 seconds back / forward in the playing player) and the Screensaver / Lock key (locks the screen).
- Not added on purpose: the airplane-mode, Wi-Fi, sleep and touchpad keys. Most laptops already handle those themselves (firmware or systemd-logind), and the shell doing it too would switch them twice.

## New in 0.3.27

- "Arqen shell warnings: Could not load icon "?fallback=application-x-executable"": an icon with no name asked Qt for a nameless theme icon. The nameless case now gets the plain executable icon, and "Could not load icon" log lines no longer turn into notifications (the plain icon is drawn instead anyway).

## New in 0.3.26

- Super+H minimises the focused window (to the hidden desktop, from where the dock brings it back). It is one of the shell's shortcuts, so it can be changed or cleared in Settings > Keyboard shortcuts, and it is in the shortcuts list shown at login.

## New in 0.3.25

- install.sh now goes for the hyprland.lua build: it enables the lionheartp/Hyprland COPR first, switches off any other Hyprland COPR (for example ashbuk/Hyprland-Fedora) and moves an already installed older Hyprland over to the lionheartp build. If the system has a hyprland.conf and no hyprland.lua, it runs tools/switch-to-lua.sh: ~/.config/hypr is backed up, the config is converted to hyprland.lua, hyprland.conf is set aside as hyprland.conf.disabled (not deleted: the backup and that file are your way back), and Quickshell is taken from lionheartp too. If Hyprland is older than 0.55 or the conversion fails, nothing is changed and the .conf stays in use.

## New in 0.3.24

- install.sh on a fresh system with Hyprland 0.55+ (which reads hyprland.lua): the starter config it writes is converted to hyprland.lua (with arqen.lua for Settings) before the shell is set up, and hyprland.conf is kept as hyprland.conf.disabled. On older Hyprland it stays hyprland.conf. An existing hyprland.lua or hyprland.conf is still only given the few lines the shell needs.

## New in 0.3.23

- Music card: it stayed open when you clicked elsewhere (seen in your recording: the pointer clicked another window and the card stayed). The focus grab and the focus-change check missed clicks that landed on a window that already had the focus. While the card is open, a see-through window now covers the screen and any click on it closes the card (this includes the rest of the panel: the first click closes the card, the next one works as usual).

## New in 0.3.22

- Image search is now a mode of the capture bar (picture / video / globe-search icon, next to each other), not a small button that fired at once on the default box. Choose it, drag the box over what you want (or pick the screen or a window), adjust it, then press the round button or Enter: the selected part opens in Google Lens. The hint line says "Enter to search the web". The pencil is only offered for pictures.

## New in 0.3.21

- Control centre header: the name card is taller, with a bigger picture and a bolder name. Uptime and battery health are now small chips with icons under the name (they used to be one line that got cut off: "Battery health 69..."). With neither available the computer's name shows instead.

## New in 0.3.20

- Panel battery ring: the ring's level was still NaN while the percentage next to it was right, so the pill's `level` was not picking up the local `pct` shorthand. It now reads the Power service directly (`Power.pct / 100`), exactly the way the Settings > Power ring does, which works. The hover tooltip keeps its debug line.

## New in 0.3.19

- Panel battery ring: the colour is right now (accent at 22%), but the ring's value still read NaN, whatever it was given. The ring's `progress` property is renamed `level` (also in the recording timer and Settings > Power),. The hover tooltip keeps its debug line (ring value and colour).

## New in 0.3.18

- Panel battery ring, found: the tooltip showed the ring's value as NaN and its colour as red at 27%, so the pill was being fed a not-a-number reading from UPower directly (the percentage text re-read it later and looked fine, the ring and colour did not). The pill now takes the level, charging state and low / critical levels from the Power service (the same one Settings > Power uses, whose ring works), with 20 / 10 as fallbacks.

## New in 0.3.17

- The keyboard-shortcuts window (shown at login, Settings > Keyboard shortcuts) is organised: groups (Windows, Desktops, Apps and panels, Screenshots and recording, System, Other), each shortcut described in plain words ("Screenshot a selected area", "Go to the next desktop", "Open a terminal") with the keys as clean caps on the right (Super, Ctrl, PrtSc, arrows as ←/→). Search matches the words, the keys and the group.
- Recording a selection or a window: its edge stays marked while it records. A red frame sits just outside the recorded area (so it is not in the video) with a "REC 0:12" label you can click to stop. Everything else stays click-through.
- Hover the panel's battery pill: the tooltip now shows the battery, whether it is charging, and what the ring is being given (ring %, colour), to help find why its coloured arc does not show.

## New in 0.3.16

- Wave beat simplified: one smooth line that swings up and down with the beat (the old filled ribbon turned into a bow-tie shape in the pill). Fewer swings (6 in the pill, 9 on the card).
- Battery ring: it now also repaints every second while it shows, and falls back to green if its colour ever comes out see-through, so a late battery reading or a lost colour can no longer leave only the grey track.

## New in 0.3.15

- Panel battery ring: the coloured level arc was still missing (only the grey track drew). Changes: the battery's own smoothing animation on the ring is gone (it is the one thing the recording timer, whose arc does show, does not have), the value is clamped directly, and the ring repaints when its canvas becomes ready, when it becomes visible and once shortly after it appears.

## New in 0.3.14

- Ring fix: 0.3.13 drew the ring at twice the size (a scaling mistake), so only a corner of it showed. It now draws at the item's own size, and the colours are handed to the canvas as plain CSS strings.

## New in 0.3.13

- The progress ring (panel battery, recording timer, Settings > Power) is now drawn with a plain 2D Canvas instead of the GPU shape renderer. On your setup the coloured arc was not showing at all (only the grey track), which is why the battery looked grey whatever the charge. Same look as your mock-ups: neutral track, a coloured arc from 9 o'clock clockwise (green charging, accent normally, orange low, red critical), plain inside.

## New in 0.3.12

- Panel battery: as in your reference, only the filled arc of the ring is coloured (green charging, accent normally, orange low, red critical). The track and the inside are neutral again, and the charging bolt is plain text colour.

## New in 0.3.11

- The beat was reworked so nothing jumps or drifts out of line:
  - One drawing, `components/BeatViz.qml`, now serves the panel item, the music card and the desktop media widget. Every bar, dot and point has a fixed place; only heights, sizes and brightness follow the beat (before, bars moved their top edge and height separately, and the wave bars hopped by odd amounts).
  - The values are smoothed once in `services/Beat.qml` (quick rise, slow fall, blended with neighbours; 24 values instead of 16), so shapes stay steady.
  - Styles: Bars (grow from the baseline), Mirror (grow both ways from the middle), Dots (a dot-matrix equaliser like the dotted waveform in your reference, mirrored, brightness changes only), Wave (a smooth mirrored ribbon), Blob (a round shape that swells and turns slowly, like the ferrofluid one; card and desktop widget). Rainbow colouring works on all of them.
  - Settings > Panels > Music: the card can draw the beat differently from the panel item. The media widget has Blob too and up to 32 bars.
- The glow round the cover is visible now (it was drawn underneath the card's own background).

## New in 0.3.10

- Credit logos: cut to the round badge with smooth edges (square avatars used to show hard corners), filling the badge.

## New in 0.3.9

- Panel battery ring: no more grey. The whole ring takes the status colour: green while charging, the accent while discharging normally, orange when low, red when critical; the unfilled part is the same colour, faint. Slightly thicker ring.

## New in 0.3.8

- The music item and its card were reworked (ideas from the GNOME music pill, Noctalia and DankMaterialShell):
  - Card: the controls now sit under the artist, beside the cover, so the title gets the full width; the player's icon shows by its name; the beat is faint behind everything by default, or in a strip of its own (it no longer covers the progress bar).
  - Panel item, Settings > Panels: what it shows (Full / Cover / Title), title width, artist, running-along or cut, previous / play / next right in the pill, cover shape (circle / rounded / square), spin, beat before or after the title.
  - Card options: beat Behind / Bottom / Off, cover blurred behind on or off.
- Credits: logos load at 256 px (shown at 160 px in the list) instead of 64, with the project's own site icon where one exists and the repository avatar as a fallback. Projects owned by one person show that person's GitHub avatar, as they have no logo of their own there.

## New in 0.3.7

- Blur is on by default (and switched on once for existing setups; turn it off in Settings if you prefer).
- Clock widget: the seconds / AM-PM block no longer slides over the date (it used an anchor inside a Row, which Qt ignores). The time is in the accent colour by default.
- Calendar widget: weekends in the accent colour and today underlined by default. When it is small (about 2 x 2 cells) it switches to a compact view: today's date big, with month and year as numbers. Options under "Small size": Auto / Always / Never, Numbers / Words, show the year.
- Screenshot pop-up: the pictures are clipped with real rounded corners (the thumbnail in the small rows is round like a notification's icon; the progress line no longer pokes out of the corners).
- Panel battery: the pill's inside is tinted with the ring colour as well (like the recording pill), so the level colour reads even at a glance.

## New in 0.3.6

- Widgets can be resized again: the corner handle read the pointer in the wrong coordinate space, so pulling it did nothing. It is now a small accent-coloured round handle (grows on hover) and snaps in whole cells.
- The beat always moves things: if cava is missing, or installed but silent, the music widgets and the panel item use a made-up kick-and-shimmer beat (cava is still used when it works, with a PulseAudio fallback if PipeWire is refused).
- The music pop-up on the panel now also closes when focus moves elsewhere (another window, the desktop, another workspace), not only on a focus-grab click.

## New in 0.3.5

- Lock screen: the media bar is smaller (max 380 px wide, 56 px tall, compact controls).
- Buttons follow the size guide: small 32 / medium 44 / large 52 high, with 16 / 24 / 32 padding and the icon + text spacings from the guide. `ArqButton` has `size`, `icon` and icon-only modes; settings choice chips are 32 high (compact 26).
- Panel: the power-profile icon no longer fights the battery pill's layout (removed a stray anchor inside a positioner).
- The harmless "QIODevice::read (QSslSocket)" warning is no longer shown as a notification.

## New in 0.3.4
- The battery ring on the panel shows how much is left by its colour: the accent colour at 100 %, green from just under full down to the low level, orange from the low level to the critical level, red from the critical level to 0 (the levels are Settings > Power > Battery notifications: low 20 % and critical 10 % by default). It still pulses slowly when low and not charging.

## Also in 0.3.3
- The corner handle for resizing a widget could not be pulled: the layer that closes the widget editor on a click elsewhere sat above it and took the click. The handle is now above that layer.
- The clock widget's 12-hour / 24-hour switch: the hour (and AM / PM) is now worked out directly instead of through a format string, in the desktop clock and the lock screen clock.

## Also in 0.3.2
- Fixes "Failed to load configuration ... Toast ... lift is a read-only property" from 0.3.1 (the shell did not start).

## Also in 0.3.1
Nothing was run live; only static checks. Please test and report.

- Settings > Date and time: changing the time zone or turning off "Set automatically" asks the desktop for permission; when no permission prompt can appear (no authentication agent running), the same command runs in a terminal with sudo (your default terminal), so it can no longer silently do nothing.
- Control centre battery tile takes a colour from the power mode: power saver = the tertiary colour, balanced = the plain tile, performance = the accent colour (and a gauge icon).
- Print Screen works on the lock screen: it saves the screen under the pointer to the screenshots folder and shows "Screenshot saved" on the lock screen (no capture screen or "what to do with it" card there).
- The capture screen (screenshot / recording toolbar) follows the system's look: Arqen's colours and pills instead of a fixed dark bar with white icons; mode, picture / video, the capture button and the small tools in one tidy bar.
- Phone battery over Bluetooth: most phones only report a rough 20 % step through the hands-free profile (40 % shown for a phone at 40-59 %). When KDE Connect is installed and the phone is paired with it, its exact battery is used (matched by the phone's name); otherwise the figure shows as "about 40 %" with a hint to install KDE Connect.

## Also in 0.3.0
Nothing was run live; only static checks. Please test and report.

- Notification pop-ups no longer overlap the "screenshot saved" card: both are 420 px wide and the notification sits next to the card (above it, or below at the top of the screen).
- Music widget (desktop) and the music item on the panel move to the beat of what is playing. Needs cava (install.sh now installs it; `sudo dnf install cava`); without it they sway gently instead.
  - Desktop widget (Settings > Desktop > the widget > Moves to the beat): visualizer (Bars, Mirror, Dots, Wave) along the bottom or behind the card, colour (Accent, Text, Rainbow), how many, height, strength, cover beats with the bass, glow round the cover, rings spreading from the cover.
  - Panel (Settings > Panels > Music): Off, Bars, Dots or Wave, colour, and the round cover beating with the bass.
- Credits updated: every project the shell uses now (Hyprland, Quickshell, cava, playerctl, grim and friends, wl-clipboard, cliphist, fonts, Fedora...), each with its project's logo from its GitHub page. A logo that cannot load no longer raises an "Arqen shell error" notification (the plain icon shows).

## Also in 0.2.9
Nothing was run live; only static checks. Please test and report.

- Battery on the panel: the power profile shows beside it (a leaf for power saver, scales for balanced, a gauge for performance); the battery pill is a little shorter.
- 12-hour clocks showed 24-hour time with "PM" beside it (Qt only gives 1-12 when AM/PM is in the format). Fixed in the desktop clock widget, the lock screen clock and the panel clock.
- Widgets are resized by pulling the round corner of the widget while customising it (right-click > Customise or Resize), snapping to the desktop's cells, like the control centre tiles. The Small / Medium / Large buttons are gone; Settings > Desktop still has width and height sliders.

## Also in 0.2.8
Nothing was run live; only static checks. Please test and report.

- Song recognition is removed from the control centre (and from the shell: the tile, its menu, the service, the scripts and the settings entry). Existing setups lose the tile on first start.
- Notification pop-up: two bars along the bottom edge, one from each side, shrink towards the middle as the time runs out (they stay full while the pointer is on it); the ring round the app icon is gone.
- Battery on the panel: a pill whose outline fills with the charge from the middle of its left end, clockwise; dark track and inside in dark mode, light in light mode; green while charging, red when low (and then it slowly pulses); it grows a little under the pointer; a click opens the control centre as before.
- Widgets: changing an option of a widget (or the desktop icons) no longer rebuilds every icon and widget on the desktop, which made the widget go blank for a moment and the editor jump. Only the widget changed is updated.

Also from 0.2.7: real logos in the credits, light-mode notification count, light navigation bar in Settings, clearer "Plugged in or wireless dongles", reset-all report.

Also from 0.2.6: widget options (outline, shadow, size) and compact menus, search jumps to the option, shell prompts use your terminal, Default apps "Trash" fix, GTK dark/light variant fix.

Older notes: see the project history; the credits are in Settings > System.

A Quickshell desktop shell for Hyprland on Fedora.

Fresh Fedora: `./install.sh` (installs Hyprland, Quickshell and everything the shell uses, writes a starter
Hyprland config if there is none, then runs update.sh). Log out, pick Hyprland, and run `./update.sh` once more
from inside Hyprland. Already installed: `./update.sh` after unpacking a new version.

- Panel items: desktop indicator (opens the desktop view; dots, numbers, roman, letters, Japanese or boxes), search, launcher button, dock, app status icons (Steam, Heroic, ...), control centre button (opens the right-hand sidebar: toggles, volume, screenshot, notifications), two-line clock
- Panels: add as many as you like (one per edge or several on one edge), each with its own edge, alignment, length and thickness
- Right-click a panel to edit it on screen: drag items to move them, the red x removes one, the blue corner resizes one item (double-click resets it), pull the bars at its ends (length) or on its inner edge (thickness), add items or panels from the card in the middle
- Panels can hide automatically (Settings > Panels): they give windows the room and come back when the pointer touches that edge
- Panels grow by themselves (longer, or thicker) when their items do not fit the size you set
- Sizes: app icons, other items, and the clock font are separate (Settings > Panels and Panel items)
- Popups: launcher (Super key), search (Super+Space, finds apps and settings), sidebar, calendar, recents / desktop view (live thumbnails of every desktop, + button adds a desktop)
- Settings app (Super+I): changes the shell AND Hyprland (gaps, rounding, blur, scale) with no dotfile editing
- Mouse and keyboard, Hyprland (all other compositor options) and Date and time have their own Settings pages
- Config lives in ~/.config/arqen/config.json; Hyprland values go to ~/.config/hypr/arqen-overrides.conf

Control centre (the sidebar):
- Opens on the side of the screen where the panel's control centre button is (next to a vertical panel it opens on that side)
- Tiles: click = do it, right-click = options (Wi-Fi networks and password prompt, Bluetooth devices and pairing, sound outputs, night light warmth, caffeine timers, accent colours ...)
- Pencil button (or press and hold a tile): the grid's cells show; every tile keeps its own place. Drag a tile onto free cells (outlined in the accent colour; red means it does not fit) or onto another tile to swap the two; nothing else moves. Pull the corner to resize (as far as the free cells allow), red button hides, "Add tiles" puts hidden ones in the first free spot
- Caffeine keeps the screen from locking or sleeping (systemd inhibitor + Wayland idle inhibitor); the panel shows a cup while it is on
- Header buttons: pencil (edit tiles), reload (restarts the shell in place), settings, power (lock, sleep, log out, restart, shut down)
- Layout is saved as `ccTiles` in ~/.config/arqen/config.json

Desktop (Settings > Desktop):
- Apps and widgets (clock, calendar, status) on a grid behind your windows
- Add an app: open the launcher, press and hold the app, drag it onto the desktop, let go
- Click an app to open it; press and hold an icon or widget, drag it, let go: it snaps to the nearest free spot (two icons swap)
- Files and folders: everything in ~/Desktop shows on the grid. Right-click the desktop for New folder / New text file;
  right-click a file to open, rename, copy its path or move it to the trash
- Drag files or folders from Files onto the desktop: moved there (copied when they come from another disk)
- Right-click the desktop: new folder / file, change wallpaper, display settings, settings. Right-click an app or widget to remove it;
  widgets are added in Settings > Desktop
- "Reset positions" puts everything back in order

Bluetooth: devices are found and connected through the system's own Bluetooth service, with a pairing agent of its own (stops scanning first, then pairs, trusts
and connects). Put the device in pairing mode, then Pair in the Bluetooth tile menu or Settings > Connections.

Notifications: click one (pop-up or the list in the control centre) for its options: the app's own buttons,
Open (its window or its default action), Copy, Dismiss. The x dismisses straight away. The pop-up stays while
the pointer is on it.

Name tips: rest the pointer on a panel item, dock app, tray icon, tile or desktop icon and its name shows
(after 2 seconds by default; Settings > Style and wallpaper > Name tips).

Windows (Settings > Display and windows):
- Apps open floating and centred
- Drag any window by its very top: an invisible strip just above each window (Hyprland's hyprbars plugin, no
  title and no buttons; ./update.sh sets it up once, log in ~/.cache/arqen-window-drag.log). Double-click it to maximise
- Gaps, corner radius, border width, blur and animations
- An app's own minimise button works (or `qs -c arqen ipc call arqen minimize`): the window waits on a hidden
  desktop, its dock icon is faded; click it to bring the window back
- Arqen Settings has its own icon and launcher entry

Wallpaper: pictures or videos (mp4, webm, mkv, mov; silent, looping) from ~/Pictures/Wallpapers. "Accent colour from the
wallpaper" picks the accent from the picture, or from a frame of the video. Videos need qt6-qtmultimedia (update.sh installs it).

Other apps (Settings > Fonts, themes and cursor): GNOME / GTK / libadwaita, Flatpak and Qt apps follow dark / light mode
and the accent colour (exact colour through gtk.css and qt6ct, nearest GNOME accent for apps that only know those).
Font, app theme, icons and cursor are picked from lists of what is installed. scripts/apply-theme.sh does the work.
The icon theme also applies to the shell itself (launcher, search, dock, desktop); it restarts once to switch.
Shell blur and transparency are on the same page.

Control centre header: your picture, name and computer; click it to change the picture (Settings > About).

Desktop portal: update.sh sets up xdg-desktop-portal for Hyprland (file pickers, screen sharing) and stops the
"Failed to register with host portal" warning.

Clipboard:
- Its own panel button (move or remove it like any other item); the popup opens next to it, type to search
- Needs cliphist + wl-clipboard (both in install.sh). It stores everything you copy, passwords included; "Clear" wipes it
- `qs -c arqen ipc call arqen toggle clipboard` opens it from a keybind

Install:  ./install.sh      Test run (inside Hyprland):  qs -c arqen
IPC:      qs -c arqen ipc call arqen toggle search|quick|notifs|clipboard|calendar|overview
          qs -c arqen ipc call arqen settings wallpaper

Layout: quickshell/arqen/{config,services,components,modules,settings}

Launcher: opened with the Super key (grid or list, size and icon size in Settings > Launcher and search).

Desktops: click the indicator on a panel (or swipe up with three fingers) to see every desktop.
Click a desktop to go to it, drag a window onto another desktop to move it, drag it onto the monitor
button to give it a new desktop. Three-finger swipe left / right changes desktop, swipe down closes the view.

hyprland.lua (Hyprland 0.55+, e.g. the lionheartp COPR):  tools/switch-to-lua.sh, then log out and in.
- Backs up ~/.config/hypr to ~/.config/hypr.bak-before-lua-<date>, converts hyprland.conf and the files it
  sources with the bundled hyprlang2lua (tools/, MIT), and renames hyprland.conf to hyprland.conf.disabled
- Takes Quickshell from the lionheartp COPR and disables the errornointernet/quickshell COPR
- The shell finds out by itself which config Hyprland runs: with Lua it writes ~/.config/hypr/arqen.lua
  (loaded at the end of hyprland.lua) instead of arqen-overrides.conf, and sends Lua dispatches
- Settings > Advanced shows which one is in use. Errors: hyprctl configerrors. Log: ~/.cache/arqen-switch-to-lua.log
- Back to hyprland.conf: tools/switch-to-conf.sh

Saved passwords: ./update.sh runs quickshell/arqen/scripts/keyring.sh (also Settings > System > Set up). It adds
pam_gnome_keyring to every login screen's PAM file (GDM, SDDM, LightDM, LXDM, ly, greetd, text console; backups as
*.bak-arqen-<date>) so your login password unlocks the "login" keyring, and gives Chromium-family browsers (Chrome,
Chromium, Brave, Vivaldi, Edge, Opera; normal and Flatpak) --password-store=gnome-libsecret. Log: ~/.cache/arqen-keyring.log

Blur and transparency: Settings > Appearance > Effects. One Blur switch covers panels, popups, menus, the desktop,
the overview and windows; Transparency sets how see-through the shell (and the Settings window) is.

Keyboard shortcuts (Settings > Keyboard shortcuts): every shortcut Hyprland has, readable. Make your own (open an
app or run a command), change one, or turn one off. Your changes go into the file Arqen writes for Hyprland
(arqen.lua / arqen-overrides.conf), never into your own hyprland config.

Default apps (Settings > Default apps): browser, email, files, terminal, text editor, pictures, videos, music, PDFs
and archives, picked from the installed apps that can open them (saved in ~/.config/mimeapps.list).

Password prompts: Arqen is the polkit agent when no other one runs, so admin actions show its own password popup.
If none can be shown, "Show" for serial numbers opens a terminal that asks with sudo instead.

Control centre: a 6-column grid of square cells. In edit mode (pencil, or press and hold a tile) drag a tile to
move it, pull the white arc at its bottom-right corner to make it 1 to 6 cells wide and tall (a tall slider stands
upright), the white "−" hides it. Screenshot tile: click for a screenshot or recording of the whole screen, a window
(click it) or a region (draw a box); click again while recording to stop.
Image search (panel item and control-centre tile): draw a box on the screen; your default browser opens a web
image search for it.

Wallpaper transitions (Settings > Appearance > Wallpaper): none, fade, slide, push, zoom, wipe, circle or blur, with
a speed slider. The accent colour glides to the new colour instead of jumping.
On-screen display (Settings > Display and windows), drawn like the control centre's sliders: volume, mute, microphone, brightness, keyboard light, play /
pause / next / previous / stop, Caps Lock and Num Lock keys are handled by Arqen and show a small display; choose
where it appears and whether it lies flat or stands up. Turn "Media and lock keys" off to keep your own key bindings.

Capture screen (Print key, the control centre's Screenshot tile, or `qs -c arqen ipc call arqen toggle capture`):
Selection / Screen / Window, picture or video, sound for recordings (none, system sound, microphone). Drag to draw,
move the box or pull its handles, then the round button or Enter. For pictures the screen is frozen the moment the
capture screen is asked for, exactly as it is (panels and any open pop-up included), so nothing changes before you take it (not for videos). Recording a window shows a row of
app icons from every workspace: pick one and it is brought to the front so the recorder can see it. While
recording, a red timer ring sits on the panel next to the battery: click it (or the tile, or Print) to stop.
You get a notification when a screenshot is taken, when a recording starts and when it is saved; click the
screenshot or saved-recording notification to open its folder with the file selected.
Settings has a search field at the top.

Switches throughout the shell use the track-and-knob style.

Settings: a round arrow next to a setting appears when it differs from the default; click it to put that one
setting back. System > "Reset all settings to the defaults" puts everything back (it can keep your wallpaper,
pinned apps, desktop and shortcuts) and saves a copy of the old settings as ~/.config/arqen/config.backup-*.json.
Sliders move in single steps (1 px, 1 %, 1 pt, 0.1 s); the mouse wheel moves one step.
Caps Lock / Num Lock: the on-screen display follows the keyboard lights, so it shows however they change.

Appearance (Settings): light / dark as two previews; one "Accent colour" card with the palette squircle (primary,
secondary, tertiary). "From wallpaper" on: the colours come from the wallpaper and the wheel is greyed out. Off:
pick each of the three on the colour wheel (secondary and tertiary can go back to "Automatic"). Fonts, app theme,
icons and cursor are on the same page now. Rounded corners > Screen corners rounds the screen's own corners.
Panels > Islands: the left, centre and right groups of a panel each sit on their own pill.
Clicking through wallpapers quickly only loads the one you stop on.

Settings > Sound and notifications: volume and output, Do not disturb and pop-up time, and system sounds: pick a
sound theme (default: the standard freedesktop sounds) and which events play one (notifications, volume keys, screenshots, charger and low
battery), each with a play button. Settings > Panels now also holds the dock, clock, desktop indicator, control
centre tiles and clipboard; add / edit / remove panel buttons sit together under the panel preview.

On-screen keyboard (panel item "On-screen keyboard", or `qs -c arqen ipc call arqen toggle keyboard`): sits along the
bottom (windows make room) and types into the window you were using (needs wtype; ./update.sh installs it). Keys with
numbers, symbols, Ctrl / Alt, arrows, hold to repeat; the globe button changes language (English, French, German,
Spanish, Portuguese, Italian, Swahili, Russian, Ukrainian, Greek, Arabic, Hindi; pick yours in Settings > Panels).
Emoji by category or search; GIFs from GIPHY (paste a free API key in Settings > Panels > On-screen keyboard):
click inserts, right-click to download (~/Pictures/GIFs), copy, or copy the link. Search by tapping the search box
and typing on the keyboard.
Control centre: on tiles like Wi-Fi, Bluetooth, sound, battery (power saver), the round icon switches it on / off;
the rest of the tile opens its options (as a right-click does).
Desktop indicator: "custom" uses your own characters (Settings > Panels > Desktop indicator).

Display and windows > Screens: each screen (more show up when plugged in) gets resolution, refresh rate, scale,
rotation, position next to the others and on / off. Changes are only staged: the arrangement shows how the screens
will look (changed ones are outlined), and you can change as many things as you like before pressing Apply (or
Discard). After Apply, "Keep these display settings?" appears on every screen and everything goes back by itself
after 10 s (Esc = back, Enter = keep). Window borders use the primary accent colour.

On-screen keyboard: about 50 languages now (European, African, Middle-Eastern, Indian, Asian scripts; Japanese kana and
Korean jamo are typed as single characters, without an input method). Drag the dots at its top left to put it
anywhere; it stays there next time, and the button beside the close button (or Settings > Panels) puts it back.
Panels: when the items do not fit (a big screen scale), the app dock folds into one button with an arrow; click it
for the apps.
Settings > Power: the battery, power mode, notifications when charged / low / critically low (each with its own
percentage, and what to do at critically low).

Panels that do not fit (big screen scale): step by step, only as far as needed: less space between items and the dock
folds into an apps button; then the whole centre group folds into one "…" button with an arrow (click it for a strip
with its items); then all items get a little smaller.
Flatpak apps: ./update.sh adds Flathub for your user (no password) to install the adw-gtk3 theme for GTK3 Flatpak
apps, and lets Flatpak apps read the shell's GTK and Qt settings. Scale 175 % is gone (Hyprland refuses it on most
screens; a saved 1.75 becomes automatic).
Errors: Hyprland config errors and the shell's own errors / warnings show up as notifications (Settings > System >
Problems to turn it off).

Fixes: panels no longer flicker while fitting at 200 % (the panel's own thickness restarted the fitting); a window
without an app name (a browser's picture-in-picture) no longer lights up pinned apps as open; running Steam games
get their icon from Steam's own downloads when no icon theme has one; desktop file and folder icons follow the
icon theme.

Emoji: every flag (all countries and regions, England, Scotland, Wales, chequered, pirate ...; flags that look the
same as another are left out). Notification pop-ups show a ring round the app icon that empties over the pop-up
time (full again while the pointer is on it). Settings > Power: critically low starts at 10 %.
Motion: pop-ups, the control centre, notifications, the keyboard and settings pages spring in; buttons, chips,
tiles, dock and launcher icons react to the pointer. Every slider uses the control centre's rounded style.

The control centre's contents (header, tiles, notifications) pop in one after another every time it opens.

Notification pop-ups you click open
stay until you click somewhere else (then their time runs again) or pick one of their options.

Edge panel: a floating window dragged (almost) off the screen (three quarters by default, Settings > Desktop > Windows
pushed off the screen) is tucked away into a small panel on the screen edge, a thin line until you click it.
Click an icon there to bring that window back to the desktop you are on, all of it on the screen; middle-click
closes it. Drag the line (or the open panel's grip) to any screen edge; it stays there. Tucked windows also show
faded in the dock, and clicking them there brings them back too.

Faster launcher and search: shortcuts reach the shell through a pipe (scripts/ipc, a couple of milliseconds)
instead of starting `qs ipc call` (which loads Qt first); update.sh switches your existing shortcuts over. The
launcher only builds the rows you can see, search results are cached, and apps start before the bookkeeping.
The control centre button shows how many notifications are waiting (grey with Do not disturb on).

Screenshots and screen recordings are saved in ~/Pictures/Screenshots and ~/Videos/Screenrecordings by default;
Settings > Desktop > Screenshots and recordings changes either with the system's folder picker (reset arrow = back
to the default). The control centre's folder buttons and the search's quick folders follow it.

Lock, sleep, log out, restart and shut down first show a full-screen countdown (30 s by default) over every screen:
Esc or Cancel stops it, Enter or the "now" button skips the wait. Settings > Power sets its length (0 = off), its
look (Ring, Big number, Bar, Glass, Pulse) and where it sits (centre, top, bottom, left, right), with a preview.

Power menu: the control centre's power button opens a full-screen, blurred menu with big round buttons in the theme's
colours (power off, restart, log out, sleep, lock) and a shortcut to Settings > Power. The countdown before them is
blurred too (looks: Ring, Big number, Bar, Glass). On-screen keyboard: the split button puts half the keys at each
side of the screen (remembered).

Lock screen (Settings > Lock screen, with a live preview): the shell's own, like a phone's. Choose the clock (big,
stacked or small; its size, accent or white, at the top or in the middle; 24-hour), the date, a message under the
clock, your picture and name, battery and waiting notifications, what is playing, and the background (your
wallpaper or another picture, how blurred and how dark). Type your password (checked with the system's normal login
rules, PAM). Hyprlock is no longer used: update.sh points lock shortcuts at Arqen's lock, moves hyprlock.conf to the
bin and removes the program. If the shell ever stops while locked, Hyprland keeps the screen locked: switch to a
text console (Ctrl+Alt+F3), sign in and run `loginctl unlock-session`. The login screen (GDM) is a separate program
that cannot be themed by the shell.

When you leave it alone (Settings > Power): dim the screen, turn it off, lock, sleep, each after its own number of
minutes (0 = never), and whether it locks before sleeping. Playing a video, Caffeine and apps that ask to stay
awake hold all of them off. The shell does this itself; do not also run hypridle.

Laptop or desktop (Settings > Power > This computer): found from the hardware (and whether there is a battery), or
set by hand. Laptops also get: sleeping on battery and plugged in separately, and what closing the lid does (sleep,
lock, screen off, nothing, hibernate, shut down; on battery and plugged in), with "keep working on another screen"
when a monitor is plugged in.

Bluetooth: the control centre button shows each connected device as what it is (earbuds, headphones, headset,
speaker, controller, keyboard, mouse, watch, phone...) with a small battery that fills with its charge. Settings >
Wi-Fi and Bluetooth shows each connected device with its icon and battery ring, Left / Right ear checks for sound
devices, and "Try it" for mice and keyboards: point at the mouse drawing and click or scroll, or click the keyboard
drawing and type, and what you press lights up (other programs can't read a keyboard or mouse themselves, so this
shows what reaches the window). Nothing moves unless you are trying a device. When pairing fails, the message says
what to do (for example "it has forgotten this computer: Forget it and pair again"). (Many earbuds, AirPods among
them, only tell phones their battery.)

Devices (Settings > Wi-Fi and Bluetooth): Bluetooth devices, and under "Other devices" everything on a cable or behind a
2.4 GHz receiver (dongle), with its battery when the driver reports one. (The game controller tester, button swapping
and the mouse tester were removed.)

Media: the panel's media item shows the cover going round, dancing bars and the title while something plays (gone
when nothing does); click it for the media card (cover, a progress line you can drag, previous / play / next),
middle-click to pause. The same card is a desktop widget (right-click the desktop > Add the media widget).

After a screenshot or recording (Settings > Desktop): a preview slides into the corner with Save, Copy, Edit
(satty or swappy when installed), Rename, Save and show in folder, and Delete. Left alone it saves by itself after
6 s (a ring round Save shows the time; resting the pointer on it waits). "Just save" skips the preview.

Window handle (Settings > Display and windows): the window you are using has a short line at its top. Drag the line
to move the window; click it and a small bar opens: hold the move button and drag, maximise, full screen, snap to a
side, tuck into the edge panel, close. Esc, another window or a few seconds left alone close it. Colour (your accent
colour, or any colour you pick) and size can be changed.

Notifications while a window is full screen (Settings > Sound and notifications): pop-ups can be kept away (the
default) or shown; they still go to the list either way.

Notifications look and behave like a phone's (One UI): rounded cards with the app's icon (a message shows the
sender's picture with the app as a small badge), the title and time, one line of text and the picture that came
with it (a screenshot shows its thumbnail). Several from one app stack up with their number; click the number to
open the stack, the arrow to open one notification (all its text, a big picture, the app's buttons across the
bottom and a reply box for apps that take replies). Swipe a card, or a whole stack, sideways to clear it.

The countdown's animation can be changed (Settings > Power menu): how it comes in (zoom, fade, rise, drop), how the
number changes each second (pop, slide, flip, fade, roll, none), whether the ring / bar runs smoothly or steps,
the speed, its colour and how dark the screen behind gets.

Plugins (Settings > Plugins; the guide: quickshell/arqen/PLUGINS.md): desktop widgets, panel items,
control centre buttons, windows of their own and background helpers, written in QML with Quickshell using the
shell's own pieces (so they match its look). They live in ~/.config/quickshell/widgets, one folder each. Import
them from a .zip / .tar.gz / folder anywhere; click one for its settings, Export (to share), Folder and Remove;
the switch turns it on and off. The built-in wallpaper settings handle wallpaper selection; no separate wallpaper-picker plugin is bundled. (Noctalia plugin support,
the plugin maker and the media player / controller mapper examples were removed.)

Panels sit on the screen edge by default; Settings > Panels > Floating panels lifts them off it (by the gap).
Settings has its own pages for the lock screen and the power menu, and its animations are calmer.

The desktop's Status widget is gone (saved ones are removed). Several notifications can be open at once;
a click on empty space closes them all.

Keyboard shortcuts: the shell's own (Settings > Keyboard shortcuts > Arqen: Settings Super+I, search Super+Space,
desktops Super+Tab, control centre Super+N, clipboard Super+V, screenshot Super+Shift+S, lock Super+L, power
menu Ctrl+Alt+Delete, full screen, maximise) are written by Arqen to its Hyprland file, which is now read last
(update.sh moves its `source` line to the end of hyprland.conf), so they always work. Click one and press new
keys to change it (Backspace: none); each has a reset arrow.

Panels keep their size on the screen when you change the screen scale (Settings > Panels > With the screen
scale: "Follow the scale" for the old way). The control centre button shows the notifications, then connected
devices with their battery percentage, then Wi-Fi. "Percentage on the panel" (Settings > Power) now does what it
says. Solid surfaces and no blur are the defaults (the Reset button of Appearance > Effects goes back to them).
Wallpapers are decoded at the screen's full pixel size (sharp at any scale and for wide pictures).

Section headers in Settings have a Reset button that puts the whole section back to its defaults.
System sounds (Settings > Sound and notifications) work like KDE's chooser: a card per sound theme with its
description, a play button and buttons to hear each of its sounds; and each event (notifications, volume keys,
screenshots, charger and battery, devices connected, urgent notifications) can have its own sound from any
installed theme. The plugin guide (quickshell/arqen/PLUGINS.md, or Settings > Plugins > Guide) is now a step-by-step tutorial.

## Wi-Fi and Bluetooth

Arqen uses what every distro already has: NetworkManager for Wi-Fi, hotspot and Ethernet, and the system Bluetooth service for Bluetooth. It installs, replaces and removes nothing there (the old `install-bluez.sh` and `uninstall-other-bluetooth.sh` are gone).
