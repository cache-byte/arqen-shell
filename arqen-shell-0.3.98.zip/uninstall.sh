#!/usr/bin/env bash
# Arqen shell uninstaller: stops the shell and removes its files. Packages are left alone.
set -euo pipefail
CONFIG_HOME="${XDG_CONFIG_HOME:-$HOME/.config}"
DATA="${XDG_DATA_HOME:-$HOME/.local/share}"
yn() { local r; read -r -p "$1 [y/N] " r || r=n; [[ "${r:-n}" =~ ^[yY] ]]; }

echo "Arqen shell uninstaller"
pkill -f "qs.* -c arqen" 2>/dev/null || true
rm -rf "$CONFIG_HOME/quickshell/arqen" && echo "removed the shell ($CONFIG_HOME/quickshell/arqen)"
rm -f "$DATA/applications/org.arqen.Settings.desktop" "$DATA/icons/hicolor/scalable/apps/org.arqen.Settings.svg"
rm -f "$CONFIG_HOME/hypr/arqen-overrides.conf" "$CONFIG_HOME/hypr/arqen.lua" && echo "removed the Hyprland settings Arqen wrote"
echo "Your hyprland.conf / hyprland.lua still starts the shell: delete the lines that mention arqen,"
echo "or restore the backup next to it (hyprland.*.bak-<date>)."
if yn "Also delete your Arqen settings (~/.config/arqen)?"; then rm -rf "$CONFIG_HOME/arqen"; echo "removed"; fi
# an old Arqen login screen (greetd) from an earlier build: hand the login back to the previous manager
if [ -d /var/lib/arqen-greeter ]; then
  prev="$(cat /var/lib/arqen-greeter/previous-dm 2>/dev/null || echo gdm.service)"; case "$prev" in *.service) ;; *) prev="$prev.service" ;; esac
  if yn "Found an old Arqen login screen. Switch the login manager back to $prev?"; then
    sudo systemctl disable greetd.service 2>/dev/null || true; sudo systemctl enable --force "$prev" >/dev/null
    [ -f /etc/greetd/config.toml.arqen-backup ] && sudo mv -f /etc/greetd/config.toml.arqen-backup /etc/greetd/config.toml || true
    sudo rm -rf /usr/share/arqen-greeter /var/lib/arqen-greeter; echo "login manager restored (takes effect next boot)"
  fi
fi
echo "Done. Icons, cursors and packages installed by install.sh were left alone."
