#!/usr/bin/env bash
# Install / update Arqen shell in place. Also moves an install made under its previous name
# (settings, Hyprland files, keybinds, session target). Backups are kept.
set -euo pipefail

# ---- warning (shown once per run: install.sh shows it and update.sh, which it calls, stays quiet) ----
if [ -z "${ARQEN_WARNED:-}" ]; then
  export ARQEN_WARNED=1
  R=""; N=""
  if [ -t 1 ] && [ -z "${NO_COLOR:-}" ]; then R=$'\033[1;31m'; N=$'\033[0m'; fi
  printf '\n'
  printf '%s  !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!%s\n' "$R" "$N"
  printf '%s   !!!!!!!!!!!!!!!!!!!!!!!!!!!!!  WARNING  !!!!!!!!!!!!!!!!!!!!!!!!!!!!!%s\n' "$R" "$N"
  printf '%s   !!!  This shell is written with AI and you may encounter errors.  !!!%s\n' "$R" "$N"
  printf '%s   !!!  TRY AT YOUR OWN RISK. pls and thank you :)  !!!%s\n' "$R" "$N"
  printf '%s  !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!%s\n' "$R" "$N"
  printf '\n'
fi
HERE="$(cd "$(dirname "$0")" && pwd)"
CFG="$HOME/.config"
STAMP="$(date +%Y%m%d-%H%M%S)"

mkdir -p "$CFG/quickshell" "$CFG/arqen" "$CFG/hypr"

# ---- remove the retired built-in Wallpaper Picker plugin -----------------
# Only remove folders whose manifest explicitly identifies the old sample plugin.
# Other user-installed plugins are left untouched.
WIDGETS="$CFG/quickshell/widgets"
if [ -d "$WIDGETS" ]; then
  while IFS= read -r -d '' manifest; do
    if python3 -I - "$manifest" <<'PYREMOVE'
import json, sys
try:
    with open(sys.argv[1], encoding="utf-8") as f:
        data = json.load(f)
    raise SystemExit(0 if data.get("id") == "wallpaper-picker" else 1)
except (OSError, ValueError, TypeError):
    raise SystemExit(1)
PYREMOVE
    then
      plugin_dir="$(dirname "$manifest")"
      rm -rf -- "$plugin_dir"
      echo "Removed retired Wallpaper Picker plugin: $plugin_dir"
    fi
  done < <(find "$WIDGETS" -mindepth 2 -maxdepth 2 -type f -name manifest.json -print0)
fi

# ---- move over from the previous name ------------------------------------
OLD="insomny"
if [ -d "$CFG/$OLD" ] && [ ! -f "$CFG/arqen/config.json" ]; then
  cp -a "$CFG/$OLD/." "$CFG/arqen/"
  echo "Copied your settings: ~/.config/$OLD -> ~/.config/arqen (old folder left in place)"
fi
[ -f "$CFG/hypr/$OLD-overrides.conf" ] && [ ! -f "$CFG/hypr/arqen-overrides.conf" ] && cp "$CFG/hypr/$OLD-overrides.conf" "$CFG/hypr/arqen-overrides.conf"
[ -f "$CFG/hypr/$OLD.lua" ] && [ ! -f "$CFG/hypr/arqen.lua" ] && cp "$CFG/hypr/$OLD.lua" "$CFG/hypr/arqen.lua"
# hyprland.conf / hyprland.lua and the files next to them: qs -c, ipc call, require, source, session
# target, keybind descriptions - also from the name before that ("dex")
for f in "$CFG"/hypr/*.conf "$CFG"/hypr/*.lua "$CFG"/hypr/*/*.conf "$CFG"/hypr/*/*.lua; do
  [ -f "$f" ] || continue
  case "$f" in */$OLD-overrides.conf|*/$OLD.lua|*/arqen-overrides.conf|*/arqen.lua) continue ;; esac
  if grep -qE "$OLD|qs -c dex|ipc call dex|(^|[^A-Za-z0-9_])dex-" "$f"; then
    cp "$f" "$f.bak-rename-$STAMP"
    sed -i -E "s/qs -c (dex|$OLD)([^A-Za-z0-9_-]|$)/qs -c arqen\2/g; s/ipc call (dex|$OLD)([^A-Za-z0-9_-]|$)/ipc call arqen\2/g; s/(^|[^A-Za-z0-9_])(dex|$OLD)-/\1arqen-/g; s/$OLD/arqen/g" "$f"
    echo "Updated $(basename "$f") for the new name (backup: $(basename "$f").bak-rename-$STAMP)"
    RENAMED=1
  fi
done
# a Lua variable still called "dex" (local dex = "qs -c ... ipc call ...") and its uses
for f in "$CFG"/hypr/*.lua "$CFG"/hypr/*/*.lua; do
  [ -f "$f" ] || continue
  if grep -qE '^[[:space:]]*local[[:space:]]+dex[[:space:]]*=' "$f"; then
    [ -f "$f.bak-rename-$STAMP" ] || cp "$f" "$f.bak-rename-$STAMP"
    sed -i -E 's/(^|[^A-Za-z0-9_.-])dex([^A-Za-z0-9_-]|$)/\1arqen\2/g' "$f"
    echo "Renamed the \"dex\" variable in $(basename "$f")"; RENAMED=1
  fi
done
# the calendar popup is gone: drop keys bound to it
for f in "$CFG"/hypr/*.conf "$CFG"/hypr/*.lua "$CFG"/hypr/*/*.conf "$CFG"/hypr/*/*.lua; do
  [ -f "$f" ] || continue
  case "$f" in */arqen-overrides.conf|*/arqen.lua) continue ;; esac
  if grep -q 'toggle calendar' "$f"; then
    [ -f "$f.bak-rename-$STAMP" ] || cp "$f" "$f.bak-rename-$STAMP"
    sed -i '/toggle calendar/d' "$f"
    echo "Removed the calendar shortcut from $(basename "$f")"; RENAMED=1
  fi
done
# names inside your settings (e.g. a pinned "Settings" app)
[ -f "$CFG/arqen/config.json" ] && grep -q "$OLD" "$CFG/arqen/config.json" && sed -i "s/$OLD/arqen/g" "$CFG/arqen/config.json"
[ -n "${RENAMED:-}" ] && [ -n "${HYPRLAND_INSTANCE_SIGNATURE:-}" ] && hyprctl reload >/dev/null 2>&1 || true
rm -rf "$CFG/quickshell/$OLD"
rm -f "$HOME/.local/share/applications/$OLD-settings.desktop" "$HOME/.local/share/icons/hicolor/scalable/apps/$OLD-settings.svg"
if [ -f "$CFG/systemd/user/$OLD-session.target" ]; then
  rm -f "$CFG/systemd/user/$OLD-session.target"
  systemctl --user daemon-reload 2>/dev/null || true
fi

# Keyboard shortcuts reach the shell through scripts/ipc now (a pipe: the launcher opens at once;
# `qs ipc call` first had to load Qt). Switch the shortcuts in your Hyprland files over.
for f in "$CFG"/hypr/*.conf "$CFG"/hypr/*.lua "$CFG"/hypr/*/*.conf "$CFG"/hypr/*/*.lua; do
  [ -f "$f" ] || continue
  case "$f" in */arqen-overrides.conf|*/arqen.lua) continue ;; esac
  if grep -q 'qs -c arqen ipc call arqen ' "$f"; then
    cp "$f" "$f.bak-ipc-$STAMP"
    sed -i 's#qs -c arqen ipc call arqen #~/.config/quickshell/arqen/scripts/ipc call arqen #g' "$f"
    echo "Faster shortcuts: updated $(basename "$f") (backup: $(basename "$f").bak-ipc-$STAMP)"
    IPCMIG=1
  fi
done

# The shell must be started once at login, not twice (two shells = every panel twice). If the Hyprland
# files start it more than once, keep the first start and take out the rest (backup kept).
for f in "$CFG"/hypr/hyprland.lua "$CFG"/hypr/hyprland.conf; do
  [ -f "$f" ] || continue
  if python3 -I - "$f" "$STAMP" <<'DEDUP'
import re, shutil, sys
path, stamp = sys.argv[1], sys.argv[2]
text = open(path, encoding="utf-8", errors="replace").read()
lines = text.split("\n")
def starts(l):
    s = l.strip()
    return "qs -c arqen" in s and " ipc " not in s and not s.startswith(("#", "--"))
idx = [i for i, l in enumerate(lines) if starts(l)]
if len(idx) <= 1:
    sys.exit(1)
drop = set()
for i in idx[1:]:
    l = lines[i].strip()
    # a Lua start wrapped in hl.on("hyprland.start", function() ... end): drop the whole wrapper
    if path.endswith(".lua") and i > 0 and "hyprland.start" in lines[i - 1] and i + 1 < len(lines) and lines[i + 1].strip() == "end)":
        drop.update({i - 1, i, i + 1})
        if i > 1 and lines[i - 2].strip() == "-- the Arqen shell":
            drop.add(i - 2)
    elif re.match(r"^(exec-once\s*=|hl\.exec_cmd\()", l):
        drop.add(i)
        if i > 0 and lines[i - 1].strip() in ("# the Arqen shell", "-- the Arqen shell"):
            drop.add(i - 1)
if not drop:
    print("   !! the shell is started %d times in %s (lines %s): please keep only one" % (len(idx), path, ", ".join(str(i + 1) for i in idx)))
    sys.exit(1)
shutil.copy(path, path + ".bak-dup-" + stamp)
open(path, "w", encoding="utf-8").write("\n".join(l for i, l in enumerate(lines) if i not in drop))
print("   the shell was started %d times in %s: kept the first (backup: %s.bak-dup-%s)" % (len(idx), path.split("/")[-1], path.split("/")[-1], stamp))
DEDUP
  then RENAMED=1; fi
done

# ---- install the shell ---------------------------------------------------
# Copied next to the old one first, then swapped in with two quick renames: the running shell
# reloads when its files change, and deleting the folder before copying the new one made it reload
# halfway ("module qs.config is not installed").
rm -rf "$CFG/quickshell/.arqen-new" "$CFG/quickshell/.arqen-old"
cp -r "$HERE/quickshell/arqen" "$CFG/quickshell/.arqen-new"
[ -d "$CFG/quickshell/arqen" ] && mv "$CFG/quickshell/arqen" "$CFG/quickshell/.arqen-old"
mv "$CFG/quickshell/.arqen-new" "$CFG/quickshell/arqen"
rm -rf "$CFG/quickshell/.arqen-old"

# Which config Hyprland reads: hyprland.lua (0.55+, wins when it exists) or hyprland.conf.
HL="$CFG/hypr/hyprland.lua"
HC="$CFG/hypr/hyprland.conf"
if [ -f "$HL" ]; then
  # ---- hyprland.lua ----
  # launcher on the Super key, with the command as description so the shell can show the key
  if ! grep -rqs --include='*.lua' 'toggle launcher' "$CFG/hypr"; then
    cat >> "$HL" <<'KB'

-- Super key on its own (press and release) opens the launcher
hl.bind("SUPER + Super_L", hl.dsp.exec_cmd("~/.config/quickshell/arqen/scripts/ipc call arqen toggle launcher"), { release = true, description = "~/.config/quickshell/arqen/scripts/ipc call arqen toggle launcher" })
hl.bind("SUPER + Super_R", hl.dsp.exec_cmd("~/.config/quickshell/arqen/scripts/ipc call arqen toggle launcher"), { release = true, description = "~/.config/quickshell/arqen/scripts/ipc call arqen toggle launcher" })
KB
  fi
  python3 -I "$HERE/tools/convert-hypr.py" --describe "$HL" 2>/dev/null || true
  # Arqen's settings file, loaded last
  if ! grep -qE 'require[ (,]*"arqen"' "$HL"; then
    cat >> "$HL" <<'REQ'

-- Arqen shell settings (gaps, blur, gestures, desktops, title bars ...), written by Arqen Settings.
do
    local ok, err = pcall(require, "arqen")
    if not ok and not tostring(err):find("module 'arqen' not found", 1, true) then
        error(err)
    end
end
REQ
  fi
elif [ -f "$HC" ]; then
  # ---- hyprland.conf ----
  # The launcher is part of the shell: drop old wofi / app-drawer keybinds, make sure Super opens it.
  sed -i '/wofi --show/d; /toggle drawer/d' "$HC"
  if ! grep -q 'toggle launcher' "$HC"; then
    cat >> "$HC" <<'KB'

# Super key on its own (press and release) opens the launcher
bindr = SUPER, Super_L, exec, ~/.config/quickshell/arqen/scripts/ipc call arqen toggle launcher
bindr = SUPER, Super_R, exec, ~/.config/quickshell/arqen/scripts/ipc call arqen toggle launcher
KB
  fi
  # Arqen's file (its settings and the shell's shortcuts) is read last, so what is set in Arqen
  # Settings wins over the same thing earlier in hyprland.conf (and its shortcuts replace old copies)
  src_at="$(grep -nE '^[[:space:]]*source[[:space:]]*=.*arqen-overrides\.conf' "$HC" | tail -n 1 | cut -d: -f1)"
  last_at="$(awk 'NF && !/^[[:space:]]*#/{n=NR} END{print n}' "$HC")"
  if [ "$src_at" != "$last_at" ]; then
    cp "$HC" "$HC.bak-source-$STAMP"
    sed -i -E '/^[[:space:]]*source[[:space:]]*=.*arqen-overrides\.conf/d' "$HC"
    printf '\n# Arqen Settings (last, so what you set there wins)\nsource = ~/.config/hypr/arqen-overrides.conf\n' >> "$HC"
    echo "   hyprland.conf: Arqen's settings file is now read last (backup: hyprland.conf.bak-source-$STAMP)"
  fi
  # Three-finger gestures use Hyprland's `gesture =` keyword (0.51+). The old workspace_swipe
  # options clash with it (and are errors on new versions), so comment them out.
  if grep -qE '^[[:space:]]*workspace_swipe' "$HC"; then
    cp "$HC" "$HC.bak-swipe-$STAMP"
    sed -i -E 's/^([[:space:]]*workspace_swipe)/# \1/' "$HC"
    echo "Commented out old workspace_swipe options in hyprland.conf (backup: hyprland.conf.bak-swipe-$STAMP)"
  fi
fi

# Drag windows by their top edge: an invisible strip from Hyprland's hyprbars plugin (no title,
# no buttons). Set it up once, inside a Hyprland session.
if [ -n "${HYPRLAND_INSTANCE_SIGNATURE:-}" ] && ! hyprctl plugin list 2>/dev/null | grep -qi hyprbars; then
  echo "Setting up window dragging by the top edge (hyprbars plugin; may ask for your password and take a few minutes)"
  bash "$HERE/quickshell/arqen/scripts/window-drag.sh" --quiet | tail -n 3 || true
fi

# Saved passwords: the keyring unlocks at login with any login screen, and Chromium-family browsers
# use it (scripts/keyring.sh; asks for your password the first time).
bash "$HERE/quickshell/arqen/scripts/keyring.sh" --quiet 2>&1 | grep -E '^(== |!!|   |[a-z-]+: added)' || true
KR_CMD='gnome-keyring-daemon --start --components=secrets,pkcs11'
if [ -f "$HL" ]; then
  grep -qF "gnome-keyring-daemon" "$HL" || printf '\n-- keyring (saved passwords), unlocked by the login screen\nhl.on("hyprland.start", function()\n    hl.exec_cmd("%s")\nend)\n' "$KR_CMD" >> "$HL"
elif [ -f "$HC" ]; then
  grep -qF "gnome-keyring-daemon" "$HC" || printf '\n# keyring (saved passwords), unlocked by the login screen\nexec-once = %s\n' "$KR_CMD" >> "$HC"
fi

# ---- Settings app: icon + launcher entry ----------------------------------
mkdir -p "$HOME/.local/share/icons/hicolor/scalable/apps" "$HOME/.local/share/applications"
cp "$HERE/quickshell/arqen/assets/arqen-settings.svg" "$HOME/.local/share/icons/hicolor/scalable/apps/arqen-settings.svg"
cat > "$HOME/.local/share/applications/arqen-settings.desktop" <<'DESK'
[Desktop Entry]
Type=Application
Name=Arqen Settings
Comment=Panels, desktop, wallpaper, Wi-Fi, Bluetooth, sound and more
Icon=arqen-settings
Exec=qs -c arqen ipc call arqen settingsApp
Categories=Settings;
Keywords=settings;preferences;control;panel;
StartupWMClass=org.quickshell
DESK
gtk-update-icon-cache -q "$HOME/.local/share/icons/hicolor" 2>/dev/null || true
update-desktop-database -q "$HOME/.local/share/applications" 2>/dev/null || true

# Packages are only installed when install.sh was not told to skip them (and only on a Fedora with dnf).
PKG=1
{ [ -n "${ARQEN_NODEPS:-}" ] || ! command -v dnf >/dev/null 2>&1 || ! command -v rpm >/dev/null 2>&1; } && PKG=0
SKIPFILE="$HOME/.config/arqen/deps-skipped"
wanted() { [ -f "$SKIPFILE" ] && grep -qx -- "$1" "$SKIPFILE" && return 1; return 0; }

# ---- default cursor: Bibata-Modern-Classic -------------------------------
# Used unless you pick another one in Settings > Fonts, themes and cursor. Installed for you (no sudo) when it
# is missing: first the Fedora package if it is already known to dnf, else the release from GitHub.
CURSOR_DEFAULT="Bibata-Modern-Classic"
have_cursor() { for d in "$HOME/.local/share/icons" "$HOME/.icons" /usr/share/icons; do [ -d "$d/$CURSOR_DEFAULT/cursors" ] && return 0; done; return 1; }
if ! have_cursor; then
  echo "Installing the $CURSOR_DEFAULT cursor"
  mkdir -p "$HOME/.local/share/icons"
  tmp="$(mktemp -d)"
  if curl -fsSL --retry 2 -o "$tmp/c.tar.xz" "https://github.com/ful1e5/Bibata_Cursor/releases/latest/download/$CURSOR_DEFAULT.tar.xz" \
     && tar -xJf "$tmp/c.tar.xz" -C "$HOME/.local/share/icons" 2>/dev/null; then
    echo "   $CURSOR_DEFAULT installed in ~/.local/share/icons"
  elif [ "$PKG" = 1 ] && sudo dnf install -y --skip-unavailable bibata-cursor-themes >/dev/null 2>&1 && have_cursor; then
    echo "   $CURSOR_DEFAULT installed from the Fedora package"
  else
    echo "   (could not get $CURSOR_DEFAULT: needs internet; run ./update.sh again later)"
  fi
  rm -rf "$tmp"
fi
# an existing settings file says "leave the cursor as it is" (empty): switch that to Bibata once, if it is there
if have_cursor && [ -f "$CFG/arqen/config.json" ] && [ ! -f "$CFG/arqen/.cursor-default-done" ]; then
  python3 - "$CFG/arqen/config.json" "$CURSOR_DEFAULT" <<'PY' || true
import json, sys
p, name = sys.argv[1], sys.argv[2]
try:
    c = json.load(open(p))
except Exception:
    sys.exit(0)
if not c.get("cursorTheme"):
    c["cursorTheme"] = name
    json.dump(c, open(p, "w"), indent=2)
    print("   cursor set to " + name + " (change it in Settings > Fonts, themes and cursor)")
PY
  touch "$CFG/arqen/.cursor-default-done"
fi

# ---- desktop portal ------------------------------------------------------
# "Failed to register with host portal ... org.freedesktop.portal.Desktop: startup job failed":
# xdg-desktop-portal could not start. Under Hyprland on a Fedora that also has GNOME it tries
# the GNOME backend (which only works inside GNOME), or it starts before the Wayland variables
# reach systemd. Fix: Hyprland + GTK backends, a preference file, the variables, then restart it.
need=""
for p in dconf gsettings-desktop-schemas xdg-desktop-portal xdg-desktop-portal-hyprland xdg-desktop-portal-gtk qt6-qtmultimedia qt6-qtsvg qt6-qtimageformats python3 python3-gobject grim slurp wf-recorder wl-clipboard cliphist curl libnotify ImageMagick pulseaudio-utils pipewire-utils wtype sound-theme-freedesktop adw-gtk3-theme qt6ct qt5ct brightnessctl gnome-keyring google-noto-color-emoji-fonts hyprland-guiutils inotify-tools; do
  [ "$PKG" = 1 ] && wanted "$p" && { rpm -q "$p" >/dev/null 2>&1 || need="$need $p"; }
done
if [ -n "$need" ]; then
  echo "Installing:$need (desktop portal, video wallpapers, app theming; needs sudo)"
  sudo dnf install -y --skip-unavailable $need || echo "  (could not install:$need - file pickers and screen sharing may not work)"
fi
# Hyprlock is no longer used: Arqen's own lock screen locks (Settings > Lock screen). Shortcuts that
# ran it now run Arqen's lock; its settings file goes to the bin; the program is removed.
for f in "$CFG"/hypr/*.conf "$CFG"/hypr/*.lua; do
  [ -f "$f" ] || continue
  case "$f" in */hyprlock.conf|*/hypridle.conf) continue ;; esac
  if grep -q 'hyprlock' "$f"; then
    cp "$f" "$f.bak-hyprlock"
    sed -i -e 's#exec, *hyprlock *$#exec, ~/.config/quickshell/arqen/scripts/ipc call arqen lock#' \
           -e 's#exec_cmd("hyprlock")#exec_cmd("~/.config/quickshell/arqen/scripts/ipc call arqen lock")#' "$f"
    echo "   $(basename "$f"): the lock shortcut now uses Arqen's lock screen (backup: $(basename "$f").bak-hyprlock)"
  fi
done
[ -f "$CFG/hypr/hyprlock.conf" ] && { gio trash -- "$CFG/hypr/hyprlock.conf" 2>/dev/null || mv "$CFG/hypr/hyprlock.conf" "$CFG/hypr/hyprlock.conf.old"; echo "   hyprlock.conf moved to the bin"; }
if [ "$PKG" = 1 ] && rpm -q hyprlock >/dev/null 2>&1; then
  echo "Removing hyprlock (Arqen locks the screen itself; needs sudo)"
  sudo dnf remove -y hyprlock >/dev/null 2>&1 || echo "  (could not remove hyprlock; it is not used either way)"
fi
# Flatpak GTK3 apps need the theme as a Flatpak extension too (libadwaita apps use the portal).
# Fedora sets Flathub up for the whole system only; a per-user Flathub needs no password.
if command -v flatpak >/dev/null 2>&1; then
  flatpak remote-add --user --if-not-exists flathub https://dl.flathub.org/repo/flathub.flatpakrepo >/dev/null 2>&1 || true
  if out=$(flatpak install -y --user --noninteractive flathub org.gtk.Gtk3theme.adw-gtk3 org.gtk.Gtk3theme.adw-gtk3-dark 2>&1); then
    echo "Flatpak: adw-gtk3 theme installed (GTK3 Flatpak apps follow light / dark)"
  else
    echo "  (Flatpak adw-gtk3 theme not installed: $(printf '%s' "$out" | tail -n 1))"
  fi
  # what Flatpak apps can see: themes, icons, cursors, the shell's gtk.css (accent colour), Qt settings
  flatpak override --user \
    --filesystem=xdg-config/gtk-3.0:ro --filesystem=xdg-config/gtk-4.0:ro \
    --filesystem=xdg-data/themes:ro --filesystem=~/.themes:ro \
    --filesystem=xdg-data/icons:ro --filesystem=~/.icons:ro \
    --filesystem=xdg-config/qt5ct:ro --filesystem=xdg-config/qt6ct:ro \
    --filesystem=xdg-config/Kvantum:ro >/dev/null 2>&1 || true
  # ADW_DISABLE_PORTAL (set for installed apps, see Config.qml) is passed into Flatpak apps too, where
  # it cut libadwaita apps (Resources, ...) off from the portal, the only place they learn dark / light from
  flatpak override --user --unset-env=ADW_DISABLE_PORTAL >/dev/null 2>&1 || true
fi
mkdir -p "$CFG/xdg-desktop-portal"
# hyprland-portals.conf is used only when XDG_CURRENT_DESKTOP=Hyprland. (Older versions also wrote the general
# portals.conf, which every other desktop reads too: it pointed a GNOME session at the Hyprland portal. It is
# taken away again, only if it is the one made here.)
cat > "$CFG/xdg-desktop-portal/hyprland-portals.conf" <<'PORTAL'
[preferred]
default=hyprland;gtk
org.freedesktop.impl.portal.FileChooser=gtk
org.freedesktop.impl.portal.Settings=gtk
org.freedesktop.impl.portal.Appearance=gtk
PORTAL
if [ -f "$CFG/xdg-desktop-portal/portals.conf" ] && cmp -s "$CFG/xdg-desktop-portal/portals.conf" "$CFG/xdg-desktop-portal/hyprland-portals.conf"; then
  mv -f "$CFG/xdg-desktop-portal/portals.conf" "$CFG/xdg-desktop-portal/portals.conf.arqen-removed"
  echo "removed the general portals.conf (it also applied to GNOME); kept as portals.conf.arqen-removed"
fi
# The portal (and other session services) only start inside an active graphical-session.target.
# Hyprland started from the login screen (without uwsm) never activates it, so the portal fails
# with "Dependency failed" (the "startup job failed" warning). A small target bound to it, started
# at login after the session environment is passed on, fixes that.
mkdir -p "$CFG/systemd/user"
cat > "$CFG/systemd/user/arqen-session.target" <<'TARGET'
[Unit]
Description=Arqen Hyprland session (brings up graphical-session.target)
Documentation=man:systemd.special(7)
BindsTo=graphical-session.target
Wants=graphical-session-pre.target
After=graphical-session-pre.target
TARGET
systemctl --user daemon-reload 2>/dev/null || true
SESSION_CMD='dbus-update-activation-environment --systemd --all && systemctl --user start arqen-session.target'
SESSION_LINE="exec-once = $SESSION_CMD"
if [ -f "$HL" ]; then
  if ! grep -qF "$SESSION_CMD" "$HL"; then
    printf '\n-- session services (desktop portal: file pickers, screen sharing, dark mode for apps)\nhl.on("hyprland.start", function()\n    hl.exec_cmd("%s")\nend)\n' "$SESSION_CMD" >> "$HL"
  fi
elif [ -f "$CFG/hypr/hyprland.conf" ] && ! grep -qF "$SESSION_LINE" "$CFG/hypr/hyprland.conf"; then
  # replace the line older versions of this script added
  sed -i '\#^exec-once = dbus-update-activation-environment --systemd --all$#d' "$CFG/hypr/hyprland.conf"
  printf '\n# session services (desktop portal: file pickers, screen sharing, dark mode for apps)\n%s\n' "$SESSION_LINE" >> "$CFG/hypr/hyprland.conf"
fi
if [ -n "${WAYLAND_DISPLAY:-}" ]; then
  dbus-update-activation-environment --systemd --all 2>/dev/null || true
  if ! systemctl --user is-active --quiet graphical-session.target; then
    systemctl --user start arqen-session.target 2>/dev/null || true
  fi
  echo "graphical-session.target: $(systemctl --user is-active graphical-session.target 2>/dev/null || true)"
  systemctl --user reset-failed xdg-desktop-portal xdg-desktop-portal-hyprland xdg-desktop-portal-gtk 2>/dev/null || true
  systemctl --user stop xdg-desktop-portal-gnome 2>/dev/null || true
  systemctl --user restart xdg-desktop-portal-gtk xdg-desktop-portal-hyprland xdg-desktop-portal 2>/dev/null || true
  sleep 1
  scheme="$(gdbus call --session --timeout 3 --dest org.freedesktop.portal.Desktop --object-path /org/freedesktop/portal/desktop --method org.freedesktop.portal.Settings.ReadOne org.freedesktop.appearance color-scheme 2>/dev/null || true)"
  if systemctl --user is-active --quiet xdg-desktop-portal && [ -n "$scheme" ]; then echo "Desktop portal: running, tells apps $scheme (1 = dark, 2 = light)"
  else
    echo
    echo "!! Desktop portal still not running. Copy everything between the lines to Claude:"
    echo "----------------------------------------------------------------"
    echo "XDG_CURRENT_DESKTOP=${XDG_CURRENT_DESKTOP:-unset}  WAYLAND_DISPLAY=${WAYLAND_DISPLAY:-unset}"
    rpm -qa "xdg-desktop-portal*" | sort || true
    systemctl --user status xdg-desktop-portal --no-pager 2>&1 | head -12 || true
    echo "-- what the portal needs:"
    systemctl --user show -p Requires -p Requisite -p BindsTo -p After xdg-desktop-portal.service 2>&1 || true
    echo "-- session targets: graphical-session=$(systemctl --user is-active graphical-session.target 2>/dev/null || true) arqen-session=$(systemctl --user is-active arqen-session.target 2>/dev/null || true)"
    systemctl --user --failed --no-pager 2>&1 | head -10 || true
    journalctl --user -b --no-pager -u xdg-desktop-portal -u xdg-desktop-portal-hyprland -u xdg-desktop-portal-gtk 2>&1 | tail -25 || true
    echo "----------------------------------------------------------------"
  fi
fi

[ -n "${IPCMIG:-}" ] && [ -n "${HYPRLAND_INSTANCE_SIGNATURE:-}" ] && hyprctl reload >/dev/null 2>&1 || true
echo
# ---- plugins: their folder, and the example plugin (yours are never touched) ----
PLUG="${XDG_CONFIG_HOME:-$HOME/.config}/quickshell/widgets"
mkdir -p "$PLUG"
# examples Arqen no longer ships (media player, controller mapper: the controller tester and button
# swapping are in Settings > Wi-Fi and Bluetooth now), when they are still Arqen's own copies
for old in media-player controller-mapper; do
  if [ -f "$PLUG/$old/manifest.json" ] && grep -q '"author": *"Arqen"' "$PLUG/$old/manifest.json"; then
    (gio trash -- "$PLUG/$old" 2>/dev/null || rm -rf -- "$PLUG/$old") && echo "   old example plugin removed: $old"
  fi
done
for ex in "$HERE"/quickshell/arqen/plugin-examples/*/; do
  [ -d "$ex" ] || continue
  name="$(basename "$ex")"
  if [ ! -e "$PLUG/$name" ]; then
    cp -r "$ex" "$PLUG/$name" && echo "   example plugin added: $name"
  elif grep -q '"author": *"Arqen"' "$PLUG/$name/manifest.json" 2>/dev/null && ! cmp -s "$ex/manifest.json" "$PLUG/$name/manifest.json"; then
    # Arqen's own example, an older version: updated, its settings kept
    find "$PLUG/$name" -mindepth 1 -maxdepth 1 ! -name settings.json -exec rm -rf -- {} +
    cp -r "$ex/." "$PLUG/$name/" && echo "   example plugin updated: $name"
  fi
done

echo "Arqen $(grep -o "version: \"[0-9.]*\"" "$HERE/quickshell/arqen/config/Config.qml" | grep -o "[0-9.]*" | head -1) is installed."
echo "Done. Restart the shell now:   pkill quickshell; while pgrep -x quickshell >/dev/null; do sleep 0.2; done; qs -c arqen"
echo "(Hyprland keybinds are reloaded automatically; or log out and in.)"
echo "To remove wofi completely:  sudo dnf remove wofi && rm -rf ~/.config/wofi"
