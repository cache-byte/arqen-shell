import Quickshell
import Quickshell.Io
import QtQuick

// Every setting and its default value. Config.qml keeps one of these in sync with
// ~/.config/arqen/config.json, and a second, untouched one as the defaults (reset buttons).
JsonAdapter {
    // style
    property bool darkMode: true
    property string accent: "#3E91FF"
    property bool accentFromWallpaper: false   // pick the accent from the wallpaper (image or video)
    // your own secondary / tertiary colours ("" = made from the accent). Not used while the accent
    // comes from the wallpaper.
    property string accent2: ""
    property string accent3: ""
    property string wallpaper: ""
    // how a new wallpaper comes in: none | fade | slide | push | zoom | wipe | circle | blur
    property string wallTransition: "fade"
    property int wallTransitionMs: 900
    property int radius: 26             // popups, the control centre, cards
    property int panelRadius: 22        // floating panels
    property int tileRadius: 22         // control centre tiles, notifications, panel pills
    property int screenCorners: 0       // round the screen's own corners by this much (0 = off)
    property real opacity: 1.0          // 1 = solid (the default); lower: see-through
    property bool shellBlur: true        // (old, no longer used: "blur" covers everything)
    property string fontFamily: "Inter"
    // other apps (Settings > Fonts, themes and cursor)
    property bool themeApps: true        // GTK / GNOME / Flatpak / Qt apps follow dark mode, accent, theme
    property string gtkTheme: "auto"     // auto = adw-gtk3 in the current dark / light version
    property string iconTheme: ""        // "" = leave as it is
    property string cursorTheme: "Bibata-Modern-Classic"      // "" = leave as it is (update.sh installs Bibata-Modern-Classic)
    property int cursorSize: 24
    property string appFont: ""          // "" = the shell's font
    property int appFontSize: 11
    // panels (the bars on the screen edges). Each one: { id, edge, align, length, thickness, layout }
    // Empty = not set up yet: the old single-taskbar settings below are turned into panel 1.
    property var panels: []
    property var knownElements: []      // elements that existed at the last save (new ones get placed once)
    // old single taskbar (only read to build the first panel)
    property int barHeight: 56
    property string barEdge: "bottom"   // top | bottom | left | right
    property int barLength: 100         // % of the screen edge
    property string barAlign: "center"  // start | center | end
    // shared by every panel
    property int iconSize: 24           // app dock icons
    property int itemSize: 22           // other panel items (buttons, status icons, desktop indicator)
    property int clockFontSize: 15      // the panel clock
    property int barMargin: 0           // panel gap from screen edge (used when gapLinked is off)
    property int panelGap: 12           // gap around the sidebar / popups, and the panels' gap while linked
    property bool gapLinked: true       // (old)
    property string panelScaleMode: "auto" // auto: panels keep their size on screen at any screen scale | scale: they follow it
    property bool panelFloat: false     // panels float off the screen edge (by panelGap) instead of sitting on it
    property bool showSearch: true
    property bool showRunning: true
    property bool showTray: true         // app status icons (Steam, Heroic, ...)
    // old single taskbar layout (only read to build the first panel)
    property var barLayout: ({
        left:   ["workspaces", "launcher", "search", "media"],
        center: ["dock"],
        right:  ["tray", "keyboard", "clipboard", "control", "clock"]
    })
    property string wsStyle: "dots"      // dots | numbers | roman | letters | custom | boxes
    property string wsCustom: "一 二 三 四 五 六 七 八 九 十"   // the custom style's characters, space-separated
    property bool gestures: true         // touchpad swipes (needs Hyprland 0.51+)
    property int gestureFingers: 0       // 0 = automatic (3 fingers; 4 with hyprland.lua, which usually has its own 3-finger swipes), or 3 / 4
    // keyboard shortcuts made in Settings: [{ keys: "SUPER + T", kind: "app" | "command", value, label }]
    property var keybinds: []
    // the shell's own window shortcuts ("" = none): full screen (any window you pick), maximise
    property string keyFullscreen: "SUPER + SHIFT + F"
    // the shell's own shortcuts (Settings > Keyboard shortcuts); "" = none. Arqen writes them to its
    // Hyprland file, after your own config, so they always work
    property var shellKeys: ({ settings: "SUPER + I", search: "SUPER + Space", overview: "SUPER + Tab", quick: "SUPER + N",
                               clipboard: "SUPER + V", capture: "SUPER + SHIFT + S", lock: "SUPER + L", power: "CTRL + ALT + Delete",
                               keyboard: "", notifs: "", draw: "SUPER + SHIFT + D", minimize: "SUPER + H" })
    property string keyMaximize: "SUPER + CTRL + F"
    property string keyFloat: "SUPER + F"
    // notification pop-ups while a window is full screen (games, videos): shown or held back
    property bool toastOverFullscreen: false
    // shortcuts from your own Hyprland config that were turned off or changed in Settings ("SUPER + Q")
    property var unbinds: []
    // volume, brightness, keyboard light, media, Caps / Num Lock keys: handled by Arqen, with an OSD
    property bool osdKeys: true
    property string osdPos: "bottom"     // 3x3 placement
    property bool osdVertical: false
    property var desktops: [1]           // desktops (workspaces) kept alive even when empty
    property bool batteryPercent: true
    property string mediaViz: "Bars"          // the music item on the panel: what moves to the beat: Off | Bars | Dots | Wave
    property string mediaVizColor: "Accent"   // Accent | Text | Rainbow
    property bool mediaPulse: true            // the round cover on the panel beats with the bass
    property string mediaPillStyle: "Full"    // the panel's music item: Full (cover, beat, title) | Cover | Title
    property int mediaPillWidth: 150          // px: how wide the title part is
    property bool mediaPillArtist: true       // the artist after the title
    property bool mediaScroll: true           // a long title runs along (off: it is cut with ...)
    property string mediaCoverShape: "Circle" // Circle | Rounded | Square
    property bool mediaSpin: true             // a round cover turns while it plays
    property string mediaVizSide: "Before"    // the beat: Before | After the title
    property bool mediaPillControls: false    // previous / play / next right in the pill
    property string mediaPopKind: "Same"      // the music card: the beat drawn as Same (as the panel) | Bars | Mirror | Dots | Wave | Blob
    property string mediaPopViz: "Behind"     // the music card: the beat Behind everything | Bottom (its own strip) | Off
    property bool mediaPopBlur: true          // the music card: the cover blurred behind it
    property bool errorNotify: true      // Hyprland config and shell errors as notifications
    // battery notifications (Settings > Power): charged up to, low, critically low, and what to do then
    property bool batteryFullOn: true
    property int batteryFull: 100
    property bool batteryLowOn: true
    property int batteryLow: 20
    property bool batteryCriticalOn: true
    property int batteryCritical: 10
    property string batteryCriticalAction: "none"   // none | suspend | hibernate | poweroff
    property bool privacyIndicators: true   // the panel shows when the microphone, camera or screen is in use
    property bool clock24: true
    property int itemPadding: 4          // space around panel items (not the app dock)
    property bool clockShowTime: true
    property bool clockShowDate: true
    property string clockLayout: "stacked"        // stacked | stacked flip | inline | inline flip
    property string clockDateFormat: "ddd dd/MM"
    property var pinned: ["org.gnome.Nautilus", "kitty", "firefox"]
    // desktop
    property bool desktopIcons: true
    property var desktopApps: []         // none to begin with: drag apps out of the launcher
    property int desktopIconSize: 56
    property bool desktopFiles: false    // show what is in ~/Desktop
    property string desktopDrop: "move"  // files dragged onto the desktop: "move" here or "copy"
    property bool desktopWidgetsOn: true
    property var desktopWidgets: []      // [{ id, type: clock | system }]
    property var desktopPos: ({})        // where things sit on the desktop grid: { key: { c, r } }
    property var recentApps: []
    // control centre (right-click a tile for its options, pencil button to edit)
    property var ccTiles: null           // null = the default layout (services/CcTiles.qml)
    property int ccCols: 4               // grid the saved layout was made for (now 6)
    // notifications
    property bool dnd: false
    property string overviewDir: "vertical"    // the desktops overview: vertical (2 x 2 shown, scroll down) | horizontal (4 in a row, scroll right)
    property bool notifGroup: false            // the notification list stacks the notifications of one app together
    property string toastPlace: "bottom-right"          // where notification pop-ups, alarms and reminders appear: top-left | top | top-right | left | center | right | bottom-left | bottom | bottom-right
    property int toastSeconds: 5
    // on-screen keyboard (panel item): its language, the languages the globe key goes through
    // ([] = all), its height, recently used emoji, and your GIPHY API key for GIFs
    property string oskLang: "en"
    property var oskLangs: []
    property int oskHeight: 320
    property var oskPos: ({})            // where it was dragged ({ x, y }); empty = along the bottom
    property var oskRecent: []
    property bool oskSplit: false        // the keyboard split in two halves
    property bool oskOnLock: true        // let the on-screen keyboard be used at the lock screen
    property string realKbLayout: "us" // XKB layout(s), comma-separated, e.g. us,gb or us,fr
    property string realKbVariant: ""  // optional XKB variant(s)
    // the pointer jumps onto a window when it gets the focus (Hyprland's default); off: it stays put
    property bool cursorWarp: false
    // this computer: "auto" (found out from the hardware), "laptop" or "desktop"
    property string deviceType: "auto"
    // when nothing is touched (minutes, 0 = never): dim, screen off, lock, sleep
    property int idleDim: 4
    property int idleOff: 5
    property int idleLock: 6
    property int idleSleep: 15
    property bool idleIgnoreInhibit: false   // dim / lock / sleep even when an app (a video, a browser tab) asks to keep the screen awake
    property int idleSleepAC: 0          // plugged in (laptops): 0 = never
    property bool lockBeforeSleep: true
    // closing the lid (laptops): sleep | lock | screenoff | nothing | hibernate | poweroff
    property string lidAction: "sleep"
    property string lidActionAC: "lock"
    property bool lidIgnoreExternal: true // a screen is plugged in: closing the lid does nothing
    // the lock screen (Settings > Lock screen)
    property string lockMode: "system"        // system (follows light / dark mode) | light | dark
    property string lockClockStyle: "big"     // big | tall | stacked | small
    property string lockClockColor: "accent"  // accent | white | custom | gradient
    property string lockClockCustom: "#F5E6D3"   // custom colour, or the top of the gradient
    property string lockClockCustom2: ""         // the bottom of the gradient ("" = the accent colour)
    property string lockClockAlign: "center"     // left | center | right
    property string lockDateFormat: "dddd d MMMM"
    property string lockFrame: "none"         // none | heart | rounded | circle | arch | blob: the picture inside a shape
    property string lockFrameColor: "accent"  // what is round the frame: accent | dark | custom
    property string lockFrameCustom: "#8B7355"
    property int lockFrameSize: 100           // %
    property string lockClockPlace: "top"     // top | middle
    property int lockClockSize: 100           // %
    property bool lockShowDate: true
    property bool lockShowInfo: true          // battery and notifications waiting
    property bool lockShowMedia: true
    property bool lockShowUser: true          // your picture and name
    property string lockMessage: ""           // a line under the clock ("If found, call...")
    property string lockImage: ""             // "" = the wallpaper
    property int lockBlur: 60                 // %
    property int lockDim: 25                  // %
    // settings changed for everyone once (new defaults that should reach old configs too)
    property int migrated: 0
    // game controllers: buttons swapped ({ "<controller name>": { "<code>": <new code or -1> } }), and on/off
    // Bluetooth devices (their kind and battery) in the control centre button
    // plugins (Settings > Plugins) that are switched off, by id
    property var pluginsDisabled: []
    property bool btDevicesInBar: true
    // after a screenshot / recording: a preview with what to do with it ("ask"), or just save ("save")
    property bool shotClipboard: true    // every screenshot also goes on the clipboard, ready to paste
    property string captureAfter: "ask"
    property int captureAfterSecs: 6     // the preview saves by itself after this (0 = waits for you)
    // the handle on windows: hold the pointer at a window's top for a moment for move / close / ...
    property string rgbMode: "off"         // Lighting (OpenRGB): off | wallpaper | custom | dark
    property string rgbColor: "#FFFFFF"
    property int rgbBrightness: 100
    property bool updateCheck: true        // look for a newer version on GitHub now and then
    property string updateSkipped: ""      // a version the user chose to skip
    property bool rgbServer: true          // keep OpenRGB's server running in the background
    property bool showAdvanced: false      // Settings: show the rarely needed settings too
    property string shellSaver: "auto"     // Shell saver: lighter animations, a slower beat and no video wallpaper while it applies: auto (on battery) | on | off
    property bool winHandle: true
    property real winHandleDelay: 1.0    // seconds
    property string winHandleColor: "accent" // accent | custom
    property string winHandleCustom: "#F5E6D3"   // the colour when custom
    property int winHandleSize: 100      // %
    property string winHandlePosition: "top-center" // top/bottom/left/right with start/center/end alignment
    // the countdown before lock / sleep / log out / restart / shut down (0 = none), its look and where it sits
    property int powerCountdown: 30
    property string powerTheme: "Big number" // Ring | Big number | Bar | Glass
    property string powerPlace: "Centre"     // Centre | Top | Bottom | Left | Right
    // how the countdown moves: coming in, each second, the progress, its speed (%), the dimming (%), its colour
    property string powerAnimIn: "Zoom"      // Zoom | Fade | Rise | Drop
    property string powerAnimTick: "Pop"     // Pop | Slide | Flip | Fade | Roll | None
    property string powerProgress: "Smooth"  // Smooth | Steps
    property int powerAnimSpeed: 100
    property int powerCdDim: 50
    property string powerColor: "Auto"       // Auto (red for restart / shut down) | Accent | Red
    // the power menu: order and which buttons, their colours, shape, size, columns, labels, dimming
    property var powerOrder: ["poweroff", "reboot", "logout", "suspend", "lock"]
    property var powerHidden: []
    property string powerStyle: "Accent"     // Accent | Soft | Mixed | Outline
    property string powerShape: "Squircle"   // Circle | Squircle
    property int powerSize: 104
    property int powerCols: 5
    property bool powerLabels: false
    property int powerDim: 45
    property bool powerSettingsBtn: true
    // where screenshots and screen recordings are saved ("" = ~/Pictures/Screenshots, ~/Videos/Screenrecordings)
    property string shotDir: ""
    property string recDir: ""
    // a window pushed (almost) off the screen is tucked into the edge panel instead of getting lost
    property bool widgetsAvoidSubject: false   // desktop widgets stay off the main subject of the wallpaper
    property bool edgeAlways: true       // the minimize bar stays on the edge when it is empty (so it can be moved)
    property bool edgeTuck: true
    property int edgeTuckPart: 75        // how much of it has to be off the screen (%)
    property string edgeSide: "right"    // the edge the panel sits on: left | right | top | bottom
    property real edgeAlong: 0.5         // where along that edge (0 = top / left, 1 = bottom / right)
    property string giphyKey: ""
    // system sounds: a freedesktop sound theme ("" = no sounds) and which events play one
    property string soundTheme: ""          // "" = no system sounds
    property bool soundNotify: true
    property bool soundVolume: true
    property bool soundCapture: true
    property bool soundPower: true
    property bool soundDevices: true
    property bool soundError: false
    property var soundPicks: ({})        // an event's own sound: { notify: "/usr/share/sounds/.../bell.oga" }
    // name tips when the pointer rests on something
    property bool tipsOn: true
    property real tipSeconds: 0.5          // wait before showing
    // hyprland
    property string scale: "auto"           // screens without their own choice
    // per screen (by name, e.g. "eDP-1"): { mode: "2560x1440@144", scale: "1.25", position: "auto-right",
    // transform: 0..3, disabled: true }
    property var monitors: ({})
    property var hyprOpts: ({})          // Settings > Hyprland / Mouse and keyboard: "section.option" -> value (assets/hypr-schema.json)
    property int gapsIn: 4
    property int gapsOut: 10
    property int borderSize: 1
    property int winRounding: 14
    property string windowMode: "floating" // floating | dwindle | master | scrolling (Hyprscrolling plugin)
    property bool blur: true             // blur behind see-through panels, popups, menus and windows
    property int blurStrength: 5         // 1..10: how strong the blur is
    property bool animations: true
    property int bounce: 120             // % of spring / overshoot in the shell's animations (0 = none); also the pop of new windows
    property bool cheatOnLogin: true      // a small shortcut sheet shows once when you log in
    property string loginCaps: "keep"     // Caps Lock at login: keep | on | off
    property string loginNum: "keep"      // Num Lock at login
    property bool nightOn: false         // screen filters (control centre): night light (hyprsunset) ...
    property int nightTemp: 4000
    property string screenFilter: ""     // ... and one colour filter from assets/shaders (grayscale, invert, sepia ...)
    // launcher (Super key)
    property string launcherLayout: "grid"   // grid | list
    property string launcherPos: "center"    // 3x3 placement
    property int launcherWidth: 50           // % of the screen
    property int launcherHeight: 70
    property int launcherIconSize: 48
    // search (Super+Space)
    property string searchLayout: "grid"     // grid | list (how app results are shown)
    property string searchPos: "center"
    property int searchWidth: 45
    property int searchHeight: 85            // max height, % of the screen
    property bool searchSuggestions: true
    property bool searchTopics: true
    property bool searchFolders: true
    property var quickFolders: []            // [{ n: name, d: path }]; empty = Downloads and Screenshots
    // learned from what you launch (powers suggestions)
    property var appUsage: ({})
}
