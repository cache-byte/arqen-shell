pragma Singleton
import Quickshell
import QtQuick

Singleton {
    id: ui
    property string open: ""            // launcher | search | quick (sidebar) | notifs (same as quick) | clipboard | calendar | overview | traymenu | paneledit
    property var trayItem: null         // the tray (status icon) whose menu is showing
    property real popAlong: -1          // where along the panel the popup should line up (-1 = panel corner)
    property string popEdge: ""         // edge of the panel the popup was opened from ("" = the first panel's)
    property string editPanel: ""       // id of the panel being edited on screen (while open === "paneledit")
    property bool settingsOpen: false
    property bool drawOpen: false       // the draw overlay (modules/DrawOverlay.qml)
    property bool drawing: true         // ... and the pointer draws (false: paused, the drawing stays)
    function toggleDraw() { if (drawOpen) drawOpen = false; else { drawing = true; drawOpen = true } }
    property double tipLast: 0          // when a name tip last showed (the next one comes quicker)
    property var dropdownOwner: null    // the drop-down list that is open (Settings): one at a time
    property bool cheatOpen: false      // the keyboard shortcut cheat sheet
    property string settingsPage: "about"
    // the "screenshot saved" card tells the notification pop-up where it is, so the two stack instead of overlapping
    property real captureH: 0
    property real ringH: 0                  // the ringing card (modules/RingAlert.qml) when it shows (+ a gap)
    property bool captureAtLeft: false
    property bool captureAtTop: false
    property var pluginBarElements: []      // panel items from plugins (services/Plugins)
    property string pluginFocus: ""          // the plugin Settings > Plugins opens on
    property string editWidget: ""          // the desktop widget whose options are open in Settings > Desktop
    property string settingsPanel: ""   // panel selected on the Panels settings page
    property color settingsColor: "#3E91FF"   // colour of the open settings page (row icons use it)
    property var desktop: null          // the desktop window (Desktop.qml), so apps can be dropped on it

    // where notification pop-ups, alarms and reminders show (Settings > Sound and notifications); older values are mapped
    readonly property string toastPlace: {
        const v = Config.c.toastPlace
        if (v === "top-center") return "top"
        if (v === "bottom-center") return "bottom"
        return ["top-left", "top", "top-right", "left", "center", "right", "bottom-left", "bottom", "bottom-right"].indexOf(v) >= 0 ? v : "bottom-right"
    }
    readonly property bool toastTop: toastPlace.indexOf("top") === 0
    readonly property bool toastBottom: toastPlace.indexOf("bottom") === 0
    readonly property bool toastMiddle: !toastTop && !toastBottom
    // pop-ups stack away from their edge instead of covering each other (the ringing card nearest the edge, then
    // the "screenshot saved" card, then notifications). `off` = the height of what is nearer the edge. Centred
    // vertically, they stack downwards (a centred window moves by half of the difference of its two margins).
    function offTop(off) { return toastTop ? off : (toastBottom ? 0 : 2 * off) }
    function offBottom(off) { return toastBottom ? off : 0 }
    readonly property bool toastLeft: toastPlace === "left" || toastPlace.endsWith("-left")
    readonly property bool toastRight: toastPlace === "right" || toastPlace.endsWith("-right")

    // the first panel decides where things go when nothing else does (toasts, keyboard-opened popups)
    readonly property string primaryEdge: Config.panelsNow.length > 0 ? Config.panelsNow[0].edge : "bottom"
    // the edge popups currently line up with: the panel they were opened from
    readonly property string edge: popEdge !== "" ? popEdge : primaryEdge
    readonly property bool vertical: edge === "left" || edge === "right"
    // One gap for everything: popups and the sidebar keep this distance from the screen
    // edges and from the panels; the panels float by the same amount while linked.
    readonly property int gap: Config.c.panelGap
    readonly property int barGap: Config.c.panelFloat ? Config.c.panelGap : 0
    // A panel can be thicker than set when its items need the room; each panel reports its
    // real thickness here so popups and the sidebar keep clear of it.
    property var panelThick: ({})
    function reportThick(id, t) {
        if (!id || panelThick[id] === t) return
        const m = Object.assign({}, panelThick)
        m[id] = t
        panelThick = m
    }
    // space taken by the panels on each edge (the thickest panel on that edge)
    function reserveOn(e) {
        let r = 0
        // autohiding panels take no space
        for (const p of Config.panelsNow) if (p.edge === e && !p.autohide) r = Math.max(r, Math.max(p.thickness, panelThick[p.id] ?? 0) + barGap)
        return r
    }
    readonly property int rTop: reserveOn("top")
    readonly property int rBottom: reserveOn("bottom")
    readonly property int rLeft: reserveOn("left")
    readonly property int rRight: reserveOn("right")
    // corner of the screen nearest the panel's tray end, where popups open when no icon position is known
    readonly property string trayCorner: edge === "top" ? "top-right" : (edge === "left" ? "bottom-left" : "bottom-right")

    // which panel element a popup belongs to (to find its panel when opened from a keybind)
    readonly property var popupElement: ({ quick: "control", calendar: "clock", clipboard: "clipboard",
                                           search: "search", launcher: "launcher", overview: "workspaces" })

    // `along` = screen coordinate (x on a horizontal panel, y on a vertical one) of the
    // icon that was clicked, so the popup opens right next to it; `fromEdge` = that panel's edge.
    function toggle(name, along, fromEdge) {
        if (name === "notifs") name = "quick"     // notifications live in the sidebar now
        if (open === name) { open = ""; return }
        popAlong = (along === undefined) ? -1 : along
        if (fromEdge !== undefined && fromEdge !== "") popEdge = fromEdge
        else {
            const el = popupElement[name]
            const p = el ? Config.panelOf(el) : null
            popEdge = p ? p.edge : ""
        }
        open = name
    }
    function close() { open = "" }
    // the capture screen: for a picture the screen is frozen first, exactly as it is (panels and
    // any open pop-up included), and only then does the capture screen open
    property var capture: null              // CaptureOverlay registers itself here
    property bool hideChrome: false
    property bool locked: false             // the lock screen is up (modules/LockScreen.qml)
    property var lockEvent: ({ n: 0, v: "" })  // key event from the on-screen keyboard (every lock surface reads it)
    property bool lockAvailable: false      // the lock screen loaded (needs Quickshell's lock and PAM parts)
    function lock() {
        close()
        if (lockAvailable) locked = true
        else Quickshell.execDetached(["notify-send", "-a", "Arqen", "-u", "critical", "Can't lock the screen", "This Quickshell was built without its lock screen (PAM) parts"])
    }         // panels etc. step aside for a moment (a window screenshot)
    function startCapture() { if (capture) capture.begin(); else toggle("capture") }
    // edit a panel on screen: drag items, remove them, resize the panel
    function editPanels(id) {
        editPanel = (id && Config.panel(id)) ? id : (Config.panelsNow.length > 0 ? Config.panelsNow[0].id : "")
        popAlong = -1
        popEdge = ""
        open = "paneledit"
    }
    function openSettings(page) {
        open = ""
        // a page asked for (e.g. "Sound settings..."), otherwise always the System / about page first
        settingsPage = page ? page : "about"
        settingsOpen = true
    }
    function launch(entry) {
        // start the app first; the bookkeeping (and the settings file it writes) waits a moment
        entry.execute()
        close()
        Qt.callLater(() => ui.noteLaunch(entry))
    }
    function noteLaunch(entry) {
        let r = (Config.c.recentApps || []).filter(x => x !== entry.id)
        r.unshift(entry.id)
        Config.c.recentApps = r.slice(0, 8)
        const u = Object.assign({}, Config.c.appUsage || {})
        u[entry.id] = (u[entry.id] || 0) + 1
        Config.c.appUsage = u
    }
}
