pragma Singleton
import Quickshell
import Quickshell.Io
import QtQuick
import qs.config

// Looks in the shell's GitHub repo for a newer arqen-shell-X.Y.Z.zip and offers to install it: download it to
// Downloads, unpack, run update.sh (your settings are kept), then ask whether to delete the zip and folder, and restart.
// It only reads the repo's file list every few hours; nothing is sent.
Singleton {
    id: root
    readonly property string repo: "cache-byte/arqen-shell"
    readonly property string branch: "main"
    property string state: "idle"          // idle | checking | uptodate | available | updating | failed
    property string latest: ""
    property string message: ""
    property string zipUrl: ""
    readonly property string downloads: (Quickshell.env("XDG_DOWNLOAD_DIR") || (Quickshell.env("HOME") + "/Downloads"))
    readonly property string zipName: "arqen-shell-" + latest
    readonly property string zipPath: downloads + "/" + zipName + ".zip"
    readonly property string folderPath: downloads + "/" + zipName
    property bool dismissed: false         // "Later" for this run
    readonly property bool enabled: Config.c.updateCheck !== false
    // the card on the screen: a new version, found by itself, not skipped, not put off
    readonly property bool prompt: state === "available" && !dismissed && latest !== (Config.c.updateSkipped || "")

    function parts(v) { return String(v).split(".").map(n => parseInt(n) || 0) }
    function newer(a, b) {            // a newer than b
        const x = parts(a), y = parts(b)
        for (let i = 0; i < Math.max(x.length, y.length); i++) {
            const d = (x[i] || 0) - (y[i] || 0)
            if (d !== 0) return d > 0
        }
        return false
    }

    function init() { first.start() }
    function check() {
        if (state === "checking" || state === "updating") return
        state = "checking"; message = ""
        checkProc.running = true
    }
    function later() { dismissed = true }
    function skip() { Config.c.updateSkipped = latest; dismissed = true }
    function install() {
        if (state === "updating" || zipUrl === "") return
        state = "updating"; message = "Downloading and installing ..."
        installProc.running = true
    }
    // after the install: optionally delete the downloaded zip and unpacked folder, then restart the shell
    function finish(removeFiles) {
        const rm = removeFiles ? 'rm -rf "' + zipPath + '" "' + folderPath + '"; ' : ""
        Quickshell.execDetached(["sh", "-c", rm + "sleep 1; pkill -x quickshell; while pgrep -x quickshell >/dev/null; do sleep 0.2; done; setsid qs -c arqen >/dev/null 2>&1 &"])
    }

    Timer { id: first; interval: 30000; onTriggered: if (root.enabled) root.check() }
    Timer { interval: 6 * 3600 * 1000; repeat: true; running: root.enabled; onTriggered: root.check() }

    // Looks in the repo for the newest arqen-shell-X.Y.Z.zip: first the files in the repo's main folder, then the
    // newest release's files. Prints "ZIP version url" or "ERR why".
    Process {
        id: checkProc
        command: ["sh", "-c", `
            t=/tmp/arqen-upd.$$; l=$t.list; net=0; : > "$l"
            get() { code=$(curl -sSL --max-time 20 -o "$t" -w '%{http_code}' "$1" 2>/dev/null) || { net=1; return 1; }; [ "$code" = 200 ]; }
            pick() { # $1 = url prefix for bare names ("" = already a full url); names on stdin; appends "version url" lines
              while read -r n; do
                v=$(basename "$n" | grep -o '[0-9][0-9]*\\(\\.[0-9][0-9]*\\)\\+' | head -1); [ -n "$v" ] || continue
                case "$n" in http*) echo "$v $n";; *) echo "$v $1$n";; esac
              done >> "$l"; }
            if get "https://api.github.com/repos/$1/contents/?ref=$2"; then
              grep -o '"name": *"[^"]*\\.zip"' "$t" | sed 's/.*: *"//; s/"$//' | pick "https://raw.githubusercontent.com/$1/$2/"
            fi
            if get "https://api.github.com/repos/$1/releases/latest"; then
              grep -o '"browser_download_url": *"[^"]*\\.zip"' "$t" | sed 's/.*: *"//; s/"$//' | pick ""
            fi
            best=$(sort -V -k1,1 "$l" | tail -1); rm -f "$t" "$l"
            [ -n "$best" ] && { echo "ZIP $best"; exit 0; }
            [ "$net" = 1 ] && echo "ERR Could not reach GitHub (no internet?)." || echo "ERR No arqen-shell-X.Y.Z.zip found in the repository (or it is private)."
            `, "sh", root.repo, root.branch]
        stdout: StdioCollector {
            onStreamFinished: {
                const t = text.trim().split("\n").pop()
                const m = t.match(/^ZIP (\d+(?:\.\d+)*) (\S+)$/)
                if (!m) { root.state = "failed"; root.message = t.replace(/^ERR /, "") || "Could not read the version from GitHub."; return }
                root.latest = m[1]; root.zipUrl = m[2]
                if (root.newer(m[1], Config.version)) { root.state = "available"; root.dismissed = false }
                else { root.state = "uptodate" }
            }
        }
        onExited: code => { if (code !== 0 && root.state === "checking") { root.state = "failed"; root.message = "The check did not run." } }
    }

    // download the zip to ~/Downloads, unpack it next to it, run its update.sh (no package installs). The shell is
    // restarted afterwards, once the person has said whether to delete the zip and folder.
    Process {
        id: installProc
        command: ["sh", "-c",
            'set -e; mkdir -p "$(dirname "$2")"; curl -fL --max-time 300 -sS -o "$2" "$1"; rm -rf "$3"; mkdir -p "$3"; '
            + '(unzip -q -o "$2" -d "$3" 2>/dev/null || python3 -m zipfile -e "$2" "$3"); '
            + 'u=$(find "$3" -maxdepth 3 -name update.sh | head -1); [ -n "$u" ] && [ -d "$(dirname "$u")/quickshell/arqen" ] || { echo "The zip is not a shell package (no update.sh with quickshell/arqen next to it)."; exit 3; }; '
            + 'cd "$(dirname "$u")"; ARQEN_NODEPS=1 ARQEN_WARNED=1 bash ./update.sh', "sh", root.zipUrl, root.zipPath, root.folderPath]
        stdout: StdioCollector { id: out }
        stderr: StdioCollector { id: err }
        onExited: code => {
            if (code === 0) {
                root.state = "installed"; root.message = "Version " + root.latest + " is installed."
            } else {
                root.state = "failed"
                const e = (err.text || out.text || "").trim().split("\n").slice(-1)[0]
                root.message = "The update did not finish" + (e ? ": " + e : ".")
            }
        }
    }
}
