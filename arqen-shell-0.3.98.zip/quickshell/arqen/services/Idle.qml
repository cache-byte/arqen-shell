pragma Singleton
import Quickshell
import Quickshell.Io
import QtQuick
import qs.config

// What happens when the computer is left alone (Settings > Power): dim the screen, turn it off,
// lock, go to sleep. Watched with the Wayland idle protocol (playing a video, Caffeine and apps that
// ask the system to stay awake hold it off). And the lid (laptops): sleep, lock, screen off, nothing...
// with an inhibitor held so the system does not also do its own thing when the lid closes.
Singleton {
    id: root
    function init() {}

    // ---- this computer: laptop or desktop ----
    property string chassis: ""                       // from the hardware: /sys/class/dmi/id/chassis_type
    FileView { id: chassisFile; path: "/sys/class/dmi/id/chassis_type"; printErrors: false; onLoaded: root.chassis = text().trim() }
    readonly property bool autoLaptop: ["8", "9", "10", "11", "14", "30", "31", "32"].indexOf(chassis) >= 0 || Power.hasBattery
    readonly property bool laptop: Config.c.deviceType === "laptop" || (Config.c.deviceType !== "desktop" && autoLaptop)
    readonly property string kindName: laptop ? "laptop" : "desktop"

    // ---- idle ----
    readonly property bool onBattery: Power.hasBattery && !Power.plugged
    readonly property int dimMin: Config.c.idleDim || 0
    readonly property int offMin: Config.c.idleOff || 0
    readonly property int lockMin: Config.c.idleLock || 0
    readonly property int sleepMin: laptop && !onBattery ? (Config.c.idleSleepAC || 0) : (Config.c.idleSleep || 0)

    // what the idle watching is doing, for Settings > Power (so "nothing happens" can be told from "it is not watching")
    property string status: "starting"
    property string lastEvent: ""
    function note(what) {
        lastEvent = Qt.formatTime(new Date(), "HH:mm:ss") + "  " + what
        console.log("arqen idle: " + what)
    }

    // one idle watcher per step (made here: a Quickshell without IdleMonitor just has none)
    function monitor(label, minutes, onIdle, onBack) {
        if (minutes <= 0) return null
        let m = null
        try { m = Qt.createQmlObject('import Quickshell.Wayland\nIdleMonitor { respectInhibitors: ' + (root.respect ? 'true' : 'false') + ' }', root, "idle-" + label) }
        catch (e) { failure = String(e); console.warn("arqen idle: no IdleMonitor: " + e); return null }
        m.timeout = minutes * 60
        m.isIdleChanged.connect(() => {
            if (m.isIdle) { note(label + " (after " + minutes + " min idle)"); onIdle() }
            else if (onBack) { note("back: " + label + " undone"); onBack() }
        })
        return m
    }
    // Settings > Power > "Even when an app wants the screen awake": a video or call, a browser tab playing something,
    // a fullscreen game ask the system not to go idle. Off (the default) respects that.
    readonly property bool respect: Config.c.idleIgnoreInhibit !== true
    onRespectChanged: rebuildLater.restart()
    property string failure: ""
    property var mons: []
    function rebuild() {
        for (const m of mons) if (m) m.destroy()
        failure = ""
        mons = [
            monitor("dim", dimMin, root.dim, root.undim),
            monitor("screen off", offMin, () => Hypr.dpms(false), () => Hypr.dpms(true)),
            monitor("lock", lockMin, () => { if (!Ui.locked) Ui.lock() }, null),
            monitor("sleep", sleepMin, root.sleep, null)
        ]
        const n = mons.filter(m => m).length
        const wanted = [dimMin, offMin, lockMin, sleepMin].filter(x => x > 0).length
        status = failure !== "" ? "Idle detection is not available here: " + failure
               : wanted === 0 ? "Nothing set to happen when idle"
               : "Watching: " + n + " of " + wanted + " steps" + (respect ? ", apps that ask to keep the screen awake are respected" : ", apps that ask to keep the screen awake are ignored")
    }
    Component.onCompleted: rebuildLater.restart()
    onDimMinChanged: rebuildLater.restart()
    onOffMinChanged: rebuildLater.restart()
    onLockMinChanged: rebuildLater.restart()
    onSleepMinChanged: rebuildLater.restart()
    Timer { id: rebuildLater; interval: 800; onTriggered: root.rebuild() }

    // dim: the screen to a third of where it was, back when you move
    property real before: -1
    function dim() {
        if (!QuickSettings.hasBrightness || before >= 0) return
        before = QuickSettings.brightness
        QuickSettings.setBrightness(Math.max(0.05, before * 0.3))
    }
    function undim() { if (before >= 0) { QuickSettings.setBrightness(before); before = -1 } }
    function sleep() {
        if (Config.c.lockBeforeSleep) Ui.lock()
        sleepSoon.restart()
    }
    // (a moment for the lock screen to be up before the computer sleeps)
    Timer { id: sleepSoon; interval: 600; onTriggered: Quickshell.execDetached(["systemctl", "suspend"]) }

    // ---- the lid ----
    readonly property string lidNow: onBattery || !Power.hasBattery ? Config.c.lidAction : Config.c.lidActionAC
    // the system's own lid handling is held off while Arqen handles it (laptops only)
    Process {
        running: root.laptop
        command: ["systemd-inhibit", "--what=handle-lid-switch", "--who=Arqen shell", "--why=Arqen does what Settings > Power says", "--mode=block", "sleep", "infinity"]
    }
    // the lid's state, printed when it changes
    Process {
        running: root.laptop
        command: ["sh", "-c", "last=; while :; do s=$(cat /proc/acpi/button/lid/*/state 2>/dev/null | head -n1 | awk '{print $2}'); [ -n \"$s\" ] && [ \"$s\" != \"$last\" ] && { echo \"$s\"; last=$s; }; sleep 1; done"]
        stdout: SplitParser { onRead: line => root.lid(line.trim()) }
    }
    property bool lidClosed: false
    property bool lidFirst: true
    function lid(state) {
        const closed = state === "closed"
        if (lidFirst) { lidFirst = false; lidClosed = closed; return }       // the state at start: nothing to do
        if (closed === lidClosed) return
        lidClosed = closed
        if (!closed) { if (offByLid) { Hypr.dpms(true); offByLid = false } return }
        // a screen is plugged in: work on with that one
        if (Config.c.lidIgnoreExternal && Quickshell.screens.length > 1) return
        const a = lidNow
        if (a === "sleep") root.sleep()
        else if (a === "lock") Ui.lock()
        else if (a === "screenoff") { Ui.lock(); Hypr.dpms(false); offByLid = true }
        else if (a === "hibernate") { if (Config.c.lockBeforeSleep) Ui.lock(); Quickshell.execDetached(["systemctl", "hibernate"]) }
        else if (a === "poweroff") Quickshell.execDetached(["systemctl", "poweroff"])
    }
    property bool offByLid: false
}
