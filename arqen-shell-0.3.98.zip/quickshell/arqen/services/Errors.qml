pragma Singleton
import Quickshell
import Quickshell.Io
import Quickshell.Hyprland
import QtQuick
import qs.config

// Problems shown as ordinary notifications (in the pop-up and in the control centre list):
//  - Hyprland config errors (the red bar Hyprland draws), after every reload
//  - the shell's own errors and warnings, read from its log as they happen
// Settings > System > "Report errors as notifications" turns it off.
Singleton {
    id: root
    readonly property bool on: Config.c.errorNotify !== false
    function init() { hyprCheck.restart(); if (on) logProc.running = true }
    onOnChanged: logProc.running = on

    function notify(title, body, urgency) {
        Quickshell.execDetached(["notify-send", "-a", "Arqen", "-i", "dialog-error", "-u", urgency || "normal", title, body])
    }

    // ---- Hyprland ----
    property string lastHypr: ""
    Timer { id: hyprCheck; interval: 1500; onTriggered: if (root.on) hyprProc.running = true }
    Connections {
        target: Hyprland
        function onRawEvent(ev) { if (ev.name === "configreloaded") hyprCheck.restart() }
    }
    Process {
        id: hyprProc
        command: ["hyprctl", "configerrors"]
        stdout: StdioCollector {
            onStreamFinished: {
                const lines = text.split("\n").map(l => l.trim()).filter(l => l !== "" && !/^no errors/i.test(l))
                const t = lines.join("\n")
                if (t === root.lastHypr) return
                root.lastHypr = t
                if (t === "") return
                root.notify("Hyprland config: " + lines.length + (lines.length === 1 ? " problem" : " problems"),
                            lines.slice(0, 4).join("\n") + (lines.length > 4 ? "\n…" : ""), "critical")
            }
        }
    }

    // ---- the shell's log ----
    // messages that are expected and harmless
    readonly property var harmless: [/quickshell\.dbus\.properties: Error updating property org\.mpris/, /Remote peer disconnected/, /Creating a popup with a parent which does not match the current topmost grabbing popup/, /Requested image from unknown handle/, /quickshell\.io\.socket/, /Cannot open: file:\/\/\/tmp\//, /Cannot create children for a parent that is in a different thread/, /Cannot filter events for objects in a different thread/, /Parent is QGuiApplication/, /An authentication agent already exists/, /failed to register listener/, /QThread: Destroyed while thread/, /Failed to register with host portal/, /Connection already associated with an application ID/, /Unable to parse pixmap as rowstride is incorrect/, /Could not register notification server/, /Registration will be attempted again/,
        /failed to register listener/, /An authentication agent already exists/, /arqen-overrides\.conf failed: File does not exist/,
        /arqen\.lua failed: File does not exist/,
        // a credits logo that did not load (offline, or the site has none): the plain icon shows instead
        /QIODevice::read \(QSslSocket\)/, /QSslSocket/, /SRow\.qml.*Error transferring https?:\/\//, /Error transferring https?:\/\/.*(favicon|\.png)/,
        // an app's notification icon in a temporary file that is already gone (browsers do this)
        /Cannot open: file:\/\/\/tmp\//, /IconImage\.qml.*Cannot open/,
        // an icon the theme does not have: the plain icon is drawn instead
        /Could not load icon/,
        // a picture still being written when it is shown (a fresh screenshot, a clipboard image): it shows once it is complete
        /Error decoding: file:\/\/.*Unable to read image data/, /Error decoding: file:\/\//,
        // clicking a window that has just closed (taskbar, overview)
        /hl\.focus: window not found/, /Dispatch request .* failed with error .*window not found/, /SSL handshake failed/, /certificate is not yet valid/, /qt\.network\.http2/, /Received GOAWAY/, /Remote host signaled shutdown/,
        // a touchpad gesture that the compositor reports twice (when the finger count is changed mid-swipe)
        /qt\.qpa\.wayland\.input: Unexpected Gesture/]
    property double started: 0
    property var pending: []
    property var seen: ({})
    Process {
        id: logProc
        command: ["qs", "log", "-c", "arqen", "--follow"]
        onStarted: root.started = Date.now()
        stdout: SplitParser {
            onRead: raw => {
                // without the terminal colour codes ("[97m")
                const line = raw.replace(/\x1b\[[0-9;]*[A-Za-z]/g, "").replace(/\[[0-9;]*m/g, "")
                if (Date.now() - root.started < 2500) return           // what was logged before now
                // only real log lines: "  WARN scene: ..." (maybe after a time); not the reader's own
                // complaints about a log file still being written (binary dumps)
                if (!/^\s*(\S+\s+)?(WARN|ERROR|CRIT|FATAL)\b/.test(line)) return
                if (/error occurred parsing|Remaining data|Explicit Modifier|BLOCK_LINEAR/i.test(line)) return
                if (root.harmless.some(r => r.test(line))) return
                const msg = line.replace(/^\s*\S*\s*(WARN|ERROR|CRIT|FATAL)\w*\s*/i, "").replace(/\s+/g, " ").trim()
                if (root.harmless.some(r => r.test(msg))) return
                const now = Date.now()
                if (root.seen[msg] && now - root.seen[msg] < 600000) return  // the same one: at most every 10 min
                root.seen[msg] = now
                root.pending = root.pending.concat([msg])
                batch.restart()
            }
        }
    }
    // a burst of messages becomes one notification
    Timer {
        id: batch
        interval: 2500
        onTriggered: {
            const p = root.pending
            root.pending = []
            if (p.length === 0 || !root.on) return
            const err = p.some(m => /ERROR|Failed|caused by|TypeError|ReferenceError/i.test(m))
            root.notify(err ? "Arqen shell error" : "Arqen shell warning" + (p.length > 1 ? "s" : ""),
                        p.slice(0, 4).join("\n") + (p.length > 4 ? "\n… and " + (p.length - 4) + " more (qs log -c arqen)" : ""),
                        err ? "critical" : "normal")
        }
    }
}
