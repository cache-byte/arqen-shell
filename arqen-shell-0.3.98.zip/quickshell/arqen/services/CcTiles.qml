pragma Singleton
import Quickshell
import Quickshell.Services.UPower
import QtQuick
import qs.config

// Everything that can be a tile in the control centre, plus the layout maths.
// The saved layout (Config.c.ccTiles) is a list of { id, c, r, w, h }: every tile has its own fixed
// place on a 6-column grid (column c, row r, w x h cells). Moving or resizing one tile never moves
// the others (except the one it swaps places with). Tiles not in the list are hidden and can be
// added back from the tray under the grid in edit mode.
Singleton {
    id: root

    // kind: toggle (icon + label), info (like toggle, read-only), slider (volume style bar; it
    // stands upright when the tile is taller than wide). Every tile can be 1 to 6 cells each way.
    readonly property var catalog: [
        { id: "wifi",       name: "Wi-Fi",          icon: "wifi",              kind: "toggle", w: 3, h: 1 },
        { id: "bluetooth",  name: "Bluetooth",      icon: "bluetooth",         kind: "toggle", w: 3, h: 1 },
        { id: "sound",      name: "Sound",          icon: "volume_up",         kind: "toggle", w: 1, h: 1 },
        { id: "dnd",        name: "Do not disturb", icon: "notifications",     kind: "toggle", w: 1, h: 1 },
        { id: "dark",       name: "Dark mode",      icon: "dark_mode",         kind: "toggle", w: 1, h: 1 },
        { id: "night",      name: "Screen filters", icon: "brightness_4",      kind: "toggle", w: 1, h: 1 },
        { id: "capture",    name: "Screenshot",     icon: "screenshot_region", kind: "toggle", w: 2, h: 1 },
        { id: "desktops",   name: "Desktops",       icon: "workspaces",        kind: "toggle", w: 1, h: 1 },
        { id: "lock",       name: "Lock",           icon: "lock",              kind: "toggle", w: 1, h: 1 },
        { id: "caffeine",   name: "Caffeine",       icon: "coffee",            kind: "toggle", w: 2, h: 1 },
        { id: "power",      name: "Power",          icon: "power_settings_new", kind: "toggle", w: 1, h: 1 },
        { id: "volume",     name: "Volume",         icon: "volume_up",         kind: "slider", w: 1, h: 3 },
        { id: "mic",        name: "Microphone",     icon: "mic",               kind: "slider", w: 1, h: 3 },
        { id: "brightness", name: "Brightness",     icon: "brightness_6",      kind: "slider", w: 1, h: 3 },
        { id: "output",     name: "Media output",   icon: "speaker",           kind: "info",   w: 3, h: 1 },
        { id: "battery",    name: "Battery",        icon: "battery_full",      kind: "info",   w: 4, h: 1 }
    ]
    readonly property int maxSpan: 6

    // brightness and volume stand on the left, like a phone's panel
    readonly property var defaults: [
        { id: "wifi", w: 3, h: 1 }, { id: "bluetooth", w: 3, h: 1 },
        { id: "brightness", w: 1, h: 3 }, { id: "volume", w: 1, h: 3 }, { id: "mic", w: 1, h: 3 },
        { id: "sound", w: 1, h: 1 }, { id: "dnd", w: 1, h: 1 }, { id: "dark", w: 1, h: 1 }, { id: "night", w: 1, h: 1 },
        { id: "capture", w: 2, h: 1 }, { id: "caffeine", w: 2, h: 1 },
        { id: "battery", w: 4, h: 1 },
        { id: "output", w: 3, h: 1 }, { id: "desktops", w: 1, h: 1 }, { id: "lock", w: 1, h: 1 }
    ]
    // tiles that were merged or renamed
    readonly property var renamed: ({ screenshot: "capture", recorder: "capture" })

    function info(id) { return catalog.find(c => c.id === id) }

    // tiles that make no sense on this machine (no battery, no backlight) are left out of the grid
    function available(id) {
        if (id === "battery") return UPower.displayDevice.isLaptopBattery
        if (id === "brightness") return QuickSettings.hasBrightness
        if (id === "mic") return Audio.hasMic
        if (id === "power") return false            // lives in the control centre header now
        return true
    }

    function clampSize(id, w, h) {
        return {
            w: Math.max(1, Math.min(maxSpan, Math.round(w))),
            h: Math.max(1, Math.min(maxSpan, Math.round(h)))
        }
    }

    function current() { return clean(Config.c.ccTiles) }
    function commit(list) { Config.c.ccCols = maxSpan; Config.c.ccTiles = list.map(t => ({ id: t.id, c: t.c, r: t.r, w: t.w, h: t.h })) }

    // tiles the user can still add (hidden ones that work on this machine)
    function addable(list) { return catalog.filter(c => !list.some(t => t.id === c.id) && available(c.id)) }

    // ---- places on the grid ----
    readonly property int maxRows: 14
    function overlaps(a, b) { return a.c < b.c + b.w && b.c < a.c + a.w && a.r < b.r + b.h && b.r < a.r + a.h }
    // the shown tiles (other than `except`) that a w x h box at (c, r) would cover
    function blockers(list, c, r, w, h, except) {
        const box = { c: c, r: r, w: w, h: h }
        return list.filter(t => t.id !== except && available(t.id) && overlaps(box, t))
    }
    function inside(c, r, w, h) { return c >= 0 && r >= 0 && c + w <= maxSpan && r + h <= maxRows }
    function free(list, c, r, w, h, except) { return inside(c, r, w, h) && blockers(list, c, r, w, h, except).length === 0 }
    // the first free spot for a w x h tile, row by row
    function firstFree(list, w, h, except) {
        for (let r = 0; r < maxRows; r++)
            for (let c = 0; c + w <= maxSpan; c++)
                if (free(list, c, r, w, h, except)) return { c: c, r: r }
        return { c: 0, r: rows(list) }
    }
    function rows(list) {
        let n = 0
        for (const t of list) if (available(t.id)) n = Math.max(n, t.r + t.h)
        return n
    }

    // a saved list, cleaned up: unknown ids and duplicates dropped, sizes clamped, every tile given
    // a place (layouts saved before tiles had places keep the arrangement they had)
    function clean(src) {
        if (!src || (Config.c.ccCols || 4) !== maxSpan) return placed(defaults)
        const out = []
        const seen = {}
        let unplaced = false
        for (const t of src) {
            const id = renamed[t.id] ?? t.id
            const d = info(id)
            if (!d || seen[id]) continue
            seen[id] = true
            const sz = clampSize(id, t.w ?? d.w, t.h ?? d.h)
            const has = typeof t.c === "number" && typeof t.r === "number"
            if (!has) unplaced = true
            out.push({ id: id, c: has ? t.c : -1, r: has ? t.r : -1, w: sz.w, h: sz.h })
        }
        if (unplaced) return placed(out)
        // anything outside the grid or on top of another tile goes to the first free spot
        const ok = []
        for (const t of out) {
            const x = Object.assign({}, t)
            x.c = Math.max(0, Math.min(maxSpan - x.w, x.c))
            if (!free(ok, x.c, x.r, x.w, x.h, x.id)) { const f = firstFree(ok, x.w, x.h, x.id); x.c = f.c; x.r = f.r }
            ok.push(x)
        }
        return ok
    }
    // places from the old left-to-right flow, for a list without them
    function placed(list) {
        const shown = list.filter(t => available(t.id))
        const pos = pack(shown, maxSpan).pos
        const out = []
        let i = 0
        for (const t of list) {
            if (available(t.id)) { const p = pos[i++]; out.push({ id: t.id, c: p.c, r: p.r, w: p.w, h: t.h }) }
            else out.push({ id: t.id, c: 0, r: 0, w: t.w, h: t.h })
        }
        return out
    }

    // ---- edits (all return a new list, or null when the change is not possible) ----
    function remove(list, id) { return list.filter(t => t.id !== id) }
    function append(list, id) {
        const d = info(id)
        if (!d || list.some(t => t.id === id)) return list
        const f = firstFree(list, d.w, d.h, id)
        return list.concat([{ id: id, c: f.c, r: f.r, w: d.w, h: d.h }])
    }
    // Put tile `id` at (c, r). Free cells: it just goes there. Exactly one tile in the way that fits
    // where the moved one came from: the two swap. Anything else: not possible (null).
    function moveTo(list, id, c, r) {
        const t = list.find(x => x.id === id)
        if (!t || (t.c === c && t.r === r)) return null
        if (!inside(c, r, t.w, t.h)) return null
        const b = blockers(list, c, r, t.w, t.h, id)
        if (b.length === 0) return list.map(x => x.id === id ? Object.assign({}, x, { c: c, r: r }) : x)
        if (b.length !== 1) return null
        const o = b[0]
        // the other tile goes to the moved tile's old place, shifted by how far into it the moved one lands
        const oc = t.c + (o.c - c), or_ = t.r + (o.r - r)
        if (!inside(oc, or_, o.w, o.h)) return null
        const moved = { id: id, c: c, r: r, w: t.w, h: t.h }
        const rest = list.filter(x => x.id !== id && x.id !== o.id)
        const box = { c: oc, r: or_, w: o.w, h: o.h }
        if (overlaps(box, moved) || rest.some(x => available(x.id) && overlaps(box, x))) return null
        return list.map(x => x.id === id ? Object.assign({}, x, { c: c, r: r }) : x.id === o.id ? Object.assign({}, x, { c: oc, r: or_ }) : x)
    }
    // Resize tile `id` towards w x h: as close as the free cells around it allow. null = no change.
    function resized(list, id, w, h) {
        const t = list.find(x => x.id === id)
        if (!t) return null
        const sz = clampSize(id, w, h)
        let best = null
        // the free size closest to what was asked for
        let bestD = 1e9
        for (let ww = 1; ww <= sz.w; ww++)
            for (let hh = 1; hh <= sz.h; hh++)
                if (free(list, t.c, t.r, ww, hh, id)) {
                    const dd = (sz.w - ww) + (sz.h - hh)
                    if (dd < bestD) { bestD = dd; best = { w: ww, h: hh } }
                }
        if (!best || (best.w === t.w && best.h === t.h)) return null
        return list.map(x => x.id === id ? Object.assign({}, x, { w: best.w, h: best.h }) : x)
    }

    // The old flow layout (only to give places to a layout saved before tiles had them): place tiles in order, each in the first free spot at or after the previous one.
    // Returns { pos: [{ c, r, w, h }] (same order as the list), rows }
    function pack(list, cols) {
        const occ = {}
        const pos = []
        let r = 0, c = 0, rows = 0
        function fits(r0, c0, w, h) {
            if (c0 + w > cols) return false
            for (let y = r0; y < r0 + h; y++)
                for (let x = c0; x < c0 + w; x++)
                    if (occ[y + "," + x]) return false
            return true
        }
        for (const t of list) {
            const w = Math.min(t.w, cols)
            while (!fits(r, c, w, t.h)) {
                c++
                if (c >= cols) { c = 0; r++ }
            }
            for (let y = r; y < r + t.h; y++)
                for (let x = c; x < c + w; x++)
                    occ[y + "," + x] = true
            pos.push({ c: c, r: r, w: w, h: t.h })
            rows = Math.max(rows, r + t.h)
            c += w
            if (c >= cols) { c = 0; r++ }
        }
        return { pos: pos, rows: rows }
    }
}
