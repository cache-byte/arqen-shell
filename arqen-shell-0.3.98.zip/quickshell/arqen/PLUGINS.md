# Writing an Arqen plugin

A plugin adds something to the shell: a button on a panel, a widget on the desktop, a button in the
control centre, a window of its own, or something that just runs in the background. It is a folder of
QML files (the language the whole shell is written in). You need no build tools: save a file and the
shell picks it up.

This guide makes a working plugin in five minutes, then explains each part.

---

## 1. Make the folder

Plugins live in `~/.config/quickshell/widgets/`, one folder each. Make one:

```sh
mkdir -p ~/.config/quickshell/widgets/hello
cd ~/.config/quickshell/widgets/hello
```

## 2. Say what it is: `manifest.json`

```json
{
  "id": "hello",
  "name": "Hello",
  "version": "1.0.0",
  "author": "You",
  "description": "My first plugin",
  "entryPoints": {
    "barWidget": "BarWidget.qml"
  },
  "metadata": { "defaultSettings": { "message": "Hello!" } }
}
```

- `id`: the same as the folder name; letters, numbers and `-`.
- `entryPoints`: which parts it has (here only a panel button). The parts are listed in section 5.
- `defaultSettings`: its settings before you change any.

## 3. Write the part: `BarWidget.qml`

```qml
import QtQuick
import Quickshell
import qs.config        // Theme (colours, font), Config (the shell's settings)
import qs.components    // DText, Icon, HoverTip, ArqButton ... (the shell's own pieces)

Item {
    id: root
    property var pluginApi: null        // given by the shell: settings, its window ...
    property real barSize: 28           // given by the shell: how big panel items are
    implicitWidth: barSize + 8
    implicitHeight: barSize + 8

    Rectangle {
        anchors.centerIn: parent
        width: root.barSize; height: width; radius: width / 2
        color: mouse.containsMouse ? Theme.hover : "transparent"
        Icon { anchors.centerIn: parent; name: "waving_hand"; size: root.barSize * 0.6; color: Theme.text }
    }
    MouseArea {
        id: mouse
        anchors.fill: parent
        hoverEnabled: true
        onClicked: Quickshell.execDetached(["notify-send", root.pluginApi?.pluginSettings.message ?? "Hello!"])
    }
    HoverTip { hovered: mouse.containsMouse; text: "Say hello" }
}
```

## 4. Turn it on

Open **Settings > Plugins**. "Hello" is in the list (press **Reload** if not). Click it, then
**Add to the panel**. Click the hand on your panel: a notification says hello.

Change the file and save: the shell loads it again by itself. If something is wrong, the plugin's row
in Settings says so in red, and the shell's log (`qs log -c arqen`) has the details.

That is a plugin. The rest of this guide is what else it can do.

---

## 5. The parts a plugin can have

Each is a `.qml` file named in `entryPoints`. Have as many as you like.

| entryPoints key       | Usual file name            | What it is                         | The shell gives it                                  |
|-----------------------|----------------------------|------------------------------------|-----------------------------------------------------|
| `barWidget`           | `BarWidget.qml`            | an item on a panel                 | `pluginApi`, `screen`, `barSize`, `vertical`        |
| `desktopWidget`       | `DesktopWidget.qml`        | a widget on the desktop            | `pluginApi`, `widgetData`, `widgetScale`            |
| `controlCenterWidget` | `ControlCenterWidget.qml`  | a button in the control centre     | `pluginApi`, `screen`                               |
| `panel`               | `Panel.qml`                | a window of its own                | `pluginApi`, `screen`                               |
| `settings`            | `Settings.qml`             | its settings in Settings > Plugins | `pluginApi`                                         |
| `main`                | `Main.qml`                 | runs in the background             | `pluginApi`                                         |

Declare the ones you use as properties, e.g. `property var pluginApi: null`, `property real barSize: 28`.
Each part says how big it is with `implicitWidth` / `implicitHeight`.

- **Desktop widget**: the shell draws the card around it (in the look picked for it) and lets you move it.
  Multiply your sizes by `widgetScale` (Small 0.8, Medium 1, Large 1.3). For text on the card use
  `Widgets.fg(widgetData.look)` (`import qs.services`).
- **Window** (`Panel.qml`): opened with `pluginApi.openPanel(screen, button)` (next to `button`) or
  `pluginApi.togglePanel(...)`; Esc or a click elsewhere closes it. Say its size with
  `property real contentPreferredWidth: 600` and `property real contentPreferredHeight: 500`.
- **Settings** (`Settings.qml`): shown when you click the plugin in Settings > Plugins, with a Save button
  that calls your `function saveSettings()`.
- **Background** (`Main.qml`): timers, programs, keyboard commands. The other parts reach it through
  `pluginApi.mainInstance` (so they can share one list, one timer ...).

## 6. Settings

```qml
// read
pluginApi.pluginSettings.message

// change and keep (written to settings.json in the plugin's folder)
const s = Object.assign({}, pluginApi.pluginSettings)
s.message = "Hi"
pluginApi.pluginSettings = s
pluginApi.saveSettings()
```

Everything showing the settings updates by itself.

## 7. `pluginApi`, all of it

| | |
|---|---|
| `pluginId`, `pluginDir`, `manifest` | its id, its folder, its manifest |
| `pluginSettings`, `saveSettings()` | its settings (section 6) |
| `openPanel(screen, button)`, `closePanel(screen)`, `togglePanel(screen, button)` | its window |
| `withCurrentScreen(fn)` | calls `fn(screen)` with the screen you are on |
| `mainInstance` | its `Main.qml` |

## 8. Looking like the shell

Use the shell's own pieces and colours, so it follows dark / light mode, the accent colour and the font:

- `import qs.config`: `Theme.text`, `Theme.subtext`, `Theme.primary` (accent), `Theme.onPrimary`,
  `Theme.tile` (a soft background), `Theme.hover`, `Theme.radius`, `Theme.font`, `Theme.dark`;
  `Config.c.<setting>` (e.g. `Config.c.wallpaper`), `Config.tilde(path)`.
- `import qs.components`: `DText` (text), `Icon { name: "..." }` (any
  [Material Symbols](https://fonts.google.com/icons) name), `ArqButton { text; primary }`,
  `ArqToggle { checked; onToggled }`, `ArqSlider { from; to; value; onMoved }`,
  `ArqField { placeholder; iconName }`, `HoverTip { hovered; text }`, `Avatar`.
- `import qs.services`: `Media` (what is playing), `Audio` (volume), `Power` (battery), `Notifs`,
  `Widgets`, `Gadgets` (Bluetooth devices, controllers).

## 9. Doing things

Anything Quickshell can do (see quickshell.org):

```qml
import Quickshell.Io

// run a program and read what it prints
Process {
    id: proc
    command: ["sh", "-c", "date +%H:%M"]
    stdout: StdioCollector { onStreamFinished: console.log(text) }
}
// proc.running = true  runs it

// a command you can run from a keyboard shortcut:  qs -c arqen ipc call plugin:hello greet
IpcHandler {
    target: "plugin:hello"
    function greet(): void { Quickshell.execDetached(["notify-send", "Hello"]) }
}
```

Also: `FileView` (read and write files), `Quickshell.Services.Mpris`, `Pipewire`, `UPower`,
`Bluetooth`, `Quickshell.Hyprland`, `SystemTray`.

## 10. Share it

In Settings > Plugins click the plugin, then **Export**: it becomes a `.zip` (your own `settings.json` is
left out). Others add it with **Import a plugin**. Add a `preview.png` to the folder for its picture in
Settings, and a `README.md` to explain it.

## Problems

- **Not in the list**: `manifest.json` must be valid JSON (no comma after the last item) and in the
  plugin's own folder. Press Reload.
- **Red text in its row**: a file named in `entryPoints` is missing, or the plugin uses something Arqen
  does not have (plugins made for other shells, such as Noctalia's, don't work).
- **"could not load"**: a mistake in the QML. `qs log -c arqen` shows the file and line.
