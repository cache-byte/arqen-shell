#!/usr/bin/env bash
# window-mode.sh MODE KIND [ADDRESS]   MODE: floating|dwindle|master|scrolling   KIND: lua|legacy
# Sets Hyprland's layout and floats / tiles the windows that are open (only ADDRESS when given: a window that
# has just opened; the shell's own windows, Settings included, follow the mode too). Prints what went wrong, or "ok".
mode="${1:-floating}"; kind="${2:-legacy}"; only="${3:-}"
case "$mode" in master|scrolling) lay="$mode" ;; *) lay=dwindle ;; esac
want=false; [ "$mode" = floating ] && want=true
err=""
note() { [ -n "$1" ] && err="$err $1;"; }

if [ -z "$only" ]; then
  if [ "$kind" = lua ]; then
    o="$(hyprctl eval "hl.config({ general = { layout = \"$lay\" } })" 2>&1)"
  else
    o="$(hyprctl keyword general:layout "$lay" 2>&1)"
  fi
  case "$o" in ""|ok*|*"ok"*) ;; *) note "layout: $o" ;; esac
  sleep 0.4
fi

[ -n "$only" ] && sleep 0.15     # the window has only just opened
list="$(hyprctl clients -j 2>/dev/null)" || { echo "hyprctl clients failed"; exit 1; }
addrs="$(printf '%s' "$list" | python3 -I -c '
import json, sys
want = sys.argv[1] == "true"; only = sys.argv[2]
for c in json.load(sys.stdin):
    if not c.get("mapped", True): continue
    if only and c.get("address") != only: continue
    if c.get("fullscreen"): continue
    if bool(c.get("floating")) != want: print(c["address"])
' "$want" "$only")"

for a in $addrs; do
  if [ "$kind" = lua ]; then
    o="$(hyprctl dispatch "hl.dsp.window.float({ action = \"toggle\", window = \"address:$a\" })" 2>&1)"
  else
    o="$(hyprctl dispatch togglefloating "address:$a" 2>&1)"
  fi
  case "$o" in ""|ok*|*"ok"*) ;; *) note "float $a: $o" ;; esac
done

[ -n "$only" ] && [ -n "$addrs" ] && [ "$want" = true ] && {
  if [ "$kind" = lua ]; then hyprctl dispatch "hl.dsp.window.center()" >/dev/null 2>&1; else hyprctl dispatch centerwindow >/dev/null 2>&1; fi
}
[ -z "$err" ] && echo ok || echo "$err"
