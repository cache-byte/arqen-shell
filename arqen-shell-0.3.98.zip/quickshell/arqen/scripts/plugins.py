#!/usr/bin/env python3
"""Arqen plugins, kept in ~/.config/quickshell/widgets.

  plugins.py list   PLUGINS_DIR                     one JSON line: every plugin found and its manifest
  plugins.py import SOURCE PLUGINS_DIR              SOURCE: a .zip / .tar(.gz/.xz/.bz2/.zst) / a folder.
                                                    Every plugin inside (a folder with manifest.json) is copied
                                                    in; a plugin already there is replaced (its settings kept)
  plugins.py export PLUGIN_FOLDER DEST              DEST ending .zip: a zip, else a .tar.gz. Without settings.json

A plugin is a folder:
  manifest.json   { "id", "name", "version", "author", "description", "entryPoints": { "main": "Main.qml",
                    "barWidget": "BarWidget.qml", "desktopWidget": "DesktopWidget.qml",
                    "controlCenterWidget": "ControlCenterWidget.qml", "panel": "Panel.qml",
                    "settings": "Settings.qml" }, "metadata": { "defaultSettings": {} } }
  preview.png, README.md, settings.json (your own settings, never exported)
"""
import json
import os
import re
import shutil
import sys
import tarfile
import tempfile
import zipfile


def out(obj):
    print(json.dumps(obj), flush=True)


def read_manifest(d):
    with open(os.path.join(d, "manifest.json"), encoding="utf-8") as f:
        return json.load(f)


def safe_id(s):
    s = re.sub(r"[^A-Za-z0-9._-]+", "-", str(s or "")).strip("-.")
    return s or "plugin"


FOREIGN = re.compile(r"^\s*import\s+qs\.(Commons|Widgets|Services|Modules|Helpers)\b", re.M)


def uses_other_shell(d):
    """A plugin written for Noctalia (its qs.Commons / qs.Widgets modules), which Arqen does not carry."""
    for cur, _dirs, files in os.walk(d):
        for f in files:
            if f.endswith(".qml"):
                try:
                    with open(os.path.join(cur, f), encoding="utf-8", errors="replace") as fh:
                        if FOREIGN.search(fh.read()):
                            return True
                except OSError:
                    pass
    return False


def cmd_list(pdir):
    os.makedirs(pdir, exist_ok=True)
    found = []
    for name in sorted(os.listdir(pdir)):
        d = os.path.join(pdir, name)
        if not os.path.isdir(d) or name.startswith("."):
            continue
        item = {"folder": name, "dir": d, "manifest": None, "error": ""}
        if not os.path.isfile(os.path.join(d, "manifest.json")):
            item["error"] = "no manifest.json"
        else:
            try:
                m = read_manifest(d)
                item["manifest"] = m
                eps = m.get("entryPoints") or {}
                missing = [f for f in eps.values() if isinstance(f, str) and not os.path.isfile(os.path.join(d, f))]
                if missing:
                    item["error"] = "missing " + ", ".join(missing)
                elif uses_other_shell(d):
                    item["error"] = "made for another shell (it needs modules Arqen does not have)"
            except Exception as e:
                item["error"] = "manifest.json: %s" % e
        item["preview"] = os.path.join(d, "preview.png") if os.path.isfile(os.path.join(d, "preview.png")) else ""
        item["hasSettings"] = os.path.isfile(os.path.join(d, "settings.json"))
        found.append(item)
    out({"plugins": found})


def find_plugins(root, depth=4):
    res = []
    for cur, dirs, files in os.walk(root):
        if cur[len(root):].count(os.sep) > depth:
            dirs[:] = []
            continue
        if "manifest.json" in files:
            res.append(cur)
            dirs[:] = []                       # a plugin's own folders are not more plugins
        dirs[:] = [x for x in dirs if not x.startswith(".") and x not in ("node_modules", "__MACOSX")]
    return res


def within(base, target):
    base = os.path.realpath(base)
    return os.path.realpath(target).startswith(base + os.sep) or os.path.realpath(target) == base


def extract(src, dest):
    low = src.lower()
    if zipfile.is_zipfile(src):
        with zipfile.ZipFile(src) as z:
            for m in z.infolist():
                if not within(dest, os.path.join(dest, m.filename)):
                    raise ValueError("unsafe path in the archive: " + m.filename)
            z.extractall(dest)
        return
    if low.endswith(".zst") or low.endswith(".tzst"):
        import subprocess
        r = subprocess.run(["tar", "--zstd", "-xf", src, "-C", dest], capture_output=True, text=True)
        if r.returncode != 0:
            raise ValueError(r.stderr.strip() or "could not unpack")
        return
    with tarfile.open(src) as t:
        for m in t.getmembers():
            if not within(dest, os.path.join(dest, m.name)) or m.issym() or m.islnk():
                if m.issym() or m.islnk():
                    continue
                raise ValueError("unsafe path in the archive: " + m.name)
        members = [m for m in t.getmembers() if not (m.issym() or m.islnk() or m.isdev())]
        try:
            t.extractall(dest, members=members, filter="data")      # Python 3.12+: the safe way
        except TypeError:
            t.extractall(dest, members=members)


def cmd_import(src, pdir):
    os.makedirs(pdir, exist_ok=True)
    src = os.path.expanduser(src)
    if not os.path.exists(src):
        out({"error": "not found: " + src}); return
    tmp = tempfile.mkdtemp(prefix="arqen-plugin-")
    imported, errors = [], []
    try:
        if os.path.isdir(src):
            roots = find_plugins(src)
        else:
            try:
                extract(src, tmp)
            except Exception as e:
                out({"error": "could not unpack: %s" % e}); return
            roots = find_plugins(tmp)
        if not roots:
            out({"error": "no plugin found (a plugin is a folder with a manifest.json)"}); return
        for r in roots:
            try:
                m = read_manifest(r)
            except Exception as e:
                errors.append("%s: %s" % (os.path.basename(r), e)); continue
            pid = safe_id(m.get("id") or os.path.basename(r))
            target = os.path.join(pdir, pid)
            keep = None
            if os.path.isfile(os.path.join(target, "settings.json")):
                with open(os.path.join(target, "settings.json"), "rb") as f:
                    keep = f.read()
            if os.path.realpath(r) == os.path.realpath(target):
                imported.append(pid); continue
            if os.path.exists(target):
                shutil.rmtree(target)
            shutil.copytree(r, target, symlinks=False, ignore=shutil.ignore_patterns(".git", "__MACOSX", "*.pyc"))
            if keep is not None:
                with open(os.path.join(target, "settings.json"), "wb") as f:
                    f.write(keep)
            imported.append(pid)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    out({"imported": imported, "errors": errors})


def cmd_export(folder, dest):
    folder = os.path.abspath(os.path.expanduser(folder))
    dest = os.path.expanduser(dest)
    if not os.path.isfile(os.path.join(folder, "manifest.json")):
        out({"error": "not a plugin (no manifest.json)"}); return
    try:
        pid = safe_id(read_manifest(folder).get("id") or os.path.basename(folder))
    except Exception:
        pid = os.path.basename(folder)
    skip = {"settings.json", ".git", "__pycache__"}
    os.makedirs(os.path.dirname(os.path.abspath(dest)) or ".", exist_ok=True)
    if dest.lower().endswith(".zip"):
        with zipfile.ZipFile(dest, "w", zipfile.ZIP_DEFLATED) as z:
            for cur, dirs, files in os.walk(folder):
                dirs[:] = [d for d in dirs if d not in skip]
                for f in files:
                    if f in skip:
                        continue
                    p = os.path.join(cur, f)
                    z.write(p, os.path.join(pid, os.path.relpath(p, folder)))
    else:
        if not re.search(r"\.(tar\.gz|tgz)$", dest.lower()):
            dest += ".tar.gz"
        with tarfile.open(dest, "w:gz") as t:
            t.add(folder, arcname=pid, filter=lambda ti: None if os.path.basename(ti.name) in skip else ti)
    out({"exported": dest})


if __name__ == "__main__":
    a = sys.argv[1:]
    try:
        if a[:1] == ["list"]:
            cmd_list(a[1])
        elif a[:1] == ["import"]:
            cmd_import(a[1], a[2])
        elif a[:1] == ["export"]:
            cmd_export(a[1], a[2])
        else:
            print(__doc__)
    except Exception as e:
        out({"error": str(e)})
