import Quickshell
import Quickshell.Wayland
import Quickshell.Hyprland
import Quickshell.Widgets
import Quickshell.Bluetooth
import Quickshell.Services.UPower
import Quickshell.Services.SystemTray
import QtQuick
import QtQuick.Layouts
import qs.config
import qs.components
import qs.services

// Panels (desktop bars). There can be several; each sits on a screen edge, with its own
// length, alignment and thickness (Config.panelsNow), on every screen. The layer window always
// spans the whole edge (so the compositor reserves space correctly); the visible bar is drawn
// inside it and only it takes input.
//
// What sits in a panel's left / centre / right section is its `layout` (Settings > Panels, or
// right-click the panel to edit it right there: drag items, remove them, pull the handles to resize).
Variants {
    // one window per screen and panel; keyed by "screen<TAB>panel" so editing a panel keeps its window
    model: {
        const out = []
        for (const sc of Quickshell.screens)
            for (const id of Config.panelIds) out.push(sc.name + "\t" + id)
        return out
    }

    PanelWindow {
        id: bar
        required property string modelData
        readonly property string screenName: modelData.split("\t")[0]
        readonly property string panelId: modelData.split("\t")[1] ?? ""
        screen: Quickshell.screens.find(s => s.name === bar.screenName) ?? Quickshell.screens[0]

        readonly property var cfg: Config.panel(panelId) ?? ({ id: panelId, edge: "bottom", align: "center", length: 100, thickness: 56,
                                                               layout: { left: [], center: [], right: [] } })
        readonly property string edge: cfg.edge
        readonly property bool vertical: edge === "left" || edge === "right"
        readonly property string align: cfg.align
        readonly property int m: Ui.barGap
        // while a resize handle is being dragged the new size is shown live and saved on release
        property int dragThick: -1
        property int dragLength: -1
        // the thickness asked for, or more when the items need it (big icons, a large clock)
        readonly property real contentCross: Math.max(cross(leftSec), cross(centreSec), cross(rightSec))
        // the screen's scale: with "Same size at any screen scale" (the default) the panel keeps its size
        // on the screen when the scale changes (bigger scale, not a bigger panel), and grows a little on
        // screens with more pixels; otherwise it grows and shrinks with the scale like apps do
        readonly property real dpr: Math.max(0.5, screen?.devicePixelRatio ?? 1)
        readonly property real ds: (Config.c.panelScaleMode || "auto") === "auto"
                                   ? Math.max(0.5, Math.min(2, Math.max(1, Math.min(1.6, (screen?.height ?? 1080) * dpr / 1080)) / dpr))
                                   : 1
        readonly property int thick: Math.max(dragThick > 0 ? dragThick : Math.round(cfg.thickness * ds), Math.ceil(contentCross) + 8)
        // global size of panel items (not the dock or the clock): Settings > Panels > Item size
        readonly property real k: Config.c.itemSize / 24 * ds
        // per-item sizes on this panel; while a size handle is dragged the live value is used
        property string sizingId: ""
        property real sizingF: 1
        function sizeOf(id) {
            if (id === sizingId) return sizingF
            const sz = cfg.sizes || {}
            return sz[id] ?? 1
        }
        function cross(g) { return g ? (vertical ? g.width : g.height) : 0 }
        function alongSize(g) { return g ? (vertical ? g.height : g.width) : 0 }
        // let popups keep clear of the real thickness
        onThickChanged: Ui.reportThick(panelId, thick)
        Component.onCompleted: Ui.reportThick(panelId, thick)
        readonly property int lengthPct: dragLength > 0 ? dragLength : cfg.length
        readonly property bool full: lengthPct >= 100
        readonly property int cell: Math.round(Config.c.iconSize * ds) + 14
        readonly property var layout: cfg.layout
        readonly property int pad: Math.round((compact ? Math.min(1, Config.c.itemPadding) : Config.c.itemPadding) * ds)
        readonly property bool editing: Ui.open === "paneledit" && Ui.editPanel === panelId
        readonly property bool primary: Config.panelIndex(panelId) === 0
        // name tips open away from the screen edge
        readonly property string tipSide: edge === "top" ? "bottom" : edge === "left" ? "right" : edge === "right" ? "left" : "top"

        anchors {
            left: vertical ? edge === "left" : true
            right: vertical ? edge === "right" : true
            top: vertical ? true : edge === "top"
            bottom: vertical ? true : edge === "bottom"
        }
        implicitHeight: vertical ? 0 : thick + m
        implicitWidth: vertical ? thick + m : 0
        color: "transparent"
        // Input only on the bar (and, for an autohiding panel, the strip along the screen edge that
        // brings it back). Everything else passes through to the windows underneath.
        // One region on one fixed item (hitArea) whose size changes: swapping the region's item, or
        // nested regions, could leave a stale input area after turning autohide off (dead panel).
        mask: Region { item: hitArea }
        // a window screenshot: the panel steps aside so it is not in the picture
        Binding { target: bar.contentItem; property: "opacity"; value: Ui.hideChrome ? 0 : 1 }
        WlrLayershell.namespace: "arqen-panel"

        // ---- autohide ----
        // An autohiding panel reserves no space: windows use the whole screen. It slides off the
        // edge when the pointer leaves it, and comes back when the pointer touches that edge.
        // It stays while you are on it, while a popup it opened is up, and while editing it.
        readonly property bool autohide: cfg.autohide === true
        readonly property bool islands: cfg.islands === true
        exclusionMode: autohide ? ExclusionMode.Ignore : ExclusionMode.Auto
        readonly property bool hovering: bgHover.hovered || stripHover.hovered
        readonly property bool keepShown: editing || dragId !== "" || sizingId !== "" || dragThick > 0 || dragLength > 0
                                          || (Ui.open !== "" && Ui.open !== "paneledit" && Ui.edge === edge)
        property bool shownByHover: false
        // the desktop overview takes the whole screen: every panel slides away while it is open
        readonly property bool overviewOpen: Ui.open === "overview"
        readonly property bool hiddenNow: overviewOpen || (autohide && !shownByHover && !keepShown)
        onHoveringChanged: { if (hovering) { shownByHover = true; hideTimer.stop() } else hideTimer.restart() }
        onKeepShownChanged: if (!keepShown && !hovering) hideTimer.restart()
        onAutohideChanged: { shownByHover = false; hideTimer.stop() }
        Timer { id: hideTimer; interval: 700; onTriggered: if (!bar.hovering) bar.shownByHover = false }
        // how far the bar moves out of sight (towards its screen edge)
        readonly property real hideShift: hiddenNow ? thick + m + 2 : 0

        SystemClock { id: clock; precision: SystemClock.Minutes }

        // Caffeine: tells the compositor not to idle (lock / dim / sleep). One window is enough:
        // the first panel on the first screen.
        IdleInhibitor { window: bar; enabled: Caffeine.active && bar.primary && Quickshell.screens[0] === bar.screen }

        function along(total, size) {
            const a = bar.align
            return a === "start" ? m : (a === "end" ? total - size - m : (total - size) / 2)
        }
        function matches(t, id, entry) {
            const a = (t.appId || "").toLowerCase()
            // a window without a name (a browser's picture-in-picture, some pop-ups) is no app's window:
            // "" would otherwise equal every app that has no startup class
            if (a === "") return false
            const sc = (entry?.startupClass || "").toLowerCase()
            return a === id.toLowerCase() || (sc !== "" && a === sc)
        }
        // Steam games (their windows are steam_app_<id>) show with the app status icons, not in the dock
        readonly property var gameWindows: ToplevelManager.toplevels.values.filter(t => /^steam_(app|icon)_\d+$/.test((t.appId || "").toLowerCase()))
        readonly property var trayModel: SystemTray.items.values.map(t => ({ tray: t, game: null })).concat(gameWindows.map(g => ({ tray: null, game: g })))
        readonly property var dockItems: {
            const running = ToplevelManager.toplevels.values
            const out = []
            for (const id of (Config.c.pinned || [])) {
                const e = Apps.byId(id)
                if (!e) continue
                const tl = running.filter(t => matches(t, id, e))
                out.push({ id: id, entry: e, tl: tl.length > 0 ? tl[0] : null, tls: tl })
            }
            if (Config.c.showRunning) {
                for (const t of running) {
                    const appId = (t.appId || "").toLowerCase()
                    if (appId === "") continue
                    // Steam games often expose a synthetic steam_app_<id> Wayland appId.
                    // Keep those game windows out of the active-app dock: Steam's own
                    // status/tray icons are rendered separately by the SystemTray section.
                    // This avoids one duplicate dock entry per launched game while keeping
                    // normal Steam, Steam Beta, and other launchers in the dock.
                    if (/^steam_app_\d+$/.test(appId) || /^steam_icon_\d+$/.test(appId)) continue
                    if (out.some(o => o.tl && (o.tl.appId || "").toLowerCase() === appId)) continue
                    if ((Config.c.pinned || []).some(id => matches(t, id, Apps.byId(id)))) continue
                    out.push({ id: t.appId, entry: Apps.byId(t.appId), tl: t, tls: running.filter(x => x.appId === t.appId) })
                }
            }
            return out
        }

        // ---- layout helpers ----
        // elements that get a thin divider in front of them (when something precedes them)
        readonly property var dividedIds: ["dock", "tray", "control"]

        function shows(id) {
            switch (id) {
            case "clock":  return Config.c.clockShowTime || Config.c.clockShowDate
            case "dock":   return dockItems.length > 0
            case "tray":   return trayModel.length > 0
            case "media":  return Media.has
            default:
                if (String(id).startsWith("plugin:")) return Plugins.find(id.slice(7)) !== null && Plugins.isEnabled(id.slice(7))
                return true
            }
        }
        function dividerBefore(id) {
            if (dividedIds.indexOf(id) < 0) return false
            for (const s of Config.barSections) {
                const i = layout[s].indexOf(id)
                if (i >= 0) return layout[s].slice(0, i).some(x => shows(x))
            }
            return false
        }
        // Where along the screen (x, or y on a vertical panel) an item's centre is. This window can
        // be pushed in by panels on the neighbouring edges (their reserved space), so the offset of
        // the window on the screen is worked out from how much of the edge it is missing.
        function screenOffset() {
            const sc = bar.screen
            if (!sc) return 0
            const free = vertical ? sc.height - bar.height : sc.width - bar.width
            const a = vertical ? Ui.rTop : Ui.rLeft
            const b = vertical ? Ui.rBottom : Ui.rRight
            if (free <= 0) return 0
            if (free >= a + b) return a
            if (free === b && free !== a) return 0
            return Math.min(free, a)
        }
        function centreOf(item) {
            const p = item.mapToItem(null, item.width / 2, item.height / 2)
            return (vertical ? p.y : p.x) + screenOffset()
        }
        function openFrom(name, item) { Ui.toggle(name, item ? centreOf(item) : -1, bar.edge) }
        function openTrayMenu(trayItem, item) {
            if (Ui.open === "traymenu" && Ui.trayItem === trayItem) { Ui.close(); return }
            // clicking another status icon while a menu is open switches to its menu
            Ui.trayItem = trayItem
            Ui.popAlong = centreOf(item)
            Ui.popEdge = bar.edge
            Ui.open = "traymenu"
        }

        // ---- edit mode: drag an item to a new spot ----
        property string dragId: ""
        function sectionOfItem(id) { return Config.barSections.find(s => bar.layout[s].indexOf(id) >= 0) ?? "" }
        // pos = where the pointer is along the panel, in the bar's (bg) coordinates
        function dropElement(id, pos) {
            const secs = [{ k: "left", g: leftSec, r: leftRep }, { k: "center", g: centreSec, r: centreRep }, { k: "right", g: rightSec, r: rightRep }]
            let best = secs[1], bd = 1e9
            for (const sc of secs) {
                const a0 = vertical ? sc.g.y : sc.g.x
                const a1 = a0 + (vertical ? sc.g.height : sc.g.width)
                const d = pos < a0 ? a0 - pos : (pos > a1 ? pos - a1 : 0)
                if (d < bd) { bd = d; best = sc }
            }
            // position inside that section: after every (other) item whose centre is before the pointer
            const ids = bar.layout[best.k]
            let idx = 0, j = 0
            for (let i = 0; i < ids.length; i++) {
                if (ids[i] === id) continue
                const it = best.r.itemAt(i)
                if (it && it.visible) {
                    const c = it.mapToItem(bg, it.width / 2, it.height / 2)
                    if ((vertical ? c.y : c.x) < pos) idx = j + 1
                }
                j++
            }
            Config.placeElement(bar.panelId, id, best.k, idx)
        }

        // ================= elements =================
        // Every element sizes itself from `u`: the global item size (Settings > Panels > Item size)
        // times its own size on this panel (pull the corner handle in edit mode). The app dock uses
        // the app icon size instead, and the clock its own font size. Nothing here depends on the
        // panel's thickness: the panel grows to fit its items, not the other way round.
        // `parent.sizeF` is set by the slot's Loader (see slotC).

        // Desktop indicator: one mark per desktop (workspace), the current one stands out.
        // Click = open the desktop view, scroll = switch desktop. Style: Settings > Panel items.
        Component {
            id: workspacesC
            Rectangle {
                id: wsb
                readonly property real sf: (parent && parent.sizeF !== undefined) ? parent.sizeF : 1
                readonly property real u: bar.k * sf
                readonly property string wsStyle: Config.c.wsStyle
                readonly property bool dots: wsStyle === "dots"
                readonly property bool boxes: wsStyle === "boxes"
                implicitWidth: bar.vertical ? Math.round(36 * u) + 2 * bar.pad : wsGrid.implicitWidth + 2 * (bar.pad + Math.round(8 * u))
                implicitHeight: bar.vertical ? wsGrid.implicitHeight + 2 * (bar.pad + Math.round(8 * u)) : Math.round(26 * u) + 2 * bar.pad
                radius: Math.min(Config.c.tileRadius * 0.86 * u, Math.min(width, height) / 2)
                color: Ui.open === "overview" ? Theme.tileOn : (wma.containsMouse ? Theme.hover : Theme.tile)
                Behavior on color { ColorAnimation { duration: 120 } }

                Grid {
                    id: wsGrid
                    anchors.centerIn: parent
                    columns: bar.vertical ? 1 : -1; rows: bar.vertical ? -1 : 1
                    spacing: Math.round((wsb.dots ? 6 : 4) * wsb.u)
                    horizontalItemAlignment: Grid.AlignHCenter
                    verticalItemAlignment: Grid.AlignVCenter
                    Repeater {
                        model: Workspaces.list
                        delegate: Rectangle {
                            id: w
                            required property int modelData
                            readonly property bool act: modelData === Workspaces.focusedId
                            readonly property bool busy: Workspaces.busy(modelData)
                            readonly property bool txt: Workspaces.textStyle
                            readonly property real u: wsb.u
                            // sizes: dots are 8 px (the current one stretches into a pill),
                            // boxes are 12 px squares, text chips grow with their label
                            width: txt ? Math.max(22 * u, lbl.implicitWidth + 14 * u)
                                 : wsb.boxes ? 12 * u
                                 : (act && !bar.vertical ? 22 * u : 8 * u)
                            height: txt ? 22 * u : wsb.boxes ? 12 * u : (act && bar.vertical ? 22 * u : 8 * u)
                            radius: txt ? 11 * u : wsb.boxes ? 3 * u : 4 * u
                            color: txt ? (act ? Theme.text : "transparent")
                                 : wsb.boxes ? (act ? Theme.text : "transparent")
                                 : (act ? Theme.text : Theme.subtext)
                            border.width: wsb.boxes ? 1.5 : 0
                            border.color: act ? Theme.text : Theme.subtext
                            opacity: (act || busy) ? 1 : 0.45
                            Behavior on width { NumberAnimation { duration: 140 } }
                            Behavior on height { NumberAnimation { duration: 140 } }
                            Behavior on opacity { NumberAnimation { duration: 140 } }
                            DText {
                                id: lbl
                                visible: w.txt
                                anchors.centerIn: parent
                                text: Workspaces.label(w.modelData)
                                font.pixelSize: Math.round(13 * w.u)
                                font.weight: w.act ? Font.Bold : Font.Medium
                                color: w.act ? (Theme.dark ? "#0B0B0D" : "#FFFFFF") : Theme.subtext
                            }
                        }
                    }
                }
                MouseArea {
                    id: wma
                    anchors.fill: parent; hoverEnabled: true
                    cursorShape: Qt.PointingHandCursor
                    onClicked: Ui.toggle("overview")
                    onWheel: wheel => Hypr.workspace(wheel.angleDelta.y > 0 ? "e-1" : "e+1")
                }
                HoverTip { hovered: wma.containsMouse; text: "Desktops"; side: bar.tipSide }
            }
        }

        Component {
            id: searchC
            TrayButton {
                readonly property real sf: (parent && parent.sizeF !== undefined) ? parent.sizeF : 1
                icon: "search"; size: Math.round(26 * bar.k * sf)
                tip: "Search"; tipSide: bar.tipSide
                active: Ui.open === "search"; onClicked: Ui.toggle("search")
            }
        }

        // Clipboard history: opens its popup next to the button.
        Component {
            id: clipboardC
            TrayButton {
                id: cbb
                readonly property real sf: (parent && parent.sizeF !== undefined) ? parent.sizeF : 1
                icon: "content_paste"; size: Math.round(24 * bar.k * sf)
                tip: "Clipboard"; tipSide: bar.tipSide
                active: Ui.open === "clipboard"
                onClicked: bar.openFrom("clipboard", cbb)
            }
        }

        // the on-screen keyboard
        Component {
            id: keyboardC
            TrayButton {
                readonly property real sf: (parent && parent.sizeF !== undefined) ? parent.sizeF : 1
                icon: "keyboard"; size: Math.round(24 * bar.k * sf)
                tip: "On-screen keyboard"; tipSide: bar.tipSide
                active: Osk.shown
                onClicked: Osk.toggle()
            }
        }

        Component {
            id: launcherC
            TrayButton {
                readonly property real sf: (parent && parent.sizeF !== undefined) ? parent.sizeF : 1
                icon: "apps"; size: Math.round(26 * bar.k * sf)
                tip: "Apps"; tipSide: bar.tipSide
                active: Ui.open === "launcher"; onClicked: Ui.toggle("launcher")
            }
        }

        // Pinned and running apps. Sized by the app icon size (Settings > Panels).
        Component {
            id: dockC
            // Too little room on the panel (a big screen scale, many items): the dock folds into one
            // button with an arrow; click it to show the apps in a strip above (or beside) the panel.
            Item {
                id: dockRoot
                readonly property real sf: (parent && parent.sizeF !== undefined) ? parent.sizeF : 1
                readonly property int icon: Math.round(Config.c.iconSize * sf * bar.ds)
                readonly property int cellSize: icon + 14
                readonly property bool folded: bar.dockCollapsed && !(parent && parent.inFold === true)
                implicitWidth: folded ? foldBtn.width : dock.width
                implicitHeight: folded ? foldBtn.height : dock.height
                width: implicitWidth; height: implicitHeight

                Component {
                    id: dockIconC
                    Item {
                        id: di
                        required property var modelData
                        width: dockRoot.cellSize
                        height: dockRoot.cellSize
                        Rectangle {
                            anchors.centerIn: parent
                            width: dockRoot.icon + 10; height: dockRoot.icon + 10; radius: 14
                            color: dma.containsMouse ? Theme.hover : "transparent"
                        }
                        AppIcon {
                            anchors.centerIn: parent
                            opacity: di.modelData.tl && Windows.isMinimized(di.modelData.tl) ? 0.5 : 1   // minimised: faded
                            scale: dma.pressed ? 0.86 : (dma.containsMouse ? 1.1 : 1)
                            Behavior on scale { NumberAnimation { duration: 260; easing.type: Easing.OutBack; easing.overshoot: Motion.os(2.5) } }
                            size: dockRoot.icon
                            entry: di.modelData.entry ?? null
                            source: di.modelData.entry ? "" : (di.modelData.id || "")
                        }
                        Rectangle {   // running indicator
                            visible: di.modelData.tl !== null
                            readonly property bool act: di.modelData.tl?.activated ?? false
                            width: bar.vertical ? 4 : (act ? 18 : 6)
                            height: bar.vertical ? (act ? 18 : 6) : 4
                            radius: 2; color: Theme.text
                            // plain x / y: switching anchors when the panel changes edge is unreliable
                            x: bar.vertical ? 0 : Math.round((di.width - width) / 2)
                            y: bar.vertical ? Math.round((di.height - height) / 2) : di.height - height
                            Behavior on width { NumberAnimation { duration: 120 } }
                            Behavior on height { NumberAnimation { duration: 120 } }
                        }
                        readonly property var wins: di.modelData.tls ?? (di.modelData.tl ? [di.modelData.tl] : [])
                        MouseArea {
                            id: dma; anchors.fill: parent; hoverEnabled: true
                            onClicked: {
                                // several windows: pick one from the previews; one: bring it up (a minimised or
                                // tucked-away one comes back to this desktop); none: start the app
                                if (di.wins.length > 1) { bar.preview = bar.preview === di ? null : di; bar.previewStick = bar.preview === di; return }
                                if (di.modelData.tl) Windows.bring(di.modelData.tl)
                                else if (di.modelData.entry) di.modelData.entry.execute()
                                bar.preview = null
                                bar.dockOpen = false
                            }
                            // resting on a running app shows its windows
                            onContainsMouseChanged: {
                                if (containsMouse && di.wins.length > 0) { prevOff.stop(); if (bar.preview && bar.preview !== di) { bar.previewStick = false; bar.preview = di } else prevOn.restart() }
                                else { prevOn.stop(); prevOff.restart() }
                            }
                        }
                        Timer { id: prevOn; interval: 450; onTriggered: if (dma.containsMouse && di.wins.length > 0) { bar.previewStick = false; bar.preview = di } }
                        Timer { id: prevOff; interval: 350; onTriggered: if (bar.preview === di && !bar.previewStick && !prevPop.hovered && !dma.containsMouse) bar.preview = null }
                        HoverTip {
                            hovered: dma.containsMouse && bar.preview !== di; side: bar.tipSide
                            text: di.modelData.entry?.name ?? (di.modelData.tl?.title || di.modelData.id || "")
                        }

                        HyprlandFocusGrab {
                            windows: [prevPop]
                            active: prevPop.visible && bar.previewStick
                            onCleared: { bar.preview = null; bar.previewStick = false }
                        }
                        // ---- small live previews of the app's windows, above the icon: click one to bring it up ----
                        PopupWindow {
                            id: prevPop
                            readonly property bool hovered: prevHov.hovered
                            onHoveredChanged: if (!hovered) prevOff.restart()
                            visible: bar.preview === di && di.wins.length > 0
                            anchor.item: di
                            anchor.edges: bar.edge === "bottom" ? Edges.Top : bar.edge === "top" ? Edges.Bottom : bar.edge === "left" ? Edges.Right : Edges.Left
                            anchor.gravity: anchor.edges
                            anchor.margins.top: bar.edge === "bottom" ? -8 : 0
                            anchor.margins.bottom: bar.edge === "top" ? -8 : 0
                            anchor.margins.left: bar.edge === "right" ? -8 : 0
                            anchor.margins.right: bar.edge === "left" ? -8 : 0
                            color: "transparent"
                            implicitWidth: prevBox.width
                            implicitHeight: prevBox.height
                            // grows in
                            property real t: 0
                            onVisibleChanged: if (visible) { t = 0; prevIn.restart() }
                            NumberAnimation { id: prevIn; target: prevPop; property: "t"; to: 1; duration: 300; easing.type: Easing.OutBack; easing.overshoot: Motion.os(1.3) }
                            Rectangle {
                                id: prevBox
                                readonly property int cardW: 196
                                readonly property int cardH: 150
                                width: prevGrid.implicitWidth + 16
                                height: prevGrid.implicitHeight + 16
                                radius: Theme.radius
                                color: Theme.glass
                                border.width: 1; border.color: Theme.stroke
                                opacity: Math.min(1, prevPop.t)
                                scale: 0.9 + 0.1 * prevPop.t
                                transformOrigin: bar.edge === "bottom" ? Item.Bottom : bar.edge === "top" ? Item.Top : bar.edge === "left" ? Item.Left : Item.Right
                                HoverHandler { id: prevHov }
                                Grid {
                                    id: prevGrid
                                    anchors.centerIn: parent
                                    columns: bar.vertical ? 1 : Math.min(4, di.wins.length)
                                    spacing: 8
                                    Repeater {
                                        model: prevPop.visible ? di.wins : []
                                        delegate: Rectangle {
                                            id: card
                                            required property var modelData
                                            readonly property bool away: Windows.isMinimized(modelData)
                                            width: prevBox.cardW; height: prevBox.cardH; radius: 14
                                            color: cma2.containsMouse ? Theme.hover : Theme.tile
                                            border.width: modelData.activated ? 2 : 0; border.color: Theme.primary
                                            scale: cma2.pressed ? 0.95 : 1
                                            Behavior on scale { NumberAnimation { duration: 200; easing.type: Easing.OutBack; easing.overshoot: Motion.os(2) } }
                                            ClippingRectangle {
                                                x: 8; y: 8; width: parent.width - 16; height: parent.height - 40; radius: 9
                                                color: Qt.rgba(0, 0, 0, 0.25)
                                                ScreencopyView {
                                                    anchors.fill: parent
                                                    captureSource: prevPop.visible ? card.modelData : null
                                                    live: true
                                                    opacity: card.away ? 0.5 : 1
                                                }
                                            }
                                            Row {
                                                x: 10; y: parent.height - 26; width: parent.width - 20; spacing: 6
                                                AppIcon { size: 16; entry: di.modelData.entry ?? null; source: di.modelData.entry ? "" : (di.modelData.id || ""); anchors.verticalCenter: parent.verticalCenter }
                                                DText { width: parent.width - 22 - (closeX.visible ? 22 : 0); elide: Text.ElideRight; font.pixelSize: 12
                                                        text: (card.away ? "(hidden) " : "") + (card.modelData.title || di.modelData.entry?.name || ""); anchors.verticalCenter: parent.verticalCenter }
                                            }
                                            MouseArea {
                                                id: cma2
                                                anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor
                                                acceptedButtons: Qt.LeftButton | Qt.MiddleButton
                                                onClicked: mouse => {
                                                    const w = card.modelData
                                                    bar.preview = null
                                                    if (mouse.button === Qt.MiddleButton) { w.close(); return }
                                                    Windows.bring(w)
                                                }
                                            }
                                            // close this window
                                            Rectangle {
                                                id: closeX
                                                visible: cma2.containsMouse || xMa2.containsMouse
                                                x: parent.width - width - 6; y: parent.height - height - 5
                                                width: 20; height: 20; radius: 10
                                                color: xMa2.containsMouse ? "#FF4D4D" : Theme.hover
                                                Icon { anchors.centerIn: parent; name: "close"; size: 14; color: xMa2.containsMouse ? "white" : Theme.text }
                                                MouseArea { id: xMa2; anchors.fill: parent; hoverEnabled: true; onClicked: { const w = card.modelData; w.close() } }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                Grid {
                    id: dock
                    visible: !dockRoot.folded
                    columns: bar.vertical ? 1 : -1; rows: bar.vertical ? -1 : 1
                    spacing: 6
                    horizontalItemAlignment: Grid.AlignHCenter
                    verticalItemAlignment: Grid.AlignVCenter
                    Repeater { model: dockRoot.folded ? [] : bar.dockItems; delegate: dockIconC }
                }

                // folded: an apps button with an arrow pointing to where the strip opens
                Rectangle {
                    id: foldBtn
                    visible: dockRoot.folded
                    readonly property string arrow: bar.edge === "bottom" ? (bar.dockOpen ? "expand_more" : "expand_less")
                                                  : bar.edge === "top" ? (bar.dockOpen ? "expand_less" : "expand_more")
                                                  : bar.edge === "left" ? (bar.dockOpen ? "chevron_left" : "chevron_right")
                                                  : (bar.dockOpen ? "chevron_right" : "chevron_left")
                    width: bar.vertical ? dockRoot.cellSize : dockRoot.cellSize + 22
                    height: bar.vertical ? dockRoot.cellSize + 22 : dockRoot.cellSize
                    radius: Math.min(width, height) / 2
                    color: bar.dockOpen ? Theme.secondaryContainer : (fma.containsMouse ? Theme.hover : "transparent")
                    Grid {
                        anchors.centerIn: parent
                        columns: bar.vertical ? 1 : 2
                        spacing: 2
                        horizontalItemAlignment: Grid.AlignHCenter
                        verticalItemAlignment: Grid.AlignVCenter
                        Icon { name: "apps"; size: Math.round(dockRoot.icon * 0.7); color: bar.dockOpen ? Theme.onSecondaryContainer : Theme.text }
                        Icon { name: foldBtn.arrow; size: 18; color: bar.dockOpen ? Theme.onSecondaryContainer : Theme.subtext }
                    }
                    MouseArea { id: fma; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: bar.dockOpen = !bar.dockOpen }
                    HoverTip { hovered: fma.containsMouse && !bar.dockOpen; side: bar.tipSide; text: "Apps (" + bar.dockItems.length + ")" }

                    // closes on a click elsewhere (a Hyprland focus grab; the popup's own grabFocus fought the visible binding)
                    HyprlandFocusGrab { windows: [foldPop]; active: foldPop.visible; onCleared: bar.dockOpen = false }
                    PopupWindow {
                        id: foldPop
                        visible: bar.dockOpen && dockRoot.folded
                        anchor.item: foldBtn
                        anchor.edges: bar.edge === "bottom" ? Edges.Top : bar.edge === "top" ? Edges.Bottom : bar.edge === "left" ? Edges.Right : Edges.Left
                        anchor.gravity: anchor.edges
                        anchor.margins.top: bar.edge === "bottom" ? -10 : 0
                        anchor.margins.bottom: bar.edge === "top" ? -10 : 0
                        anchor.margins.left: bar.edge === "right" ? -10 : 0
                        anchor.margins.right: bar.edge === "left" ? -10 : 0
                        color: "transparent"
                        implicitWidth: strip.width + 16
                        implicitHeight: strip.height + 16
                        onVisibleChanged: if (!visible) bar.dockOpen = false
                        Rectangle {
                            anchors.fill: parent
                            radius: Math.min(Config.c.panelRadius + 4, Math.min(width, height) / 2)
                            color: Theme.cardSolid
                            border.width: 1; border.color: Theme.stroke
                            Grid {
                                id: strip
                                anchors.centerIn: parent
                                // a long list wraps instead of running off the screen
                                columns: bar.vertical ? 1 : Math.max(1, Math.min(bar.dockItems.length, Math.floor((bar.edgeLen * 0.9) / (dockRoot.cellSize + 6))))
                                rows: bar.vertical ? Math.max(1, Math.min(bar.dockItems.length, Math.floor((bar.edgeLen * 0.9) / (dockRoot.cellSize + 6)))) : -1
                                flow: bar.vertical ? Grid.TopToBottom : Grid.LeftToRight
                                spacing: 6
                                Repeater { model: dockRoot.folded && bar.dockOpen ? bar.dockItems : []; delegate: dockIconC }
                            }
                        }
                    }
                }
            }
        }

        // App status icons: Steam, Heroic, Discord, ... anything that registers a tray icon.
        // Left click = the app's own action, middle click = secondary action, right click = menu.
        Component {
            id: trayC
            Grid {
                id: tray
                readonly property real sf: (parent && parent.sizeF !== undefined) ? parent.sizeF : 1
                readonly property int icon: Math.round(22 * bar.k * sf)
                columns: bar.vertical ? 1 : -1; rows: bar.vertical ? -1 : 1
                spacing: 0
                horizontalItemAlignment: Grid.AlignHCenter
                verticalItemAlignment: Grid.AlignVCenter
                Repeater {
                    model: bar.trayModel
                    delegate: Item {
                        id: ti
                        required property var modelData
                        readonly property var tr: modelData.tray        // an app's status icon, or
                        readonly property var game: modelData.game      // a running Steam game (its window)
                        readonly property bool isGame: game !== null
                        implicitWidth: tray.icon + 2 * bar.pad + 2; implicitHeight: implicitWidth
                        Rectangle {
                            anchors.fill: parent; radius: 12
                            color: (tma.containsMouse || (!ti.isGame && Ui.open === "traymenu" && Ui.trayItem === ti.tr)) ? Theme.hover : "transparent"
                        }
                        AppIcon {
                            visible: ti.isGame
                            anchors.centerIn: parent
                            size: tray.icon
                            source: ti.isGame ? (ti.game.appId || "") : ""
                        }
                        Image {
                            visible: !ti.isGame
                            anchors.centerIn: parent
                            width: tray.icon; height: tray.icon
                            source: ti.isGame ? "" : ti.tr.icon
                            sourceSize: Qt.size(tray.icon * 2, tray.icon * 2)
                            fillMode: Image.PreserveAspectFit
                            smooth: true
                        }
                        Rectangle {   // "needs attention" dot (e.g. a Steam message)
                            visible: !ti.isGame && ti.tr.status === 2
                            width: 9; height: 9; radius: 5; color: "#FF4D4D"
                            border.width: 1; border.color: Theme.bar
                            x: parent.width - width - 5; y: 5
                        }
                        MouseArea {
                            id: tma
                            anchors.fill: parent; hoverEnabled: true
                            cursorShape: Qt.PointingHandCursor
                            acceptedButtons: Qt.LeftButton | Qt.RightButton | Qt.MiddleButton
                            onClicked: mouse => {
                                if (ti.isGame) {   // the game's window: bring it forward (right click: close it)
                                    if (mouse.button === Qt.RightButton || mouse.button === Qt.MiddleButton) ti.game.close()
                                    else { Ui.close(); ti.game.activate() }
                                    return
                                }
                                const t = ti.tr
                                if (mouse.button === Qt.MiddleButton) { t.secondaryActivate(); return }
                                if (mouse.button === Qt.RightButton || t.onlyMenu) {
                                    if (t.hasMenu) bar.openTrayMenu(t, ti)
                                    return
                                }
                                Ui.close()
                                t.activate()
                            }
                        }
                        HoverTip {
                            hovered: tma.containsMouse; side: bar.tipSide
                            text: ti.isGame ? ((ti.game.title || "Game") + "  (right click closes it)") : (ti.tr.tooltipTitle || ti.tr.title || ti.tr.id || "")
                        }
                    }
                }
            }
        }

        // Control centre: the notifications waiting (a red bell with how many), connected devices with their battery,
        // Wi-Fi, volume and battery in one button.
        // Click = open the sidebar, scroll = volume, middle click = mute.
        Component {
            id: controlC
            Rectangle {
                id: cc
                readonly property real sf: (parent && parent.sizeF !== undefined) ? parent.sizeF : 1
                readonly property real u: bar.k * sf
                readonly property int ic: Math.round(20 * u)
                readonly property bool charging: UPower.displayDevice.state === UPowerDeviceState.Charging
                readonly property bool hasBattery: UPower.displayDevice.isLaptopBattery
                readonly property bool btOn: Bluetooth.defaultAdapter?.enabled ?? false
                readonly property int nCount: Notifs.count
                implicitWidth: bar.vertical ? Math.round(36 * u) + 2 * bar.pad : ccGrid.implicitWidth + 2 * (bar.pad + Math.round(8 * u))
                implicitHeight: bar.vertical ? ccGrid.implicitHeight + 2 * (bar.pad + Math.round(6 * u)) : Math.round(26 * u) + 2 * bar.pad
                radius: Math.min(Config.c.tileRadius * 0.86 * u, Math.min(width, height) / 2)
                color: Ui.open === "quick" ? Theme.tileOn : (cma.containsMouse ? Theme.hover : Theme.tile)
                Behavior on color { ColorAnimation { duration: 120 } }

                Grid {
                    id: ccGrid; z: 2
                    anchors.centerIn: parent
                    columns: bar.vertical ? 1 : -1; rows: bar.vertical ? -1 : 1
                    spacing: bar.pad + Math.round((bar.vertical ? 6 : 8) * cc.u)
                    horizontalItemAlignment: Grid.AlignHCenter
                    verticalItemAlignment: Grid.AlignVCenter
                    // in use right now: the microphone (orange), the camera (green), the screen being shared (blue),
                    // before the bell. Hover for the apps.
                    Repeater {
                        model: Config.c.privacyIndicators ? [
                            { on: Privacy.mic,    icon: "mic",          col: "#FF9F0A", apps: Privacy.micApps,    what: "Microphone" },
                            { on: Privacy.camera, icon: "videocam",     col: "#30D158", apps: Privacy.cameraApps, what: "Camera" },
                            { on: Privacy.screen, icon: "screen_share", col: "#0A84FF", apps: Privacy.screenApps, what: "Screen being shared" }
                        ].filter(x => x.on) : []
                        delegate: Rectangle {
                            id: pv
                            required property var modelData
                            width: Math.round(20 * cc.u); height: width; radius: width / 2
                            color: Qt.rgba(Qt.color(modelData.col).r, Qt.color(modelData.col).g, Qt.color(modelData.col).b, 0.2)
                            border.width: 1; border.color: modelData.col
                            Icon { anchors.centerIn: parent; name: pv.modelData.icon; size: Math.round(12 * cc.u); color: pv.modelData.col }
                            SequentialAnimation on opacity {
                                running: !Power.saving; loops: Animation.Infinite
                                NumberAnimation { to: 0.55; duration: 900; easing.type: Easing.InOutSine }
                                NumberAnimation { to: 1; duration: 900; easing.type: Easing.InOutSine }
                            }
                            MouseArea { id: pvma; anchors.fill: parent; hoverEnabled: true }
                            HoverTip {
                                hovered: pvma.containsMouse; side: bar.tipSide
                                text: pv.modelData.what + " in use" + (pv.modelData.apps.length > 0 ? "\n" + pv.modelData.apps.join("\n") : "")
                            }
                        }
                    }
                    // notifications waiting: a red bell with how many, first in the row (grey with Do not disturb on);
                    // not there at all when there are none. Grows in and out, bounces when one arrives.
                    Item {
                        id: bell
                        readonly property bool want: cc.nCount > 0
                        property real t: want ? 1 : 0
                        Behavior on t { NumberAnimation { duration: 320; easing.type: Easing.OutCubic } }
                        visible: t > 0.01
                        implicitWidth: chip.width * t
                        implicitHeight: chip.height
                        property int shownN: 1
                        onWantChanged: if (want) shownN = cc.nCount
                        Connections { target: cc; function onNCountChanged() { if (cc.nCount > 0) { bell.shownN = cc.nCount; ring.restart() } } }
                        Rectangle {
                            id: chip
                            anchors.verticalCenter: parent.verticalCenter
                            x: (parent.width - width) / 2
                            height: Math.round(18 * cc.u)
                            width: bar.vertical ? height + Math.round(10 * cc.u) : bRow.implicitWidth + Math.round(10 * cc.u)
                            radius: height / 2
                            color: Config.c.dnd ? Qt.rgba(Theme.subtext.r, Theme.subtext.g, Theme.subtext.b, 0.55) : (Theme.dark ? Theme.tertiary : Qt.darker(Theme.tertiary, 1.45))
                            Behavior on color { ColorAnimation { duration: 200 } }
                            scale: bell.t
                            opacity: bell.t
                            Row {
                                id: bRow
                                anchors.centerIn: parent
                                spacing: Math.round(1 * cc.u)
                                Icon {
                                    id: bIcon
                                    visible: !bar.vertical
                                    name: "notifications"; size: Math.round(12 * cc.u); color: "#FFFFFF"
                                    anchors.verticalCenter: parent.verticalCenter
                                    transformOrigin: Item.Top
                                }
                                DText {
                                    anchors.verticalCenter: parent.verticalCenter
                                    text: bell.shownN > 99 ? "99+" : bell.shownN
                                    color: "#FFFFFF"
                                    font.pixelSize: Math.round(11 * cc.u); font.weight: Font.ExtraBold
                                }
                            }
                        }
                        // the bell swings when a notification comes in
                        SequentialAnimation {
                            id: ring
                            NumberAnimation { target: bIcon; property: "rotation"; to: 22; duration: 70 }
                            NumberAnimation { target: bIcon; property: "rotation"; to: -18; duration: 110 }
                            NumberAnimation { target: bIcon; property: "rotation"; to: 12; duration: 100 }
                            NumberAnimation { target: bIcon; property: "rotation"; to: -6; duration: 90 }
                            NumberAnimation { target: bIcon; property: "rotation"; to: 0; duration: 160; easing.type: Easing.OutBack }
                        }
                    }
                    // Bluetooth (when on): the plain sign while nothing is connected; else each connected
                    // device as what it is (earbuds, headphones, a controller, a mouse...) with a little
                    // battery beside it that fills with its charge (red when low)
                    LiveIcon {
                        visible: cc.btOn && (!Config.c.btDevicesInBar || Gadgets.connected.length === 0)
                        name: Gadgets.connected.length > 0 ? "bluetooth_connected" : "bluetooth"; size: cc.ic
                    }
                    Repeater {
                        model: cc.btOn && Config.c.btDevicesInBar ? Gadgets.connected.slice(0, 3) : []
                        delegate: Item {
                            id: btd
                            required property var modelData
                            readonly property real bat: Gadgets.battery(modelData)
                            readonly property bool low: bat >= 0 && bat < 0.2
                            // the room for the battery is kept whether or not it is known yet (and for "100%"), so a device
                            // that connects, or whose charge arrives a moment later, does not move the rest of the panel
                            implicitWidth: bar.vertical ? btIc.width : btIc.width + btRef.implicitWidth + Math.round(3 * cc.u)
                            implicitHeight: bar.vertical ? btIc.height + gauge.height + Math.round(2 * cc.u) : btIc.height
                            // arrives by fading in (a scale animation changed the size the panel laid out)
                            opacity: 0
                            Component.onCompleted: btIn.start()
                            NumberAnimation { id: btIn; target: btd; property: "opacity"; to: 1; duration: 260; easing.type: Easing.OutCubic }
                            DText { id: btRef; visible: false; text: "100%"; font.pixelSize: Math.round(11 * cc.u); font.weight: Font.DemiBold }
                            LiveIcon {
                                id: btIc
                                name: Gadgets.icon(btd.modelData); size: cc.ic
                                anchors.verticalCenter: bar.vertical ? undefined : parent.verticalCenter
                                anchors.horizontalCenter: bar.vertical ? parent.horizontalCenter : undefined
                            }
                            // the battery: its percentage beside it (a small bar under it on vertical panels)
                            DText {
                                id: btPct
                                visible: !bar.vertical && btd.bat >= 0
                                x: btIc.width + Math.round(3 * cc.u)
                                anchors.verticalCenter: parent.verticalCenter
                                text: Math.round(btd.bat * 100) + "%"
                                color: btd.low ? "#FF4A4A" : Theme.text
                                font.pixelSize: Math.round(11 * cc.u); font.weight: Font.DemiBold
                            }
                            Rectangle {
                                id: gauge
                                visible: bar.vertical && btd.bat >= 0
                                readonly property int len: Math.round(cc.ic * 0.62)
                                readonly property int thick: Math.max(4, Math.round(5 * cc.u))
                                width: bar.vertical ? len : thick; height: bar.vertical ? thick : len
                                x: bar.vertical ? (parent.width - width) / 2 : btIc.width + Math.round(2 * cc.u)
                                y: bar.vertical ? btIc.height + Math.round(2 * cc.u) : (parent.height - height) / 2
                                radius: Math.min(width, height) / 2
                                color: Qt.rgba(Theme.text.r, Theme.text.g, Theme.text.b, 0.22)
                                Rectangle {
                                    readonly property real f: Math.max(0.12, btd.bat)
                                    width: bar.vertical ? parent.width * f : parent.width
                                    height: bar.vertical ? parent.height : parent.height * f
                                    y: bar.vertical ? 0 : parent.height - height
                                    radius: parent.radius
                                    color: btd.low ? "#FF4A4A" : Theme.text
                                    Behavior on height { NumberAnimation { duration: 600; easing.type: Easing.OutCubic } }
                                    Behavior on width { NumberAnimation { duration: 600; easing.type: Easing.OutCubic } }
                                }
                            }
                        }
                    }
                    // Wi-Fi: as many bars as the signal has (or a cable, or off)
                    LiveIcon { name: Net.icon; size: cc.ic; opacity: Net.wifiOn || Net.wired ? 1 : 0.55 }
                    LiveIcon { visible: Config.c.dnd && cc.nCount === 0; name: "notifications_off"; size: cc.ic }
                    LiveIcon { visible: Caffeine.active; name: "coffee"; size: cc.ic }
                    // volume: the speaker's waves follow the level; changing it shows the number for a moment
                    Item {
                        id: vol
                        readonly property real v: Audio.volume
                        readonly property bool showPct: volShow.running
                        // the same size always: the number shows in the speaker's place for a moment
                        // (a button that grew made the panel think its items no longer fit)
                        implicitWidth: vIcon.width
                        implicitHeight: vIcon.height
                        onVChanged: { volShow.restart(); vIcon.pulse() }
                        Timer { id: volShow; interval: 1400 }
                        LiveIcon {
                            id: vIcon
                            anchors.verticalCenter: parent.verticalCenter
                            name: Audio.muted ? "volume_off" : (vol.v <= 0.001 ? "volume_mute" : (vol.v < 0.5 ? "volume_down" : "volume_up"))
                            size: cc.ic
                            opacity: vol.showPct ? 0 : 1
                            scale: vol.showPct ? 0.6 : 1
                            Behavior on opacity { NumberAnimation { duration: 140 } }
                            Behavior on scale { NumberAnimation { duration: 180; easing.type: Easing.OutCubic } }
                        }
                        DText {
                            id: pct
                            anchors.centerIn: vIcon
                            opacity: vol.showPct ? 1 : 0
                            scale: vol.showPct ? 1 : 0.6
                            Behavior on opacity { NumberAnimation { duration: 140 } }
                            Behavior on scale { NumberAnimation { duration: 220; easing.type: Easing.OutBack } }
                            text: Math.round(vol.v * 100)
                            // fits the speaker's square even at 100
                            font.pixelSize: Math.max(8, Math.round(cc.ic * (vol.v >= 0.995 ? 0.5 : 0.6))); font.weight: Font.Bold
                        }
                    }
                    // screen recording: a red ring that goes round once a minute, the time inside; click to stop
                    RingPill {
                        visible: QuickSettings.recording
                        height: Math.round(22 * cc.u); width: Math.round((bar.vertical ? 40 : 62) * cc.u)
                        level: (QuickSettings.recSecs % 60) / 60
                        stroke: Math.max(2.2, 2.8 * cc.u)
                        color: "#FF4A4A"
                        fill: Qt.rgba(1, 0.29, 0.29, 0.16)
                        Row {
                            anchors.centerIn: parent; spacing: 4
                            Rectangle { visible: !bar.vertical; width: Math.round(7 * cc.u); height: width; radius: 2; color: "#FF4A4A"; anchors.verticalCenter: parent.verticalCenter }
                            DText { text: QuickSettings.recText; font.weight: Font.Bold; font.pixelSize: Math.round((bar.vertical ? 9 : 11) * cc.u); anchors.verticalCenter: parent.verticalCenter }
                        }
                        MouseArea { anchors.fill: parent; z: 10; cursorShape: Qt.PointingHandCursor; onClicked: QuickSettings.record("stop") }
                    }
                    // battery (laptops only): a pill whose outline fills up with the charge, from the bottom of its left
                    // end clockwise over the top; the accent colour, green while charging, red when low.
                    // Inside: the percentage, or (with the percentage off) a little battery that empties
                    // the power profile beside it: a leaf (power saver), scales (balanced) or a gauge (performance)
                    Icon {
                        id: profIcon
                        visible: cc.hasBattery
                        readonly property int prof: PowerProfiles.profile
                        name: prof === PowerProfile.PowerSaver ? "eco" : (prof === PowerProfile.Performance ? "speed" : "balance")
                        size: Math.round(16 * cc.u)
                        color: prof === PowerProfile.PowerSaver ? "#34C759" : (prof === PowerProfile.Performance ? Theme.primary : Theme.subtext)
                    }
                    RingPill {
                        id: batPill
                        visible: cc.hasBattery
                        readonly property real pct: Power.pct >= 0 ? Power.pct / 100 : 0      // from the Power service (whole percent), the one Settings > Power uses too
                        readonly property bool showPct: Config.c.batteryPercent
                        startAt: "mid"
                        height: Math.round(22 * cc.u); width: Math.round((bar.vertical ? (showPct ? 40 : 36) : (showPct ? 52 : 40)) * cc.u)
                        level: Power.pct >= 0 ? Power.pct / 100 : 0      // written out in full (as Settings > Power does), not through the local `pct`
                        stroke: Math.max(3, Math.round(4 * cc.u))
                        // the ring says it all: green while charging, the accent while it runs down normally, orange when low,
                        // red when critical
                        color: Power.charging ? "#34C759"
                             : Power.pct > (Config.c.batteryLow ?? 20) ? Theme.primary
                             : Power.pct > (Config.c.batteryCritical ?? 10) ? "#FF9F0A" : "#FF3B4A"
                        // the track and the inside stay neutral (dark in dark mode, light in light mode): only the filled arc is coloured
                        track: Theme.dark ? Qt.rgba(1, 1, 1, 0.16) : Qt.rgba(0, 0, 0, 0.14)
                        fill: Theme.dark ? Qt.rgba(0, 0, 0, 0.78) : Qt.rgba(1, 1, 1, 0.9)
                        // reacts to the pointer, and the ring breathes while the charge is low and not charging
                        scale: cma.containsMouse ? 1.07 : 1
                        Behavior on scale { NumberAnimation { duration: 140; easing.type: Easing.OutCubic } }
                        SequentialAnimation on opacity {
                            running: Power.pct >= 0 && Power.pct <= (Config.c.batteryLow ?? 20) && !Power.charging && batPill.visible && !Power.saving
                            loops: Animation.Infinite
                            NumberAnimation { to: 0.55; duration: 900; easing.type: Easing.InOutSine }
                            NumberAnimation { to: 1; duration: 900; easing.type: Easing.InOutSine }
                            onRunningChanged: if (!running) batPill.opacity = 1
                        }
                        Row {
                            anchors.centerIn: parent; spacing: Math.round(2 * cc.u)
                            Icon { visible: cc.charging && !(bar.vertical && batPill.showPct); name: "bolt"; size: Math.round(12 * cc.u); color: Theme.dark ? "#FFFFFF" : "#16161E"; anchors.verticalCenter: parent.verticalCenter }
                            // the little battery (percentage off)
                            Item {
                                visible: !batPill.showPct
                                width: Math.round(16 * cc.u); height: Math.round(9 * cc.u)
                                anchors.verticalCenter: parent.verticalCenter
                                Rectangle {
                                    width: parent.width - Math.max(1, Math.round(1.5 * cc.u)); height: parent.height
                                    radius: Math.round(2 * cc.u); color: "transparent"
                                    border.width: Math.max(1, Math.round(1.2 * cc.u)); border.color: Qt.rgba(Theme.text.r, Theme.text.g, Theme.text.b, 0.8)
                                    Rectangle {
                                        x: Math.max(1.5, 2 * cc.u); anchors.verticalCenter: parent.verticalCenter
                                        height: parent.height - 2 * Math.max(1.5, 2 * cc.u)
                                        width: Math.max(1, (parent.width - 2 * Math.max(1.5, 2 * cc.u)) * batPill.pct)
                                        radius: 1; color: batPill.color
                                    }
                                }
                                Rectangle { anchors.right: parent.right; anchors.verticalCenter: parent.verticalCenter; width: Math.max(1, Math.round(1.5 * cc.u)); height: Math.round(4 * cc.u); radius: 1; color: Qt.rgba(Theme.text.r, Theme.text.g, Theme.text.b, 0.8) }
                            }
                            DText {
                                visible: batPill.showPct
                                text: Math.round(batPill.pct * 100) + (bar.vertical ? "" : "%")
                                font.weight: Font.Bold; font.pixelSize: Math.round((bar.vertical ? 10 : 11) * cc.u)
                                color: Theme.dark ? "#FFFFFF" : "#16161E"
                                anchors.verticalCenter: parent.verticalCenter
                            }
                        }
                    }
                }
                MouseArea {
                    id: cma
                    anchors.fill: parent; hoverEnabled: true
                    cursorShape: Qt.PointingHandCursor
                    acceptedButtons: Qt.LeftButton | Qt.MiddleButton
                    onClicked: mouse => {
                        if (mouse.button === Qt.MiddleButton) Audio.toggleMute()
                        else bar.openFrom("quick", cc)
                    }
                    onWheel: wheel => Audio.setVolume(Audio.volume + (wheel.angleDelta.y > 0 ? 0.05 : -0.05))
                }
                HoverTip {
                    hovered: cma.containsMouse; side: bar.tipSide
                    // the connected devices and their battery, by name
                    text: ["Control centre" + (cc.hasBattery ? "\nBattery " + Math.round(batPill.pct * 100) + " %" + (cc.charging ? ", charging" : "") + "  (ring " + Math.round(batPill.level * 100) + " %, " + batPill.color.toString() + ")" : "")].concat(Gadgets.connected.map(d => (d.name || d.address) + (Gadgets.battery(d) >= 0 ? "  " + Gadgets.batteryText(d) : "")))
                        .concat(Gadgets.otherPeripherals.filter(d => d.battery >= 0).map(d => d.name + "  " + d.battery + " %" + (d.charging ? " ⚡" : ""))).join("\n")
                }
            }
        }

        // Media: the cover going round while it plays, little dancing bars and the title running along.
        // Click: the media card (cover, progress you can drag, previous / play / next). Middle click:
        // play / pause. Gone from the panel while nothing plays.
        Component {
            id: mediaC
            Rectangle {
                id: md
                readonly property real sf: (parent && parent.sizeF !== undefined) ? parent.sizeF : 1
                readonly property real u: bar.k * sf
                readonly property int disc: Math.round(22 * u)
                property bool open: false
                implicitWidth: bar.vertical ? Math.round(36 * u) + 2 * bar.pad : mdRow.implicitWidth + 2 * (bar.pad + Math.round(8 * u))
                implicitHeight: bar.vertical ? mdRow.implicitHeight + 2 * (bar.pad + Math.round(6 * u)) : Math.round(26 * u) + 2 * bar.pad
                radius: Math.min(Config.c.tileRadius * 0.86 * u, Math.min(width, height) / 2)
                color: md.open ? Theme.tileOn : (mdMa.containsMouse ? Theme.hover : Theme.tile)
                Behavior on color { ColorAnimation { duration: 120 } }

                Grid {
                    id: mdRow
                    z: 2
                    anchors.centerIn: parent
                    columns: bar.vertical ? 1 : -1; rows: bar.vertical ? -1 : 1
                    spacing: Math.round(6 * md.u)
                    verticalItemAlignment: Grid.AlignVCenter
                    horizontalItemAlignment: Grid.AlignHCenter
                    readonly property string style: bar.mediaIconOnly ? "Cover" : Config.c.mediaPillStyle
                    // the cover: round (turning while it plays), rounded or square
                    Rectangle {
                        visible: mdRow.style !== "Title" || bar.vertical
                        width: md.disc; height: md.disc
                        radius: Config.c.mediaCoverShape === "Circle" ? width / 2 : Config.c.mediaCoverShape === "Square" ? Math.round(2 * md.u) : Math.round(7 * md.u)
                        color: Theme.primaryContainer
                        clip: true
                        Image {
                            anchors.fill: parent
                            source: Media.art; fillMode: Image.PreserveAspectCrop
                            asynchronous: true; sourceSize.width: 96
                            visible: status === Image.Ready
                        }
                        Icon { anchors.centerIn: parent; visible: Media.art === ""; name: "music_note"; size: Math.round(md.disc * 0.6); color: Theme.onPrimaryContainer }
                        Rectangle { anchors.centerIn: parent; width: Math.round(md.disc * 0.22); height: width; radius: width / 2; color: Theme.tile; visible: Media.art !== "" && Config.c.mediaCoverShape === "Circle" }
                        RotationAnimation on rotation { running: Config.c.mediaSpin && Config.c.mediaCoverShape === "Circle" && Media.playing && md.visible; from: 0; to: 360; duration: 6000; loops: Animation.Infinite }
                        scale: Config.c.mediaPulse && Media.playing ? 1 + 0.16 * Beat.bass : 1
                        Behavior on scale { NumberAnimation { duration: 70 } }
                    }
                    // what moves to the beat while it plays (Settings > Panels > Music); fixed places, only heights follow the beat
                    BeatViz {
                        id: viz
                        visible: !bar.vertical && mdRow.style !== "Cover" && Config.c.mediaViz !== "Off" && Config.c.mediaVizSide !== "After"
                        kind: Config.c.mediaViz === "Blob" ? "Wave" : Config.c.mediaViz
                        n: kind === "Wave" ? 6 : 6
                        tint: Config.c.mediaVizColor
                        width: Math.round((kind === "Wave" ? 34 : 26) * md.u); height: Math.round(16 * md.u)
                        BeatUser { on: md.visible && Media.playing && (Config.c.mediaViz !== "Off" || Config.c.mediaPulse) }
                    }
                    // the title (and artist), running along when long (or cut with ... when running along is off)
                    Item {
                        id: ttl
                        visible: !bar.vertical && mdRow.style !== "Cover"
                        width: Math.round(Config.c.mediaPillWidth * md.u)
                        height: mdTitle.implicitHeight
                        clip: true
                        DText {
                            id: mdTitle
                            readonly property real over: implicitWidth - ttl.width
                            width: Config.c.mediaScroll ? implicitWidth : ttl.width
                            elide: Config.c.mediaScroll ? Text.ElideNone : Text.ElideRight
                            text: Media.title + (Config.c.mediaPillArtist && Media.artist ? "  ·  " + Media.artist : "")
                            font.pixelSize: Math.round(12 * md.u); font.weight: Font.Medium
                            onTextChanged: x = 0
                            SequentialAnimation on x {
                                running: Config.c.mediaScroll && mdTitle.over > 2 && md.visible
                                loops: Animation.Infinite
                                PauseAnimation { duration: 2500 }
                                NumberAnimation { to: -mdTitle.over; duration: Math.max(1500, mdTitle.over * 30); easing.type: Easing.InOutSine }
                                PauseAnimation { duration: 1500 }
                                NumberAnimation { to: 0; duration: 450; easing.type: Easing.InOutSine }
                            }
                        }
                    }
                    // the beat after the title
                    BeatViz {
                        visible: !bar.vertical && mdRow.style !== "Cover" && Config.c.mediaViz !== "Off" && Config.c.mediaVizSide === "After"
                        kind: viz.kind; n: viz.n; tint: viz.tint
                        width: viz.width; height: viz.height
                    }
                    // previous / play / next, right in the pill (Settings > Panels > Music)
                    Row {
                        visible: !bar.vertical && Config.c.mediaPillControls && mdRow.style !== "Cover"
                        spacing: 0
                        Repeater {
                            model: [["skip_previous", "prev"], [Media.playing ? "pause" : "play_arrow", "toggle"], ["skip_next", "next"]]
                            delegate: Rectangle {
                                id: pcb
                                required property var modelData
                                width: Math.round(22 * md.u); height: width; radius: width / 2
                                color: pcm.containsMouse ? Theme.hover : "transparent"
                                Icon { anchors.centerIn: parent; name: pcb.modelData[0]; size: Math.round(16 * md.u); color: Theme.text }
                                MouseArea {
                                    id: pcm
                                    anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor
                                    onClicked: { const f = pcb.modelData[1]; if (f === "prev") Media.prev(); else if (f === "next") Media.next(); else Media.toggle() }
                                }
                            }
                        }
                    }
                }
                MouseArea {
                    id: mdMa
                    anchors.fill: parent; hoverEnabled: true
                    cursorShape: Qt.PointingHandCursor
                    acceptedButtons: Qt.LeftButton | Qt.MiddleButton
                    onClicked: mouse => { if (mouse.button === Qt.MiddleButton) Media.toggle(); else md.open = !md.open }
                }
                HoverTip { hovered: mdMa.containsMouse && !md.open; text: Media.title + (Media.artist ? "\n" + Media.artist : ""); side: bar.tipSide }
                // the media card, next to the panel
                // closes on a click elsewhere
                HyprlandFocusGrab { windows: [mdPop]; active: mdPop.visible; onCleared: md.open = false }
                // also closes when the focus moves anywhere else (another window, the desktop, another workspace)
                Connections {
                    target: Hyprland
                    enabled: md.open
                    ignoreUnknownSignals: true
                    function onRawEvent(ev) { if (ev.name === "activewindowv2" || ev.name === "workspacev2" || ev.name === "focusedmon") md.open = false }
                }
                // a click anywhere else closes it: the focus grab alone did not, when the click landed on a window
                // that already had the focus. A see-through window over the screen takes that click.
                PanelWindow {
                    id: mdCatch
                    visible: md.open && Media.has
                    screen: bar.screen
                    color: "transparent"
                    anchors { top: true; left: true; right: true; bottom: true }
                    exclusionMode: ExclusionMode.Ignore
                    WlrLayershell.namespace: "arqen-media-catch"
                    WlrLayershell.layer: WlrLayer.Top
                    WlrLayershell.keyboardFocus: WlrKeyboardFocus.None
                    MouseArea {
                        anchors.fill: parent
                        acceptedButtons: Qt.LeftButton | Qt.RightButton | Qt.MiddleButton
                        onPressed: md.open = false
                    }
                }
                PopupWindow {
                    id: mdPop
                    visible: md.open && Media.has
                    anchor.item: md
                    anchor.edges: bar.edge === "bottom" ? Edges.Top : bar.edge === "top" ? Edges.Bottom : bar.edge === "left" ? Edges.Right : Edges.Left
                    anchor.gravity: anchor.edges
                    anchor.margins.top: bar.edge === "bottom" ? -10 : 0
                    anchor.margins.bottom: bar.edge === "top" ? -10 : 0
                    anchor.margins.left: bar.edge === "right" ? -10 : 0
                    anchor.margins.right: bar.edge === "left" ? -10 : 0
                    color: "transparent"
                    implicitWidth: 400; implicitHeight: mdCard.implicitHeight
                    onVisibleChanged: if (visible) mdIn.restart()
                    property real t: 0
                    MediaCard {
                        id: mdCard
                        anchors.fill: parent
                        opacity: mdPop.t
                        scale: 0.94 + 0.06 * mdPop.t
                    }
                    NumberAnimation { id: mdIn; target: mdPop; property: "t"; from: 0; to: 1; duration: 340; easing.type: Easing.OutBack; easing.overshoot: Motion.os(1.4) }
                }
            }
        }

        // A plugin's panel item (Settings > Plugins): its BarWidget.qml, given pluginApi, screen,
        // widgetId and section. A plugin that fails to load shows a red mark
        // with the reason when you point at it.
        Component {
            id: pluginBarC
            Item {
                id: pb
                readonly property string pid: parent && parent.elementId !== undefined ? String(parent.elementId).slice(7) : ""
                readonly property var plug: Plugins.find(pid)
                readonly property real sf: (parent && parent.sizeF !== undefined) ? parent.sizeF : 1
                implicitWidth: pl.status === Loader.Ready && pl.item ? Math.max(1, pl.item.implicitWidth || pl.item.width) : bad.width
                implicitHeight: pl.status === Loader.Ready && pl.item ? Math.max(1, pl.item.implicitHeight || pl.item.height) : bad.height
                Loader {
                    id: pl
                    anchors.centerIn: parent
                    active: pb.plug !== null && Plugins.isEnabled(pb.pid)
                    source: pb.plug ? Plugins.entryUrl(pb.plug, "barWidget") : ""
                    onLoaded: {
                        const it = pl.item
                        if ("pluginApi" in it) it.pluginApi = Plugins.api(pb.pid)
                        if ("screen" in it) it.screen = bar.screen
                        if ("widgetId" in it) it.widgetId = "plugin:" + pb.pid
                        if ("section" in it) it.section = Config.sectionOf("plugin:" + pb.pid)
                        if ("barSize" in it) it.barSize = Qt.binding(() => Math.round(28 * bar.k * pb.sf))
                        if ("vertical" in it) it.vertical = Qt.binding(() => bar.vertical)
                    }
                }
                Rectangle {
                    id: bad
                    visible: pl.status === Loader.Error
                    anchors.centerIn: parent
                    width: Math.round(28 * bar.k * pb.sf); height: width; radius: width / 2
                    color: Qt.rgba(1, 0.3, 0.3, 0.18)
                    Icon { anchors.centerIn: parent; name: "extension_off"; size: Math.round(16 * bar.k * pb.sf); color: "#FF5A5A" }
                    MouseArea { id: badMa; anchors.fill: parent; hoverEnabled: true; onClicked: Plugins.openSettings(pb.pid) }
                    HoverTip { hovered: badMa.containsMouse; text: (pb.plug?.name ?? pb.pid) + " could not load: see Settings > Plugins"; side: bar.tipSide }
                }
            }
        }

        // Clock: its own font size (Settings > Panel items > Clock), times its size on this panel.
        Component {
            id: clockC
            Item {
                id: clk
                readonly property real sf: (parent && parent.sizeF !== undefined) ? parent.sizeF : 1
                readonly property int fs: Math.max(8, Math.round(Config.c.clockFontSize * sf * bar.ds) - (bar.vertical ? 1 : 0))
                readonly property string mode: Config.c.clockLayout
                readonly property bool inline: !bar.vertical && mode.indexOf("inline") === 0
                readonly property bool flip: mode.indexOf("flip") > 0
                readonly property string timeText: Qt.formatDateTime(clock.date, bar.vertical ? (Config.c.clock24 ? "HH\nmm" : "h AP\nmm") : (Config.c.clock24 ? "HH:mm" : "h:mm AP")).replace(/ [AaPp]\.?[Mm]\.?(?=\n|$)/, bar.vertical ? "" : "$&")
                // on a vertical panel the chosen format is kept, one word per line ("Mon 12/10" -> Mon / 12/10)
                readonly property string dateText: bar.vertical ? Qt.formatDateTime(clock.date, Config.c.clockDateFormat).trim().replace(/[ ,]+/g, "\n") : Qt.formatDateTime(clock.date, Config.c.clockDateFormat)
                readonly property bool both: Config.c.clockShowTime && Config.c.clockShowDate
                implicitWidth: clockWrap.implicitWidth + 2 * (bar.pad + Math.round(8 * bar.k * sf))
                implicitHeight: clockWrap.implicitHeight + (bar.vertical ? 16 : 8)
                readonly property bool shown: Ui.open === "calendar"
                // the pill behind it: it lights up under the pointer and while the calendar is open
                Rectangle {
                    anchors.fill: parent; anchors.margins: 1
                    radius: Math.min(width, height) / 2
                    color: clk.shown ? Theme.tileOn : Theme.hover
                    opacity: clk.shown ? 1 : (clkMa.containsMouse ? 1 : 0)
                    Behavior on opacity { NumberAnimation { duration: 160 } }
                    Behavior on color { ColorAnimation { duration: 160 } }
                }
                // squashes when pressed, grows a little under the pointer and springs back
                scale: clkMa.pressed ? 0.92 : (clkMa.containsMouse || clk.shown ? 1.05 : 1)
                Behavior on scale { NumberAnimation { duration: 300; easing.type: Easing.OutBack; easing.overshoot: Motion.os(2.6) } }
                // little marks for what is set: an alarm, a timer, the stopwatch, a reminder, an event today
                Grid {
                    id: clockWrap
                    anchors.centerIn: parent
                    columns: bar.vertical ? 1 : -1; rows: bar.vertical ? -1 : 1
                    spacing: bar.vertical ? 3 : 8
                    horizontalItemAlignment: Grid.AlignHCenter
                    verticalItemAlignment: Grid.AlignVCenter
                    Grid {
                        id: cueBox
                        visible: cueRep.count > 0
                        columns: bar.vertical ? 1 : Math.max(1, cueRep.count)
                        spacing: bar.vertical ? 2 : 8
                        Repeater {
                            id: cueRep
                            model: Clocks.cueKey === "" ? [] : Clocks.cueKey.split(",")
                            delegate: Item {
                                id: cue
                                required property string modelData
                                readonly property real isz: Math.max(11, Math.round(clk.fs * 0.95))
                                readonly property string txt: Clocks.cueText(modelData)
                                width: cueRow.implicitWidth; height: Math.max(isz, cueRow.implicitHeight)
                                scale: 0
                                Component.onCompleted: scale = 1
                                Behavior on scale { NumberAnimation { duration: 420; easing.type: Easing.OutBack; easing.overshoot: Motion.os(2.4) } }
                                Row {
                                    id: cueRow
                                    anchors.centerIn: parent
                                    spacing: 3
                                    Icon {
                                        anchors.verticalCenter: parent.verticalCenter
                                        size: cue.isz
                                        name: ({ ring: "alarm_on", snooze: "snooze", alarm: "alarm", timer: "hourglass_top", watch: "timer", reminder: "notifications_active", event: "event" })[cue.modelData] || "schedule"
                                        color: cue.modelData === "ring" ? "#FF5A5A" : Theme.primary
                                        // a running timer or stopwatch breathes
                                        SequentialAnimation on opacity {
                                            running: (cue.modelData === "timer" || cue.modelData === "watch" || cue.modelData === "ring") && clk.visible && !Power.saving
                                            loops: Animation.Infinite
                                            NumberAnimation { to: 0.45; duration: 900; easing.type: Easing.InOutSine }
                                            NumberAnimation { to: 1; duration: 900; easing.type: Easing.InOutSine }
                                        }
                                    }
                                    // the countdown (the stopwatch counts up)
                                    DText {
                                        visible: cue.txt !== ""
                                        anchors.verticalCenter: parent.verticalCenter
                                        text: cue.txt
                                        color: cue.modelData === "ring" ? "#FF5A5A" : Theme.primary
                                        font.pixelSize: Math.max(9, clk.fs - 2); font.weight: Font.DemiBold
                                    }
                                }
                            }
                        }
                    }
                    Grid {
                        id: clockGrid
                        columns: clk.inline ? 2 : 1
                        spacing: clk.inline ? 10 : 0
                        horizontalItemAlignment: Grid.AlignHCenter
                        verticalItemAlignment: Grid.AlignVCenter
                        Repeater {
                            model: clk.flip ? ["date", "time"] : ["time", "date"]
                            delegate: DText {
                                required property string modelData
                                readonly property bool isTime: modelData === "time"
                                visible: isTime ? Config.c.clockShowTime : Config.c.clockShowDate
                                horizontalAlignment: Text.AlignHCenter
                                text: isTime ? clk.timeText : clk.dateText
                                // the date is the small grey line when both are shown; alone it is full size
                                font.pixelSize: (isTime || !clk.both) ? clk.fs : (clk.inline ? clk.fs - 1 : Math.round(clk.fs * 0.8))
                                color: (isTime || !clk.both) ? Theme.text : Theme.subtext
                            }
                        }
                    }
                }
                // click: the calendar, reminders, alarms, timers and world clocks
                MouseArea { id: clkMa; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: bar.openFrom("calendar", clk) }
                HoverTip { hovered: clkMa.containsMouse && Ui.open !== "calendar"; text: Qt.formatDateTime(clock.date, "dddd d MMMM yyyy") + (Clocks.cueTip !== "" ? "\n" + Clocks.cueTip : "\nClick for the calendar, alarms and timers"); side: bar.tipSide }
            }
        }

        readonly property var elementComponents: ({
            workspaces: workspacesC, search: searchC, launcher: launcherC, dock: dockC,
            tray: trayC, clipboard: clipboardC, keyboard: keyboardC, control: controlC, clock: clockC, media: mediaC
        })

        // One slot in a section: an optional divider, then the element itself.
        // In edit mode each slot can be dragged (it follows the pointer) and has a remove button.
        Component {
            id: slotC
            Item {
                id: slot
                required property string modelData
                readonly property bool shown: bar.shows(modelData)
                property real dx: 0
                property real dy: 0
                visible: shown || bar.editing
                implicitWidth: slotLay.implicitWidth
                implicitHeight: slotLay.implicitHeight
                z: bar.dragId === modelData ? 50 : 0
                transform: Translate { x: slot.dx; y: slot.dy }
                Grid {
                    id: slotLay
                    columns: bar.vertical ? 1 : -1; rows: bar.vertical ? -1 : 1
                    spacing: bar.pad + 4
                    horizontalItemAlignment: Grid.AlignHCenter
                    verticalItemAlignment: Grid.AlignVCenter
                    Rectangle {
                        visible: slot.shown && bar.dividerBefore(slot.modelData)
                        width: bar.vertical ? 24 : 1; height: bar.vertical ? 1 : 24
                        color: Theme.divider
                    }
                    Loader {
                        // read by the element (parent.sizeF) to scale itself; a plugin's item reads parent.elementId
                        property real sizeF: bar.sizeOf(slot.modelData) * bar.fitShrink
                        readonly property string elementId: slot.modelData
                        visible: slot.shown
                        sourceComponent: bar.elementComponents[slot.modelData] ?? (String(slot.modelData).startsWith("plugin:") ? pluginBarC : null)
                        width: item ? item.implicitWidth : 0
                        height: item ? item.implicitHeight : 0
                    }
                    // edit mode: an element that has nothing to show right now (empty tray, ...)
                    Rectangle {
                        visible: !slot.shown && bar.editing
                        width: 36; height: 36; radius: 12
                        color: Theme.tile
                        opacity: 0.7
                        Icon { anchors.centerIn: parent; name: Config.elementInfo(slot.modelData).icon; size: 20; color: Theme.subtext }
                    }
                }

                // ---- edit mode ----
                Rectangle {   // outline so you can see what you are about to drag
                    visible: bar.editing
                    anchors { fill: parent; margins: -3 }
                    radius: 12
                    color: dragMa.containsMouse || bar.dragId === slot.modelData ? Qt.rgba(1, 1, 1, 0.08) : "transparent"
                    border.width: 1
                    border.color: bar.dragId === slot.modelData ? Theme.accent : Theme.stroke
                }
                MouseArea {
                    id: dragMa
                    visible: bar.editing
                    anchors.fill: parent
                    z: 10
                    hoverEnabled: true
                    preventStealing: true
                    cursorShape: pressed ? Qt.ClosedHandCursor : Qt.OpenHandCursor
                    property real sx: 0
                    property real sy: 0
                    property bool dragging: false
                    function reset() { dragging = false; slot.dx = 0; slot.dy = 0; if (bar.dragId === slot.modelData) bar.dragId = "" }
                    onPressed: mouse => {
                        const p = dragMa.mapToItem(bg, mouse.x, mouse.y)
                        sx = p.x; sy = p.y; dragging = false
                    }
                    onPositionChanged: mouse => {
                        if (!pressed) return
                        const p = dragMa.mapToItem(bg, mouse.x, mouse.y)
                        if (!dragging && Math.abs(p.x - sx) + Math.abs(p.y - sy) > 6) { dragging = true; bar.dragId = slot.modelData }
                        if (!dragging) return
                        // move along the panel only
                        slot.dx = bar.vertical ? 0 : p.x - sx
                        slot.dy = bar.vertical ? p.y - sy : 0
                    }
                    onReleased: mouse => {
                        if (!dragging) { reset(); return }
                        const p = dragMa.mapToItem(bg, mouse.x, mouse.y)
                        const id = slot.modelData
                        const pos = bar.vertical ? p.y : p.x
                        reset()
                        Qt.callLater(() => bar.dropElement(id, pos))
                    }
                    onCanceled: reset()
                }
                Rectangle {   // size handle: pull it out (right / down) to make the item bigger, in to shrink it
                    visible: bar.editing && bar.dragId === "" && slot.shown
                    z: 12
                    width: 18; height: 18; radius: 9
                    x: parent.width - width / 2 - 2
                    y: parent.height - height / 2 - 2
                    color: Theme.primary
                    Icon { anchors.centerIn: parent; name: "open_in_full"; size: 12; color: Theme.onPrimary }
                    MouseArea {
                        id: sizeMa
                        anchors { fill: parent; margins: -4 }
                        preventStealing: true
                        cursorShape: Qt.SizeFDiagCursor
                        property real sx: 0
                        property real sy: 0
                        property real f0: 1
                        onPressed: mouse => {
                            const p = sizeMa.mapToItem(bg, mouse.x, mouse.y)
                            sx = p.x; sy = p.y
                            f0 = bar.sizeOf(slot.modelData)
                            bar.sizingF = f0
                            bar.sizingId = slot.modelData
                        }
                        onPositionChanged: mouse => {
                            if (!pressed) return
                            const p = sizeMa.mapToItem(bg, mouse.x, mouse.y)
                            // both directions count, so it works the same on every edge
                            const d = (p.x - sx) + (p.y - sy)
                            bar.sizingF = Math.max(0.5, Math.min(2.5, Math.round(sizeMa.f0 * (1 + d / 120) * 20) / 20))
                        }
                        function finish() {
                            if (bar.sizingId === "") return
                            const id = bar.sizingId, f = bar.sizingF, pid = bar.panelId
                            Config.setItemSize(pid, id, f)
                            bar.sizingId = ""
                        }
                        onReleased: finish()
                        onCanceled: bar.sizingId = ""
                        onDoubleClicked: { const id = slot.modelData, pid = bar.panelId; bar.sizingId = ""; Config.setItemSize(pid, id, 1) }
                    }
                }
                Rectangle {   // size label while resizing
                    visible: bar.sizingId === slot.modelData
                    z: 13
                    width: szTxt.implicitWidth + 12; height: 20; radius: 10
                    color: Theme.accent
                    x: (parent.width - width) / 2
                    y: (parent.height - height) / 2
                    DText { id: szTxt; anchors.centerIn: parent; text: Math.round(bar.sizingF * 100) + "%"; color: Theme.onPrimary; font.pixelSize: 11; font.weight: Font.Bold }
                }
                Rectangle {   // remove from this panel
                    visible: bar.editing && bar.dragId === ""
                    z: 11
                    width: 18; height: 18; radius: 9
                    x: parent.width - width / 2 - 2
                    y: -height / 2 + 2
                    color: "#E5484D"
                    Icon { anchors.centerIn: parent; name: "close"; size: 13; color: "white" }
                    MouseArea {
                        anchors { fill: parent; margins: -4 }
                        cursorShape: Qt.PointingHandCursor
                        onClicked: { const id = slot.modelData, pid = bar.panelId; Qt.callLater(() => Config.removeElement(pid, id)) }
                    }
                }
            }
        }

        // ---- length: what is set, or longer when the items do not fit (up to the whole edge) ----
        readonly property real edgeLen: vertical ? height : width
        // the distance from the screen edge moves the panel away from its edge; it does not make it shorter
        readonly property real maxLen: Math.max(0, edgeLen)
        readonly property real setLen: full ? maxLen : Math.round(edgeLen * lengthPct / 100)
        readonly property real sectionGap: compact ? 6 : 12
        // room the items need: the centre group stays centred, so the longer side counts twice
        readonly property real needLen: {
            const L = alongSize(leftSec), C = alongSize(centreSec), R = alongSize(rightSec)
            const a = bg.startPad + L + (L > 0 ? sectionGap : 0)
            const b = bg.endPad + R + (R > 0 ? sectionGap : 0)
            return C > 0 ? C + 2 * Math.max(a, b) : a + b
        }
        readonly property real barLen: Math.min(maxLen, Math.max(setLen, Math.ceil(needLen)))
        // the least room the three groups can share (the centre one then sits off-centre, see centreAt): fitting
        // starts when even that is too little, so nothing overlaps, and nothing shrinks that would have fitted
        readonly property real minNeed: bg.startPad + alongSize(leftSec) + alongSize(centreSec) + alongSize(rightSec) + bg.endPad
                                        + (alongSize(leftSec) > 0 ? sectionGap : 0) + (alongSize(rightSec) > 0 ? sectionGap : 0)
                                        + (alongSize(centreSec) > 0 && (alongSize(leftSec) > 0 || alongSize(rightSec) > 0) ? sectionGap : 0)

        // ---- the dock folds away when everything does not fit (a big screen scale) ----
        // ---- making everything fit (a big screen scale, many items) ----
        // Step by step, only as far as needed: 1 = less space between items and the dock folds into
        // an apps button; 2 = the whole centre group folds into one button with an arrow (its items
        // show in a strip when clicked); 3 and up = all items get a little smaller each step.
        // Anything that changes what is on the panel starts again from 0.
        property int fitLevel: 0
        readonly property bool compact: fitLevel >= 1
        // first thing to give way: the media widget shrinks to its round cover, the controls stay
        readonly property bool mediaIconOnly: fitLevel >= 1
        readonly property bool dockCollapsed: fitLevel >= 1 && dockItems.length >= 2 && !editing
        readonly property bool centreFolded: fitLevel >= 2 && !editing && layout.center.length > 1
        readonly property real fitShrink: fitLevel >= 3 ? Math.max(0.6, 1 - 0.08 * (fitLevel - 2)) : 1
        property bool dockOpen: false
        // the dock icon whose window previews are showing (and whether a click opened them: they then
        // stay until you click elsewhere, instead of going when the pointer leaves)
        property var preview: null
        property bool previewStick: false
        property bool centreOpen: false
        function fitStep() {
            if (minNeed > maxLen - 4 && fitLevel < 7) { fitLevel++; fitTimer.restart() }
        }
        function fitReset() { fitLevel = 0; dockOpen = false; centreOpen = false; fitTimer.restart() }
        Timer { id: fitTimer; interval: 50; onTriggered: bar.fitStep() }
        Timer { id: refitTimer; interval: 150; onTriggered: bar.fitReset() }
        onNeedLenChanged: fitTimer.restart()
        onMinNeedChanged: fitTimer.restart()
        onMaxLenChanged: refitTimer.restart()
        // (not the thickness: that follows the item sizes, which fitting itself changes; it went round
        // in circles: smaller items, thinner panel, start again, bigger items ... the flicker)
        readonly property string fitKey: JSON.stringify(layout) + "|" + dockItems.length + "|" + Config.c.itemSize + "|" + Config.c.iconSize
                                         + "|" + Config.c.itemPadding + "|" + cfg.thickness + "|" + ds + "|" + editing + "|" + trayModel.length
                                         // things that come and go on the panel by themselves
                                         + "|" + Media.has + "|" + (Notifs.count > 0)
                                         + "|" + Privacy.mic + Privacy.camera + Privacy.screen + "|" + QuickSettings.recording + "|" + Caffeine.active + "|" + Config.c.dnd
        onFitKeyChanged: refitTimer.restart()

        // where the panel takes the pointer: the bar; for an autohiding panel also the strip by the
        // edge (shown) or only that strip (hidden)
        Item {
            id: hitArea
            readonly property bool stripOnly: bar.autohide && bar.hiddenNow
            readonly property bool withStrip: bar.autohide && !bar.hiddenNow
            x: stripOnly ? edgeStrip.x : (withStrip ? Math.min(bg.x, edgeStrip.x) : bg.x)
            y: stripOnly ? edgeStrip.y : (withStrip ? Math.min(bg.y, edgeStrip.y) : bg.y)
            width: stripOnly ? edgeStrip.width : (withStrip ? Math.max(bg.x + bg.width, edgeStrip.x + edgeStrip.width) - x : bg.width)
            height: stripOnly ? edgeStrip.height : (withStrip ? Math.max(bg.y + bg.height, edgeStrip.y + edgeStrip.height) - y : bg.height)
        }

        // the strip along the screen edge that brings a hidden panel back
        Item {
            id: edgeStrip
            readonly property int depth: Math.max(4, bar.m + 2)
            x: bar.vertical ? (bar.edge === "left" ? 0 : bar.width - depth) : bg.x
            y: bar.vertical ? bg.y : (bar.edge === "top" ? 0 : bar.height - depth)
            width: bar.vertical ? depth : bg.width
            height: bar.vertical ? bg.height : depth
            HoverHandler { id: stripHover; enabled: bar.autohide }
        }

        Rectangle {
            id: bg
            HoverHandler { id: bgHover; enabled: bar.autohide }
            transform: Translate {
                x: bar.edge === "left" ? -bar.hideShift : (bar.edge === "right" ? bar.hideShift : 0)
                y: bar.edge === "top" ? -bar.hideShift : (bar.edge === "bottom" ? bar.hideShift : 0)
                Behavior on x { NumberAnimation { duration: 200; easing.type: Easing.OutCubic } }
                Behavior on y { NumberAnimation { duration: 200; easing.type: Easing.OutCubic } }
            }
            width: bar.vertical ? bar.thick : bar.barLen
            height: bar.vertical ? bar.barLen : bar.thick
            x: bar.vertical ? (bar.edge === "left" ? bar.m : 0) : bar.along(bar.width, width)
            y: bar.vertical ? bar.along(bar.height, height) : (bar.edge === "top" ? bar.m : 0)
            // floating panels get the corner radius from Settings; an attached one stays square.
            // Islands: the bar itself is see-through and each group of items has its own pill.
            radius: bar.m > 0 || bar.islands ? Math.min(Config.c.panelRadius, Math.min(width, height) / 2) : 0
            color: bar.islands ? "transparent" : Theme.bar
            border.width: bar.editing ? 2 : (bar.m > 0 && !bar.islands ? 1 : 0)
            border.color: bar.editing ? Theme.accent : Theme.stroke

            // ---- islands: a pill behind each group (left, centre, right) ----
            Repeater {
                model: bar.islands ? [leftSec, centreSec, rightSec] : []
                delegate: Rectangle {
                    required property var modelData
                    readonly property var sec: modelData
                    readonly property real padAlong: 4 + bar.pad + 4
                    readonly property real inset: bar.m > 0 ? 0 : 4      // attached: a little off the edge
                    visible: sec.width > 0 && sec.height > 0
                    x: bar.vertical ? inset : sec.x - padAlong
                    y: bar.vertical ? sec.y - padAlong : inset
                    width: bar.vertical ? bg.width - 2 * inset : sec.width + 2 * padAlong
                    height: bar.vertical ? sec.height + 2 * padAlong : bg.height - 2 * inset
                    radius: Math.min(Config.c.panelRadius, Math.min(width, height) / 2)
                    color: Theme.bar
                    border.width: 1; border.color: Theme.stroke
                    Behavior on x { NumberAnimation { duration: 160; easing.type: Easing.OutCubic } }
                    Behavior on y { NumberAnimation { duration: 160; easing.type: Easing.OutCubic } }
                    Behavior on width { NumberAnimation { duration: 160; easing.type: Easing.OutCubic } }
                    Behavior on height { NumberAnimation { duration: 160; easing.type: Easing.OutCubic } }
                }
            }

            // Panel editing is intentionally opened from Settings, not a right-click
            // overlay. This avoids intercepting secondary clicks intended for panel items.

            // The sections are placed with plain x / y, not anchors. Anchors that switch between
            // left/right and top/bottom when the panel moves to another edge can be applied in the
            // wrong order; Qt then drops one and the section sticks at a stale spot outside the bar
            // (the "left and right icons vanish after moving the panel a few times" bug).
            readonly property real startPad: 8 + bar.pad + (bar.m > 0 ? 0 : 4)   // island edge sits as far from the screen edge as from the top
            readonly property real endPad: 8 + bar.pad + (bar.m > 0 ? 0 : 4)

            // ---- left section (top on a vertical bar) ----
            Grid {
                id: leftSec
                z: bar.dragId !== "" && bar.sectionOfItem(bar.dragId) === "left" ? 5 : 0
                x: bar.vertical ? Math.round((bg.width - width) / 2) : bg.startPad
                y: bar.vertical ? bg.startPad : Math.round((bg.height - height) / 2)
                columns: bar.vertical ? 1 : -1; rows: bar.vertical ? -1 : 1
                spacing: bar.pad
                horizontalItemAlignment: Grid.AlignHCenter
                verticalItemAlignment: Grid.AlignVCenter
                Repeater { id: leftRep; model: bar.layout.left; delegate: slotC }
            }

            // ---- centre section ----
            // Centred on the panel, unless that would overlap the left / right items (a full panel
            // on a small screen): then it sits in the middle of the space between them.
            function centreAt(total, size, l0, r0) {
                const ideal = (total - size) / 2
                const lo = l0 > 0 ? bg.startPad + l0 + bar.sectionGap : 0
                const hi = total - (r0 > 0 ? bg.endPad + r0 + bar.sectionGap : 0)
                if (ideal >= lo && ideal + size <= hi) return Math.round(ideal)
                return Math.round(lo + Math.max(0, (hi - lo - size) / 2))
            }
            Grid {
                id: centreSec
                z: bar.dragId !== "" && bar.sectionOfItem(bar.dragId) === "center" ? 5 : 0
                x: bar.vertical ? Math.round((bg.width - width) / 2) : bg.centreAt(bg.width, width, leftSec.width, rightSec.width)
                y: bar.vertical ? bg.centreAt(bg.height, height, leftSec.height, rightSec.height) : Math.round((bg.height - height) / 2)
                columns: bar.vertical ? 1 : -1; rows: bar.vertical ? -1 : 1
                spacing: bar.pad
                horizontalItemAlignment: Grid.AlignHCenter
                verticalItemAlignment: Grid.AlignVCenter
                Repeater { id: centreRep; model: bar.centreFolded ? [] : bar.layout.center; delegate: slotC }
                // folded: one button; its items show in a strip next to the panel
                Rectangle {
                    id: centreBtn
                    visible: bar.centreFolded
                    readonly property string arrow: bar.edge === "bottom" ? (bar.centreOpen ? "expand_more" : "expand_less")
                                                  : bar.edge === "top" ? (bar.centreOpen ? "expand_less" : "expand_more")
                                                  : bar.edge === "left" ? (bar.centreOpen ? "chevron_left" : "chevron_right")
                                                  : (bar.centreOpen ? "chevron_right" : "chevron_left")
                    readonly property int s: Math.round(26 * bar.k * bar.fitShrink)
                    width: bar.vertical ? s + 16 : s + 38
                    height: bar.vertical ? s + 38 : s + 16
                    radius: Math.min(width, height) / 2
                    color: bar.centreOpen ? Theme.secondaryContainer : (cbm.containsMouse ? Theme.hover : Theme.tile)
                    Grid {
                        anchors.centerIn: parent
                        columns: bar.vertical ? 1 : 2
                        spacing: 2
                        horizontalItemAlignment: Grid.AlignHCenter
                        verticalItemAlignment: Grid.AlignVCenter
                        Icon { name: "more_horiz"; size: centreBtn.s; color: bar.centreOpen ? Theme.onSecondaryContainer : Theme.text }
                        Icon { name: centreBtn.arrow; size: 18; color: bar.centreOpen ? Theme.onSecondaryContainer : Theme.subtext }
                    }
                    MouseArea { id: cbm; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: bar.centreOpen = !bar.centreOpen }
                    HoverTip { hovered: cbm.containsMouse && !bar.centreOpen; side: bar.tipSide; text: "More: " + bar.layout.center.map(id => Config.elementInfo(id).name).join(", ") }

                    // closes on a click elsewhere (a Hyprland focus grab; the popup's own grabFocus fought the visible binding)
                    HyprlandFocusGrab { windows: [centrePop]; active: centrePop.visible; onCleared: bar.centreOpen = false }
                    PopupWindow {
                        id: centrePop
                        visible: bar.centreOpen && bar.centreFolded
                        anchor.item: centreBtn
                        anchor.edges: bar.edge === "bottom" ? Edges.Top : bar.edge === "top" ? Edges.Bottom : bar.edge === "left" ? Edges.Right : Edges.Left
                        anchor.gravity: anchor.edges
                        anchor.margins.top: bar.edge === "bottom" ? -10 : 0
                        anchor.margins.bottom: bar.edge === "top" ? -10 : 0
                        anchor.margins.left: bar.edge === "right" ? -10 : 0
                        anchor.margins.right: bar.edge === "left" ? -10 : 0
                        color: "transparent"
                        implicitWidth: foldStrip.width + 20
                        implicitHeight: foldStrip.height + 20
                        // Do not write back to centreOpen from a binding-driven visible
                        // change: doing so can create a visible <-> centreOpen binding loop.
                        Rectangle {
                            anchors.fill: parent
                            radius: Math.min(Config.c.panelRadius + 4, Math.min(width, height) / 2)
                            color: Theme.cardSolid
                            border.width: 1; border.color: Theme.stroke
                            Grid {
                                id: foldStrip
                                anchors.centerIn: parent
                                columns: bar.vertical ? 1 : -1; rows: bar.vertical ? -1 : 1
                                spacing: 10
                                horizontalItemAlignment: Grid.AlignHCenter
                                verticalItemAlignment: Grid.AlignVCenter
                                Repeater {
                                    model: bar.centreOpen && bar.centreFolded ? bar.layout.center : []
                                    delegate: Loader {
                                        required property string modelData
                                        // read by the element: its size, and that it is in this strip (the dock shows all its apps here)
                                        property real sizeF: bar.sizeOf(modelData)
                                        property bool inFold: true
                                        active: bar.shows(modelData)
                                        visible: active
                                        sourceComponent: bar.elementComponents[modelData]
                                        width: item ? item.implicitWidth : 0
                                        height: item ? item.implicitHeight : 0
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // ---- right section (bottom on a vertical bar) ----
            Grid {
                id: rightSec
                z: bar.dragId !== "" && bar.sectionOfItem(bar.dragId) === "right" ? 5 : 0
                x: bar.vertical ? Math.round((bg.width - width) / 2) : bg.width - width - bg.endPad
                y: bar.vertical ? bg.height - height - bg.endPad : Math.round((bg.height - height) / 2)
                columns: bar.vertical ? 1 : -1; rows: bar.vertical ? -1 : 1
                spacing: bar.pad
                horizontalItemAlignment: Grid.AlignHCenter
                verticalItemAlignment: Grid.AlignVCenter
                Repeater { id: rightRep; model: bar.layout.right; delegate: slotC }
            }

            // ---- edit mode: resize handles ----
            // length: the panel's ends (only the end that can move for start / end alignment)
            Repeater {
                model: ["start", "end"]
                delegate: Rectangle {
                    id: lh
                    required property string modelData
                    readonly property bool atStart: modelData === "start"
                    visible: bar.editing && !(bar.align === "start" && atStart) && !(bar.align === "end" && !atStart)
                    z: 60
                    width: bar.vertical ? 30 : 8
                    height: bar.vertical ? 8 : 30
                    radius: 4
                    color: lma.pressed || lma.containsMouse ? Theme.accent : Theme.subtext
                    x: bar.vertical ? (bg.width - width) / 2 : (atStart ? 4 : bg.width - width - 4)
                    y: bar.vertical ? (atStart ? 4 : bg.height - height - 4) : (bg.height - height) / 2
                    MouseArea {
                        id: lma
                        anchors { fill: parent; margins: -6 }
                        hoverEnabled: true
                        preventStealing: true
                        cursorShape: bar.vertical ? Qt.SizeVerCursor : Qt.SizeHorCursor
                        onPositionChanged: mouse => {
                            if (!pressed) return
                            const p = lma.mapToItem(null, mouse.x, mouse.y)      // window coordinates
                            const total = bar.vertical ? bar.height : bar.width
                            const a = bar.vertical ? p.y : p.x
                            const len = bar.align === "center" ? 2 * Math.abs(a - total / 2)
                                      : bar.align === "start" ? a - bar.m
                                      : total - bar.m - a
                            bar.dragLength = Math.max(15, Math.min(100, Math.round(len / total * 100)))
                        }
                        onReleased: { const v = bar.dragLength; if (v > 0) Config.setPanel(bar.panelId, "length", v); bar.dragLength = -1 }
                        onCanceled: bar.dragLength = -1
                    }
                }
            }
            // thickness: the edge facing the middle of the screen
            Rectangle {
                visible: bar.editing
                z: 60
                width: bar.vertical ? 8 : 64
                height: bar.vertical ? 64 : 8
                radius: 4
                color: tma2.pressed || tma2.containsMouse ? Theme.accent : Theme.subtext
                x: bar.edge === "left" ? bg.width - width - 2 : (bar.edge === "right" ? 2 : (bg.width - width) / 2)
                y: bar.edge === "top" ? bg.height - height - 2 : (bar.edge === "bottom" ? 2 : (bg.height - height) / 2)
                MouseArea {
                    id: tma2
                    anchors { fill: parent; margins: -6 }
                    hoverEnabled: true
                    preventStealing: true
                    cursorShape: bar.vertical ? Qt.SizeHorCursor : Qt.SizeVerCursor
                    onPositionChanged: mouse => {
                        if (!pressed) return
                        const p = tma2.mapToItem(null, mouse.x, mouse.y)          // window coordinates
                        const t = bar.edge === "bottom" ? bar.height - p.y - bar.m
                                : bar.edge === "top" ? p.y - bar.m
                                : bar.edge === "left" ? p.x - bar.m
                                : bar.width - p.x - bar.m
                        bar.dragThick = Math.max(32, Math.min(120, Math.round(t / 2) * 2))
                    }
                    onReleased: { const v = bar.dragThick; if (v > 0) Config.setPanel(bar.panelId, "thickness", Math.round(v / bar.ds)); bar.dragThick = -1 }
                    onCanceled: bar.dragThick = -1
                }
            }
        }
    }
}
