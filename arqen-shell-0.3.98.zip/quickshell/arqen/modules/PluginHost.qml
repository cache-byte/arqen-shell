import Quickshell
import Quickshell.Wayland
import Quickshell.Hyprland
import QtQuick
import qs.config
import qs.components
import qs.services

// Runs the plugins' background parts (Main.qml) and shows a plugin's window (Panel.qml) when it asks
// (pluginApi.openPanel): next to the button that opened it, or in the middle of the screen.
// Esc or a click elsewhere closes it.
Scope {
    id: host

    // ---- Main.qml of every plugin that is on ----
    Variants {
        model: Plugins.mains
        Loader {
            id: ml
            required property string modelData
            readonly property string pid: modelData.split("\t")[0]
            readonly property var plug: Plugins.find(pid)
            source: plug ? Plugins.entryUrl(plug, "main") : ""
            onLoaded: {
                const a = Plugins.api(pid)
                if (item && "pluginApi" in item) item.pluginApi = a
                if (a) a.mainInstance = item
            }
            Component.onDestruction: { const a = Plugins.apis[pid]; if (a && a.mainInstance === item) a.mainInstance = null }
        }
    }

    // ---- a plugin's window ----
    readonly property var plug: Plugins.find(Plugins.panelId)
    readonly property bool want: plug !== null && Plugins.panelId !== ""
    readonly property var button: Plugins.panelButton
    readonly property bool nearButton: want && button !== null && button.visible
    // its size, as Panel.qml asks (contentPreferredWidth / Height)
    property real prefW: 420
    property real prefH: 480

    Component {
        id: panelContentC
        Item {
            id: pc
            clip: true
            Rectangle { anchors.fill: parent; radius: Theme.radius + 2; color: Theme.cardSolid; border.width: 1; border.color: Theme.stroke }
            Loader {
                id: pl
                anchors.fill: parent
                source: host.plug ? Plugins.entryUrl(host.plug, "panel") : ""
                onLoaded: {
                    const it = pl.item
                    if ("pluginApi" in it) it.pluginApi = Plugins.api(Plugins.panelId)
                    if ("screen" in it) it.screen = Plugins.panelScreen
                    host.prefW = it.contentPreferredWidth ?? it.implicitWidth ?? 420
                    host.prefH = it.contentPreferredHeight ?? it.implicitHeight ?? 480
                }
            }
            Column {
                visible: pl.status === Loader.Error
                anchors.centerIn: parent
                width: parent.width - 40
                spacing: 8
                Icon { anchors.horizontalCenter: parent.horizontalCenter; name: "extension_off"; size: 32; color: "#FF5A5A" }
                DText { width: parent.width; horizontalAlignment: Text.AlignHCenter; wrapMode: Text.Wrap; text: (host.plug?.name ?? "") + "'s window could not load. Settings > Plugins shows why"; color: Theme.subtext }
            }
            Shortcut { sequence: "Escape"; onActivated: Plugins.hidePanel() }
        }
    }

    // next to the button (a panel item, a control centre button)
    PopupWindow {
        id: pop
        visible: host.nearButton
        anchor.item: host.button
        // below the button when it is in the top half of the screen, else above; same for sides
        readonly property point gp: host.button ? host.button.mapToGlobal(host.button.width / 2, host.button.height / 2) : Qt.point(0, 0)
        readonly property var scr: Plugins.panelScreen
        readonly property bool below: scr ? gp.y - scr.y < scr.height / 2 : true
        anchor.edges: below ? Edges.Bottom : Edges.Top
        anchor.gravity: anchor.edges
        anchor.margins.top: below ? 0 : -8
        anchor.margins.bottom: below ? -8 : 0
        grabFocus: true
        color: "transparent"
        implicitWidth: Math.min(host.prefW, (scr?.width ?? 1600) - 40)
        implicitHeight: Math.min(host.prefH, (scr?.height ?? 900) - 120)
        onVisibleChanged: if (!visible && host.nearButton) Plugins.hidePanel()
        Loader { anchors.fill: parent; active: pop.visible; sourceComponent: panelContentC }
    }

    // in the middle of the screen (opened by a shortcut or from Settings)
    PanelWindow {
        id: mid
        visible: host.want && !host.nearButton
        screen: Plugins.panelScreen ?? Quickshell.screens[0]
        color: "transparent"
        anchors { top: true; bottom: true; left: true; right: true }
        exclusionMode: ExclusionMode.Ignore
        WlrLayershell.namespace: "arqen-popup"
        WlrLayershell.layer: WlrLayer.Overlay
        WlrLayershell.keyboardFocus: visible ? WlrKeyboardFocus.OnDemand : WlrKeyboardFocus.None
        MouseArea { anchors.fill: parent; onClicked: Plugins.hidePanel() }
        Rectangle { anchors.fill: parent; color: "black"; opacity: 0.25 }
        Item {
            anchors.centerIn: parent
            width: Math.min(host.prefW, mid.width - 40)
            height: Math.min(host.prefH, mid.height - 80)
            MouseArea { anchors.fill: parent }        // clicks inside stay inside
            Loader { anchors.fill: parent; active: mid.visible; sourceComponent: panelContentC }
        }
    }
}
