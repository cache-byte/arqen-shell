import QtQuick
import qs.config

// A drawing of this computer for Settings > System, with your wallpaper on its screen.
// kind: "laptop" | "desktop" | "tablet" (from the firmware's chassis type, see sysinfo.sh)
Item {
    id: art
    property string kind: "laptop"
    implicitWidth: 300
    implicitHeight: 190

    readonly property string wall: Config.c.wallpaper
    readonly property bool wallIsImage: wall !== "" && !/\.(mp4|webm|mkv|mov|m4v|avi)$/i.test(wall)
    readonly property color body: Theme.dark ? "#2A2A31" : "#C9C9D2"
    readonly property color bodyEdge: Theme.dark ? "#3A3A43" : "#B4B4BE"
    readonly property color bezel: "#0C0C0F"

    // the screen picture: the wallpaper, or a soft gradient in the accent colours
    // (inline components do not see this file's ids: what they need is passed in)
    component Screen: Rectangle {
        property string wall: ""
        property bool wallIsImage: false
        color: "#0C0C0F"
        clip: true
        Rectangle {
            anchors { fill: parent; margins: 4 }
            radius: Math.max(0, parent.radius - 3)
            clip: true
            gradient: Gradient {
                GradientStop { position: 0; color: Theme.primaryContainer }
                GradientStop { position: 1; color: Theme.tertiaryContainer }
            }
            Image {
                anchors.fill: parent
                visible: parent.parent.wallIsImage && status === Image.Ready
                source: parent.parent.wallIsImage ? "file://" + parent.parent.wall : ""
                sourceSize.width: 480
                fillMode: Image.PreserveAspectCrop
                asynchronous: true
            }
        }
    }

    // ---- laptop: screen on a hinge, keyboard deck in perspective ----
    Item {
        visible: art.kind === "laptop"
        anchors.centerIn: parent
        width: Math.min(art.width, art.height * 1.6); height: width / 1.6
        Screen {
            wall: art.wall; wallIsImage: art.wallIsImage
            id: lid
            width: parent.width * 0.78; height: parent.height * 0.80
            anchors.horizontalCenter: parent.horizontalCenter
            radius: 10
            border.width: 2; border.color: art.bodyEdge
        }
        Rectangle {   // deck
            anchors { top: lid.bottom; horizontalCenter: parent.horizontalCenter }
            width: parent.width; height: parent.height * 0.09
            radius: height / 2
            color: art.body
            border.width: 1; border.color: art.bodyEdge
            Rectangle {   // the notch for opening the lid
                anchors { top: parent.top; horizontalCenter: parent.horizontalCenter }
                width: parent.width * 0.16; height: parent.height * 0.35; radius: height / 2
                color: art.bodyEdge
            }
        }
    }

    // ---- desktop: monitor on a stand ----
    Item {
        visible: art.kind === "desktop"
        anchors.centerIn: parent
        width: Math.min(art.width, art.height * 1.45); height: width / 1.45
        Screen {
            wall: art.wall; wallIsImage: art.wallIsImage
            id: mon
            width: parent.width; height: parent.height * 0.74
            radius: 10
            border.width: 2; border.color: art.bodyEdge
        }
        Rectangle {   // neck
            anchors { top: mon.bottom; horizontalCenter: parent.horizontalCenter }
            width: parent.width * 0.09; height: parent.height * 0.17
            color: art.body
        }
        Rectangle {   // foot
            anchors { bottom: parent.bottom; horizontalCenter: parent.horizontalCenter }
            width: parent.width * 0.34; height: parent.height * 0.07; radius: height / 2
            color: art.body
            border.width: 1; border.color: art.bodyEdge
        }
    }

    // ---- tablet ----
    Screen {
        wall: art.wall; wallIsImage: art.wallIsImage
        visible: art.kind === "tablet"
        anchors.centerIn: parent
        width: Math.min(art.width, art.height * 1.45); height: width / 1.45
        radius: 16
        border.width: 3; border.color: art.bodyEdge
    }
}
