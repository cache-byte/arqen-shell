import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Io
import Quickshell.Widgets
import qs.config
import qs.components
import qs.services
import qs.settings

// Lock screen: a live preview at the top, then what it shows and how it looks.
ColumnLayout {
    id: pg
    width: parent.width; spacing: 16

    // ---- the settings window's scrolling page, and its window: a small copy of the preview floats there once the
    // real one has scrolled out of sight, so a change can be seen without scrolling back up ----
    readonly property var flick: { let p = pg.parent; while (p && p.contentY === undefined) p = p.parent; return p }
    readonly property Item host: flick ? flick.parent : null
    readonly property bool pinOn: flick !== null && flick.contentY > mainPreview.height + 24
    Item {
        id: pin
        parent: pg.host
        visible: opacity > 0.01
        opacity: pg.pinOn ? 1 : 0
        Behavior on opacity { NumberAnimation { duration: 180 } }
        z: 50
        width: 240; height: 135
        // it never covers what you are changing: point at it and it hops to the other side
        property bool onLeft: false
        x: parent ? (onLeft ? 20 : parent.width - width - 20) : 0
        Behavior on x { NumberAnimation { duration: 240; easing.type: Easing.OutCubic } }
        HoverHandler { onHoveredChanged: if (hovered && pg.pinOn) pin.onLeft = !pin.onLeft }
        y: parent ? parent.height - height - 92 : 0
        Rectangle { anchors.fill: parent; anchors.margins: -2; radius: Math.max(0, Theme.radius - 4) + 2; color: Theme.cardSolid; border.width: 1; border.color: Theme.stroke }
        Loader {
            anchors.fill: parent
            active: pg.pinOn
            sourceComponent: ClippingRectangle {
                radius: Math.max(0, Theme.radius - 4)
                color: "black"
                LockFace { anchors.fill: parent; preview: true }
            }
        }
    }

    // ---- preview: the real lock screen, small ----
    SCard {
        id: mainPreview
        ClippingRectangle {
            Layout.fillWidth: true
            Layout.preferredHeight: width * 9 / 16
            radius: Math.max(0, Theme.radius - 8)
            color: "black"
            LockFace { anchors.fill: parent; preview: true }
        }
        RowLayout {
            Layout.fillWidth: true
            spacing: 10
            DText {
                Layout.fillWidth: true
                text: Ui.lockAvailable ? "Your password unlocks it, checked with the system's normal login rules"
                                       : "This Quickshell was built without its lock screen parts (PAM), so it can't lock"
                color: Theme.subtext; font.pixelSize: 12; wrapMode: Text.Wrap
            }
            ArqButton { text: "Lock now"; primary: true; visible: Ui.lockAvailable; onClicked: Ui.lock() }
        }
    }

    SHeader { text: "Light or dark"; key: "lockMode" }
    SGroup {
        SRow { key: "lockMode"; title: "Lock screen colours"; subtitle: "Follow system: light in light mode, dark in dark mode"; icon: "contrast"
            SChoices { model: ["Follow system", "Light", "Dark"]; current: ({ light: "Light", dark: "Dark" })[Config.c.lockMode] || "Follow system"
                       onPicked: v => Config.c.lockMode = ({ "Light": "light", "Dark": "dark" })[v] || "system" } }
    }

    // ---- the clock ----
    SHeader { text: "Clock"; key: "lockClockStyle,lockClockSize,lockClockColor,lockClockCustom,lockClockCustom2,lockClockPlace,lockClockAlign,lockShowDate,lockDateFormat" }
    SGroup {
        SRow { key: "lockClockStyle"; title: "Style"; subtitle: "Tall: narrow digits, like a phone's"; icon: "schedule"
            SChoices { model: ["Big", "Tall", "Stacked", "Small"]; current: (Config.c.lockClockStyle || "big").charAt(0).toUpperCase() + (Config.c.lockClockStyle || "big").slice(1)
                       onPicked: v => Config.c.lockClockStyle = v.toLowerCase() } }
        SliderRow { key: "lockClockSize"; title: "Size"; icon: "format_size"; suffix: " %"; from: 50; to: 160; step: 5
            value: Config.c.lockClockSize; onMoved: v => Config.c.lockClockSize = Math.round(v) }
        SRow { key: "lockClockColor"; title: "Colour"; subtitle: "Gradient: fades from the first colour at the top to the second at the bottom"; icon: "palette"
            SChoices { model: ["Accent", "White", "Custom", "Gradient"]; current: ({ white: "White", custom: "Custom", gradient: "Gradient" })[Config.c.lockClockColor] || "Accent"
                       onPicked: v => Config.c.lockClockColor = v.toLowerCase() } }
        SRow { key: "lockClockCustom"; visible: Config.c.lockClockColor === "custom" || Config.c.lockClockColor === "gradient"
            title: Config.c.lockClockColor === "gradient" ? "Top colour" : "Colour"; icon: "colorize"
            SSwatches { value: Config.c.lockClockCustom; onPicked: hex => Config.c.lockClockCustom = hex } }
        SRow { key: "lockClockCustom2"; visible: Config.c.lockClockColor === "gradient"; title: "Bottom colour"; subtitle: "Empty: your accent colour"; icon: "colorize"
            SSwatches { value: Config.c.lockClockCustom2 || "#000000"; onPicked: hex => Config.c.lockClockCustom2 = hex } }
        SRow { key: "lockClockPlace"; title: "Position"; icon: "vertical_align_center"
            SChoices { model: ["Top", "Middle"]; current: Config.c.lockClockPlace === "middle" ? "Middle" : "Top"
                       onPicked: v => Config.c.lockClockPlace = v.toLowerCase() } }
        SRow { key: "lockClockAlign"; title: "Side"; icon: "format_align_center"
            SChoices { model: ["Left", "Centre", "Right"]; current: Config.c.lockClockAlign === "left" ? "Left" : Config.c.lockClockAlign === "right" ? "Right" : "Centre"
                       onPicked: v => Config.c.lockClockAlign = v === "Centre" ? "center" : v.toLowerCase() } }
        SRow { key: "lockShowDate"; title: "Date"; icon: "calendar_today"
            ArqToggle { checked: Config.c.lockShowDate; onToggled: v => Config.c.lockShowDate = v } }
        SRow { key: "lockDateFormat"; visible: Config.c.lockShowDate; title: "Date format"; icon: "edit_calendar"
            SChoices { model: ["Sat 10 October", "Saturday 10 October", "Saturday, October 10", "10/10"]
                       current: ({ "ddd d MMMM": "Sat 10 October", "dddd d MMMM": "Saturday 10 October", "dddd, MMMM d": "Saturday, October 10", "dd/MM": "10/10" })[Config.c.lockDateFormat] || "Saturday 10 October"
                       onPicked: v => Config.c.lockDateFormat = ({ "Sat 10 October": "ddd d MMMM", "Saturday 10 October": "dddd d MMMM", "Saturday, October 10": "dddd, MMMM d", "10/10": "dd/MM" })[v] } }
    }

    // ---- frame ----
    SHeader { text: "Picture frame"; key: "lockFrame,lockFrameColor,lockFrameCustom,lockFrameSize" }
    SGroup {
        SRow { key: "lockFrame"; title: "Shape"; subtitle: "The picture sits inside a shape on a plain colour. None: the picture fills the screen"; icon: "category"
            SChoices { model: ["None", "Heart", "Rounded", "Circle", "Arch", "Blob"]; current: (Config.c.lockFrame || "none").charAt(0).toUpperCase() + (Config.c.lockFrame || "none").slice(1)
                       onPicked: v => Config.c.lockFrame = v.toLowerCase() } }
        SRow { key: "lockFrameColor"; visible: (Config.c.lockFrame || "none") !== "none"; title: "Colour round it"; icon: "format_color_fill"
            SChoices { model: ["Accent", "Dark", "Custom"]; current: Config.c.lockFrameColor === "dark" ? "Dark" : Config.c.lockFrameColor === "custom" ? "Custom" : "Accent"
                       onPicked: v => Config.c.lockFrameColor = v.toLowerCase() } }
        SRow { key: "lockFrameCustom"; visible: (Config.c.lockFrame || "none") !== "none" && Config.c.lockFrameColor === "custom"; title: "Custom colour"; icon: "colorize"
            SSwatches { colors: ["#8B7355", "#5D4037", "#37474F", "#263238", "#4A148C", "#880E4F", "#1B5E20", "#BF360C", "#F5E6D3", "#111114"]
                        value: Config.c.lockFrameCustom; onPicked: hex => Config.c.lockFrameCustom = hex } }
        SliderRow { key: "lockFrameSize"; visible: (Config.c.lockFrame || "none") !== "none"; title: "Size"; icon: "aspect_ratio"; suffix: " %"; from: 60; to: 130; step: 5
            value: Config.c.lockFrameSize; onMoved: v => Config.c.lockFrameSize = Math.round(v) }
    }

    // ---- what else it shows ----
    SHeader { text: "Shown"; key: "lockShowUser,lockShowInfo,lockShowMedia,lockMessage" }
    SGroup {
        SRow { key: "lockShowUser"; title: "Your picture and name"; icon: "account_circle"
            ArqToggle { checked: Config.c.lockShowUser; onToggled: v => Config.c.lockShowUser = v } }
        SRow { key: "lockShowInfo"; title: "Battery and notifications"; subtitle: "How many notifications are waiting, never what they say"; icon: "notifications"
            ArqToggle { checked: Config.c.lockShowInfo; onToggled: v => Config.c.lockShowInfo = v } }
        SRow { key: "lockShowMedia"; title: "What is playing"; subtitle: "With play / pause, previous and next"; icon: "music_note"
            ArqToggle { checked: Config.c.lockShowMedia; onToggled: v => Config.c.lockShowMedia = v } }
        SRow { key: "lockMessage"; title: "Message"; subtitle: "A line under the clock, e.g. who to call if this computer is found"; icon: "chat"
            ArqField {
                readonly property real naturalWidth: 260
                width: 260; implicitHeight: 38
                placeholder: "None"
                text: Config.c.lockMessage
                onEdited: Config.c.lockMessage = text
            }
        }
    }

    // ---- background ----
    property bool picking: false
    function pickImage() {
        if (picker.running) return
        picking = true
        picker.command = ["python3", "-I", Quickshell.shellDir + "/scripts/pick-file.py", "open", "Lock screen picture",
                          Quickshell.env("HOME") + "/Pictures", "*.jpg", "*.jpeg", "*.png", "*.webp"]
        picker.running = true
    }
    Process {
        id: picker
        stdout: StdioCollector { onStreamFinished: { const p = text.trim(); if (p !== "") Config.c.lockImage = p; pg.picking = false } }
        onExited: code => { if (code !== 0) pg.picking = false }
    }
    SHeader { text: "Background"; key: "lockImage,lockBlur,lockDim" }
    SGroup {
        SRow { key: "lockImage"; title: "Picture"; subtitle: (Config.c.lockImage || "") === "" ? "Your wallpaper" : Config.tilde(Config.c.lockImage); icon: "image"
            ArqButton { text: pg.picking ? "Choosing…" : "Choose…"; onClicked: pg.pickImage() }
            ArqButton { visible: (Config.c.lockImage || "") !== ""; text: "Use the wallpaper"; onClicked: Config.c.lockImage = "" } }
        SliderRow { key: "lockBlur"; title: "Blur"; icon: "blur_on"; suffix: " %"; from: 0; to: 100; step: 5
            value: Config.c.lockBlur; onMoved: v => Config.c.lockBlur = Math.round(v) }
        SliderRow { key: "lockDim"; title: "Darken"; icon: "brightness_4"; suffix: " %"; from: 0; to: 80; step: 5
            value: Config.c.lockDim; onMoved: v => Config.c.lockDim = Math.round(v) }
    }
}
