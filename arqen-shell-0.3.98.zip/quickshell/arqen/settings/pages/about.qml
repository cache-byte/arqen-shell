import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Io
import Quickshell.Widgets
import Qt.labs.folderlistmodel
import qs.config
import qs.components
import qs.services
import qs.settings

ColumnLayout {
    id: pg
    width: parent.width; spacing: 16
    property bool choosing: false

    SHeader { text: "You" }
    SCard {
        RowLayout {
            Layout.fillWidth: true
            spacing: 16
            Avatar { size: 72 }
            ColumnLayout {
                Layout.fillWidth: true; spacing: 2
                DText { text: User.name; font.pixelSize: 20; font.weight: Font.Medium; Layout.fillWidth: true; elide: Text.ElideRight }
                DText { text: User.login + (User.host !== "" ? "  ·  " + User.host : ""); color: Theme.subtext; font.pixelSize: 12; Layout.fillWidth: true; elide: Text.ElideRight }
            }
        }
        Flow {
            Layout.fillWidth: true
            spacing: 8
            ArqButton { text: pg.choosing ? "Done" : "Change picture"; primary: !pg.choosing; onClicked: pg.choosing = !pg.choosing }
            ArqButton { visible: User.face !== ""; text: "Remove picture"; onClicked: User.clearFace() }
            ArqButton { visible: User.face !== ""; text: "Use on login screen"; onClicked: User.applyFace() }
        }
        DText {
            visible: User.loginBusy || User.loginStatus !== ""
            Layout.fillWidth: true; wrapMode: Text.WordWrap; font.pixelSize: 12
            text: User.loginBusy ? "Sending it to the login screen ..."
                : User.loginStatus === "ok" ? "Login screen: updated. It shows the next time you log out."
                : "Login screen: not updated (" + User.loginStatus.replace(/^failed - /, "") + "). Needs the AccountsService (GDM, GNOME and KDE login screens read it)."
            color: User.loginStatus === "ok" || User.loginBusy ? Theme.subtext : "#E5484D"
        }
        DText {
            visible: pg.choosing
            Layout.fillWidth: true; wrapMode: Text.WordWrap
            text: "Pictures from your Pictures folder (GIFs move). Click one to use it."
            color: Theme.subtext; font.pixelSize: 12
        }
        Flow {
            visible: pg.choosing
            Layout.fillWidth: true
            spacing: 10
            Repeater {
                model: pg.choosing ? pics : null
                delegate: Item {
                    id: pic
                    required property string filePath
                    readonly property bool gif: /\.gif$/i.test(filePath)
                    width: 72; height: 72
                    ClippingRectangle {
                        anchors.fill: parent; radius: 36; color: Theme.tile
                        AnimatedImage {   // a GIF moves while you point at it
                            visible: pic.gif
                            anchors.fill: parent; source: pic.gif ? "file://" + pic.filePath : ""
                            fillMode: Image.PreserveAspectCrop; asynchronous: true
                            playing: pma.containsMouse
                        }
                        Image {
                            visible: !pic.gif
                            anchors.fill: parent; source: pic.gif ? "" : "file://" + pic.filePath
                            sourceSize: Qt.size(144, 144); fillMode: Image.PreserveAspectCrop; asynchronous: true
                        }
                    }
                    Rectangle { anchors.fill: parent; radius: 36; color: "transparent"; border.width: pma.containsMouse ? 3 : 0; border.color: Theme.accent }
                    MouseArea { id: pma; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor
                        onClicked: { User.setFace(pic.filePath); pg.choosing = false } }
                }
            }
        }
    }
    FolderListModel {
        id: pics
        folder: "file://" + Config.home + "/Pictures"
        nameFilters: ["*.png", "*.jpg", "*.jpeg", "*.webp", "*.gif"]
        showDirs: false
        sortField: FolderListModel.Time
    }

    // ---- this computer: a picture of it, its name, and what it is made of ----
    property var sys: ({})                // key -> value from scripts/sysinfo.sh
    property var gpus: []
    property bool sysLoaded: false
    property var priv: []                 // [[label, value]] after the password; never saved
    property bool privBusy: false
    property string privError: ""
    property bool renaming: false
    readonly property string kind: {
        const c = parseInt(sys.chassis || "0")
        if ([8, 9, 10, 14, 31, 32].includes(c)) return "laptop"
        if ([30].includes(c)) return "tablet"
        if (c === 0 && (sys.battery || "") !== "") return "laptop"
        return "desktop"
    }
    // "LENOVO ThinkPad T14" reads better as "Lenovo ThinkPad T14"; no maker twice
    readonly property string deviceModel: {
        let v = sys.vendor || "", m = sys.model || ""
        if (v === v.toUpperCase() && v.length > 3) v = v.charAt(0) + v.slice(1).toLowerCase()
        if (m === "") return ""
        return m.toLowerCase().startsWith(v.toLowerCase()) ? m : (v + " " + m).trim()
    }
    readonly property string deviceName: (sys.pretty || "") !== "" ? sys.pretty : (sys.hostname || "This computer")
    Process {
        id: sysProc
        running: true
        command: ["sh", Appearance.scripts + "sysinfo.sh"]
        stdout: StdioCollector {
            onStreamFinished: {
                const o = {}, g = []
                for (const line of text.split("\n")) {
                    const i = line.indexOf("\t")
                    if (i <= 0) continue
                    const k = line.slice(0, i), v = line.slice(i + 1)
                    if (k === "gpu") g.push(v); else o[k] = v
                }
                pg.sys = o; pg.gpus = g; pg.sysLoaded = true
            }
        }
    }
    // uptime and battery health: again every 5 seconds while this page is open
    Process {
        id: liveProc
        command: ["sh", Appearance.scripts + "sysinfo.sh", "live"]
        stdout: StdioCollector {
            onStreamFinished: {
                const o = Object.assign({}, pg.sys)
                for (const line of text.split("\n")) {
                    const i = line.indexOf("\t")
                    if (i > 0) o[line.slice(0, i)] = line.slice(i + 1)
                }
                pg.sys = o
            }
        }
    }
    Timer {
        interval: 5000; repeat: true
        running: pg.sysLoaded && Ui.settingsOpen && pg.visible
        onTriggered: if (!liveProc.running) liveProc.running = true
    }
    function parsePriv(text) {
        const rows = []
        for (const line of text.split("\n")) {
            const i = line.indexOf("\t")
            if (i > 0) rows.push([line.slice(0, i), line.slice(i + 1)])
        }
        return rows
    }
    // 1st choice: pkexec, which shows Arqen's own password prompt (or the session's polkit agent)
    Process {
        id: privProc
        command: ["pkexec", "sh", Appearance.scripts + "sysinfo-private.sh"]
        stdout: StdioCollector { id: privOut }
        stderr: StdioCollector { id: privErr }
        property int code: 0
        // the output may arrive just after the exit: look a moment later
        onExited: c => { code = c; privCheck.restart() }
    }
    Timer {
        id: privCheck
        interval: 200
        onTriggered: {
            const code = privProc.code
            const rows = pg.parsePriv(privOut.text)
            if (code === 0 && rows.length > 0) { pg.priv = rows; pg.privBusy = false; return }
            // no password prompt available at all: ask in a terminal instead
            if (/authentication agent|No session for cookie/i.test(privErr.text) || (code === 127 && privErr.text.trim() === "")) { termProc.running = true; return }
            pg.privBusy = false
            pg.privError = code === 126 ? "Not shown: the password was not given" : "Not shown: " + (privErr.text.trim().split("\n").pop() || "could not read them")
        }
    }
    // 2nd choice: a terminal asks for the password (sudo); the result comes back through a private file
    Process {
        id: termProc
        command: ["sh", "-c", "f=\"${XDG_RUNTIME_DIR:-/tmp}/arqen-private-$$\"; umask 077; : > \"$f\"; "
            + "c=\"echo 'Arqen needs your password to show serial numbers and addresses.'; echo; sudo sh '$1' > '$f' || sleep 3\"; "
            + "sh \"$2\" \"$c\"; "
            + "cat \"$f\"; rm -f \"$f\"", "priv", Appearance.scripts + "sysinfo-private.sh", Appearance.scripts + "term-run.sh"]
        stdout: StdioCollector {
            onStreamFinished: {
                const rows = pg.parsePriv(text)
                pg.privBusy = false
                if (rows.length > 0) pg.priv = rows
                else pg.privError = "Not shown: the password was not given"
            }
        }
    }
    Process {
        id: renameProc
        onExited: sysProc.running = true
    }
    function rename(name) {
        name = name.trim()
        if (name === "") return
        // the "pretty" name keeps spaces and capitals; the network name gets a safe version of it
        const net = name.toLowerCase().replace(/[^a-z0-9-]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 63) || "computer"
        renameProc.command = ["sh", "-c", "hostnamectl set-hostname --pretty \"$1\" && hostnamectl set-hostname --static \"$2\"", "rn", name, net]
        renameProc.running = true
        pg.renaming = false
    }

    // two columns, like an "About" page: what on the left, the answer on the right
    component InfoRow: Item {
        id: ir
        property string label: ""
        property string value: ""
        visible: value !== ""
        Layout.fillWidth: true
        implicitHeight: Math.max(48, vt.implicitHeight + 24)
        DText { id: lt; x: 18; anchors.verticalCenter: parent.verticalCenter; text: ir.label; color: Theme.subtext; font.pixelSize: 14; width: Math.min(implicitWidth, parent.width * 0.4) ; elide: Text.ElideRight }
        DText {
            id: vt
            anchors { right: parent.right; rightMargin: 18; verticalCenter: parent.verticalCenter }
            width: parent.width - lt.width - 18 - 18 - 16
            horizontalAlignment: Text.AlignRight
            text: ir.value; font.pixelSize: 14; wrapMode: Text.Wrap
        }
    }
    SHeader { text: "Updates" }
    SGroup {
        SRow {
            title: "Arqen shell " + Config.version
            icon: "system_update"
            subtitle: Updater.state === "checking" ? "Looking on GitHub ..."
                : Updater.state === "available" ? "Version " + Updater.latest + " is available."
                : Updater.state === "uptodate" ? "You have the newest version."
                : Updater.state === "updating" ? Updater.message
                : Updater.state === "installed" ? "Installed. Answer the card in the corner to finish."
                : Updater.state === "failed" ? Updater.message
                : "Not checked yet."
            Row {
                spacing: 8
                ArqButton { visible: Updater.state === "available"; text: "Download and install"; primary: true; onClicked: Updater.install() }
                ArqButton { visible: Updater.state !== "updating" && Updater.state !== "installed"; text: "Check now"; onClicked: { Updater.dismissed = false; Updater.check() } }
            }
        }
        SRow { key: "updateCheck"; title: "Look for updates by itself"; subtitle: "Looks for a newer arqen-shell zip in github.com/cache-byte/arqen-shell every few hours and asks before downloading"; icon: "update"
            ArqToggle { checked: Config.c.updateCheck !== false; onToggled: v => Config.c.updateCheck = v } }
    }

    SHeader { text: "This computer" }
    // the device on the left, what it is made of on the right (one above the other when narrow)
    GridLayout {
        Layout.fillWidth: true
        columns: pg.width >= 760 ? 2 : 1
        columnSpacing: 16; rowSpacing: 16
        SCard {
            Layout.alignment: Qt.AlignTop
            Layout.preferredWidth: pg.width >= 760 ? 320 : -1
            Layout.fillWidth: pg.width < 760
            ColumnLayout {
                Layout.fillWidth: true
                spacing: 10
                DeviceArt { Layout.alignment: Qt.AlignHCenter; Layout.preferredWidth: 260; Layout.preferredHeight: 160; kind: pg.kind }
                DText {
                    Layout.fillWidth: true; horizontalAlignment: Text.AlignHCenter
                    text: pg.deviceName; font.pixelSize: 24; color: Theme.primary; elide: Text.ElideRight
                }
                DText {
                    visible: pg.deviceModel !== "" && pg.deviceModel !== pg.deviceName
                    Layout.fillWidth: true; horizontalAlignment: Text.AlignHCenter
                    text: pg.deviceModel
                    color: Theme.subtext; font.pixelSize: 13; elide: Text.ElideRight
                }
                Row {
                    visible: !pg.renaming
                    Layout.alignment: Qt.AlignHCenter
                    ArqButton { text: "Rename"; onClicked: { pg.renaming = true; nameField.text = pg.deviceName; nameField.focusInput() } }
                }
                ArqField { id: nameField; visible: pg.renaming; Layout.fillWidth: true; implicitHeight: 38; placeholder: "Name of this computer"; onAccepted: pg.rename(text) }
                Row {
                    visible: pg.renaming
                    Layout.alignment: Qt.AlignHCenter
                    spacing: 8
                    ArqButton { text: "Save"; primary: true; onClicked: pg.rename(nameField.text) }
                    ArqButton { text: "Cancel"; onClicked: pg.renaming = false }
                }
                LoadingPill { visible: !pg.sysLoaded || renameProc.running; Layout.alignment: Qt.AlignHCenter; width: 48; height: 26 }
            }
        }
        SGroup {
            Layout.alignment: Qt.AlignTop
            InfoRow { label: "Device"; value: pg.deviceModel }
            InfoRow { label: "System"; value: pg.sys.os || "" }
            InfoRow { label: "Shell"; value: "Arqen " + Config.version }
            InfoRow { label: "Desktop"; value: ((pg.sys.hyprland || "") !== "" ? "Hyprland " + pg.sys.hyprland : "Hyprland") + "  ·  Arqen " + Config.version }
            InfoRow { label: "Processor"; value: pg.sys.cpu || "" }
            InfoRow { label: "Graphics"; value: pg.gpus.join("\n") }
            InfoRow { label: "Memory"; value: pg.sys.memory || "" }
            InfoRow { label: "Storage"; value: pg.sys.storage || "" }
            InfoRow { label: "Display"; value: pg.sys.displays || "" }
            InfoRow { label: "Battery health"; value: pg.sys.battery || "" }
            InfoRow { label: "Up for"; value: pg.sys.uptime || "" }
        }
    }
    SGroup {
        SRow {
            visible: pg.priv.length === 0
            title: "Serial numbers and addresses"
            subtitle: pg.privError !== "" ? pg.privError : "Hidden. Your password shows them here until you leave this page"
            icon: "lock"
            LoadingPill { anchors.verticalCenter: parent.verticalCenter; visible: pg.privBusy }
            ArqButton { text: "Show"; enabled: !pg.privBusy; onClicked: { pg.privError = ""; pg.privBusy = true; privProc.running = true } }
        }
        Repeater {
            model: pg.priv
            delegate: InfoRow { required property var modelData; label: modelData[0]; value: modelData[1] }
        }
        SRow {
            visible: pg.priv.length > 0
            title: "Hide them again"; icon: "visibility_off"
            ArqButton { text: "Hide"; onClicked: pg.priv = [] }
        }
    }

    // ---- saved passwords (the keyring) ----
    property string keyring: ""          // unlocked | locked | none | other
    function checkKeyring() { if (!krProc.running) krProc.running = true }
    Process {
        id: krProc
        running: true
        command: ["sh", "-c", "gdbus call --session --dest org.freedesktop.secrets --object-path /org/freedesktop/secrets/collection/login --method org.freedesktop.DBus.Properties.Get org.freedesktop.Secret.Collection Locked 2>/dev/null; echo @@; ls ~/.local/share/keyrings 2>/dev/null"]
        stdout: StdioCollector {
            onStreamFinished: {
                const p = text.split("@@")
                if (/false/.test(p[0])) pg.keyring = "unlocked"
                else if (/true/.test(p[0])) pg.keyring = "locked"
                else pg.keyring = /\.keyring/.test(p[1] || "") ? "other" : "none"
            }
        }
    }
    SHeader { text: "Saved passwords" }
    SGroup {
        SRow {
            title: "Unlock at login"
            subtitle: pg.keyring === "unlocked" ? "The keyring opens with your login password. Browsers and apps use it without asking"
                    : pg.keyring === "locked" ? "The keyring is locked, so browsers ask for its password. Set up makes your login unlock it"
                    : pg.keyring === "other" ? "Your keyring has its own password, so logging in cannot open it. Set up explains what to do"
                    : pg.keyring === "none" ? "No keyring yet. Set up, then log out and in"
                    : "Checking"
            icon: pg.keyring === "unlocked" ? "lock_open" : "key"
            iconColor: (pg.keyring === "locked" || pg.keyring === "other") ? "#E5484D" : Theme.tile
            LoadingPill { anchors.verticalCenter: parent.verticalCenter; visible: pg.keyring === "" || krProc.running }
            ArqButton { text: "Check"; onClicked: pg.checkKeyring() }
            ArqButton { text: "Set up"; primary: pg.keyring !== "unlocked"
                onClicked: Quickshell.execDetached(["sh", Appearance.scripts + "term-run.sh", "bash '" + Appearance.scripts + "keyring.sh'"]) }
        }
        SRow { title: "Passwords and keys"; subtitle: "See or change what is in the keyring (Seahorse)"; icon: "manage_accounts"
            ArqButton { text: "Open"; onClicked: Quickshell.execDetached(["sh", "-c", "seahorse || (command -v seahorse >/dev/null || kitty -e sudo dnf install -y seahorse)"]) } }
    }

    SHeader { visible: Config.c.showAdvanced; text: "Name tips" }
    SGroup { visible: Config.c.showAdvanced;
        SRow { key: "tipsOn"; title: "Show names on hover"; subtitle: "Rest the pointer on a button, app or icon to see what it is"; icon: "tooltip"
            ArqToggle { checked: Config.c.tipsOn; onToggled: v => Config.c.tipsOn = v } }
        SliderRow { key: "tipSeconds"; visible: Config.c.tipsOn; title: "Wait before showing"; icon: "timer"; suffix: " s"; from: 0.2; to: 5; step: 0.1
            value: Config.c.tipSeconds; onMoved: v => Config.c.tipSeconds = Math.round(v * 10) / 10 }
    }

    SHeader { visible: Config.c.showAdvanced; text: "Problems" }
    SGroup { visible: Config.c.showAdvanced;
        SRow { key: "errorNotify"; title: "Report errors as notifications"; subtitle: "Mistakes in the Hyprland config, and the shell's own errors, show up with your other notifications"; icon: "report"
            ArqToggle { checked: Config.c.errorNotify; onToggled: v => Config.c.errorNotify = v } }
    }

    // ---- everything back to how Arqen comes ----
    property bool resetAsk: false
    // what to keep when resetting: each its own switch (all on: only real settings are reset)
    property var resetKeep: ({ wallpaper: true, pinned: true, desktop: true, shortcuts: true })
    property bool resetDone: false
    property string resetNote: ""
    SCard {
        spacing: 12
        Rectangle {
            Layout.fillWidth: true
            implicitHeight: 52
            radius: 26
            color: resetMa.containsMouse ? Qt.rgba(0.9, 0.28, 0.3, 0.26) : Qt.rgba(0.9, 0.28, 0.3, 0.16)
            border.width: 1; border.color: Qt.rgba(0.9, 0.28, 0.3, 0.5)
            Row {
                anchors.centerIn: parent
                spacing: 10
                Icon { name: "restart_alt"; size: 24; color: "#E5484D"; anchors.verticalCenter: parent.verticalCenter }
                DText { text: pg.resetDone ? "Done: the settings are back to their defaults" : "Reset all settings to the defaults"; font.pixelSize: 16; font.weight: Font.DemiBold; color: "#E5484D"; anchors.verticalCenter: parent.verticalCenter }
            }
            MouseArea { id: resetMa; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: { pg.resetDone = false; pg.resetAsk = true } }
        }
        DText { visible: pg.resetDone && pg.resetNote !== ""; Layout.fillWidth: true; wrapMode: Text.WordWrap; color: Theme.subtext; font.pixelSize: 13; text: pg.resetNote }
        ColumnLayout {
            visible: pg.resetAsk
            Layout.fillWidth: true
            spacing: 10
            DText {
                Layout.fillWidth: true; wrapMode: Text.WordWrap; color: Theme.subtext; font.pixelSize: 13
                text: "Every setting goes back to how Arqen comes: colours, panels, control centre tiles, launcher, clock, sounds and the rest. A copy of your current settings is saved first (~/.config/arqen/config.backup-….json)."
            }
            DText { text: "Keep"; font.pixelSize: 13; font.weight: Font.DemiBold; Layout.topMargin: 4 }
            Repeater {
                model: [
                    { k: "wallpaper", t: "My wallpaper", i: "wallpaper" },
                    { k: "pinned",    t: "My pinned apps", i: "push_pin" },
                    { k: "desktop",   t: "My desktop: icons, where they sit, widgets, desktops", i: "home" },
                    { k: "shortcuts", t: "My keyboard shortcuts", i: "keyboard" }
                ]
                delegate: RowLayout {
                    required property var modelData
                    Layout.fillWidth: true; spacing: 12
                    Icon { name: modelData.i; size: 20; color: Theme.subtext }
                    DText { Layout.fillWidth: true; wrapMode: Text.WordWrap; font.pixelSize: 13; text: modelData.t }
                    ArqToggle {
                        checked: pg.resetKeep[modelData.k] === true
                        onToggled: v => { const m = Object.assign({}, pg.resetKeep); m[modelData.k] = v; pg.resetKeep = m }
                    }
                }
            }
            RowLayout {
                Layout.fillWidth: true; spacing: 10
                Item { Layout.fillWidth: true }
                ArqButton { text: "Cancel"; onClicked: pg.resetAsk = false }
                ArqButton {
                    text: "Reset"; primary: true
                    onClicked: {
                        const f = Config.home + "/.config/arqen/config"
                        Quickshell.execDetached(["sh", "-c", "cp \"$1.json\" \"$1.backup-$(date +%F_%H-%M-%S).json\" 2>/dev/null", "sh", f])
                        const kept = Object.keys(pg.resetKeep).filter(k => pg.resetKeep[k])
                        const left = Config.resetAll(kept)
                        pg.resetNote = (kept.length > 0 ? "Kept as you asked: " + kept.map(k => ({ wallpaper: "wallpaper", pinned: "pinned apps", desktop: "desktop", shortcuts: "keyboard shortcuts" })[k]).join(", ") + ". " : "")
                                     + (left.length > 0 ? "These did not reset: " + left.join(", ") + "." : "")
                        pg.resetAsk = false
                        pg.resetDone = true
                    }
                }
            }
        }
    }


    SHeader { text: "Credits" }
    SGroup {
        SRow {
            title: "Made with Claude"
            subtitle: "Written entirely with Claude (Anthropic) as a test. Expect rough edges; use it at your own risk."
            icon: "auto_awesome"
        }
        SRow {
            title: "Built on"
            subtitle: "Hyprland (Vaxry and contributors) and Quickshell"
            icon: "dashboard"
            ArqButton { text: "Hyprland"; onClicked: Qt.openUrlExternally("https://hypr.land") }
            ArqButton { text: "Quickshell"; onClicked: Qt.openUrlExternally("https://quickshell.org") }
        }
        SRow {
            title: "Ideas from"
            subtitle: "DankMaterialShell, HyprMod, skwd-wall and GNOME"
            icon: "lightbulb"
        }
        SRow {
            title: "Looks"
            subtitle: "Papirus icons, Bibata cursor, Material Symbols, Inter, adw-gtk3 and qt6ct"
            icon: "palette"
        }
        SRow {
            title: "Parts it uses"
            subtitle: "NetworkManager, BlueZ, PipeWire, cava, playerctl, grim, slurp, wf-recorder, wtype, wl-clipboard, cliphist, brightnessctl, UPower, ImageMagick and hyprlang2lua. GIF search: GIPHY. Image search: Google Lens"
            icon: "extension"
        }
    }

    SMore {}
}
