import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Widgets
import qs.config
import qs.components
import qs.services
import qs.settings

import Qt.labs.folderlistmodel
// Settings > Appearance: light / dark, the colours, the wallpaper, effects, corners, fonts, icons
// and the cursor.
ColumnLayout {
    id: page
    width: parent.width; spacing: 16
    Component.onCompleted: { Appearance.refreshLists(); Appearance.checkPortal() }

    readonly property bool fromWall: Config.c.accentFromWallpaper
    // which colour the wheel is changing: 0 primary (the accent), 1 secondary, 2 tertiary
    property int role: 0
    readonly property var roleKeys: ["accent", "accent2", "accent3"]
    readonly property var roleNames: ["Primary", "Secondary", "Tertiary"]
    function roleShown(i) { return i === 0 ? Theme.primary : i === 1 ? Theme.secondary : Theme.tertiary }
    // the colour the wheel starts from: what you picked, or what it is now
    function roleSeed(i) {
        if (i === 0) return Config.c.accent
        const v = Config.c[roleKeys[i]] || ""
        return v !== "" ? v : roleShown(i)
    }
    function own(i) { return i === 0 || (Config.c[roleKeys[i]] || "") !== "" }
    function setRole(hex) { if (fromWall) return; Config.c[roleKeys[role]] = hex }

    // ---------- light or dark ----------
    SHeader { text: "Style"; key: "darkMode" }
    SCard {
        Item {
            id: modes
            Layout.fillWidth: true
            implicitHeight: (width - 14) / 2 * 9 / 16 + 34
            Repeater {
                model: [{ dark: false, name: "Light" }, { dark: true, name: "Dark" }]
                delegate: Item {
                    id: mode
                    required property var modelData
                    required property int index
                    readonly property bool on: Config.c.darkMode === modelData.dark
                    readonly property color glassC: modelData.dark ? Qt.rgba(0.07, 0.07, 0.08, 0.86) : Qt.rgba(0.95, 0.95, 0.97, 0.9)
                    width: (modes.width - 14) / 2
                    height: modes.height
                    x: index * (width + 14)
                    // a little desktop in that style: the wallpaper, a card and a panel
                    Rectangle {   // selection ring
                        x: -4; y: -4; width: parent.width + 8; height: shot.height + 8
                        radius: 22; color: "transparent"
                        border.width: mode.on ? 3 : 0; border.color: Theme.primary
                    }
                    ClippingRectangle {
                        id: shot
                        width: parent.width; height: width * 9 / 16
                        radius: 18
                        color: mode.modelData.dark ? "#1a1830" : "#cfd3e6"
                        Image {
                            anchors.fill: parent
                            visible: Config.c.wallpaper !== "" && !/\.(mp4|webm|mkv|mov|m4v|avi)$/i.test(Config.c.wallpaper)
                            source: visible ? "file://" + Config.c.wallpaper : ""
                            sourceSize: Qt.size(720, 405)
                            fillMode: Image.PreserveAspectCrop
                            asynchronous: true
                        }
                        Rectangle {
                            x: parent.width * 0.52; y: parent.height * 0.14
                            width: parent.width * 0.4; height: parent.height * 0.5; radius: 10
                            color: mode.glassC
                            Rectangle { x: 9; y: 10; width: parent.width * 0.6; height: 6; radius: 3; color: mode.modelData.dark ? "#ffffff" : "#111114"; opacity: 0.8 }
                            Rectangle { x: 9; y: 22; width: parent.width * 0.4; height: 6; radius: 3; color: mode.modelData.dark ? "#ffffff" : "#111114"; opacity: 0.4 }
                            Rectangle { x: 9; y: parent.height - 21; width: 24; height: 12; radius: 6; color: Theme.primary }
                            Rectangle { x: 38; y: parent.height - 21; width: 12; height: 12; radius: 6; color: Theme.tertiary }
                        }
                        Rectangle {
                            x: 8; width: parent.width - 16; height: 16; radius: 8
                            y: parent.height - height - 8
                            color: mode.glassC
                            Row {
                                anchors.centerIn: parent; spacing: 4
                                Repeater { model: 4; delegate: Rectangle { width: 8; height: 8; radius: 3; color: index === 1 ? Theme.primary : (mode.modelData.dark ? "#55555f" : "#b4b4c0") } }
                            }
                        }
                    }
                    Row {
                        anchors.horizontalCenter: parent.horizontalCenter
                        y: shot.height + 10
                        spacing: 6
                        Icon { name: mode.modelData.dark ? "dark_mode" : "light_mode"; size: 18; color: mode.on ? Theme.primary : Theme.subtext; anchors.verticalCenter: parent.verticalCenter }
                        DText { text: mode.modelData.name; font.pixelSize: 14; font.weight: mode.on ? Font.DemiBold : Font.Normal; color: mode.on ? Theme.text : Theme.subtext; anchors.verticalCenter: parent.verticalCenter }
                    }
                    MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor; onClicked: Config.c.darkMode = mode.modelData.dark }
                }
            }
        }
    }

    // ---------- the colours ----------
    SHeader { text: "Colours"; key: "accent,accent2,accent3,accentFromWallpaper" }
    SCard {
        spacing: 18
        // header: the three colours, the name, back-to-default, and "from the wallpaper"
        Item {
            Layout.fillWidth: true
            implicitHeight: Math.max(48, hdrText.implicitHeight)
            PaletteMark { id: mark; size: 46; anchors.verticalCenter: parent.verticalCenter }
            Column {
                id: hdrText
                x: mark.width + 14
                width: parent.width - x - hdrRight.width - 14
                anchors.verticalCenter: parent.verticalCenter
                spacing: 2
                DText { text: "Accent colour"; font.pixelSize: 15 }
                DText {
                    width: parent.width; wrapMode: Text.WordWrap; font.pixelSize: 12; color: Theme.subtext
                    text: page.fromWall ? "Taken from the wallpaper (a frame of it for videos). Turn this off to pick your own"
                                        : "Pick the primary colour, and the secondary and tertiary ones if you like"
                }
            }
            Row {
                id: hdrRight
                anchors { right: parent.right; verticalCenter: parent.verticalCenter }
                spacing: 10
                Rectangle {   // back to the default colours
                    readonly property bool changed: !Config.isDefault("accent,accent2,accent3,accentFromWallpaper")
                    width: 30; height: 30; radius: 15
                    anchors.verticalCenter: parent.verticalCenter
                    opacity: changed ? 1 : 0
                    color: arm.containsMouse ? Theme.hover : "transparent"
                    Icon { anchors.centerIn: parent; name: "restart_alt"; size: 19; color: Theme.subtext }
                    MouseArea { id: arm; anchors.fill: parent; enabled: parent.changed; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: { Config.resetKeys("accentFromWallpaper,accent,accent2,accent3"); page.role = 0 } }
                    HoverTip { hovered: arm.containsMouse && parent.changed; text: "Back to the default" }
                }
                DText { text: "From wallpaper"; font.pixelSize: 13; color: Theme.subtext; anchors.verticalCenter: parent.verticalCenter }
                ArqToggle { checked: page.fromWall; onToggled: v => Config.c.accentFromWallpaper = v; anchors.verticalCenter: parent.verticalCenter }
            }
        }

        // the wheel and the three colours; greyed out while the wallpaper decides
        Item {
            id: picker
            Layout.fillWidth: true
            readonly property bool side: width >= 520            // wheel beside the list, or above it
            readonly property real wheelSize: 180
            implicitHeight: side ? Math.max(wheel.height, roles.height) : wheel.height + 18 + roles.height
            enabled: !page.fromWall
            opacity: page.fromWall ? 0.38 : 1
            Behavior on opacity { NumberAnimation { duration: 150 } }

            ColorWheel {
                id: wheel
                size: picker.wheelSize
                width: picker.wheelSize; height: implicitHeight
                x: picker.side ? 0 : (picker.width - width) / 2
                color: page.roleSeed(page.role)
                onPicked: hex => page.setRole(hex)
            }
            Column {
                id: roles
                x: picker.side ? wheel.width + 26 : 0
                y: picker.side ? 0 : wheel.height + 18
                width: picker.width - x
                spacing: 8
                // which colour you are changing
                Repeater {
                    model: 3
                    delegate: Rectangle {
                        id: rc
                        required property int index
                        readonly property bool sel: page.role === index
                        readonly property bool custom: rc.index > 0 && page.own(rc.index) && !page.fromWall
                        width: roles.width
                        height: 54
                        radius: 17
                        color: sel ? Theme.secondaryContainer : (rcm.containsMouse ? Theme.hover : Theme.tile)
                        Behavior on color { ColorAnimation { duration: 120 } }
                        MouseArea { id: rcm; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor; onClicked: page.role = rc.index }
                        Rectangle {
                            id: sw
                            x: 11; anchors.verticalCenter: parent.verticalCenter
                            width: 32; height: 32; radius: 11
                            color: page.roleShown(rc.index); border.width: 1; border.color: Theme.stroke
                        }
                        Column {
                            x: sw.x + sw.width + 12
                            width: parent.width - x - (autoBtn.visible ? autoBtn.width + 20 : 12)
                            anchors.verticalCenter: parent.verticalCenter
                            spacing: 1
                            DText { width: parent.width; elide: Text.ElideRight; text: page.roleNames[rc.index]; font.pixelSize: 14; font.weight: rc.sel ? Font.DemiBold : Font.Normal; color: rc.sel ? Theme.onSecondaryContainer : Theme.text }
                            DText {
                                width: parent.width; elide: Text.ElideRight
                                text: rc.index === 0 ? "Switches, sliders, buttons" : (rc.custom ? "Your own colour" : "Made from the primary")
                                font.pixelSize: 11; color: rc.sel ? Theme.onSecondaryContainer : Theme.subtext; opacity: 0.85
                            }
                        }
                        ArqButton {
                            id: autoBtn
                            visible: rc.custom
                            text: "Automatic"
                            anchors { right: parent.right; rightMargin: 10; verticalCenter: parent.verticalCenter }
                            onClicked: Config.c[page.roleKeys[rc.index]] = ""
                        }
                    }
                }
                // quick picks and an exact colour
                Flow {
                    width: roles.width
                    spacing: 8
                    topPadding: 4
                    Repeater {
                        model: ["#3E91FF", "#7A5AF5", "#2FBF71", "#F2994A", "#F0507A", "#00BCD4", "#E5484D", "#C2A43B"]
                        delegate: Rectangle {
                            required property string modelData
                            width: 30; height: 30; radius: 11; color: modelData
                            border.width: String(page.roleSeed(page.role)).toLowerCase() === modelData.toLowerCase() ? 3 : 0
                            border.color: Theme.text
                            MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor; onClicked: page.setRole(parent.modelData) }
                        }
                    }
                    ArqField {
                        width: 112; implicitHeight: 30
                        placeholder: String(page.roleSeed(page.role)).toUpperCase()
                        onAccepted: if (/^#[0-9a-fA-F]{6}$/.test(text)) { page.setRole(text); text = "" }
                    }
                }
            }
        }
    }

    // ---------- wallpaper ----------
    SHeader { text: "Wallpaper"; key: "wallTransition,wallTransitionMs" }

    // what a picked wallpaper will look like, on a screen like yours (its shape and turn), before it is set
    property string previewPath: ""
    property bool previewVideo: false
    property int previewMon: 0
    readonly property var previewScreen: Monitors.list[Math.min(previewMon, Math.max(0, Monitors.list.length - 1))] ?? null
    readonly property real screenAspect: {
        const m = previewScreen
        if (!m || !m.width || !m.height) return 16 / 9
        const t = (m.transform || 0) % 2 === 1
        return t ? m.height / m.width : m.width / m.height
    }
    function pick(path, video) { previewPath = path; previewVideo = video }
    // a click sets the wallpaper at once
    function apply(path) { previewPath = ""; Config.c.wallpaper = path }

    // Only the pictures near the visible part of the page are loaded (with hundreds of wallpapers, loading and
    // decoding all of them at once is what made the shell slow). The settings page's scroll position is found
    // by walking up to its scrolling area.
    readonly property var flick: { let p = page.parent; while (p && p.contentY === undefined) p = p.parent; return p }
    property real viewTop: 0
    property real viewBottom: 1500
    function updateView() {
        if (!flick || !wbox) return
        const y0 = wbox.mapToItem(flick.contentItem, 0, 0).y
        viewTop = flick.contentY - y0 - 500
        viewBottom = flick.contentY + flick.height - y0 + 500
    }
    Connections {
        target: page.flick
        ignoreUnknownSignals: true
        function onContentYChanged() { page.updateView() }
        function onHeightChanged() { page.updateView() }
    }
    Timer { interval: 400; running: true; onTriggered: page.updateView() }
    SCard {
        visible: page.previewPath !== "" && page.previewPath !== Config.c.wallpaper
        spacing: 12
        RowLayout {
            Layout.fillWidth: true
            spacing: 10
            Icon { name: "preview"; size: 22; color: Theme.tertiary }
            DText { Layout.fillWidth: true; text: "Preview: how it will look on your screen"; font.weight: Font.DemiBold; font.pixelSize: 14; elide: Text.ElideRight }
            SSegmented { visible: Monitors.list.length > 1; model: Monitors.list.map((m, i) => String(i + 1)); currentIndex: page.previewMon; onPicked: i => page.previewMon = i; segW: 44 }
        }
        Item {
            Layout.fillWidth: true
            Layout.preferredHeight: frame.height
            // a screen-shaped frame: as large as fits, never taller than 300 px
            Rectangle {
                id: frame
                readonly property real maxH: 300
                width: Math.min(parent.width, maxH * page.screenAspect)
                height: width / page.screenAspect
                anchors.horizontalCenter: parent.horizontalCenter
                radius: 12
                color: Theme.tile
                border.width: 2; border.color: Theme.stroke
                ClippingRectangle {
                    anchors { fill: parent; margins: 2 }
                    radius: 10
                    color: "black"
                    Image {
                        visible: !page.previewVideo
                        anchors.fill: parent
                        source: page.previewVideo || page.previewPath === "" ? "" : "file://" + page.previewPath
                        sourceSize: Qt.size(900, 900)
                        fillMode: Image.PreserveAspectCrop        // the same as the desktop shows it
                        asynchronous: true
                    }
                    Column {
                        visible: page.previewVideo
                        anchors.centerIn: parent; spacing: 6
                        Icon { anchors.horizontalCenter: parent.horizontalCenter; name: "movie"; size: 36; color: "white" }
                        DText { text: "Video: plays silently on a loop"; color: "white"; font.pixelSize: 12 }
                    }
                    // a hint of the panel
                    Rectangle { anchors { left: parent.left; right: parent.right; bottom: parent.bottom; margins: 6 } height: 8; radius: 4; color: Qt.rgba(0, 0, 0, 0.45) }
                }
            }
        }
        RowLayout {
            Layout.fillWidth: true
            spacing: 8
            DText { Layout.fillWidth: true; color: Theme.subtext; font.pixelSize: 12; elide: Text.ElideMiddle
                    text: page.previewPath.split("/").pop() + (page.previewScreen ? "  ·  screen " + (page.previewMon + 1) + (((page.previewScreen.transform || 0) % 2 === 1) ? " (turned)" : "") : "") }
            ArqButton { text: "Cancel"; onClicked: page.previewPath = "" }
            ArqButton { text: "Set as wallpaper"; primary: true; onClicked: { Config.c.wallpaper = page.previewPath; page.previewPath = "" } }
        }
    }
    SCard {
        Item {
            id: wbox
            Layout.fillWidth: true
            implicitHeight: wgrid.height
            // every picture keeps its own shape (any aspect ratio): rows of one height, widths from the pictures
            readonly property real rowH: width < 420 ? 96 : 130
            onWidthChanged: page.updateView()
            Flow {
                id: wgrid
                width: wbox.width
                spacing: 12
                // the built-in one: the soft gradient
                Item {
                    width: Math.round(wbox.rowH * 16 / 9); height: wbox.rowH
                    readonly property bool sel: Config.c.wallpaper === ""
                    Rectangle { x: -4; y: -4; width: parent.width + 8; height: parent.height + 8; radius: 20; color: "transparent"; border.width: parent.sel ? 3 : 0; border.color: Theme.primary }
                    Rectangle {
                        anchors.fill: parent; radius: 16
                        gradient: Gradient {
                            GradientStop { position: 0.0; color: "#1a1830" }
                            GradientStop { position: 0.55; color: "#5f5a72" }
                            GradientStop { position: 1.0; color: "#14142e" }
                        }
                        DText { anchors.centerIn: parent; text: "Default"; color: "white"; font.weight: Font.Medium }
                    }
                    MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor; onClicked: page.apply("") }
                }
                Repeater {
                    model: FolderListModel {
                        folder: "file://" + Config.home + "/Pictures/Wallpapers"
                        nameFilters: ["*.png", "*.jpg", "*.jpeg", "*.webp", "*.avif", "*.bmp", "*.gif", "*.mp4", "*.webm", "*.mkv", "*.mov", "*.m4v"]
                        showDirs: false
                    }
                    delegate: Item {
                        id: wpi
                        required property string filePath
                        required property string fileName
                        readonly property bool video: /\.(mp4|webm|mkv|mov|m4v)$/i.test(fileName)
                        readonly property bool sel: Config.c.wallpaper === filePath
                        readonly property bool peek: page.previewPath === filePath
                        // one tile shape for all (the layout cannot depend on pictures that are not loaded yet)
                        // near the visible part of the page: its picture is loaded; far from it: let it go
                        readonly property bool near: y + height > page.viewTop && y < page.viewBottom
                        width: Math.round(wbox.rowH * 16 / 9); height: wbox.rowH
                        Rectangle { x: -4; y: -4; width: parent.width + 8; height: parent.height + 8; radius: 20; color: "transparent"; border.width: wpi.sel || wpi.peek ? 3 : 0; border.color: wpi.sel ? Theme.primary : Theme.tertiary }
                        ClippingRectangle {
                            anchors.fill: parent; radius: 16
                            color: Theme.tile
                            // small copies, decoded off the main thread: the page stays smooth
                            Image {
                                id: thumb
                                visible: !wpi.video
                                anchors.fill: parent
                                source: wpi.video || !wpi.near ? "" : "file://" + wpi.filePath
                                sourceSize: Qt.size(400, 0)
                                fillMode: Image.PreserveAspectCrop
                                asynchronous: true
                                opacity: status === Image.Ready ? 1 : 0
                                Behavior on opacity { NumberAnimation { duration: 150 } }
                            }
                            Column {   // videos: no thumbnail, a marked tile with the name
                                visible: wpi.video
                                anchors.centerIn: parent; spacing: 4; width: parent.width - 16
                                Icon { anchors.horizontalCenter: parent.horizontalCenter; name: "movie"; size: 28; color: Theme.subtext }
                                DText { width: parent.width; text: wpi.fileName; font.pixelSize: 11; color: Theme.subtext; elide: Text.ElideMiddle; horizontalAlignment: Text.AlignHCenter }
                            }
                        }
                        MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor; onClicked: page.apply(wpi.filePath) }
                    }
                }
            }
        }
    }
    SGroup {
        SRow { key: "wallTransition"; title: "Transition"; subtitle: "How a new wallpaper comes in"; icon: "animation"
            SChoices { model: ["none", "fade", "slide", "push", "zoom", "wipe", "circle", "blur"]; current: Config.c.wallTransition || "fade"; onPicked: v => Config.c.wallTransition = v } }
        SliderRow { key: "wallTransitionMs"; visible: (Config.c.wallTransition || "fade") !== "none"; title: "Transition speed"; icon: "speed"; suffix: " s"; from: 0.3; to: 2.5; step: 0.1
            value: (Config.c.wallTransitionMs || 900) / 1000; onMoved: v => Config.c.wallTransitionMs = Math.round(v * 10) * 100 }
        SRow { visible: Config.c.showAdvanced; title: "skwd-wall"; subtitle: "A separate wallpaper selector with more pickers and sources (by liixini, MIT). Arqen's own wallpaper stays the one that is drawn and gives the accent colours, so both keep working"; icon: "wallpaper_slideshow"
            ArqButton { text: "Open"; onClicked: Quickshell.execDetached(["sh", "-c", "command -v skwd-wall-v2 >/dev/null && exec skwd-wall-v2 || notify-send -a Arqen 'skwd-wall is not installed' 'Run ./update.sh with ARQEN_SKWD=1 to install it (Fedora)'"]) } }
        SRow { title: "Wallpapers folder"; subtitle: "Pictures and videos in ~/Pictures/Wallpapers. Videos play silently on a loop"; icon: "folder_open"
            ArqButton { text: "Open"; onClicked: QuickSettings.openFolder(Quickshell.env("HOME") + "/Pictures/Wallpapers") } }
    }

    // ---------- effects ----------
    SHeader { text: "Effects"; key: "blur,blurStrength,opacity" }
    SGroup {
        SRow { key: "blur"; title: "Blur"; subtitle: "Frosted glass behind see-through panels, popups, menus and windows. Off: no blur anywhere"; icon: "blur_on"
            ArqToggle { checked: Config.c.blur; onToggled: v => Config.c.blur = v } }
        SliderRow { key: "blurStrength"; visible: Config.c.blur; title: "Blur strength"; icon: "deblur"; from: 1; to: 10; step: 1
            value: Config.c.blurStrength || 5; onMoved: v => Config.c.blurStrength = Math.round(v) }
        SliderRow { key: "opacity"; title: "Opacity"; subtitle: "Panels, pop-ups, the control centre and Settings. 100 % = solid, lower = see-through"; icon: "opacity"; suffix: " %"; factor: 100; from: 0.3; to: 1; step: 0.01
            value: Config.c.opacity; onMoved: v => Config.c.opacity = Math.round(v * 100) / 100 }
    }

    // ---------- corners ----------
    SHeader { text: "Desktop indicator"; key: "wsStyle,wsCustom,gestures" }
    SGroup {
        SRow { key: "wsStyle"; title: "Style"
            subtitle: "Preview:  " + (Workspaces.textStyle ? [1, 2, 3, 4].map(n => Workspaces.label(n)).join("  ") : (Config.c.wsStyle === "boxes" ? "▢ ▢ ▢ ▢" : "• • • •"))
            icon: "workspaces"
            SChoices { model: Workspaces.styles; current: Config.c.wsStyle === "japanese" ? "custom" : Config.c.wsStyle; onPicked: v => Config.c.wsStyle = v } }
        SRow { key: "wsCustom"; visible: Config.c.wsStyle === "custom" || Config.c.wsStyle === "japanese"; title: "Your characters"
            subtitle: "One per desktop, with a space between them: letters, symbols or emoji. Press Enter to use them"
            icon: "edit"
            ArqField {
                width: 280; implicitHeight: 38
                text: Config.c.wsCustom
                placeholder: "一 二 三 四 五"
                onAccepted: { Config.c.wsCustom = text.trim(); if (Config.c.wsStyle === "japanese") Config.c.wsStyle = "custom" }
                anchors.verticalCenter: parent.verticalCenter
            } }
        SRow { key: "gestures"; title: "Touchpad gestures"; subtitle: "Swipe sideways to change desktop, up for the desktop view, down to close it"; icon: "swipe"
            ArqToggle { checked: Config.c.gestures; onToggled: v => Config.c.gestures = v } }
        SRow { key: "gestureFingers"; title: "Fingers for the swipes"; icon: "touch_app"; visible: Config.c.gestures
            subtitle: "Automatic: 3 fingers, or 4 when Hyprland runs hyprland.lua (it usually has its own 3-finger swipes). Pick 3 or 4 to decide yourself"
            SChoices { model: ["Automatic", "3 fingers", "4 fingers"]; current: Config.c.gestureFingers === 3 ? "3 fingers" : Config.c.gestureFingers === 4 ? "4 fingers" : "Automatic"
                onPicked: v => Config.c.gestureFingers = v === "3 fingers" ? 3 : v === "4 fingers" ? 4 : 0 } }
    }

    SHeader { visible: Config.c.showAdvanced; text: "Rounded corners"; key: "screenCorners,panelRadius,radius,tileRadius" }
    SGroup { visible: Config.c.showAdvanced;
        SliderRow { key: "screenCorners"; title: "Screen corners"; subtitle: "Rounds the corners of the screen itself; 0 = off"; icon: "fullscreen"; suffix: " px"; from: 0; to: 40
            value: Config.c.screenCorners || 0; onMoved: v => Config.c.screenCorners = Math.round(v) }
        SliderRow { key: "panelRadius"; title: "Panels"; subtitle: "Floating panels and panel islands; 0 = square"; icon: "rounded_corner"; suffix: " px"; from: 0; to: 40
            value: Config.c.panelRadius; onMoved: v => Config.c.panelRadius = Math.round(v) }
        SliderRow { key: "radius"; title: "Popups and cards"; subtitle: "Launcher, search, menus, the control centre, settings cards"; icon: "rounded_corner"; suffix: " px"; from: 0; to: 40
            value: Config.c.radius; onMoved: v => Config.c.radius = Math.round(v) }
        SliderRow { key: "tileRadius"; title: "Tiles and pills"; subtitle: "Control centre tiles, notifications, the pills on the panel"; icon: "rounded_corner"; suffix: " px"; from: 0; to: 32
            value: Config.c.tileRadius; onMoved: v => Config.c.tileRadius = Math.round(v) }
    }

    SHeader { text: "Fonts"; key: "fontFamily,appFont,appFontSize" }
    SPicker {
        title: "Shell font"; icon: "text_fields"; previewFont: true
        model: Appearance.fonts; current: Config.c.fontFamily; key: "fontFamily"
        onPicked: v => Config.c.fontFamily = v
    }
    SPicker {
        title: "App font"; icon: "font_download"; previewFont: true
        model: Appearance.fonts; current: Config.c.appFont; key: "appFont"
        extra: [{ value: "", label: "Same as the shell (" + Config.c.fontFamily + ")" }]
        onPicked: v => Config.c.appFont = v
    }
    SGroup {
        SliderRow { key: "appFontSize"; title: "App font size"; icon: "format_size"; suffix: " pt"; from: 8; to: 18; step: 1
            value: Config.c.appFontSize; onMoved: v => Config.c.appFontSize = Math.round(v) }
    }

    SHeader { text: "Apps and icons"; key: "gtkTheme,iconTheme" }
    SPicker {
        title: "App theme"; icon: "web_asset"
        model: Appearance.gtkThemes; current: Config.c.gtkTheme; key: "gtkTheme"
        extra: [{ value: "auto", label: "Automatic: adw-gtk3, follows dark / light mode" }]
        onPicked: v => Config.c.gtkTheme = v
    }
    SPicker {
        title: "Icons for apps and the shell"; icon: "interests"
        model: Appearance.iconThemes; current: Config.c.iconTheme; key: "iconTheme"
        extra: [{ value: "", label: "Keep the current one" }]
        onPicked: v => Config.c.iconTheme = v
    }

    SHeader { text: "Cursor"; key: "cursorTheme,cursorSize" }
    SPicker {
        title: "Cursor"; icon: "arrow_selector_tool"
        model: Appearance.cursorThemes; current: Config.c.cursorTheme; key: "cursorTheme"
        extra: [{ value: "", label: "Keep the current one" }]
        onPicked: v => Config.c.cursorTheme = v
    }
    SGroup {
        SliderRow { key: "cursorSize"; title: "Cursor size"; icon: "pan_zoom"; suffix: " px"; from: 16; to: 64; step: 1
            value: Config.c.cursorSize; onMoved: v => Config.c.cursorSize = Math.round(v) }
    }

    SHeader { text: "Other apps"; key: "themeApps" }
    SGroup {
        SRow { key: "themeApps"; title: "Match the shell in other apps"
            subtitle: "GNOME, GTK, Flatpak and Qt apps follow dark / light mode, the accent colour and the choices below. Open apps may need a restart"
            icon: "palette"
            ArqToggle { checked: Config.c.themeApps; onToggled: v => Config.c.themeApps = v } }
        SRow {
            visible: Config.c.showAdvanced
            title: "What apps are told"
            subtitle: Appearance.portalScheme === "none"
                ? "Nothing: the desktop portal is not answering, so Flatpak apps stay light. Run update.sh and send the log it prints"
                : Appearance.portalScheme === "" ? "Checking"
                : (Appearance.portalScheme === "dark" ? "Dark" : "Light") + " (through the desktop portal; installed apps also read it directly)"
            icon: Appearance.portalScheme === "none" ? "error" : "check_circle"
            iconColor: Appearance.portalScheme === "none" ? "#E5484D" : Theme.tile
            LoadingPill { anchors.verticalCenter: parent.verticalCenter; visible: Appearance.portalScheme === "" }
            ArqButton { text: "Check"; onClicked: Appearance.checkPortal() }
        }
        SRow { visible: Config.c.showAdvanced; title: "Check and repair"; subtitle: "Apps stay dark or light? Looks at everything they read, fixes what it can and shows what it found"; icon: "troubleshoot"
            ArqButton { text: "Open"; onClicked: Quickshell.execDetached(["sh", Quickshell.shellDir + "/scripts/run-in-terminal.sh", "Check app colours", "sh " + Quickshell.shellDir + "/scripts/theme-doctor.sh"]) } }
        SRow { visible: Config.c.showAdvanced; title: "Apply again"; subtitle: "If an app did not pick up a change"; icon: "sync"
            ArqButton { text: "Apply"; onClicked: Appearance.apply() }
            ArqButton { text: "Refresh lists"; onClicked: Appearance.refreshLists() } }
    }

    SMore {}
}
