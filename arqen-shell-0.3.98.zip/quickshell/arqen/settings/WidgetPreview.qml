import QtQuick
import Quickshell.Widgets
import qs.config
import qs.components
import qs.services

// A desktop widget drawn exactly as it will look (its size in grid cells, its look and options),
// over your wallpaper, scaled down to fit. Used in Settings > Desktop > Widgets.
ClippingRectangle {
    id: pv
    property var wd: ({ type: "clock" })      // the widget's settings (as in Config.c.desktopWidgets)
    readonly property var cfg: Widgets.cfg(wd)
    readonly property var cells: Widgets.cells(wd)
    // the desktop's grid (modules/Desktop.qml)
    readonly property int cellW: Widgets.cellW
    readonly property int cellH: Widgets.cellH
    readonly property real realW: cells[0] * cellW - 12
    readonly property real realH: cells[1] * cellH - 12
    readonly property real k: Math.min((width - 20) / realW, (height - 20) / realH, 1)
    radius: Config.c.tileRadius
    color: Theme.tile

    // the wallpaper behind (so see-through looks show as they will)
    readonly property string wall: Config.c.wallpaper
    Image {
        anchors.fill: parent
        visible: status === Image.Ready
        source: pv.wall !== "" && !/\.(mp4|webm|mkv|mov|m4v|avi)$/i.test(pv.wall) ? "file://" + pv.wall : ""
        sourceSize.width: 480
        fillMode: Image.PreserveAspectCrop
        asynchronous: true
    }
    Rectangle {
        anchors.fill: parent
        visible: pv.wall === ""
        gradient: Gradient {
            GradientStop { position: 0; color: Theme.primaryContainer }
            GradientStop { position: 1; color: Theme.tertiaryContainer }
        }
    }

    Item {
        width: pv.realW; height: pv.realH
        scale: pv.k
        anchors.centerIn: parent
        Loader {
            id: ld
            anchors.fill: parent
            sourceComponent: pv.wd.type === "clock" ? clockC : pv.wd.type === "calendar" ? calC : pv.wd.type === "note" ? noteC : String(pv.wd.type).startsWith("plugin:") ? pluginC : mediaC
            // Assign after creation rather than binding through Loader.item. Plugin widgets
            // can derive their own properties from cfg; a live Binding here can form a cycle.
            onLoaded: {
                // PluginDesktopWidget already receives cfg through pluginC's declarative
                // binding. Assigning it imperatively here breaks that binding and can create
                // a pid -> cfg -> widget preview feedback loop. Keep imperative setup only for
                // the built-in preview widgets.
                if (ld.item && "cfg" in ld.item && !String(pv.wd.type).startsWith("plugin:"))
                    ld.item.cfg = pv.cfg
            }
        }
    }
    Component { id: clockC; ClockWidget {} }
    Component { id: calC; CalendarWidget {} }
    Component { id: noteC; NoteWidget {} }
    Component { id: mediaC; MediaCard { solid: false } }
    Component { id: pluginC; PluginDesktopWidget { cfg: pv.cfg } }
}
